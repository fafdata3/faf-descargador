# -*- coding: utf-8 -*-
"""Configuración del runner cloud de FAF Stats.

Toda la configuración se lee de variables de entorno (o fichero .env en
el mismo directorio). Nada depende de ningún PC concreto: la ruta de datos
apunta a /data dentro del contenedor (volumen persistente) y el resto de
destinos (R2, Cloudflare Pages, proxies) vienen por entorno.
"""
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


def _env(name, default):
    return os.environ.get(name, default)


def _env_int(name, default):
    try:
        return int(_env(name, str(default)))
    except Exception:
        return default


# ── Rutas dentro del runner ────────────────────────────────────────────────
DATA_DIR   = _env("FAF_DATA_DIR", "/data")          # volumen persistente
BUILD_DIR  = os.path.join(DATA_DIR, "build")        # FAF_Stats.html regenerado
FUENTES_DIR = os.path.join(DATA_DIR, "fuentes")     # txt + json por federación
STATE_FILE = os.path.join(DATA_DIR, "state.json")   # cursors por fuente
STATUS_FILE = os.path.join(DATA_DIR, "sync_status.json")
LIVE_STATUS_FILE = os.path.join(DATA_DIR, "live_sync_status.json")  # volcado en vivo

# Ruta absoluta del proyecto faf-stats (el build_original.mjs trabaja ahí)
FAFSTATS_DIR = _env("FAF_FAFSTATS_DIR", "C:\\Users\\Pablo\\Documents\\Default Project\\faf-stats")

# Ruta del descargador/parser original (fuente única de lógica de parseo)
MONOLITO_PY = _env("FAF_MONOLITO", "C:\\Users\\Pablo\\Desktop\\F\\FUT_stats_fixed.py")

# Carpeta base del corpus en el escritorio (solo usada por seed_cloud.py)
DESKTOP_BASE = _env("FAF_DESKTOP_BASE", "C:\\Users\\Pablo\\Desktop\\F")

# ── Fuentes activas ────────────────────────────────────────────────────────
ALL_SOURCES = ["alava", "euskadi", "gipuzkoa", "bizkaia", "navarra", "rfef", "rioja", "cantabria"]
SOURCES = [s.strip() for s in _env("FAF_SOURCES", ",".join(ALL_SOURCES)).split(",") if s.strip() and s.strip() != "all"]
if not SOURCES:
    SOURCES = ALL_SOURCES

# ── Ritmo de descarga (humanizado, anti-bloqueo) ───────────────────────────
PACING_SEC         = _env_int("FAF_PACING", 10)          # segundos entre actas por fuente
MAX_PER_RUN_SOURCE = _env_int("FAF_MAX_PER_RUN", 60)     # máx actas x fuente y pasada
NEW_WINDOW         = _env_int("FAF_NEW_WINDOW", 400)     # IDs que se miran bajo el cursor
FRONTIER           = _env_int("FAF_FRONTIER", 25)        # IDs NUEVOS por encima del cursor (el feed publica arriba)
RESTART_CHROME_EVERY = _env_int("FAF_RESTART_CHROME_EVERY", 25)
HARD_BLOCK_PAUSE   = (45, 75)                            # pausa tras bloqueo + nueva sesión
CONSEC_EMPTY_PAUSE = _env_int("FAF_EMPTY_PAUSE_EVERY", 12)  # vacías seguidas -> pausa

# Gaps clásicos 1-5 entre IDs (desktop Modo 6). 1 = activado en la pasada.
GAPS_SCAN = _env("FAF_GAPS", "0") in ("1", "true", "yes", "on")

# ── Modo 7 cloud: completar historico hacia abajo (jornadas antiguas) ─────
# Cuando cambian ligas/categorias la numeracion de actas no es correlativa y
# quedan huecos grandes bajo el cursor (p.ej. bizkaia falta ~3680 IDs reales
# bajo 9974661). Con FAF_M7=1 el runner, tras la pasada normal, baja desde el
# pie de la ventana probando ID a ID, ya tengan marcado 'vacias' o no. El
# presupuesto FAF_M7_MAX_PER_RUN es POR EJECUCION (todas las fuentes, lo
# controla el free tier de GitHub Actions).
M7_ENABLED      = _env("FAF_M7", "0") in ("1", "true", "yes", "on")
M7_BATCH        = _env_int("FAF_M7_BATCH", 30)
M7_MAX_PER_RUN  = _env_int("FAF_M7_MAX_PER_RUN", 90)
M7_MAX_VACIOS_CONSEC = _env_int("FAF_M7_VACIOS", 60)  # vacios seguidos -> zona completa
M7_PAUSA_LARGA  = _env_int("FAF_M7_PAUSA_LARGA", 15 * 60)  # pausa fuerte tras 2 bloqueos seguidos (Modo 7 escritorio)

# ── Modo rescue (reprocesar temporadas recientes con el parser corregido) ───
# Vuelve a descargar las actas 2025/2026 presentes en los bundles y las repasa
# con el Parser actual, corrigiendo en origen los marcadores con goles en
# propia que el TXT/fallback asignaba mal (p.ej. San Ignacio 3-3 leído 2-4).
# Se lanza a demanda (workflow_dispatch) con un job por fuente.
RESCUE_TEMPS = [t.strip() for t in _env("FAF_RESC_TEMPS", "2025,2026").split(",") if t.strip()]
RESCUE_MAX_PER_SOURCE = _env_int("FAF_RESC_MAX_PER_SOURCE", 0)  # 0 = sin tope por fuente
RESCUE_SKIP = [s.strip() for s in _env("FAF_RESC_SKIP", "gipuzkoa").split(",") if s.strip()]

# ── Regeneración / deploy ──────────────────────────────────────────────────
REBUILD_MIN  = _env_int("FAF_REBUILD_MIN", 15)           # piso en minutos entre deploys (evita saturar)
REBUILD_AFTER_N = _env_int("FAF_REBUILD_AFTER_N", 1)     # o tras N actas OK nuevas (1 = con cada acta)
DEPLOY_ENABLED = _env("FAF_DEPLOY", "1") in ("1", "true", "yes", "on")

# ── Chrome (dentro del contenedor) ─────────────────────────────────────────
CHROME_BIN      = _env("CHROME_BIN", "")                 # p.ej. /usr/bin/chromium
CHROMEDRIVER    = _env("CHROMEDRIVER", "")               # p.ej. /usr/bin/chromedriver

# ── Nube de almacenamiento (cualquier S3: Oracle Object Storage, R2, AWS) ──
# Compatible con Oracle Cloud Object Storage (endpoint compat) y R2.
S3_ACCESS_KEY = _env("S3_ACCESS_KEY", "") or _env("R2_ACCESS_KEY", "")
S3_SECRET_KEY = _env("S3_SECRET_KEY", "") or _env("R2_SECRET_KEY", "")
S3_BUCKET     = _env("S3_BUCKET", "") or _env("R2_BUCKET", "faf-actas")
R2_ACCOUNT_ID = _env("R2_ACCOUNT_ID", "")
S3_ENDPOINT   = (_env("S3_ENDPOINT", "") or _env("R2_ENDPOINT", "") or
                 (f"https://{R2_ACCOUNT_ID}.r2.cloudflarestorage.com" if R2_ACCOUNT_ID else ""))
S3_REGION     = _env("S3_REGION", "auto")   # 'auto' para R2; región del bucket en B2 (p.ej. us-east-1)
# Verificar persistencia con head_object tras cada upload. Cuesta una lectura
# (Class B) por objeto y B2 lo limita a ~2500/día en free tier. El seed la usa
# a mano; el runner la deja OFF por defecto (el decorre igual sin verificar).
S3_VERIFY     = _env("FAF_S3_VERIFY", "0") in ("1", "true", "yes", "on")
# Web pública del corpus (chunks de actas). Se usa como FALLBACK del bootstrap
# cuando B2 no deja leer (tope Class B): el corpus se siembra desde aquí sin
# consumir transacciones de lectura del bucket.
WEB_BASE      = _env("FAF_WEB_BASE", "https://faf-stats.pages.dev")
# Si el bootstrap no trae NADA de la nube (p.ej. cap B2 agotado), abortar la
# ejecución en vez de sondear durante 30+ min un corpus que no existe.
REQUIRE_BOOTSTRAP = _env("FAF_REQUIRE_BOOTSTRAP", "1") in ("1", "true", "yes", "on")
# Tope de tiempo de toda la pasada (todas las fuentes). GitHub free tier son
# 2000 min/mes; con FAF_RUN_BUDGET_SEC la corrida nunca se dispara.
RUN_BUDGET_SEC = _env_int("FAF_RUN_BUDGET_SEC", 480)
# Si una fuente no logra NINGÚN ok y encadena este nº de errores, se salta
# (evita perder 10 min con una federación caída/inaccesible).
MAX_CONSEC_ERRORS = _env_int("FAF_MAX_CONSEC_ERRORS", 6)

# ── Supabase (espejo de actas) ─────────────────────────────────────────────
# Tabla public.actas: cada acta descargada/parseada se inserta también aquí.
# Solo es un espejo: la web sigue siendo estática (B2 + cron). Sin URL/key
# el runner funciona igual y simplemente no espeja.
SUPABASE_URL        = _env("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = _env("SUPABASE_SERVICE_KEY", "")
SUPABASE_TABLE      = _env("SUPABASE_TABLE", "actas")

# ── Heurística de dónde empezar/continuar (modo PC) ────────────────────────
# Preferir actas de la temporada más reciente (2026-2027) como ancla al
# arrancar sin estado previo → sino el ID más alto del corpus.
PREFER_TEMP         = _env("FAF_PREFER_TEMP", "2026-2027")
# Tras N vacías SEGUIDAS en la fronte, cambiar a buscar huecos de tamaño
# ~3 dentro del rango ya rellenado (lo que el usuario pidió: "todo relleno
# menos justo 3 números") y luego a la ventana descendente.
FRONTIER_EMPTY_STOP  = _env_int("FAF_FRONTIER_EMPTY_STOP", 2)
GAP_HUNT_SIZE        = _env_int("FAF_GAP_HUNT_SIZE", 3)   # huecos que interesan
GAP_HUNT_MAX         = _env_int("FAF_GAP_HUNT_MAX", 60)   # máx candidatos por pasada
# En el PC (modo portable) las fuentes corren en hilos paralelos reales
# (cada una con su Chrome). En GitHub/un contenedor se deja secuencial
# (1 Chrome) para no disparar el uso; el descargador pone FAF_PARALLEL=1.
PARALLEL_SOURCES     = _env("FAF_PARALLEL", "0") in ("1", "true", "yes", "on")

# ── Cloudflare Pages (web) ─────────────────────────────────────────────────
CF_API_TOKEN    = _env("CLOUDFLARE_API_TOKEN", "")
CF_ACCOUNT_ID   = _env("CLOUDFLARE_ACCOUNT_ID", "")
CF_PROJECT_NAME = _env("CF_PROJECT_NAME", "faf-stats")

# ── Proxies (rotación de IP si nos detectan) ───────────────────────────────
# Lista separada por saltos de línea o comas. Formato por línea:
#   http://user:pass@host:puerto   (o https:// / socks5:// según soporte)
def _split_list(raw):
    import re
    return [p.strip() for p in re.split(r"[\n,]+", raw or "") if p.strip()]


PROXY_LIST = _split_list(_env("PROXY_LIST", ""))
PROXY_SWITCH_AFTER_BLOCKS = _env_int("FAF_PROXY_SWITCH_AFTER", 2)  # bloqueos seguidos -> cambiar IP

# Modo ensayo: no descarga, solo imprime qué descargaría
DRY = os.environ.get("FAF_DRY", "0") in ("1", "true", "yes", "on")