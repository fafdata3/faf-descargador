# -*- coding: utf-8 -*-
"""Espejo de actas a Supabase (tabla public.actas).

Cada acta descargada/parseada se inserta también en Supabase mediante la
REST API con la service_role key (upsert idempotente por acta_id). La web
sigue siendo estática; esta tabla es un espejo que en el futuro puede
alimentar una web dinámica sin rehacer el build.

Las filas se acumulan en un buffer y se vuelcan en lotes (bulk upsert) al
final de cada pasada de fuente, para no frenar la descarga acta a acta.

Si falta config.SUPABASE_URL / SUPABASE_SERVICE_KEY no hace nada (no rompe
ningún flujo: los datos siguen viviendo en B2 + web estática).
"""
import json
import threading

import requests

import config

_LOCK = threading.Lock()
_BUFFER = []            # lista de filas pendientes
_BOOTSTRAPPED = False   # evalúa config una sola vez
_CACHE_ENABLED = False

# Envío por lotes: cuántas actas juntar antes de empujar a Supabase.
BULK_SIZE = 200
TIMEOUT = (8, 30)


def _api_url(extra=""):
    return f"{config.SUPABASE_URL.rstrip('/')}/rest/v1/{config.SUPABASE_TABLE}{extra}"


def _headers():
    return {
        "apikey": config.SUPABASE_SERVICE_KEY,
        "Authorization": f"Bearer {config.SUPABASE_SERVICE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates,return=minimal",
    }


_FILA_AVISADA = False   # aviso único si una acta no se puede convertir


def habilitado():
    """True si el espejo está configurado. Se evalúa una vez y se cachea."""
    global _BOOTSTRAPPED, _CACHE_ENABLED
    if not _BOOTSTRAPPED:
        _CACHE_ENABLED = bool(config.SUPABASE_URL and config.SUPABASE_SERVICE_KEY)
        _BOOTSTRAPPED = True
        if _CACHE_ENABLED:
            print(f"[supabase] espejo de actas activo (tabla {config.SUPABASE_TABLE})")
        else:
            print("[supabase] aviso: espejo desactivado (faltan "
                  f"SUPABASE_URL / SUPABASE_SERVICE_KEY en el entorno)")
    return _CACHE_ENABLED


def acta_a_fila(jp):
    """Convierte el JSON parseado de un acta (disco) en fila de la tabla."""
    try:
        with open(jp, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return None
    if not isinstance(d, dict):
        return None
    clave = d.get("acta_id")
    if clave is None and d.get("filename"):
        clave = d["filename"].replace(".txt", "").replace("Acta_", "")
    if clave is None:
        return None
    return {
        "acta_id": str(clave),
        "filename": d.get("filename"),
        "fuente": d.get("fuente"),
        "temporada": d.get("temporada"),
        "jornada": d.get("jornada"),
        "fecha": d.get("fecha"),
        "hora": d.get("hora"),
        "categoria": d.get("categoria"),
        "equipo_local": d.get("equipo_local"),
        "equipo_visitante": d.get("equipo_visitante"),
        "goles_local": d.get("goles_local"),
        "goles_visitante": d.get("goles_visitante"),
        "resultado": d.get("resultado"),
        "estadio": d.get("estadio"),
        "ciudad": d.get("ciudad"),
        "datasets": d,
    }


def enqueue(jp):
    """Añade un acta al buffer. Vuelca automáticamente al llegar a BULK_SIZE.
    Convierte (lectura de disco) YA, para que la limpieza posterior no
    borre el fichero antes de espejarlo."""
    if not habilitado():
        return False
    fila = acta_a_fila(jp)
    if fila is None:
        global _FILA_AVISADA
        if not _FILA_AVISADA:
            _FILA_AVISADA = True
            print(f"[supabase] aviso: acta sin acta_id ni filename (no se espeja): {jp}")
        return False
    with _LOCK:
        _BUFFER.append(fila)
        vaciar = len(_BUFFER) >= BULK_SIZE
    if vaciar:
        flush()
    return True


def _post(filas):
    try:
        r = requests.post(_api_url("?on_conflict=acta_id"), json=filas,
                          headers=_headers(), timeout=TIMEOUT)
        if r.status_code in (200, 201, 204):
            return True
        print(f"[supabase] bulk upsert falló ({r.status_code}): "
              f"{r.text[:200]}")
        return False
    except Exception as e:
        print(f"[supabase] bulk upsert error: {e}")
        return False


def flush():
    """Envía todo lo pendiente (best-effort). Devuelve nº de actas enviadas
    o -1 si el envío falló para re-encolarlas."""
    global _BUFFER
    with _LOCK:
        pendientes = _BUFFER
        _BUFFER = []
    if not pendientes or not habilitado():
        return len(pendientes)
    n = 0
    for i in range(0, len(pendientes), BULK_SIZE):
        lote = pendientes[i:i + BULK_SIZE]
        if _post(lote):
            n += len(lote)
        else:
            # re-encolar lo no enviado para intentarlo en el próximo flush
            with _LOCK:
                _BUFFER = lote + _BUFFER
    info = f"[supabase] {n}/{len(pendientes)} actas espejadas"
    if n < len(pendientes):
        info += " (resto pendiente)"
    print(info)
    return n


def upsert_acta(jp):
    """Compatibilidad: enviar una acta sola (con buffer). No bloqueante."""
    return enqueue(jp)