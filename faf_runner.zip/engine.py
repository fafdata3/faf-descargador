# -*- coding: utf-8 -*-
"""Motor de rastreo silencioso multi-fuente para el runner cloud.

Reutiliza EXACTAMENTE el parser y el flujo de descarga del monólogo de
escritorio (FUT_stats_fixed.py) para que los datos sean idénticos a los del
PC, pero corriendo en cualquier servidor/contenedor 24/7 y escribiendo a
/ruta-de-datos (volumen) + nube (R2/S3).

Cada pasada (batch) por fuente:
  1. ventana de IDs nuevos bajo el "high watermark" (más recientes primero),
  2. huecos clásicos 1-5 entre IDs ya presentes (opcional),
  3. ritmo humanizado (FAF_PACING), reinicio de Chrome periódico,
  4. ante bloqueo: pausa + nueva sesión + rotación de proxy si hay pool,
  5. parseo inmediato con el Parser original + backup a la nube,
  6. registro de estado/incidencias en sync_status.json.
"""
import importlib.util
import json
import os
import random
import re
import threading
import time
import traceback

import requests
from bs4 import BeautifulSoup

import config
import storage
import supabase_espejo
from proxy import ProxyPool

MONOLITO_CACHE = {"mod": None}


def load_monolito():
    """Carga FUT_stats_fixed.py como módulo Python (sin ejecutar su main)."""
    if MONOLITO_CACHE["mod"] is not None:
        return MONOLITO_CACHE["mod"]
    spec = importlib.util.spec_from_file_location("fa_dl", config.MONOLITO_PY)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"No se puede cargar el monolito: {config.MONOLITO_PY}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    # Re-apuntar directorios al runner cloud (nada depende del escritorio)
    mod.HTML_DIR = config.BUILD_DIR
    cloud_fuentes = {}
    for key, cfg in mod.FUENTES.items():
        base = os.path.join(config.FUENTES_DIR, key)
        cloud_cfg = dict(cfg)
        cloud_cfg["output_dir"] = os.path.join(base, "txt")
        cloud_cfg["json_dir"] = os.path.join(base, "json")
        cloud_cfg["empty_file"] = os.path.join(base, "empty_ids.json")
        cloud_cfg["revisadas_file"] = os.path.join(base, "revisadas.json")
        os.makedirs(cloud_cfg["output_dir"], exist_ok=True)
        os.makedirs(cloud_cfg["json_dir"], exist_ok=True)
        cloud_fuentes[key] = cloud_cfg
    mod.FUENTES = cloud_fuentes
    MONOLITO_CACHE["mod"] = mod
    return mod


# ── Temporada preferida (2026/2027) como ancla de arranque ─────────────────
_ANCLA_CACHE = {}  # fkey → id máximo con temporada PREFER_TEMP (cache por pase)

def _ancla_preferida(cfg):
    """Devuelve el mayor acta_id del corpus JSON cuya temporada empieza por
    PREFER_TEMP (p.ej. 2026-2027) o None si no hay ninguno. Se cachea por
    json_dir (un solo barrido de disco por fuente y pase; el daemon puede
    releerlo en pasadas largas, pero el ancla solo importa en el arranque
    y una vez que high ya está ahí el salto no vuelve a disparar)."""
    pref = config.PREFER_TEMP
    if not pref:
        return None
    clave = cfg["json_dir"]
    if clave in _ANCLA_CACHE:
        return _ANCLA_CACHE[clave]
    pat = re.compile(rf"^{re.escape(cfg['prefix'])}(\d+)\.json$")
    mejor = None
    jdir = cfg["json_dir"]
    for fn in os.listdir(jdir):
        m = pat.match(fn)
        if not m:
            continue
        try:
            with open(os.path.join(jdir, fn), encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        if (d or {}).get("temporada", "").startswith(pref):
            iid = int(m.group(1))
            if mejor is None or iid > mejor:
                mejor = iid
    _ANCLA_CACHE[clave] = mejor
    return mejor


# ── Estado compartido ──────────────────────────────────────────────────────
class Status:
    def __init__(self):
        self.sources = {k: {
            "cursor": None, "high": None, "ok": 0, "vacias": 0, "fails": 0,
            "blocks": 0, "last_ok_ts": None, "last_block_ts": None,
            "last_error": None, "ip": "", "paused": 0, "incidents": [],
        } for k in config.ALL_SOURCES}
        self.global_ = {"ok_total": 0, "gaps_found": 0, "deploys": 0,
                        "rebuilds": 0, "started": time.strftime("%Y-%m-%d %H:%M:%S")}

    def to_dict(self, running=True, version=""):
        return {
            "generated": time.strftime("%Y-%m-%d %H:%M:%S"),
            "running": running,
            "version": version,
            "sources": self.sources,
            "global": self.global_,
        }


class StateStore:
    def __init__(self):
        self.data = storage.load_json(config.STATE_FILE, {})
        self.cloud = storage.ObjectStore()
        # En modo paralelo (varias fuentes en hilos) serializa save/upload del
        # state para que el volcado del dict compartido sea coherente.
        self._state_lock = threading.Lock()

    def hidden_key(self, key):
        return self.data.setdefault(key, {"cursor": None})

    def save(self):
        with self._state_lock:
            storage.save_json(config.STATE_FILE, self.data)

    def upload(self, local_path, key, verify=True):
        return self.cloud.upload(local_path, key, verify=verify)


# ── Navegador ──────────────────────────────────────────────────────────────
def create_nav(proxy="", ua_idx=0):
    dl = load_monolito()
    if os.name == "nt" and not config.CHROME_BIN:
        return dl.crear_nav(ua_idx)
    import undetected_chromedriver as uc
    op = uc.ChromeOptions()
    op.add_argument("--headless=new")
    op.add_argument("--no-sandbox")
    op.add_argument("--disable-dev-shm-usage")
    op.add_argument("--disable-gpu")
    op.add_argument("--disable-blink-features=AutomationControlled")
    op.add_argument("--lang=es-ES,es")
    op.add_argument("--window-position=-32000,-32000")
    op.add_argument(f"--window-size={random.choice([1280, 1366])},{random.choice([768, 900])}")
    op.add_argument(f"--user-agent={dl.USER_AGENTS[ua_idx % len(dl.USER_AGENTS)]}")
    if config.CHROME_BIN:
        op.binary_location = config.CHROME_BIN
    if proxy:
        op.add_argument(f"--proxy-server={proxy}")
    kwargs = dict(options=op, use_subprocess=True, headless=True)
    if config.CHROMEDRIVER:
        # setup-chrome/apt pueden dejar el driver sin permiso de ejecución
        # para el usuario del runner: forzar +x antes de que uc lo lance.
        try:
            if os.path.exists(config.CHROMEDRIVER):
                os.chmod(config.CHROMEDRIVER, 0o755)
        except Exception:
            pass
        kwargs["driver_executable_path"] = config.CHROMEDRIVER
    drv = uc.Chrome(**kwargs)
    drv.set_page_load_timeout(dl.PAGE_TIMEOUT)
    return drv


# ═══════════════════════════════════════════════════════════════
#  SESIÓN CHROME (Modo 7 cloud — ritmo escritorio)
# ═══════════════════════════════════════════════════════════════
class SesionChrome:
    """Sesión Chrome real (Selenium) persistente durante la pasada de una fuente.

    Replica la estrategia del Modo 7 del escritorio:
      · descarga con dl.descargar (drv.get + sleeps 0.3–1.3 s/acta),
      · reinicia Chrome cada RESTART_CHROME_EVERY actas (fingerprint nuevo),
      · bloqueo leve → reiniciar Chrome (new fingerprint, sin pausa),
      · 2º bloqueo seguido → pausa larga M7_PAUSA_LARGA (15 min por defecto)
        + reiniciar Chrome,
      · 3º+ bloqueos seguidos → misma pausa cada vez.
    Sin Chrome (p.ej. sin undetected-chromedriver) → degrada a HTTP plano."""
    def __init__(self, dl):
        self.dl = dl
        self.drv = None
        self._fkey = None
        self._cfg = None
        self.actas = 0        # actas OK desde último reinicio
        self._bloqueos = 0    # bloqueos consecutivos (se resetea con OK)
        self._fallos = 0      # errores genéricos consecutivos
        self._ok_total = 0    # total OK en la sesión (para logs)

    def iniciar(self, fkey, cfg):
        """Abre Chrome y calienta con la fuente dada. Devuelve True si OK."""
        self.cerrar()
        self._fkey = fkey
        self._cfg = cfg
        try:
            self.drv = create_nav(proxy="", ua_idx=random.randrange(len(self.dl.USER_AGENTS)))
            self.dl.calentar(self.drv, cfg)
            self.actas = 0
            self._bloqueos = 0
            self._fallos = 0
            return True
        except Exception as e:
            print(f"[{fkey}] Chrome no disponible ({e}); se usa HTTP plano.")
            self.drv = None
            return False

    def cerrar(self):
        if self.drv is not None:
            try:
                self.dl.cerrar(self.drv)
            except Exception:
                pass
            self.drv = None

    def ok(self):
        """Llamar tras cada descarga OK. Reinicia si se alcanza RESTART_CHROME_EVERY."""
        self.actas += 1
        self._ok_total += 1
        self._bloqueos = 0
        self._fallos = 0
        if self.actas >= config.RESTART_CHROME_EVERY:
            print(f"[{self._fkey}] reinicio Chrome cada "
                  f"{config.RESTART_CHROME_EVERY} actas (fingerprint nuevo)")
            self.iniciar(self._fkey, self._cfg)

    def bloqueo(self):
        """Llamar ante bloqueo. Gestiona reinicio/pausa estilo Modo 7."""
        self._bloqueos += 1
        if self._bloqueos == 1:
            # Bloqueo leve: reiniciar Chrome (nuevo fingerprint, sin pausa)
            print(f"[{self._fkey}] bloqueo → Chrome nuevo (sin pausa)")
            self.iniciar(self._fkey, self._cfg)
        else:
            # Bloqueo fuerte (2+ seguidos): pausa larga + reiniciar
            seg = config.M7_PAUSA_LARGA
            print(f"[{self._fkey}] {self._bloqueos} bloqueos seguidos: "
                  f"pausa {seg}s ({seg//60} min) + Chrome nuevo")
            for _ in range(seg):
                time.sleep(1)
            self.iniciar(self._fkey, self._cfg)

    def error(self):
        """Llamar ante error genérico. Tras FALLOS_PAUSA errores seguidos:
        pausa 40-60s (PAUSA_MIN..PAUSA_MAX) + reiniciar Chrome."""
        self._fallos += 1
        if self._fallos >= 3:
            p = random.randint(40, 60)
            print(f"[{self._fkey}] {self._fallos} errores seguidos: "
                  f"pausa {p}s + Chrome nuevo")
            for _ in range(p):
                time.sleep(1)
            self.iniciar(self._fkey, self._cfg)
            self._fallos = 0

    def descargar(self, cod, lbl=0, tot=0):
        """Descarga un acta con dl.descargar (Selenium). Misma firma que bajar_acta."""
        try:
            fp, estado = self.dl.descargar(self.drv, cod, lbl, tot, self._cfg)
        except Exception:
            return None, "error"
        if estado == "ok":
            self.ok()
        elif estado == "bloqueo":
            self.bloqueo()
        elif estado == "vacia":
            pass
        elif estado == "error":
            self.error()
        return fp, estado


# ═══════════════════════════════════════════════════════════════
#  DESCARGA POR DEFECTO (HTTP plano — requests)
# ═══════════════════════════════════════════════════════════════
def bajar_acta(fkey, cfg, cod, dl, sesion=None):
    """Descarga un acta con HTTP plano (requests) o Selenium (sesion).
    Misma semántica que dl.descargar del monolito -> (ruta_txt, estado):
    'ok'/'vacia'/'bloqueo'/'error'.
    Si sesion no es None y tiene Chrome activo → usa dl.descargar (Selenium),
    que es la estrategia real del Modo 7 del escritorio (ritmo 0.3–1.3 s/acta,
    sin bloqueos por fingerprint de requests)."""
    # ── Camino Selenium (Modo 7 cloud) ─────────────────────────
    if sesion is not None and sesion.drv is not None:
        return sesion.descargar(cod, lbl=0, tot=0)

    # ── Camino requests (fallback) ─────────────────────────────
    url = f"{cfg['base_url']}?cod_primaria={cfg['cod_primaria']}&CodActa={cod}"
    out_dir = cfg["output_dir"]
    prefix = cfg["prefix"]
    ua = dl.USER_AGENTS[random.randrange(len(dl.USER_AGENTS))]
    headers = {
        "User-Agent": ua,
        "Accept-Language": "es-ES,es;q=0.9",
        "Accept": "text/html,application/xhtml+xml,*/*",
    }
    cortas = 0
    for intento in range(1, 4):
        try:
            r = requests.get(url, headers=headers,
                             timeout=(10, 30))
            if r.status_code in (403, 429, 503):
                return None, "bloqueo"
            if r.status_code != 200:
                time.sleep(1.5)
                continue
            if len(r.text) == 0 and r.status_code == 200:
                return None, "bloqueo"
            if len(r.text) < 300:
                cortas += 1
                if cortas >= 2:
                    return None, "vacia"
                time.sleep(1.5)
                continue
            soup = BeautifulSoup(r.text, "html.parser")
            body = soup.find("body")
            raw = dl._txt(body) if body is not None else []
            if not raw:
                time.sleep(1)
                continue
            fp = os.path.join(out_dir, f"Acta_{prefix}{cod}.txt")
            with open(fp, "w", encoding="utf-8") as f:
                f.write("\n".join(raw))
            raw_fp = os.path.splitext(fp)[0] + ".html"
            with open(raw_fp, "w", encoding="utf-8") as f:
                f.write(r.text)
            if len(raw) < dl.MIN_LINEAS_REAL:
                print(f"  [~] ({intento}) Acta {prefix}{cod} VACIA ({len(raw)} lineas)")
                return fp, "vacia"
            print(f"  [+] Acta {prefix}{cod} ({len(raw)} lineas)")
            return fp, "ok"
        except (requests.ConnectionError, requests.Timeout):
            time.sleep(2)
    return None, "error"


def ids_en_disco(dl, cfg):
    # En el runner, el corpus restaurado es JSON (bundles), no TXT: aquí "ya
    # tengo la acta" significa fichero JSON presente. El TXT lo escribe la
    # descarga y hace de caché local de la pasada, pero no es la fuente de
    # verdad de "ya descargada".
    pat = re.compile(rf"{re.escape(cfg['prefix'])}(\d+)\.json$")
    out = set()
    for fn in os.listdir(cfg["json_dir"]):
        m = pat.match(fn)
        if m:
            out.add(int(m.group(1)))
    return out


def gaps_clasicos(disco, max_gap=5, limite=25):
    """Huecos 1..max_gap entre IDs presentes. Devuelve lista de IDs a mirar."""
    if not disco:
        return []
    lo, hi = min(disco), max(disco)
    presentes = set(disco)
    huecos = []
    cur = lo
    while cur <= hi:
        if cur not in presentes:
            sig = cur
            while sig <= hi and sig not in presentes:
                sig += 1
            if sig - cur <= max_gap:
                huecos.extend(range(cur, sig))
            cur = sig
        else:
            cur += 1
    return huecos[:limite]


# ════ MODO 7 (cloud) — completar historial hacia abajo ══════════════════
# Copia la lógica del Modo 7 del escritorio para el runner efímero:
#   · tras la pasada normal, baja DESDE DONDE LA VENTANA SE QUEDÓ hacia abajo
#     probando ID a ID (las jornadas antiguas no son correlativas al cambiar
#     ligas: p.ej. bizkaia tiene un hueco real de ~3680 IDs bajo el cursor);
#   · además aterriza en el mínimo de cada categoría que no tiene su J1;
#   · para tras un muro de M7_MAX_VACIOS_CONSEC vacíos seguidos (desierto);
#   · NO reutiliza empty_ids: reintenta lo que el escritorio pudo marcar mal;
#   · persiste cursores por pase/spot en el state (nube), no en disco.
_M7_EXCL_KEYS = ['sala', 'futsal', 'futsala', 'femenina', 'femenino',
                 'femeninas', 'femeninos']


def _m7_excluida(cat):
    c = (cat or '').lower()
    return any(k in c for k in _M7_EXCL_KEYS)


def m7_pendientes(cfg):
    """Categorías de una fuente que todavía no tienen su J1 descargada.
    Devuelve [{cat, min_id, min_jor, cursor}] ordenado por min_id desc."""
    prefix = cfg["prefix"]
    json_dir = cfg["json_dir"]
    pat = re.compile(rf"^{re.escape(prefix)}(\d+)\.json$")
    cats = {}
    for fn in os.listdir(json_dir):
        m = pat.match(fn)
        if not m:
            continue
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        cat = d.get("categoria", "?")
        if _m7_excluida(cat):
            continue
        iid = int(m.group(1))
        jor = d.get("jornada") or 0
        info = cats.get(cat)
        if info is None:
            cats[cat] = {"min_id": iid, "min_jor": jor}
        else:
            if iid < info["min_id"]:
                info["min_id"] = iid
            if jor and (jor < info["min_jor"] or info["min_jor"] == 0):
                info["min_jor"] = jor
    out = []
    for cat, info in cats.items():
        if info["min_jor"] <= 1:
            continue
        out.append({
            "cat": cat, "min_id": info["min_id"],
            "min_jor": info["min_jor"], "cursor": info["min_id"] - 1,
        })
    out.sort(key=lambda x: x["min_id"], reverse=True)
    return out


def m7_scan(fkey, cfg, st, dl, store, pool, ok_acumulado, presupuesto,
            sesion=None, lock=None):
    """Tandas descendentes (histórico). Devuelve el nº de actas OK nuevas.
    Pase A - "deep": sigue bajando desde el pie de la ventana normal.
    Pase B - landings: aterriza en el mínimo de cada categoría sin J1.
    Ambos ignoran empty_ids (el escritorio marcó falsos 'vacia').
    Si sesion (Selenium) está activa → ritmo Modo 7 0.3–1.3 s/acta;
    sin sesión → degrada a HTTP plano (requests) con PACING extra."""

    def _sumar_ok_global():
        if lock is not None:
            with lock:
                ok_acumulado[0] += 1
        else:
            ok_acumulado[0] += 1

    def _gastar_presupuesto():
        if lock is not None:
            with lock:
                presupuesto[0] -= 1
                queda = presupuesto[0]
        else:
            presupuesto[0] -= 1
            queda = presupuesto[0]
        return queda
    def _en_disco(cod):
        return os.path.exists(os.path.join(cfg["json_dir"],
                                          f"{cfg['prefix']}{cod}.json"))

    def _try(cod):
        nonlocal _vacios_consec, ok
        _gastar_presupuesto()
        # Pacing: con Selenium el ritmo ya es humano; sin Selenium → PACING
        if sesion is None or sesion.drv is None:
            time.sleep(random.uniform(config.PACING_SEC * 0.6,
                                      config.PACING_SEC * 1.5))
        ruta, estado = bajar_acta(fkey, cfg, cod, dl, sesion=sesion)
        if estado == "ok":
            ok += 1
            _vacios_consec = 0
            st["ok"] += 1
            st["last_ok_ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
            st["m7_ok"] = st.get("m7_ok", 0) + 1
            _sumar_ok_global()
            try:
                aid2 = re.search(r"Acta_(.+)\.txt",
                                 os.path.basename(ruta)).group(1)
                jp2 = os.path.join(cfg["json_dir"], f"{aid2}.json")
                if not os.path.exists(jp2):
                    dl.Parser(ruta, json_dir=cfg["json_dir"],
                              fuente=fkey).process()
                store.backup_acta(fkey, aid2, ruta,
                                  jp2 if os.path.exists(jp2) else None)
                if os.path.exists(jp2):
                    supabase_espejo.enqueue(jp2)
            except Exception:
                pass
            return 1
        if estado == "vacia":
            dl.mark_empty(cod, {}, cfg["empty_file"])
            if ruta:
                try:
                    os.remove(ruta)
                except Exception:
                    pass
            st["vacias"] += 1
            _vacios_consec += 1
            return 0
        st["fails"] += 1
        if estado == "bloqueo" and pool is not None:
            st["blocks"] += 1
        time.sleep(random.uniform(6, 12))
        return 0

    pendientes = m7_pendientes(cfg)
    m7st = store.data.setdefault(fkey, {}).setdefault("m7", {})
    ok = 0
    _vacios_consec = 0
    tag = f"[{fkey}]"

    # ── Pase A: bajar desde el pie de la ventana normal ──────────────────
    deep = m7st.setdefault("deep", {"cursor": None, "done": False})
    hd = store.data.setdefault(fkey, {"cursor": None, "high": None})
    high = hd.get("high")
    if high is not None and not deep.get("done"):
        start = (deep.get("cursor") if deep.get("cursor") is not None
                 else high - config.NEW_WINDOW - 1)
        print(f"{tag} [M7] deep desde {start} (high {high}, "
              f"presupuesto {presupuesto[0]})")
        cod = start
        while presupuesto[0] > 0 and cod > 0 and _vacios_consec < config.M7_MAX_VACIOS_CONSEC:
            if not _en_disco(cod):
                _try(cod)
            else:
                _vacios_consec = 0
            cod -= 1
        deep["cursor"] = max(cod, 0)
        if _vacios_consec >= config.M7_MAX_VACIOS_CONSEC or cod <= 0:
            deep["done"] = True
        store.save()

    # ── Pase B: landings por categoría sin J1 ─────────────────────────────
    for cat_info in pendientes:
        if presupuesto[0] <= 0:
            break
        cat = cat_info["cat"]
        s = m7st.setdefault(cat, {"cursor": cat_info["cursor"],
                                  "done": False})
        if s.get("done") or s.get("cursor", 0) <= 0:
            continue
        batch = [s["cursor"] - i for i in range(config.M7_BATCH)
                 if s["cursor"] - i > 0]
        pend = [c for c in batch if not _en_disco(c)]
        if not pend:
            s["cursor"] = max(s["cursor"] - config.M7_BATCH, 0)
            store.save()
            continue
        print(f"{tag} [M7] categoría '{cat[:40]}' (falta J1, min J"
              f"{cat_info['min_jor']}) IDs {pend[0]}→{pend[-1]} "
              f"| presupuesto {presupuesto[0]}")
        _vacios_consec = 0
        for cod in pend:
            if presupuesto[0] <= 0:
                break
            _try(cod)
        s["cursor"] = max((min(pend) - 1) if pend
                          else s["cursor"] - config.M7_BATCH, 0)
        if _vacios_consec >= config.M7_MAX_VACIOS_CONSEC:
            s["done"] = True
            print(f"{tag} [M7] '{cat[:40]}': completa (más de "
                  f"{config.M7_MAX_VACIOS_CONSEC} vacíos seguidos).")
        store.save()
    return ok


def scan_source(fkey, status, store, pool, ok_acumulado, presupuesto=None,
                ancla_usuario=None, lock=None):
    """Una pasada de rastreo para una fuente. Devuelve nº actas OK nuevas.
    Si hay Chrome disponible (Selenium), usa sesión Modo 7: ritmo
    0.3–1.3 s/acta, reinicio cada RESTART_CHROME_EVERY actas, bloqueo
    adaptativo. Sin Chrome → degrada a HTTP plano (requests).

    ancla_usuario: si se pasa (acta elegida en el prompt del PC), la pasada
    arranca desde ESE acta hacia arriba (lo que pide el usuario cuando la
    heurística no encuentra nada). lock: opcional para contadores compartidos
    entre hilos (modo paralelo de varias fuentes a la vez)."""
    dl = load_monolito()
    cfg = dl.FUENTES[fkey]
    st = status.sources[fkey]
    prefix = cfg["prefix"]
    out_dir = cfg["output_dir"]
    json_dir = cfg["json_dir"]

    disco = ids_en_disco(dl, cfg)
    hd = store.data.setdefault(fkey, {"cursor": None, "high": None})
    seed = int(cfg["seed_high"]) if cfg.get("seed_high") else None
    high = hd.get("high")

    def _guarda_ok():
        """ok_acumulado[0] y status.global_['ok_total'] son compartidos entre
        fuentes: en modo paralelo (hilos) se protegen con un lock."""
        if lock is not None:
            with lock:
                ok_acumulado[0] += 1
                status.global_["ok_total"] += 1
        else:
            ok_acumulado[0] += 1
            status.global_["ok_total"] += 1

    # Solo se escanea el corpus (potencialmente 60k JSON) si el ancla puede
    # importar: arranque frío (high sin definir) o el corpus restaurado trae
    # actas por ENCIMA del state (p.ej. uploads desde PCs). En pasadas
    # normales del cron con corpus y state al mismo nivel no se barre nada.
    if ancla_usuario:
        ancla_temp = None
    elif high is None or (disco and high < max(disco)):
        ancla_temp = _ancla_preferida(cfg)
    else:
        ancla_temp = None
    if ancla_usuario:
        # Arranque manual: el usuario marcó un acta → empezar desde ahí
        # (fronte barre X, X+1, X+2, ... hacia arriba desde ese acta).
        target = ancla_usuario - 1
        if high is None or high < target:
            print(f"[{fkey}] arranque manual: acta {ancla_usuario} → "
                  f"se rastrea desde ahí hacia arriba")
            high = target
            hd["high"] = high
    elif ancla_temp and (high is None or high < ancla_temp):
        print(f"[{fkey}] temporada {config.PREFER_TEMP} hasta acta "
              f"{ancla_temp}: salto al bloque más nuevo")
        high = ancla_temp
        hd["high"] = high
    elif high is None:
        if disco:
            high = max(disco)
        elif seed:
            # Fuente nueva sin corpus: arrancar desde la primera acta conocida
            # (p.ej. cantabria Cadete) en vez de desde el acta_tope.
            high = seed
        else:
            high = cfg["acta_tope"]
        hd["high"] = high
    elif seed and high < seed:
        # Hay estado previo pero quedó por DEBAJO del bloque que el usuario
        # quiere ahora (cadetes de bizkaia publicados miles de IDs más arriba).
        # Saltar el hueco: el fronte/ventana barren desde el bloque conocido.
        print(f"[{fkey}] high {high} < seed_high {seed}: se salta al bloque nuevo")
        high = seed
        hd["high"] = high
    st["high"] = high
    st["cursor"] = high
    st["ip"] = pool.current_proxy(fkey)

    # ── Sesión Chrome (Modo 7 cloud) ───────────────────────────────────
    # Se crea por fuente y se cierra al final. Con Chrome, el ritmo ya es
    # humano (0.3–1.3 s/acta) por lo que NO se añade PACING extra.
    ses = None if config.DRY else SesionChrome(dl)
    if ses is not None and not ses.iniciar(fkey, cfg):
        ses = None  # sin Chrome → fallback a requests

    # Segmentos de candidatos, en orden (heurística del PC):
    #   1. FRONTE: IDs por ENCIMA del cursor (las federaciones publican arriba).
    #      Si hay FRONTIER_EMPTY_STOP vacías seguidas se CAMBIA de parámetro.
    #   2. HUEcos: rangos casi llenos con solo ~GAP_HUNT_SIZE números sueltos
    #      ("todo relleno menos justo 3 números") → GAP_HUNT_MAX candidatos.
    #   3. VENTANA: descendente bajo el cursor (completa huecos recientes).
    fronte = list(range(high + 1, high + config.FRONTIER + 1))
    huecos = gaps_clasicos(disco, max_gap=config.GAP_HUNT_SIZE,
                           limite=config.GAP_HUNT_MAX) if disco else []
    ventana = list(range(high, max(high - config.NEW_WINDOW, 0) - 1, -1))
    segmentos = [("fronte", fronte), ("huecos", huecos), ("ventana", ventana)]

    empty_ids = dl.load_empty_ids(cfg["empty_file"])
    # Índice cross-fuente: mismo partido (misma fecha+equipos) en otra fuente
    # con MÁS datos -> estos acta_id no se vuelven a descargar.
    alvo_file = os.path.join(os.path.dirname(cfg["empty_file"]),
                             "duplicados_descartadas.json")
    descartadas = dl.load_duplicados(alvo_file)
    ok = 0
    vacias = 0
    consec_errores = 0
    try:
        if config.DRY:
            ok = 0
        for seg_nombre, seg_ids in segmentos:
            if ok >= config.MAX_PER_RUN_SOURCE:
                st["paused"] = 1
                break
            vacias_segmento = 0
            for cod in seg_ids:
                if ok >= config.MAX_PER_RUN_SOURCE:
                    st["paused"] = 1
                    break
                st["paused"] = 0

                txt_path = os.path.join(out_dir, f"Acta_{prefix}{cod}.txt")
                jp = os.path.join(json_dir, f"{prefix}{cod}.json")
                if os.path.exists(jp):
                    continue
                if f"{prefix}{cod}" in descartadas:
                    # Misma fecha+equipos ya cubierta por otra fuente con más datos.
                    # Saltar: tampoco se descarga ni se sube a la web (¿)
                    continue
                if str(cod) in empty_ids and not dl.should_retry_empty(cod, empty_ids):
                    continue
                if config.DRY:
                    print(f"[{fkey}] (dry) pendiente de descargar: {prefix}{cod}")
                    continue

                # Pacing: con Selenium el ritmo ya es humano (dl.descargar hace
                # 0.3–1.3 s/acta); sin Selenium se añade PACING.
                if ses is None:
                    time.sleep(random.uniform(config.PACING_SEC * 0.6,
                                              config.PACING_SEC * 1.5))

                ruta, estado = bajar_acta(fkey, cfg, cod, dl, sesion=ses)

                if estado == "ok":
                    ok += 1
                    vacias_segmento = 0
                    pool.on_ok(fkey)
                    st["ok"] += 1
                    st["last_ok_ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    _guarda_ok()
                    try:
                        aid = re.search(r"Acta_(.+)\.txt", os.path.basename(ruta)).group(1)
                        jp = os.path.join(json_dir, f"{aid}.json")
                        if not os.path.exists(jp):
                            dl.Parser(ruta, json_dir=json_dir, fuente=fkey).process()
                        store.backup_acta(fkey, aid, ruta,
                                          jp if os.path.exists(jp) else None)
                        # Espejo a Supabase (buffer+bulk): cada acta nueva.
                        if os.path.exists(jp):
                            supabase_espejo.enqueue(jp)
                    except Exception:
                        pass
                elif estado == "vacia":
                    dl.mark_empty(cod, empty_ids, cfg["empty_file"])
                    if ruta:
                        try:
                            os.remove(ruta)
                        except Exception:
                            pass
                    vacias += 1
                    vacias_segmento += 1
                    st["vacias"] += 1
                    if vacias % config.CONSEC_EMPTY_PAUSE == 0:
                        _pausa_larga(st)
                    # Heurística del PC: si la frontera tiene N vacías seguidas
                    # se cambia de parámetro (huecos pequeños → ventana) en vez
                    # de seguir sondando IDs muertos hacia arriba.
                    if (seg_nombre == "fronte"
                            and vacias_segmento >= config.FRONTIER_EMPTY_STOP):
                        print(f"[{fkey}] fronte: {vacias_segmento} vacías seguidas"
                              f" → huecos/ventana")
                        break
                else:  # bloqueo / error
                    st["fails"] += 1
                    if estado == "bloqueo":
                        st["blocks"] += 1
                        st["last_block_ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
                        if pool.on_block(fkey, status):
                            st["ip"] = pool.current_proxy(fkey)
                        # Con sesión Selenium el bloqueo ya fue gestionado por
                        # SesionChrome (reinicio leve o pausa M7 larga). Sin
                        # sesión (HTTP plano) sí se aplica backoff largo.
                        if ses is None:
                            _pausa_larga(st)
                    else:
                        st["last_error"] = (estado or "")
                        time.sleep(random.uniform(6, 12))
                    if ok == 0:
                        consec_errores += 1
                        print(f"[{fkey}] {consec_errores} errores seguidos sin "
                              f"ningún OK; si llega a {config.MAX_CONSEC_ERRORS} "
                              f"se salta la fuente esta pasada.")
                        if consec_errores >= config.MAX_CONSEC_ERRORS:
                            print(f"[{fkey}] fuente inaccesible, se salta "
                                  f"({config.MAX_CONSEC_ERRORS} errores seguidos).")
                            break
                    else:
                        consec_errores = 0

                # Avanzar el high-watermark: si este ID ya consta (descargado o
                # en el corpus JSON restaurado), el feed ha publicado hasta aquí.
                # Al subir el high, la próxima pasada mirará más arriba.
                if os.path.exists(jp):
                    high = max(high, cod)
                    hd["high"] = high
                st["cursor"] = hd.get("high")

        # Después de los segmentos: volcar lo pendiente a Supabase (best-effort).
        supabase_espejo.flush()

        # ── MODO 7 cloud: rellenar histórico hacia abajo (jornadas antiguas) ──
        # Cada pasada baja una tanda desde el pie de la ventana y desde el
        # mínimo de cada categoría sin J1, tapando los huecos grandes que
        # dejan los cambios de liga.
        if config.M7_ENABLED and not config.DRY and presupuesto and presupuesto[0] > 0:
            ok += m7_scan(fkey, cfg, st, dl, store, pool, ok_acumulado,
                          presupuesto, sesion=ses, lock=lock)
        supabase_espejo.flush()
    except Exception:
        st["last_error"] = traceback.format_exc().splitlines()[-1]
        print(f"[{fkey}] ERROR crítico:\n{traceback.format_exc()}")
    finally:
        try:
            supabase_espejo.flush()
        except Exception:
            pass
        if ses is not None:
            ses.cerrar()

    # Persistir a la nube lo que cambió en la pasada (el runner es efímero:
    # en GitHub Actions la máquina desaparece al terminar).
    if store.cloud.cloud_enabled:
        # empty_ids/revisadas (cambian al marcar huecos vacíos) y el bundle
        # comprimido si hubo actas nuevas de esta fuente.
        for (fichero, clave) in (
                (cfg["empty_file"], f"fuentes/{fkey}/empty_ids.json"),
                (cfg["revisadas_file"], f"fuentes/{fkey}/revisadas.json"),
                (alvo_file, f"fuentes/{fkey}/duplicados_descartadas.json")):
            if os.path.exists(fichero):
                store.upload(fichero, clave, verify=False)
        store.upload(config.STATE_FILE, "state.json")
        if ok > 0:
            try:
                os.makedirs(config.BUILD_DIR, exist_ok=True)
                bundle = os.path.join(config.BUILD_DIR, f"bundle_{fkey}.tar.gz")
                if store.cloud.tar_bundle(fkey, bundle):
                    if store.cloud.upload(bundle, store.cloud.bundle_key(fkey)):
                        print(f"[{fkey}] bundle actualizado en la nube")
                try:
                    os.remove(bundle)
                except Exception:
                    pass
            except Exception:
                traceback.print_exc()
    return ok


def maybe_proxy(driver):
    return driver


def _pausa_larga(st):
    seg = random.randint(*config.HARD_BLOCK_PAUSE)
    print(f"[pause] {seg}s (anti-bloqueo)")
    st["paused"] = seg
    for _ in range(seg):
        time.sleep(1)
    st["paused"] = 0


def get_run_id():
    """ID de la ejecución actual (GitHub Actions) o 'local' fuera de GH."""
    rid = os.environ.get("GITHUB_RUN_ID")
    return rid if rid else "local"


def pub_live(status, store, version=""):
    """Publica el progreso en B2 mientras la pasada sigue corriendo, para
    poder revisar en vivo una ejecución (sin esperar a que acabe). Escribe
    live/sync_status.json (punto vivo) y una copia por run. Lo lee ver.py."""
    if not store.cloud.cloud_enabled:
        return
    blob = status.to_dict(running=True, version=version)
    blob["run_id"] = get_run_id()
    for fkey, src in blob["sources"].items():
        m7 = store.data.get(fkey, {}).get("m7")
        if m7:
            src["m7"] = m7
    storage.save_json(config.LIVE_STATUS_FILE, blob)
    store.upload(config.LIVE_STATUS_FILE, "live/sync_status.json", verify=False)
    store.upload(config.LIVE_STATUS_FILE,
                 f"live/sync_status_{blob['run_id']}.json", verify=False)


def batch(status, store, pool, ok_acumulado, anclas=None):
    """Pasada sobre todas las fuentes activas.

    Con config.PARALLEL_SOURCES activado (desde el PC) cada fuente corre en
    un hilo real con SU propia sesión Chrome/IP, de modo que algo que tarde
    en una federación (alava) no bloquea a las demás (euskadi, gipuzkoa, ...).
    En GitHub/contenedor se mantiene 1 Chrome secuencial (evita disparar uso).

    anclas: dict {fkey: acta_id} con actas elegidas por el usuario en el
    prompt del descargador → scan_source arranca desde cada una hacia arriba.
    """
    dl = load_monolito()
    presupuesto = [config.M7_MAX_PER_RUN]
    pub_live(status, store)
    t0 = time.time()
    activas = [f for f in config.SOURCES if f in dl.FUENTES]

    if config.PARALLEL_SOURCES and len(activas) > 1:
        lock = threading.Lock()
        def _pasada(fkey):
            print(f"[{fkey}] pasada iniciada "
                  f"(high={status.sources[fkey].get('high')})")
            try:
                scan_source(fkey, status, store, pool, ok_acumulado,
                            presupuesto=presupuesto,
                            ancla_usuario=(anclas or {}).get(fkey),
                            lock=lock)
            except Exception:
                print(f"[{fkey}] fallo inesperado de la pasada.")
                traceback.print_exc()
        hilos = [threading.Thread(target=_pasada, args=(f,), name=f)
                 for f in activas]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()
        with lock:
            store.save()
        for fkey in activas:
            status.sources[fkey]["ip"] = pool.current_proxy(fkey)
        pub_live(status, store)
        return

    for fkey in activas:
        if (time.time() - t0) >= config.RUN_BUDGET_SEC:
            print(f"[{fkey}] presupuesto de tiempo agotado "
                  f"({config.RUN_BUDGET_SEC}s), se salta el resto.")
            break
        print(f"[{fkey}] pasada iniciada (high={status.sources[fkey].get('high')})")
        try:
            scan_source(fkey, status, store, pool, ok_acumulado,
                        presupuesto=presupuesto,
                        ancla_usuario=(anclas or {}).get(fkey))
        except Exception:
            print(f"[{fkey}] fallo inesperado de la pasada.")
            traceback.print_exc()
        store.save()
        status.sources[fkey]["ip"] = pool.current_proxy(fkey)
        pub_live(status, store)


def publish_status(status, store, version="", running=True):
    status.sources = {k: status.sources.get(k, {}) for k in config.ALL_SOURCES}
    blob = status.to_dict(running=running, version=version)
    storage.save_json(config.STATUS_FILE, blob)
    store.save()
    store.upload(config.STATUS_FILE, "sync_status.json")
    return blob