# -*- coding: utf-8 -*-
"""Pool de proxies para rotar la IP de salida si una fuente nos bloquea.

Cuando un sistema anti-bot detecta el ritmo o la IP del runner (IP de
datacenter), basta cambiar la IP de salida. Este módulo:
  - mantiene la IP actual por fuente,
  - tras FAF_PROXY_SWITCH_AFTER bloqueos seguidos: pasa a la siguiente IP,
  - registra incidencias (fuente, IP, motivo, momento) en el status.
"""
import time

import config


class ProxyPool:
    def __init__(self):
        self.pool = config.PROXY_LIST
        self._idx = 0
        self._by_source = {}        # fuente -> índice de IP en uso
        self._blocks_by_source = {} # fuente -> bloqueos seguidos con esta IP

    @property
    def enabled(self):
        return len(self.pool) > 0

    def current_proxy(self, fuente_key):
        """Devuelve la IP activa para una fuente ("" = sin proxy)."""
        if not self.enabled:
            return ""
        idx = self._by_source.get(fuente_key, self._idx)
        return self.pool[idx % len(self.pool)]

    def on_ok(self, fuente_key):
        self._blocks_by_source[fuente_key] = 0

    def on_block(self, fuente_key, status):
        """Registra un bloqueo; si acumula suficientes, rota la IP."""
        self._blocks_by_source[fuente_key] = self._blocks_by_source.get(fuente_key, 0) + 1
        n = self._blocks_by_source[fuente_key]
        if n >= config.PROXY_SWITCH_AFTER_BLOCKS:
            old = self.current_proxy(fuente_key)
            if self.enabled:
                self._by_source[fuente_key] = self._by_source.get(fuente_key, self._idx) + 1
                nuevo = self.current_proxy(fuente_key)
                self._blocks_by_source[fuente_key] = 0
                msg = f"bloqueo x{n} con {old or 'IP directa'} → IP {nuevo or 'directa'}"
            else:
                self._by_source[fuente_key] = 0
                msg = f"bloqueo x{n} sin pool de proxies (se mantiene IP directa + backoff)"
            self._add_incident(status, fuente_key, "proxy", msg)
            return True
        return False

    def _add_incident(self, status, fuente_key, tipo, detalle):
        st = status.sources[fuente_key]
        st["incidents"].append({
            "tipo": tipo, "detalle": detalle,
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ip": self.current_proxy(fuente_key),
        })
        # mantener solo las últimas 25 incidencias para no inflar el status
        st["incidents"] = st["incidents"][-25:]