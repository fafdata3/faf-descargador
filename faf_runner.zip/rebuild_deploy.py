# -*- coding: utf-8 -*-
"""Regenera el HTML maestro, replica al sitio estático y despliega a Pages.

Flujo (todo en la nube, sin depender del escritorio):
  1. genera_html() del monolito -> BUILD_DIR/FAF_Stats.html
     (usa las fuentes cloud del runner: mismos TXT/JSON que el PC)
  2. node build_original.mjs (env ORIG=...)  -> FAFSTATS_DIR/site
  3. copia data/sync_status.json al site
  4. wrangler pages deploy (tokens por entorno) -> faf-stats.pages.dev
"""
import os
import re
import shutil
import subprocess
import time
import zipfile

import config
import engine
import storage
from engine import load_monolito


def extraer_version_index(html_path):
    try:
        with open(html_path, encoding="utf-8") as f:
            c = f.read()
        m = re.search(r'VER\s*=\s*"?(\d+)"?', c) or \
            re.search(r'id="VER"\s*>\s*(\d+)', c)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ""


def _run(cmd, cwd=None, env=None, timeout=1800):
    print(">", " ".join(cmd) if isinstance(cmd, list) else cmd)
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    proc = subprocess.run(cmd, cwd=cwd, env=full_env, capture_output=True,
                          text=True, timeout=timeout)
    if proc.stdout:
        print(proc.stdout[-3000:])
    if proc.stderr:
        print("STDERR:", proc.stderr[-2000:])
    return proc.returncode, proc.stdout


def regenerar_html():
    """Regenera BUILD_DIR/FAF_Stats.html con todos los datos actuales."""
    dl = load_monolito()
    os.makedirs(config.BUILD_DIR, exist_ok=True)
    dl.HTML_DIR = config.BUILD_DIR
    html = os.path.join(config.BUILD_DIR, "FAF_Stats.html")
    if os.path.exists(html):
        os.remove(html)
    print("[rebuild] generando FAF_Stats.html (monolito)...")
    dl.generar_html()
    return html if os.path.exists(html) else None


def build_site():
    """Replica a FAFSTATS_DIR/site con build_original.mjs."""
    if not os.path.isdir(config.FAFSTATS_DIR):
        raise RuntimeError(f"FAF_FAFSTATS_DIR no existe: {config.FAFSTATS_DIR}")
    os.makedirs(config.FAFSTATS_DIR, exist_ok=True)
    code, out = _run(["node", "build_original.mjs"], cwd=config.FAFSTATS_DIR,
                     env={"ORIG": os.path.join(config.BUILD_DIR, "FAF_Stats.html")})
    if code != 0:
        raise RuntimeError("build_original.mjs falló")
    # publicar el estado dentro del sitio (lo lee la web)
    site_data = os.path.join(config.FAFSTATS_DIR, "site", "data")
    os.makedirs(site_data, exist_ok=True)
    if os.path.exists(config.STATUS_FILE):
        shutil.copyfile(config.STATUS_FILE,
                        os.path.join(site_data, "sync_status.json"))
    _publicar_descargador(site_data)
    _inyectar_boton_descargar(os.path.join(config.FAFSTATS_DIR, "site"))
    return os.path.join(config.FAFSTATS_DIR, "site")


def _repo_root():
    """Raíz del proyecto runner (donde está sync_all.py)."""
    return os.path.dirname(os.path.abspath(__file__))


def _publicar_descargador(site_data):
    """Publica en la web el descargador portátil para PC:
      data/faf_runner.zip  -> zip con el runner (sync_all + engine + monolito)
      data/faf_descarga.py -> script autocontenido que instala y ejecuta
    El PC descarga faf_runner.zip desde faf-stats.pages.dev, lo extrae junto al
    faf_descarga.py y lanza sync_all --portable (descarga con Chrome real/IP
    residencial, sube el bundle a S3 y el cron de GH despliega la web)."""
    root = _repo_root()
    blobs = os.path.join(root, "blobs")
    monolito = os.path.join(blobs, "FUT_stats_fixed.py")
    archivos = ["sync_all.py", "engine.py", "config.py", "storage.py",
                "proxy.py", "rebuild_deploy.py", "requirements.txt",
                "supabase_espejo.py"]
    try:
        with zipfile.ZipFile(os.path.join(site_data, "faf_runner.zip"), "w",
                             zipfile.ZIP_DEFLATED) as zf:
            for a in archivos:
                p = os.path.join(root, a)
                if os.path.exists(p):
                    zf.write(p, a)
            if os.path.exists(monolito):
                zf.write(monolito, "blobs/FUT_stats_fixed.py")
        desc = os.path.join(root, "faf_descarga.py")
        if os.path.exists(desc):
            shutil.copyfile(desc, os.path.join(site_data, "faf_descarga.py"))
        print(f"[descargador] web: faf_runner.zip + faf_descarga.py publicados")
    except Exception as e:
        print(f"[descargador] no se pudo publicar el descargador: {e}")


def _inyectar_boton_descargar(site):
    """Añade un botón en la web para descargar el descargador de PC."""
    idx = os.path.join(site, "index.html")
    if not os.path.exists(idx):
        return
    boton = ("</body>"
             "<script>"
             "(function(){"
             "try{var d=document.createElement('div');"
             "d.style.cssText='position:fixed;right:14px;bottom:14px;z-index:99999;"
             "background:#0b7285;color:#fff;padding:10px 14px;border-radius:10px;"
             "font:600 13px/1.1 system-ui;box-shadow:0 2px 8px rgba(0,0,0,.35);"
             "cursor:pointer';"
             "d.innerHTML='⬇️ Descargar<br>para PC';"
             "d.onclick=function(){window.open('data/faf_descarga.py','_blank')};"
             "document.body.appendChild(d);"
             "}catch(e){}})();"
             "</script>"
             "</body>")
    try:
        with open(idx, encoding="utf-8") as f:
            html = f.read()
        if "faf_descarga" in html:
            return
        with open(idx, "w", encoding="utf-8") as f:
            f.write(html.replace("</body>", boton, 1))
        print("[descargador] botón 'Descargar para PC' inyectado en index.html")
    except Exception as e:
        print(f"[descargador] no se pudo inyectar el botón: {e}")


def deploy_pages():
    """wrangler pages deploy con tokens de Cloudflare (por entorno)."""
    if not (config.CF_API_TOKEN and config.CF_ACCOUNT_ID):
        print("[deploy] faltan tokens CF: se omite el despliegue.")
        return None
    env = {
        "CLOUDFLARE_API_TOKEN": config.CF_API_TOKEN,
        "CLOUDFLARE_ACCOUNT_ID": config.CF_ACCOUNT_ID,
    }
    site = os.path.join(config.FAFSTATS_DIR, "site")
    code, out = _run(["npx", "--yes", "wrangler", "pages", "deploy", site,
                      "--project-name", config.CF_PROJECT_NAME, "--branch", "main"],
                     cwd=config.FAFSTATS_DIR, env=env, timeout=3600)
    if code != 0:
        raise RuntimeError("wrangler deploy falló")
    m = re.search(r"https://[\w-]+\.faf-stats\.pages\.dev", out)
    return m.group(0) if m else "https://faf-stats.pages.dev"


def regenerar_y_desplegar(status, store, version="", force=False):
    """Pipeline completo nube: regenerar -> build -> deploy. Devuelve (ver, url)."""
    if not force and not (
        config.DEPLOY_ENABLED and (config.CF_API_TOKEN and config.CF_ACCOUNT_ID)
    ):
        print("[rebuild] sin tokens CF / despliegue desactivado; solo build local.")
    t0 = time.time()
    html = regenerar_html()
    if not html:
        print("[rebuild] no se generó HTML; abortando.")
        return "", ""
    site = build_site()
    status.global_["rebuilds"] += 1
    ver = extraer_version_index(os.path.join(site, "index.html"))
    engine.publish_status(status, store, version=ver or version, running=True)
    url = ""
    if config.DEPLOY_ENABLED and config.CF_API_TOKEN:
        url = deploy_pages()
        status.global_["deploys"] += 1
    print(f"[rebuild] ok en {int(time.time()-t0)}s | ver={ver} | url={url}")
    return ver, url