# -*- coding: utf-8 -*-
"""
FAF Stats -- Pipeline completo
  Descarga actas, detecta vacias, parsea y genera HTML en F/2/FAF_Stats.html
"""
import sys, os, subprocess, traceback

def preparar_entorno():
    print("--- VERIFICANDO ENTORNO ---")
    try:
        import undetected_chromedriver, selenium
        from bs4 import BeautifulSoup
        # python 3.12+ quita distutils (lo necesita undetected-chromedriver)
        import distutils  # noqa: F401
        print("[+] Librerias listas.\n")
    except ImportError:
        print("[!] Instalando librerias...")
        subprocess.check_call([sys.executable, "-m", "pip", "install",
                               "undetected-chromedriver", "selenium",
                               "beautifulsoup4", "setuptools", "wheel"])
        print("[+] OK\n")
preparar_entorno()

import re, json, time, random, base64
from bs4 import BeautifulSoup, NavigableString, Tag
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
import undetected_chromedriver as uc
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import WebDriverException, TimeoutException

# ═══════════════════════════════════════════════════════════════
#  CONFIGURACION
# ═══════════════════════════════════════════════════════════════
ACTA_TOPE        = 9990198   # ID más reciente conocido
ACTAS_POR_RUN    = 50        # Máx. actas nuevas por ejecución
MIN_LINEAS_REAL  = 80        # Menos de esto → acta vacía/sin datos

CHROME_VERSION   = 149
PAGE_TIMEOUT     = 12
FALLOS_PAUSA     = 3
PAUSA_MIN        = 40
PAUSA_MAX        = 60
REINICIAR_CADA   = 25

# ── Anti-bloqueo reforzado (Modo 2 Manual y Modo 12 Tablas cruzadas) ──────
# Estos modos se usan a demanda con IDs concretos y suelen ser donde más se
# nota un bloqueo por IP, así que llevan su propio ritmo, más conservador,
# sin tocar el comportamiento de los demás modos (6/7/9...).
DELAY_ENTRE_PETICIONES = (1.8, 4.2)   # pausa "humana" ANTES de cada petición
REINICIAR_CADA_SUAVE   = 15           # sesión de Chrome más corta -> fingerprint nuevo más a menudo
PAUSA_TOPE_BLOQUEO     = 600          # tope de pausa tras escaladas sucesivas (10 min)
RACHAS_MAX_BLOQUEO     = 4            # tras esto, mejor parar que seguir insistiendo
PAUSA_ENTRE_LOTES_TC   = (14, 28)     # pausa ENTRE LOTES en el Modo 12 (re-descarga de discrepancias)

# ── Ritmo "humano" específico del Modo 6 (Huecos) ─────────────────────────
# La descarga de TODOS los huecos de TODAS las fuentes en una sola tanda es
# justo el patrón que más llama la atención a un sistema anti-bot (muchas
# peticiones seguidas, siempre la misma IP). Estas constantes marcan un
# ritmo deliberadamente más lento y variable que el resto de modos.
M6_DELAY_ENTRE_ACTAS   = (3.5, 7.0)   # pausa "humana" entre cada descarga individual
M6_REINICIAR_CADA      = 12           # sesión de Chrome más corta -> fingerprint nuevo más a menudo
M6_PAUSA_LARGA_CADA    = 40           # cada N actas, una pausa larga "de descanso"
M6_PAUSA_LARGA_RANGO   = (45, 90)     # duración de esa pausa larga (segundos)
M6_PAUSA_ENTRE_FUENTES = (20, 40)     # pausa al pasar de una fuente a otra (cambia de dominio)

# ── Modo 6 sub-modo 2: Rastreo de zonas inexploradas ──────────────────────
# Cuando ya no quedan huecos clásicos (1-5 IDs), este sub-modo busca actas
# en los grandes vacíos del ID-space (e.g. entre la 36 y la 270).
# Por cada zona lanza sondas aleatorias espaciadas M6_PASO_SONDEO IDs;
# si encuentra una acta válida, baja secuencialmente hasta topar con
# M6_VACIAS_STOP_EXP vacías seguidas, luego vuelve al sondeo.
M6_PASO_SONDEO     = 150   # IDs entre puntos de sondeo dentro de cada zona inexplorada
M6_UMBRAL_GAP_EXP  = 20    # gap mínimo (IDs) para considerar una zona como "inexplorada"
M6_VACIAS_STOP_EXP = 3     # vacías consecutivas bajando para abandonar esa zona

# ── Modo 6: fuentes excluidas temporalmente ───────────────────────────────
# Gipuzkoa tiene un error pendiente de resolver -> el Modo 6 (huecos clásicos
# Y zonas inexploradas) no la toca hasta que se arregle. Bizkaia se re-habilitó
# cuando su web pasó a fvf-bff.eus (la antigua fcbf.eus ya no resuelve DNS).
# El resto de modos (2, 3, 3.1, 12...) siguen tratándolas con normalidad;
# esta exclusión es solo dentro del Modo 6.
M6_FUENTES_EXCLUIDAS = {"gipuzkoa"}


def _ts():
    """Hora exacta HH:MM:SS para cada línea de log (no fecha completa, solo hora,
    que es lo único relevante para diagnosticar bloqueos dentro de una misma sesión)."""
    return time.strftime("%H:%M:%S")


# ── Color en CMD para mensajes de bloqueo (solo visual, no cambia nada más) ──
# Windows necesita "activar" el soporte ANSI en la consola antes de que los
# códigos de color funcionen (cmd.exe clásico los ignora si no se hace esto).
def _activar_colores_consola():
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
        except Exception:
            pass
_activar_colores_consola()

_ROJO   = "\033[91m"
_RESET  = "\033[0m"

def _rojo(msg):
    """Envuelve un mensaje en rojo para la consola. Solo estética: el texto
    en sí no cambia, así que copiar/pegar el log sigue funcionando igual."""
    return f"{_ROJO}{msg}{_RESET}"


def log6(msg, rojo=False):
    """Log con timestamp para el Modo 6. Todo lo que imprime esta función es lo
    que el usuario puede copiar/pegar para que se revise un posible bloqueo:
    a qué hora pasó cada cosa, cuánto se esperó y por qué.
    rojo=True resalta la línea en rojo en la consola (solo para avisos de
    bloqueo; no cambia el ritmo, los reintentos ni nada de la lógica)."""
    linea = f"  [{_ts()}] {msg}"
    print(_rojo(linea) if rojo else linea)

BASE_DIR = r"C:\Users\Pablo\Desktop\F"
HTML_DIR = os.path.join(BASE_DIR, "2")

# ── Configuración por fuente ──────────────────────────────────────────────────
FUENTES = {
    "alava": {
        "label":       "Álava (FAF)",
        "base_url":    "https://www.faf-aff.eus/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.faf-aff.eus/",
        "warm_cal":    "https://www.faf-aff.eus/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   ACTA_TOPE,
        "prefix":      "",          # sin prefijo: Acta_NNNNNN.txt  /  NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "ALAVA"),
        "json_dir":    os.path.join(BASE_DIR, "ALAVA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "ALAVA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "ALAVA", "tarjetas_revisadas.json"),
    },
    "euskadi": {
        "label":       "Euskadi (EuskadiFutbol)",
        "base_url":    "https://www.euskadifutbol.eus/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.euskadifutbol.eus/",
        "warm_cal":    "https://www.euskadifutbol.eus/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        "prefix":      "E_",        # Acta_E_NNNNNN.txt  /  E_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "EUSKADI"),
        "json_dir":    os.path.join(BASE_DIR, "EUSKADI", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "EUSKADI", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "EUSKADI", "tarjetas_revisadas.json"),
    },
    "gipuzkoa": {
        "label":       "Gipuzkoa (RFGF)",
        "base_url":    "https://www.gipuzkoafutbola.eus/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.gipuzkoafutbola.eus/",
        "warm_cal":    "https://www.gipuzkoafutbola.eus/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        "prefix":      "G_",        # Acta_G_NNNNNN.txt  /  G_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "GIPUZKOA"),
        "json_dir":    os.path.join(BASE_DIR, "GIPUZKOA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "GIPUZKOA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "GIPUZKOA", "tarjetas_revisadas.json"),
    },
    "bizkaia": {
        "label":       "Bizkaia (FVF)",
        "base_url":    "https://www.fvf-bff.eus/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.fvf-bff.eus/",
        "warm_cal":    "https://www.fvf-bff.eus/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        # El bloque de juveniles (9970695-9970978) dejó el high en ~9974661, pero
        # los Cadetes 2026-27 se publican en ~9974306 (2ª) y ~9979604 (1ª), mucho
        # más arriba. Sin semeña el runner nunca cruzaría miles de IDs huecos.
        "seed_high":   9979604,
        "prefix":      "B_",        # Acta_B_NNNNNN.txt  /  B_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "BIZKAIA"),
        "json_dir":    os.path.join(BASE_DIR, "BIZKAIA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "BIZKAIA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "BIZKAIA", "tarjetas_revisadas.json"),
    },
    "navarra": {
        "label":       "Navarra (FutNavarra)",
        "base_url":    "https://www.futnavarra.es/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.futnavarra.es/",
        "warm_cal":    "https://www.futnavarra.es/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        "prefix":      "NA_",       # Acta_NA_NNNNNN.txt  /  NA_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "NAVARRA"),
        "json_dir":    os.path.join(BASE_DIR, "NAVARRA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "NAVARRA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "NAVARRA", "tarjetas_revisadas.json"),
    },
    "rfef": {
        "label":       "Nacional (RFEF)",
        "base_url":    "https://marcadores.rfef.es/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://marcadores.rfef.es/",
        "warm_cal":    "https://marcadores.rfef.es/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   79000000,    # IDs RFEF son de 8 cifras (ej: 70674828)
        "prefix":      "N_",        # Acta_N_NNNNNN.txt  /  N_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "RFEF"),
        "json_dir":    os.path.join(BASE_DIR, "RFEF", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "RFEF", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "RFEF", "tarjetas_revisadas.json"),
        "page_timeout": 3,
    },
    "rioja": {
        "label":       "La Rioja (FRFutbol)",
        "base_url":    "https://www.frfutbol.com/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.frfutbol.com/",
        "warm_cal":    "https://www.frfutbol.com/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        "prefix":      "R_",        # Acta_R_NNNNNN.txt  /  R_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "RIOJA"),
        "json_dir":    os.path.join(BASE_DIR, "RIOJA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "RIOJA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "RIOJA", "tarjetas_revisadas.json"),
    },
    "cantabria": {
        "label":       "Cantabria (RFCF)",
        "base_url":    "https://www.rfcf.es/pnfg/NPcd/NFG_CmpPartido",
        "warm_home":   "https://www.rfcf.es/",
        "warm_cal":    "https://www.rfcf.es/pnfg/NPcd/NFG_CmpCalendario?cod_primaria=1000120",
        "cod_primaria":"1000120",
        "acta_tope":   9990000,
        # Primera acta conocida del bloque Cadete 2026/27 (239964). Al ser una
        # fuente nueva sin corpus no podemos arrancar desde 9990000; se siembra
        # el high aquí para que la ventana baje YA hacia las actas publicadas.
        "seed_high":   239963,
        "prefix":      "C_",        # Acta_C_NNNNNN.txt  /  C_NNNNNN.json
        "output_dir":  os.path.join(BASE_DIR, "CANTABRIA"),
        "json_dir":    os.path.join(BASE_DIR, "CANTABRIA", "JSON"),
        "empty_file":  os.path.join(BASE_DIR, "CANTABRIA", "empty_ids.json"),
        "revisadas_file": os.path.join(BASE_DIR, "CANTABRIA", "tarjetas_revisadas.json"),
    },
}

# Estos se sobreescriben en main() según la fuente elegida
OUTPUT_DIR   = FUENTES["alava"]["output_dir"]
JSON_DIR     = FUENTES["alava"]["json_dir"]
EMPTY_FILE   = FUENTES["alava"]["empty_file"]
BASE_URL     = FUENTES["alava"]["base_url"]
COD_PRIMARIA = FUENTES["alava"]["cod_primaria"]
ACTA_PREFIX  = FUENTES["alava"]["prefix"]

for f in FUENTES.values():
    for d in (f["output_dir"], f["json_dir"], HTML_DIR):
        os.makedirs(d, exist_ok=True)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Edg/121.0.0.0 Safari/537.36",
]

# ═══════════════════════════════════════════════════════════════
#  DETECTAR Y CORREGIR ACTAS DUPLICADAS (MODO 10)
# ═══════════════════════════════════════════════════════════════
def detectar_duplicados(json_dir, output_dir, prefix):
    """
    Detecta actas duplicadas (mismo jornada, equipos, resultado, categoría).
    Solo considera actas con datos completos (jornada, equipos y categoría definidos).
    Retorna: dict {clave_duplicada: [lista de IDs acta]}
    """
    duplicados = defaultdict(list)
    json_files = [f for f in os.listdir(json_dir) if f.endswith(".json")]
    
    for fn in json_files:
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                j = json.load(f)
            
            # Extraer datos
            jornada = j.get("jornada")
            eq_local = j.get("equipo_local", "").strip() if j.get("equipo_local") else ""
            eq_visit = j.get("equipo_visitante", "").strip() if j.get("equipo_visitante") else ""
            categoria = j.get("categoria", "").strip() if j.get("categoria") else ""
            goles_local = j.get("goles_local")
            goles_visit = j.get("goles_visitante")
            
            # Filtrar actas incompletas: sin jornada, sin equipos o con datos None
            if (jornada is None or 
                not eq_local or 
                not eq_visit or 
                goles_local is None or 
                goles_visit is None or
                categoria in ("", "Desconocida", None)):
                continue  # Ignorar esta acta
            
            resultado = f"{goles_local}-{goles_visit}"
            clave = f"{jornada}|{eq_local}|{eq_visit}|{resultado}|{categoria}"
            aid = fn.replace(".json", "")
            duplicados[clave].append(aid)
        except:
            pass
    
    # Filtrar solo los que realmente son duplicados (2+ entradas)
    return {k: v for k, v in duplicados.items() if len(v) > 1}

def corregir_duplicados(fuente_key, fuente_cfg):
    """
    Modo 10: Detecta duplicados, descarga nuevamente, actualiza .txt y .json.
    Solo re-descarga si ambas actas tienen equipos definidos.
    """
    out_dir = fuente_cfg["output_dir"]
    json_dir = fuente_cfg["json_dir"]
    prefix = fuente_cfg["prefix"]
    
    print("=" * 72)
    print(f"  MODO 10: DETECTAR Y CORREGIR ACTAS DUPLICADAS")
    print(f"  Fuente: {fuente_cfg['label']}")
    print("=" * 72 + "\n")
    
    duplicados = detectar_duplicados(json_dir, out_dir, prefix)
    
    if not duplicados:
        print("[+] No hay actas duplicadas detectadas.\n")
        return
    
    print(f"[!] ENCONTRADOS {len(duplicados)} GRUPOS DE DUPLICADOS:\n")
    
    actas_a_redes = []
    actas_sin_equipos = []
    
    for clave, ids in duplicados.items():
        partes = clave.split("|")
        eq_local = partes[1]
        eq_visit = partes[2]
        
        # Verificar si tiene equipos definidos
        if not eq_local or not eq_visit or eq_local == "?" or eq_visit == "?":
            print(f"  ⊘ Jornada {partes[0]} | {eq_local or '?'} vs {eq_visit or '?'} | {partes[3]} | Categoría: {partes[4]}")
            print(f"    IDs: {', '.join(ids)} — IGNORADO (sin equipos definidos)")
            print()
            actas_sin_equipos.extend(ids)
        else:
            print(f"  • Jornada {partes[0]} | {eq_local} vs {eq_visit} | {partes[3]} | Categoría: {partes[4]}")
            print(f"    IDs: {', '.join(ids)}")
            print()
            actas_a_redes.extend(ids)
    
    if not actas_a_redes:
        print(f"[!] No hay actas con equipos definidos para re-descargar.\n")
        return
    
    print(f"[*] Se re-descargarán {len(actas_a_redes)} actas...\n")
    
    # ── Iniciar Chrome ──────────────────────────────────────────
    t0 = time.time()
    print("[*] Iniciando Chrome...")
    ua_idx = 0
    driver = crear_nav(ua_idx)
    calentar(driver, fuente_cfg)
    
    ok = fail = 0
    for idx, aid in enumerate(actas_a_redes, 1):
        print(f"  [{idx}/{len(actas_a_redes)}] Re-descargando {aid}...")
        
        # Extraer el ID numérico del aid
        cod_str = aid.replace(prefix, "")
        try:
            cod = int(cod_str)
        except:
            print(f"    [!] No se pudo extraer ID numérico de {aid}")
            continue
        
        # Descargar
        ruta, estado = descargar(driver, cod, idx, len(actas_a_redes), fuente_cfg)
        
        if estado == "ok":
            ok += 1
            print(f"    [+] Re-descargado OK: {os.path.basename(ruta)}")
            
            # Re-parsear inmediatamente
            try:
                Parser(ruta, json_dir=json_dir, fuente=fuente_key).process()
                print(f"    [+] Re-parseado OK")
            except Exception as e:
                print(f"    [!] Error parseando: {e}")
        else:
            fail += 1
            print(f"    [!] Fallo al re-descargar: {estado}")
    
    cerrar(driver)
    print(f"\n[+] Re-descarga: {ok} OK | {fail} fallidas\n")
    
    # ── Regenerar HTML ──────────────────────────────────────────
    print("[*] Regenerando HTML...")
    generar_html()
    
    t = time.time() - t0
    print("=" * 72)
    print(f"  MODO 10 COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
    print(f"  HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    print("=" * 72)

# ═══════════════════════════════════════════════════════════════
#  GESTIÓN DE IDs VACÍOS
# ═══════════════════════════════════════════════════════════════
def load_empty_ids(fpath=None):
    """Carga IDs marcados como vacíos (con timestamp para re-chequear)."""
    try:
        with open(fpath or EMPTY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_empty_ids(d, fpath=None):
    with open(fpath or EMPTY_FILE, "w", encoding="utf-8") as f:
        json.dump(d, f)

def mark_empty(cod, empty_ids, fpath=None):
    empty_ids[str(cod)] = time.time()
    save_empty_ids(empty_ids, fpath)

def should_retry_empty(cod, empty_ids, dias=7):
    """Re-chequear un vacío si han pasado N días."""
    t = empty_ids.get(str(cod))
    if t is None: return True   # nunca visto → intentar
    return (time.time() - t) > dias * 86400

# ═══════════════════════════════════════════════════════════════
#  DEDUPE CROSS-FUENTE (mismo partido en 2 federaciones)
#  El mismo partido puede publicarse en RFEF (N_) y en la federación
#  territorial (R_, E_, ...). RFEF trae alineaciones completas (11/11)
#  mientras que algunas webs territoriales (p.ej. Rioja en DH Juvenil y
#  Segunda Federación) NO publican titulares. Conservamos la versión con
#  MÁS datos y el resto NO se vuelve a descargar ni aparece en la web.
# ═══════════════════════════════════════════════════════════════
NORM_PUNCT = ".,:-()/'\""

def _norm_accent(s):
    return ((s or "").upper()
            .replace("Á", "A").replace("É", "E").replace("Í", "I")
            .replace("Ó", "O").replace("Ú", "U").replace("Ü", "U")
            .replace("Ñ", "N"))

def norm_equipo(s):
    """Normaliza un nombre de equipo para comparar entre fuentes."""
    if not s:
        return ""
    s = _norm_accent(s)
    for ch in NORM_PUNCT:
        s = s.replace(ch, " ")
    return "".join(s.split())

def comp_key(categoria):
    """Clave de COMPETICIÓN para emparejar la misma categoría entre fuentes
    (RFEF y territoriales la escriben distinto). Normaliza acentos, quita el
    paréntesis (grupo/fase), palabras genéricas y compara sin tilde."""
    import re
    c = _norm_accent(categoria)
    c = re.sub(r"\(.*?\)", " ", c)
    for ch in ".,:-'\"":
        c = c.replace(ch, " ")
    c = " ".join(c.split())
    for frase in ("CAMPEONATO NACIONAL DE LIGA DE", "CAMPEONATO NACIONAL DE LIGA",
                  "PRIMERA FASE", "SEGUNDA FASE", "TERCERA FASE",
                  "FASE REGULAR", "FASE REGULADORA", "FASE UNICA", "GRUPO",
                  "GRUPOS", "DE", "EN", "LA", "EL", "LOS", "1", "2", "3"):
        c = c.replace(frase, " ")
    c = " ".join(x for x in c.split() if x not in ("DE", "EN", "LA", "EL", "LOS",
                                                   "1", "2", "3", "GRUPO", "GRUPOS"))
    return "".join(c.split())[:24]

def _score_acta(a):
    """Mejor acta = más datos (titulares) + resultado no pendiente + RFEF (fiable)."""
    n_tit = (len(a.get("titulares_local") or []) +
             len(a.get("titulares_visitante") or []))
    pend  = a.get("resultado") in (None, "", "pendiente")
    aid   = str(a.get("acta_id") or "")
    prio  = {"N_": 6, "E_": 5, "NA_": 4, "B_": 3, "G_": 2, "R_": 1, "": 0}.get(aid[:2], 0)
    return (n_tit, 0 if pend else 1, prio)

def dedupe_actas(actas):
    """Devuelve (keep, drop_ids_por_fuente).
    Agrupa por (local_norm, visitante_norm, fecha, competición); si hay 2+
    versiones del mismo partido de distintas fuentes, conserva la de mayor
    '_score_acta'. drop_ids_por_fuente: {clave_fuente: {acta_id,...}}."""
    grupos = {}
    for a in actas:
        k = (norm_equipo(a.get("equipo_local")),
             norm_equipo(a.get("equipo_visitante")),
             a.get("fecha"),
             comp_key(a.get("categoria")))
        grupos.setdefault(k, []).append(a)

    keep = []
    drop = {}
    for k, v in grupos.items():
        if len(v) == 1:
            keep.append(v[0])
            continue
        mejor = max(v, key=_score_acta)
        keep.append(mejor)
        for a in v:
            if a is not mejor:
                aid = str(a.get("acta_id") or "")
                if aid:
                    drop.setdefault(a.get("fuente") or "", set()).add(aid)
    return keep, drop

def load_duplicados(fpath=None):
    """Carga lista de acta_id descartadas por dedupe cross-fuente."""
    try:
        with open(fpath or "", "r", encoding="utf-8") as f:
            return set(json.load(f))
    except:
        return set()

def save_duplicados(ids, fpath):
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump(sorted(ids), f, ensure_ascii=False)

# ═══════════════════════════════════════════════════════════════
#  GESTIÓN DE CLASIFICACIÓN Y CALENDARIO
# ═══════════════════════════════════════════════════════════════
class GestorLiga:
    """Gestiona clasificación, calendario y detección de partidos faltantes"""
    
    def __init__(self, json_dir):
        self.json_dir = json_dir
        self.partidos = self._cargar_partidos()
    
    def _cargar_partidos(self):
        """Carga todos los partidos de los JSONs parseados"""
        partidos = []
        try:
            for fn in os.listdir(self.json_dir):
                if not fn.endswith(".json"): continue
                try:
                    with open(os.path.join(self.json_dir, fn), encoding="utf-8") as jf:
                        data = json.load(jf)
                        if all(k in data for k in ("equipo_local", "equipo_visitante", "jornada")):
                            partidos.append(data)
                except: pass
        except: pass
        return partidos
    
    def obtener_equipos(self):
        """Obtiene lista única de equipos"""
        equipos = set()
        for p in self.partidos:
            equipos.add(p.get("equipo_local"))
            equipos.add(p.get("equipo_visitante"))
        return sorted(list(equipos))
    
    def obtener_clasificacion(self):
        """Calcula la clasificación actual"""
        tabla = {}
        equipos = self.obtener_equipos()
        
        # Inicializar
        for eq in equipos:
            tabla[eq] = {
                'nombre': eq,
                'puntos': 0, 'pj': 0, 'pg': 0, 'pe': 0, 'pp': 0,
                'gf': 0, 'gc': 0, 'dg': 0
            }
        
        # Procesar partidos con resultado
        for p in self.partidos:
            if not p.get("resultado"):
                continue
            
            local = p.get("equipo_local")
            visitante = p.get("equipo_visitante")
            goles_local = p.get("goles_local", 0)
            goles_visitante = p.get("goles_visitante", 0)
            
            if local not in tabla or visitante not in tabla:
                continue
            
            tabla[local]['pj'] += 1
            tabla[visitante]['pj'] += 1
            tabla[local]['gf'] += goles_local
            tabla[local]['gc'] += goles_visitante
            tabla[visitante]['gf'] += goles_visitante
            tabla[visitante]['gc'] += goles_local
            
            if goles_local > goles_visitante:
                tabla[local]['pg'] += 1
                tabla[local]['puntos'] += 3
                tabla[visitante]['pp'] += 1
            elif goles_local < goles_visitante:
                tabla[visitante]['pg'] += 1
                tabla[visitante]['puntos'] += 3
                tabla[local]['pp'] += 1
            else:
                tabla[local]['pe'] += 1
                tabla[local]['puntos'] += 1
                tabla[visitante]['pe'] += 1
                tabla[visitante]['puntos'] += 1
            
            tabla[local]['dg'] = tabla[local]['gf'] - tabla[local]['gc']
            tabla[visitante]['dg'] = tabla[visitante]['gf'] - tabla[visitante]['gc']
        
        # Ordenar
        clasificacion = sorted(tabla.values(), key=lambda x: (-x['puntos'], -x['dg'], -x['gf']))
        for i, eq in enumerate(clasificacion, 1):
            eq['posicion'] = i
        
        return clasificacion
    
    def obtener_partidos_jornada(self, jornada):
        """Obtiene partidos de una jornada específica"""
        return sorted([p for p in self.partidos if p.get("jornada") == jornada], 
                     key=lambda x: x.get("fecha", ""))
    
    def obtener_jornadas(self):
        """Obtiene rango de jornadas disponibles"""
        jornadas = set(p.get("jornada") for p in self.partidos if p.get("jornada"))
        return sorted(list(jornadas)) if jornadas else []
    
    def obtener_partidos_faltantes(self):
        """Detecta partidos que deberían existir (ida/vuelta) pero están sin acta/resultado."""
        equipos = self.obtener_equipos()
        jornadas = self.obtener_jornadas()
        
        if not equipos or not jornadas:
            return []
        
        # Estructura esperada: ida/vuelta = (n_equipos - 1) jornadas x 2
        num_jornadas_esperadas = (len(equipos) - 1) * 2
        
        # Partidos que existen (con datos)
        partidos_encontrados = set()
        for p in self.partidos:
            local = p.get("equipo_local", "").strip()
            visitante = p.get("equipo_visitante", "").strip()
            jornada = p.get("jornada")
            if local and visitante and jornada:
                # Clave única: (jornada, local, visitante) 
                partidos_encontrados.add((jornada, local, visitante))
        
        # Generar fixture esperada
        faltantes = []
        max_jornada = max(jornadas) if jornadas else 0
        
        for jornada in range(1, num_jornadas_esperadas + 1):
            # En cada jornada, cada equipo juega exactamente una vez
            equipos_restantes = set(equipos)
            
            # Generar emparejamientos (algoritmo round-robin simple)
            for i, eq_local in enumerate(equipos):
                for j, eq_visitante in enumerate(equipos):
                    if i < j and (jornada, eq_local, eq_visitante) not in partidos_encontrados:
                        # Este partido DEBERÍA existir pero no tiene acta
                        faltantes.append({
                            'jornada': jornada,
                            'equipo_local': eq_local,
                            'equipo_visitante': eq_visitante,
                            'estado': 'sin_acta',
                            'tipo': 'ida' if jornada <= (num_jornadas_esperadas // 2) else 'vuelta'
                        })
        
        return sorted(faltantes, key=lambda x: (x['jornada'], x['equipo_local']))
    
    
    def obtener_estadisticas(self, jornada):
        """Obtiene estadísticas de una jornada"""
        partidos = self.obtener_partidos_jornada(jornada)
        con_resultado = len([p for p in partidos if p.get("resultado")])
        sin_resultado = len([p for p in partidos if not p.get("resultado")])
        return {
            'total': len(partidos),
            'con_resultado': con_resultado,
            'sin_resultado': sin_resultado
        }
    
    def exportar_para_html(self):
        """Exporta datos listos para embeber en HTML/JS"""
        return {
            'clasificacion': self.obtener_clasificacion(),
            'jornadas': self.obtener_jornadas(),
            'calendario_por_jornada': {j: self.obtener_partidos_jornada(j) 
                                       for j in self.obtener_jornadas()},
            'partidos_faltantes': self.obtener_partidos_faltantes(),
            'estadisticas': {j: self.obtener_estadisticas(j) 
                           for j in self.obtener_jornadas()}
        }

def es_acta_vacia(filepath):
    """Detecta si una acta está vacía/corrupta: debe contener marcadores reales del acta."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            contenido = f.read().strip().lower()
        
        if not contenido:
            return True
        
        # Palabras clave que DEBE tener un acta válida
        palabras_clave = [
            "árbitro", "arbitro",
            "jornada", "temporada",
            "titular", "suplente",
            "estadio", "ciudad",
            "gol", "tarjeta"
        ]
        
        coincidencias = sum(1 for kw in palabras_clave if kw in contenido)
        if coincidencias < 3:
            return True  # Falta contenido real del acta
        
        # Detectar basura: cookie banners, ads, etc
        basura_markers = [
            "consentimiento para cookies",
            "almacenar la información",
            "publicidad y contenido",
            "refinery89", "ad by"
        ]
        
        basura_count = sum(1 for m in basura_markers if m in contenido)
        if basura_count >= 2:
            return True  # Demasiada basura
        
        # Check de líneas
        lineas = [l for l in contenido.split('\n') if l.strip()]
        return len(lineas) < MIN_LINEAS_REAL
    except:
        return True

# ═══════════════════════════════════════════════════════════════
#  NAVEGADOR
# ═══════════════════════════════════════════════════════════════
def _detectar_version_chrome():
    """Detecta la versión principal de Chrome SIN lanzar el ejecutable.
    Lee desde el registro de Windows o desde el archivo Last Version en disco."""
    # 1) Registro de Windows (más fiable, sin abrir nada)
    try:
        import winreg as _wr
        claves = [
            (_wr.HKEY_CURRENT_USER,  r"SOFTWARE\Google\Chrome\BLBeacon"),
            (_wr.HKEY_CURRENT_USER,  r"SOFTWARE\Wow6432Node\Google\Chrome\BLBeacon"),
            (_wr.HKEY_LOCAL_MACHINE, r"SOFTWARE\Google\Chrome\BLBeacon"),
            (_wr.HKEY_LOCAL_MACHINE, r"SOFTWARE\Wow6432Node\Google\Chrome\BLBeacon"),
        ]
        for hive, ruta_reg in claves:
            try:
                with _wr.OpenKey(hive, ruta_reg) as k:
                    ver_str, _ = _wr.QueryValueEx(k, "version")
                    ver = int(ver_str.split(".")[0])
                    print(f"[+] Chrome detectado (registro): v{ver}")
                    return ver
            except Exception:
                pass
    except ImportError:
        pass  # No estamos en Windows

    # 2) Archivo "Last Version" en el directorio de instalación (sin ejecutar nada)
    rutas_last = [
        r"C:\Program Files\Google\Chrome\Application\Last Version",
        r"C:\Program Files (x86)\Google\Chrome\Application\Last Version",
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Google", "Chrome", "Application", "Last Version"),
        os.path.expanduser(os.path.join("~", "AppData", "Local", "Google", "Chrome", "Application", "Last Version")),
    ]
    for ruta in rutas_last:
        if os.path.isfile(ruta):
            try:
                with open(ruta) as fv:
                    ver = int(fv.read().strip().split(".")[0])
                print(f"[+] Chrome detectado (Last Version): v{ver}")
                return ver
            except Exception:
                pass

    print(f"[!] No se pudo detectar versión de Chrome, usando fallback {CHROME_VERSION}")
    return CHROME_VERSION

def _headless_activo():
    """FAF_HEADLESS=1 (default) → headless (cron de GitHub, sin pantalla).
    FAF_HEADLESS=0 → Chrome REAL con ventana FUERA DE PANTALLA (descargador
    de PC): no lo ves, pero para el anti-bot es un navegador visible de
    verdad (no headless), mucho más difícil de detectar."""
    v = os.environ.get("FAF_HEADLESS", "1").strip().lower()
    return v not in ("0", "false", "no", "off")

def crear_nav(ua=0):
    version = _detectar_version_chrome()
    headless = _headless_activo()
    op = uc.ChromeOptions()
    # Headless: se pasa por argumento Y por parámetro del constructor para
    # cubrir todas las versiones de undetected_chromedriver
    if headless:
        op.add_argument("--headless=new")
        op.add_argument("--headless")
    for a in ["--disable-blink-features=AutomationControlled", "--lang=es-ES,es"]:
        op.add_argument(a)
    if headless:
        for a in ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"]:
            op.add_argument(a)
    # NO headless → Chrome real con ventana FUERA DE PANTALLA (no la ves, pero
    # para el anti-bot es un navegador visible de verdad, no headless).
    op.add_argument("--window-position=-32000,-32000")
    op.add_argument(f"--window-size={random.choice([1280,1366])},{random.choice([768,900])}")
    op.add_argument(f"--user-agent={USER_AGENTS[ua % len(USER_AGENTS)]}")
    drv = uc.Chrome(options=op, use_subprocess=True, version_main=version,
                    headless=headless)
    drv.set_page_load_timeout(PAGE_TIMEOUT)
    return drv

def calentar(drv, fuente_cfg=None):
    print("[*] Calentando sesion...")
    if fuente_cfg is None:
        fuente_cfg = FUENTES["alava"]
    try:
        drv.get(fuente_cfg["warm_home"]); time.sleep(random.uniform(1.2, 2.0))
        _scroll_humano(drv); time.sleep(random.uniform(0.5, 1.0))
        drv.get(fuente_cfg["warm_cal"])
        time.sleep(random.uniform(0.8, 1.5)); _scroll_humano(drv)
        print("[+] Sesion lista.\n")
    except Exception as e:
        print(f"  [!] Warning: {str(e).split(chr(10))[0]}")

def cerrar(drv):
    try: drv.quit()
    except: pass

# ── Helpers de anti-bloqueo reforzado (Modo 2 y Modo 12) ──────────────────
def _delay_humano():
    """Pausa aleatoria ANTES de cada petición para que el patrón de tráfico
    no sea constante/robótico. Reduce peticiones por minuto desde nuestra IP,
    que es justo lo que suelen mirar los sistemas anti-bot para bloquear."""
    time.sleep(random.uniform(*DELAY_ENTRE_PETICIONES))

def _pausa_escalada(racha):
    """Backoff exponencial con tope según el nº de rachas de bloqueo sufridas
    en la sesión. Si el servidor ya nos está cortando, insistir al mismo ritmo
    es lo que hace que un bloqueo temporal se vuelva permanente; cada racha
    adicional duplica la espera (hasta PAUSA_TOPE_BLOQUEO)."""
    base = random.randint(PAUSA_MIN, PAUSA_MAX)
    return int(min(base * (2 ** (racha - 1)), PAUSA_TOPE_BLOQUEO))

# ── Comportamiento "humano" para Selenium (ventana visible en el PC) ─────
# El anti-bot de las federaciones mira, sobre todo: ritmo constante,
# ausencia de scroll/ratón, y navegador headless. Estos helpers introducen
# esperas variables, scrolls y movimientos de ratón ocasionales, y un
# descanso corto cada N actas, como haría una persona real.
def _scroll_humano(drv):
    try:
        for _ in range(random.randint(1, 3)):
            drv.execute_script("window.scrollBy(0, arguments[0]);",
                               random.randint(140, 480))
            time.sleep(random.uniform(0.25, 0.65))
        drv.execute_script("window.scrollTo(0, 0);")
        time.sleep(random.uniform(0.15, 0.4))
    except Exception:
        pass

def _raton_humano(drv):
    try:
        from selenium.webdriver.common.action_chains import ActionChains
        ActionChains(drv).move_by_offset(
            random.randint(-90, 90), random.randint(-50, 50)
        ).pause(random.uniform(0.1, 0.35)).perform()
    except Exception:
        pass

_conta_ritmo = {"actas": 0, "descanso_en": 10}

def _ritmo_humano(drv):
    """Esperas aleatorias + scroll/ratón ocasionales + descanso corto cada
    N actas. Se llama antes de cada petición del modo Selenium."""
    time.sleep(random.uniform(0.55, 1.15))
    _conta_ritmo["actas"] += 1
    if _conta_ritmo["actas"] >= _conta_ritmo["descanso_en"]:
        _conta_ritmo["actas"] = 0
        _conta_ritmo["descanso_en"] = random.randint(8, 16)
        p = random.uniform(6, 18)
        print(f"  [~] pausa corta {p:.0f}s (ritmo humano)...")
        time.sleep(p)
    if random.random() < 0.35:
        _scroll_humano(drv)
    if random.random() < 0.20:
        _raton_humano(drv)

# ═══════════════════════════════════════════════════════════════
#  SCRAPER
# ═══════════════════════════════════════════════════════════════
def _txt(el):
    out = []
    for c in el.children:
        if isinstance(c, Tag):
            if c.name not in ['script','style','noscript','nav']: out.extend(_txt(c))
        elif isinstance(c, NavigableString):
            t = c.strip()
            if t: out.append(t)
    return out

# Extrae info basica del partido (equipos, resultado, temporada, fecha) de las
# lineas crudas del TXT sin instanciar el Parser completo.
def _info_rapida_acta(raw):
    import re as _re
    lines = [l.strip() for l in raw if l.strip()]
    # Localizar "Ficha de Partido" como punto de partida
    try:
        start = next(i for i, l in enumerate(lines) if "Ficha de Partido" in l or
                     "Partizdaren Akta" in l or "Partidaren Akta" in l)
        lines = lines[start:]
    except StopIteration:
        pass

    temp = fecha = equipo_local = equipo_visitante = ""
    goles_local = goles_visitante = "?"

    _NOISE_SET = {
        "Ficha de Partido","Partizdaren Akta","Partidaren Akta","Acta del partido",
        "Ficha de Partido","Acciones","Generar PDF","Intranet","GESTIÓN AVANZADA",
        "Consentimiento para cookies","Gol","G. Penalti","G. Propia Puerta",
        "Gola","Penaltia","Bere Atean","Golak","Ekintzak","Sortu PDFa",
    }

    def _nom(s):
        return (len(s) > 2 and not s.isdigit() and s not in _NOISE_SET
                and not s.startswith("http") and not _re.match(r"^\d{2}/\d{2}/\d{4}", s)
                and not _re.match(r"^Temporada|^Jornada|^Árbitros|^Goles|^Titulares", s))

    for i, l in enumerate(lines):
        m = _re.search(r"Temporada[:\s]+(\d{4}[-/]\d{2,4}|\d{4})", l)
        if m and not temp:
            temp = m.group(1); continue
        if _re.match(r"Denboraldia\s+(\d{4})", l):
            m2 = _re.search(r"(\d{4}[-/]\d{2,4}|\d{4})", l)
            if m2 and not temp: temp = m2.group(1); continue
        m = _re.match(r"(\d{2}/\d{2}/\d{4})", l)
        if m and not fecha:
            fecha = m.group(1); continue
        if not equipo_local and i > 0 and _nom(l):
            equipo_local = l; continue
        if equipo_local and not equipo_visitante and _nom(l) and l != equipo_local:
            equipo_visitante = l; continue
        # Marcador: "2 - 1" o "2-1"
        if equipo_visitante:
            m = _re.match(r"(\d+)\s*[-–]\s*(\d+)$", l)
            if m:
                goles_local, goles_visitante = m.group(1), m.group(2)
                break

    partes = []
    if equipo_local and equipo_visitante:
        partes.append(f"{equipo_local} {goles_local}-{goles_visitante} {equipo_visitante}")
    if temp:
        partes.append(f"[{temp}]")
    if fecha:
        partes.append(fecha)
    return "  ".join(partes) if partes else "(?)"

# Resultado: (ruta|None, estado)
# estado: "ok" | "vacia" | "bloqueo" | "error"
def descargar(drv, cod, lbl, tot, fuente_cfg=None):
    if fuente_cfg is None:
        fuente_cfg = FUENTES["alava"]
    url = f"{fuente_cfg['base_url']}?cod_primaria={fuente_cfg['cod_primaria']}&CodActa={cod}"
    prefix = fuente_cfg["prefix"]
    out_dir = fuente_cfg["output_dir"]
    timeout = fuente_cfg.get("page_timeout", PAGE_TIMEOUT)
    for intento in range(1, 4):
        try:
            _ritmo_humano(drv)
            drv.get(url)
            WebDriverWait(drv, timeout).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
                          and len(d.page_source) > 300)
            time.sleep(random.uniform(0.3, 0.7))
            if random.random() < 0.45:
                _scroll_humano(drv)
            soup = BeautifulSoup(drv.page_source, 'html.parser')
            body = soup.find('body')
            if not body: time.sleep(1); continue
            raw = _txt(body)
            if not raw: time.sleep(1); continue

            fp = os.path.join(out_dir, f"Acta_{prefix}{cod}.txt")
            with open(fp, "w", encoding="utf-8") as f:
                f.write("\n".join(raw))
            # HTML crudo como sibling: el Parser decodifica de él el marcador
            # final autoritativo (widget ntype) que el TXT pierde.
            try:
                raw_fp = os.path.splitext(fp)[0] + ".html"
                with open(raw_fp, "w", encoding="utf-8") as f:
                    f.write(drv.page_source)
            except Exception:
                pass

            if len(raw) < MIN_LINEAS_REAL:
                print(f"  [~] ({lbl:>3}/{tot}) Acta {prefix}{cod} VACIA ({len(raw)} lineas)")
                return fp, "vacia"

            # Extraer info del partido de las primeras lineas del TXT para mostrar en CMD
            try:
                info = _info_rapida_acta(raw)
            except Exception:
                info = f"({len(raw)} lineas)"
            print(f"  [+] ({lbl:>3}/{tot}) Acta {prefix}{cod}  {info}")
            time.sleep(random.uniform(0.7, 1.3))
            return fp, "ok"

        except (WebDriverException, TimeoutException) as e:
            msg = str(e).split(chr(10))[0].strip()
            blq = msg in ("", "Message:")
            print(f"  [!] Acta {prefix}{cod} intento {intento}: {msg or '(bloqueo)'}")
            if blq and intento == 1:
                return None, "bloqueo"   # fallo rápido en bloqueo
            time.sleep(2 if blq else 2 * intento)
        except Exception as e:
            print(f"  [!] Acta {prefix}{cod} error: {e}"); time.sleep(2)

    return None, "error"

# ═══════════════════════════════════════════════════════════════
#  PARSER  —  formato verificado con actas reales
# ═══════════════════════════════════════════════════════════════
_NOISE = {
    "Consentimiento para cookies","Aceptar todo","Rechazar y suscribirse",
    "Configuraciones","Guardar + Salir","Cookie Banner powered by","consentmanager.net",
    "Intranet","Acciones","Generar PDF","Acta del partido","Ficha de Partido",
    "Gol","G. Penalti","G. Propia Puerta","PATROCINADORES OFICIALES",
    "De Interés","Política de privacidad","Política de cookies","Aviso legal","Contacto",
    "AFF - FAF","GESTIÓN AVANZADA",
    # Euskadi (euskera) — palabras exactas cortas
    "Ekintzak","Sortu PDFa","Partizdaren Akta","Partidaren Akta","Partiduen orria",
    "Gola","Penaltia","Bere Atean",
    "BABESLE OFIZIALAK","HORNITZAILE OFIZIALAK",
    "euskadifutbol.eus","faf-aff.eus",
    "Euskadiko Futbol Federakundea - Federación Vasca de Fútbol",
    "Kirolean abusu, sexu jazarpen eta generoaren aurkako laguntza zerbitzua",
    "Interesgarria","Pribatutasun politika","Cookieen politika","Harremanetan jarri",
    # RFEF Nacional
    "marcadores.rfef.es","rfef.es","Real Federación Española de Fútbol",
    "Cerrar","Volver","Imprimir","Ver PDF",
    "Alineaciones","Incidencias","INCIDENCIAS","JUGADORES","AMONESTACIONES",
    "EXPULSIONES","OTRAS INCIDENCIAS","DIRIGENTES y TÉCNICOS","PÚBLICO",
    "DEFICIENCIAS OBSERVADAS EN EL TERRENO DE JUEGO E INSTALACIONES",
    "OTRAS OBSERVACIONES O AMPLIACIONES A LAS ANTERIORES",
    "^^Entrar^^","^^Cerrar^^","Protección de datos","Aviso legal",
    # La Rioja (FRFutbol)
    "frfutbol.com","Federación Riojana de Fútbol","CRECEMOS JUNTOS",
    "Portal del Federado","Federación","Árbitros","Fútbol Sala","Selecciones",
    "Fútbol Femenino","Inclusividad","Noticias","Convocatorias","Cursos",
    "Toma de Partido","Ficha de Partido",
}
_CUERPO = (
    "DEL. Campo:","DEL. Equipo:","Entrenador:","2ºEntrenador:","AUXILIAR","No presenta",
    "Preparador Físico","ATS o Fisioterapeuta",
    # Euskadi
    "Zelaiko Delegatua:","Taldeko Delegatua:","Entrenatzailea:","2ºEntrenatzailea:",
    "AUXILIAR / LAGUNTZAILEA","ESPECIALISTA DE PORTEROS",
)
_FOOTER = (
    "Plaza Amadeo","administracion@","945 258","Horario de atención","©20","▼ Ad",
    "consentmanager","AFF - FAF","GESTIÓN",
    # Euskadi
    "Julian Gaiarre","info@euskadifutbol","94 473",
    "48004 Bilbo","48004 Bilbao",
    # RFEF Nacional
    "rfef.es","marcadores.rfef","C/ Ramón y Cajal","28230 Las Rozas",
    "info@rfef","RFEF ©",
    # La Rioja (FRFutbol)
    "frfutbol.com","info@frfutbol","C/ Ruavieja","26001 Logroño",
    "FRF ©","Federación Riojana",
    # Cookie banner y ruido inicial completo
    "Consentimiento para cookies","Aceptar todo","Rechazar y suscribirse","Configuraciones",
    "Guardar + Salir","Intranet","Acciones","Generar PDF","Acta del partido",
    "Cookie Banner","powered by","En este sitio web","Almacenar la información",
    "funciones similares para procesar","Datos de localización geográfica","información del navegador",
    "Publicidad y contenido personalizados","análisis/medición estadística","servicios externos",
)

def _dors(s): return bool(re.match(r"^\d{1,3}$", s))
def _min_(s): return bool(re.match(r"^\([\d'+]['\d+]*\)$", s))
def _min_val(s):
    """Extrae el número de minuto de una cadena tipo (45') o ('). Devuelve 0 si no hay dígitos."""
    m = re.search(r"\d+", s)
    return int(m.group()) if m else 0
def _nom(s):
    return (len(s) > 3 and not _dors(s) and not _min_(s)
            and s not in _NOISE
            and not any(s.startswith(p) for p in _CUERPO)
            and not any(s.startswith(p) for p in _FOOTER)
            and not re.match(r"^\d{2}-\d{2}-\d{4}", s)
            and "©" not in s and "▼" not in s
            and not s.startswith("Estadio") and not s.startswith("Ciudad"))

class Parser:
    MIN = 90
    def __init__(self, fp, json_dir=None, fuente="alava"):
        self.fp = fp
        self.json_dir = json_dir or JSON_DIR
        self.fuente = fuente
        self.raw_html = os.path.splitext(fp)[0] + ".html"
        aid = os.path.basename(fp).replace("Acta_","").replace(".txt","")
        self.d = dict(
            acta_id=aid, filename=os.path.basename(fp),
            fuente=fuente,
            temporada="", jornada=None, fecha="", hora="",
            categoria="Desconocida", equipo_local=None, equipo_visitante=None,
            goles_local=0, goles_visitante=0, resultado="",  # Resultado: "W"|"D"|"L"|"pendiente"
            arbitros=[],           # lista de árbitros
            estadio="", ciudad="",
            goleadores=[],         # {minuto, jugador, equipo}
            tarjetas=[],           # {minuto, jugador, equipo, tipo: "amarilla"|"roja"}
            entrenador_local=None, entrenador_visitante=None,
            segundo_entrenador_local=None, segundo_entrenador_visitante=None,
            delegado_campo_local=None, delegado_campo_visitante=None,
            delegado_equipo_local=None, delegado_equipo_visitante=None,
            titulares_local=[], titulares_visitante=[],
            suplentes_local=[], suplentes_visitante=[],
            convocados_sin_jugar_local=[], convocados_sin_jugar_visitante=[],
            jugadores_local=[], jugadores_visitante=[],
            sustituciones_local=[], sustituciones_visitante=[],
            minutos_jugadores={},
        )

    def process(self):
        lines = self._clean()

        # ── Normalizar keywords Euskadi (euskera → castellano) ───────────
        # Solo transforma líneas EXACTAS o con prefijo conocido.
        # El texto largo de cookies no coincide con ninguna clave → se ignora aquí
        # y ya queda bloqueado por _nom() al procesar equipos.
        _EUS = {
            "Partizdaren Akta":  "Ficha de Partido",
            "Partidaren Akta":   "Ficha de Partido",
            "Partiduen orria":   "Ficha de Partido",
            "Epaileak":          "Árbitros",
            "Golak":             "Goles",
            "Gola":              "Gol",
            "Titularrak":        "Titulares",
            "Ordezkoak":         "Suplentes",
            "Langile Teknikoak": "Cuerpo Técnico",
            "Ordezkapenak":      "Sustituciones",
            "Txartelak":         "Tarjetas",
            "Txartelak eta Zigorrak": "Tarjetas",
            "Zelaiko Delegatua:":"DEL. Campo:",
            "Taldeko Delegatua:":"DEL. Equipo:",
            "Entrenatzailea:":   "Entrenador:",
            "2ºEntrenatzailea:": "2ºEntrenador:",
        }
        # Prefijos con parámetro inline (p.ej. "Futbol Zelaia: GOBELA")
        _EUS_PREFIX = {
            "Futbol Zelaia:": "Estadio:",
            "Futbol Zelaia":  "Estadio:",
            "Hiria:":         "Ciudad:",
            "Hiria":          "Ciudad:",
            "AUXILIAR / LAGUNTZAILEA": "AUXILIAR",
            "ESPECIALISTA DE PORTEROS": "AUXILIAR",
        }
        normalized = []
        for l in lines:
            # Línea que mezcla "Denboraldia XXXX   Jardunaldia YY"
            if "Denboraldia" in l or "Jardunaldia" in l:
                l = l.replace("Denboraldia","Temporada").replace("Jardunaldia","Jornada")
            # Coincidencia exacta
            if l in _EUS:
                l = _EUS[l]
            else:
                # Coincidencia por prefijo con contenido inline
                for k, v in _EUS_PREFIX.items():
                    if l.startswith(k):
                        l = v + l[len(k):]
                        break
            normalized.append(l)
        lines = normalized

        start = next((i for i, l in enumerate(lines) if "Ficha de Partido" in l), 0)
        lines = lines[start:]
        if len(lines) < 10:
            self._guardar(); return self.d
        self._cabecera(lines)
        self._equipos(lines)
        if self.fuente == "rfef":
            self._rfef_incidencias(lines)
        self._fix_tarjetas_tipo()
        if self.fuente == "rfef":
            self._rfef_normalizar_mayusculas()
        self._guardar()
        return self.d

    def _widget_score(self):
        """Marcador final autoritativo decodificado del widget ntype del HTML
        crudo (sibling `<txt>.html`). El parser solo ve el texto de reserva:
        el dígito visitante suele ir en un span que _txt pierde, dejando el
        marcador mal (verificado: E_10043043 → '3 - 3', no '2 - 4').
        IMPORTANTE: solo valen los widgets del BLOQUE `h2 class=ntype` de la
        cabecera; escanear las primeras ntype del HTML entero se liaba con
        otros contadores de la página (vi '3 - 1' siendo '3 - 3').
        Devuelve (goles_local, goles_visitante) o None."""
        if not self.raw_html or not os.path.exists(self.raw_html):
            return None
        try:
            raw = open(self.raw_html, encoding="utf-8", errors="replace").read()
        except OSError:
            return None
        h = re.search(r"<h2\b[^>]*class\s*=[^>]*ntype[^>]*>", raw, re.I)
        if not h:
            return None
        end = raw.find("</h2>", h.end())
        seg = raw[h.end(): end if end >= 0 else h.end() + 4000]
        dm = re.search(r"d\s*=\s*\[([0-9,]+)\]", seg)
        if not dm:
            return None
        d = [int(x) for x in dm.group(1).split(",")]

        def _digs(part):
            out = []
            for mm in re.finditer(r'ntype\("(?:idh)?[a-zA-Z0-9_]+",(\d+),(\d+),', part):
                n, i = int(mm.group(1)), int(mm.group(2))
                idx = i * 10 + n
                if idx < len(d):
                    out.append(str(d[idx]))
            for sp in re.finditer(r"<span\b([^>]*)>([0-9]+)", part):
                attr = sp.group(1)
                if "display:none" in attr or "display: none" in attr:
                    continue
                out.append(sp.group(2))
            s = "".join(out)
            return int(s) if s.isdigit() else None

        sep = None
        for s in (" - ", " – ", " − "):
            k = seg.find(s)
            if k >= 0 and (sep is None or k < sep):
                sep = k
        if sep is not None:
            a, b = _digs(seg[:sep]), _digs(seg[sep + 1:])
        else:
            a, b = _digs(seg), None
        if (a is not None and b is not None
                and 0 <= a <= 50 and 0 <= b <= 50):
            return (a, b)
        return None

    def _goles_propias_raw(self):
        """Goles en propia marcados EXPLÍCITAMENTE por la web (clase
        `lgolpp` / title con 'propia'): devuelve {(minuto, jugador)}.
        Normalmente la fila del acta lo etiqueta con un icono rojo
        (p.ej. euskadi: title='Norberaren gola')."""
        if not self.raw_html or not os.path.exists(self.raw_html):
            return set()
        try:
            raw = open(self.raw_html, encoding="utf-8", errors="replace").read()
        except OSError:
            return set()
        own = set()
        for mm in re.finditer(r'lgolpp|title="[^"]*[Pp]ropia[^"]*"', raw):
            fin = raw.find("</tr>", mm.start())
            seg = raw[mm.start(): fin if fin >= 0 else mm.start() + 600]
            th = re.search(r"\((\d+)(?:\+\d+)?'\)(.*?)</td>", seg, re.S)
            if th:
                nombre = re.sub(r"<[^>]+>", " ", th.group(2))
                nombre = re.sub(r"\s+", " ", nombre).strip()
                own.add((int(th.group(1)), nombre.upper()))
        return own

    def _clean(self):
        out = []
        with open(self.fp, "r", encoding="utf-8") as f:
            content = f.read()
        
        # ── BLOQUE 1: Eliminar cookie banner completo al inicio ──────────────
        # Busca desde "Consentimiento para cookies" hasta "Ficha de Partido"
        # Si lo encuentra, toma solo a partir de "Ficha de Partido"
        if "Ficha de Partido" in content:
            idx = content.find("Ficha de Partido")
            if idx > 0:
                content = content[idx:]
        
        # ── BLOQUE 2: Procesar líneas normalmente ────────────────────────────
        for line in content.split('\n'):
            # Normalizar espacios no separables y similares antes de strip
            c = line.replace("\xa0", " ").replace("\u200b", "").strip()
            if not c: continue
            # Solo filtrar separadores LARGOS (>=3 chars): preserva el "-" del marcador
            if len(c) >= 3 and set(c).issubset({'=','-','_','*',' '}): continue
            if any(c.startswith(p) for p in _FOOTER): continue
            out.append(c)
        return out

    def _cabecera(self, lines):
        i = 0; n = len(lines)
        while i < n and "Ficha de Partido" in lines[i]: i += 1

        if i < n and ("Jornada" in lines[i] or "Temporada" in lines[i]):
            m = re.search(r"Temporada\s*([\d\-]+)", lines[i])
            if m: self.d["temporada"] = m.group(1)
            m = re.search(r"Jornada\s*(\d+)", lines[i])
            if m: self.d["jornada"] = int(m.group(1))
            i += 1

        if i < n and re.match(r"\d{2}-\d{2}-\d{4}", lines[i]):
            p = lines[i].split(); self.d["fecha"] = p[0]
            if len(p) > 1: self.d["hora"] = p[1]
            i += 1

        if i < n and _nom(lines[i]): self.d["categoria"] = lines[i]; i += 1
        # ── RFEF: cabecera tiene "Alineaciones" como placeholder antes de los equipos reales
        if i < n and lines[i] == "Alineaciones": i += 1
        if i < n and _nom(lines[i]): self.d["equipo_local"] = lines[i]; i += 1
        if i < n and _nom(lines[i]): self.d["equipo_visitante"] = lines[i]; i += 1

        # Marcador hasta "Árbitros" — preservar "-" es CRITICO para el score
        buf = []
        while i < n and lines[i] != "Árbitros":
            buf.append(lines[i]); i += 1

        di = next((j for j, x in enumerate(buf) if x == "-"), -1)
        if di >= 0:
            nb = [x for j, x in enumerate(buf) if re.match(r"^\d+$", x) and j < di]
            na = [x for j, x in enumerate(buf) if re.match(r"^\d+$", x) and j > di]
            self.d["goles_local"]     = int(nb[0]) if nb else 0
            self.d["goles_visitante"] = int(na[0]) if na else 0

        # Árbitros (puede haber más de uno)
        if i < n and lines[i] == "Árbitros":
            i += 1
            _stop_arb = {"Goles","Estadio:","Estadio","Incidencias",
                         self.d["equipo_local"] or "",
                         self.d["equipo_visitante"] or ""}
            while i < n and lines[i] not in _stop_arb:
                if _nom(lines[i]) and not _dors(lines[i]):
                    self.d["arbitros"].append(lines[i])
                i += 1

        # RFEF intercala "Incidencias" entre árbitros y goles — saltarla
        if i < n and lines[i] == "Incidencias":
            i += 1

        # Goles: formato real del acta:
        # Estructura: (min') → marcador parcial (número - número) → nombre goleador
        # LÓGICA: Cada gol trae un marcador parcial. Si sube el primer número = gol local, si sube el segundo = gol visitante
        # ── Parsear secciones de goles: normales, penaltis y propias puerta ──
        _SEC_GOLES    = {"Gol", "G. Penalti", "G. Propia Puerta",
                         "Gola", "Penaltia", "Bere Atean"}   # euskera
        _SEC_FIN      = ("Estadio:", "Estadio", "PATROCINADORES OFICIALES",
                         "Sustituciones", "Tarjetas", "Árbitros")
        _ES_PROPIA    = {"G. Propia Puerta", "Bere Atean"}
        marcador_prev = (0, 0)

        # Avanzar hasta "Goles" (o sección de goles euskera)
        while i < n and lines[i] not in _SEC_GOLES and lines[i] != "Goles":
            i += 1

        # Iterar por todas las secciones de gol hasta llegar a fin de bloque
        while i < n:
            l = lines[i]
            if l.startswith("Ciudad:"):
                self.d["ciudad"] = l.replace("Ciudad:", "").strip()
                i += 1; continue
            if l in _SEC_FIN or l.startswith("Estadio"):
                break
            # Detectar si estamos en una sección de goles propias
            if l in _SEC_GOLES or l == "Goles":
                es_propia_sec = l in _ES_PROPIA
                i += 1; continue
            if _min_(l):
                minuto = _min_val(l)
                j = i + 1
                nums = []
                while j < n and (lines[j] == "-" or _dors(lines[j])):
                    if _dors(lines[j]): nums.append(int(lines[j]))
                    j += 1
                if (j < n and _nom(lines[j])
                        and lines[j] not in _SEC_GOLES
                        and not lines[j].startswith("Estadio")):
                    equipo_gol = "?"
                    if len(nums) >= 2:
                        marcador_actual = (nums[-2], nums[-1])
                        if marcador_actual[0] > marcador_prev[0]:
                            equipo_gol = "local"
                        elif marcador_actual[1] > marcador_prev[1]:
                            equipo_gol = "visitante"
                        marcador_prev = marcador_actual
                    self.d["goleadores"].append({
                        "minuto":  minuto,
                        "jugador": lines[j],
                        "equipo":  equipo_gol,
                        "propia":  es_propia_sec})
                    i = j + 1
                    continue
            i += 1

        for idx, l in enumerate(lines):
            if l.startswith("Estadio:") and not self.d["estadio"]:
                inline = l.replace("Estadio:","").strip()
                if inline:
                    self.d["estadio"] = inline
                elif idx+1 < len(lines) and lines[idx+1] not in _NOISE and not any(lines[idx+1].startswith(p) for p in _FOOTER+_CUERPO):
                    # siguiente linea es el nombre del estadio (puede empezar con "Ciudad")
                    self.d["estadio"] = lines[idx+1]
            if l.startswith("Ciudad:") and not self.d["ciudad"]:
                self.d["ciudad"] = l.replace("Ciudad:","").strip()

    def _equipos(self, lines):
        loc = self.d["equipo_local"]; vis = self.d["equipo_visitante"]
        if not loc or not vis: return

        def find_block(name, after=0):
            for i, l in enumerate(lines):
                if l == name and i > after:
                    if any(lines[j] == "Titulares" for j in range(i, min(i+7, len(lines)))):
                        return i
            return None

        il = find_block(loc, after=0)
        iv = find_block(vis, after=0)
        if il is None or iv is None: return
        if iv <= il:
            iv2 = find_block(vis, after=iv)
            if iv2 and iv2 > il: iv = iv2
            else: return

        tl,sl,stl,jl,ml,csl,entl,sent_l,dc_l,de_l,portl,dors_l = self._bloque(lines[il:iv])
        tv,sv,stv,jv,mv,csv,entv,sent_v,dc_v,de_v,portv,dors_v = self._bloque(lines[iv:])

        # Tarjetas: dos pasadas (una por equipo)
        mapa_eq = {j:"local"     for j in jl}
        mapa_eq.update({j:"visitante" for j in jv})
        # Entrenadores y staff en el mapa de equipo
        for n in (entl, sent_l, dc_l, de_l):
            if n: mapa_eq[n] = "local"
        for n in (entv, sent_v, dc_v, de_v):
            if n: mapa_eq[n] = "visitante"

        # Sets para clasificar destinatario de tarjeta
        jugadores_set  = set(jl) | set(jv)
        entrenadores_set = {n for n in (entl,entv) if n}
        staff_set = {n for n in (sent_l,sent_v,dc_l,dc_v,de_l,de_v) if n}

        tars = []; lm = None; et = "X"
        for l in lines:
            if l == "Tarjetas": et = "TAR"
            elif l in ("Sustituciones","Titulares","Suplentes","Cuerpo Técnico",
                       "Goles","Árbitros","PATROCINADORES OFICIALES"): et = "X"
            elif et == "TAR":
                if _min_(l): lm = _min_val(l)
                elif _nom(l) and lm is not None:
                    eq = mapa_eq.get(l, "?")
                    if l in entrenadores_set:
                        dest = "entrenador"
                    elif l in staff_set:
                        dest = "staff"
                    else:
                        dest = "jugador"
                    tars.append({"minuto":lm, "jugador":l, "equipo":eq, "tipo":"amarilla", "destinatario":dest})

        # Resolver equipo de cada gol
        # Si el jugador pertenece al equipo contrario al que anotó → gol en propia puerta
        for g in self.d["goleadores"]:
            jugador   = g.get("jugador", "")
            eq_marcador = g.get("equipo", "?")   # local/visitante según marcador parcial
            eq_jugador  = mapa_eq.get(jugador, "?")
            if eq_jugador != "?" and eq_marcador != "?" and eq_jugador != eq_marcador:
                # El jugador está en el equipo contrario → gol en propia puerta confirmado
                g["propia"] = True
            # El equipo del gol es el que indica el marcador parcial (no el del jugador)
            # Para propias: el gol se anota al equipo beneficiado (el del marcador)
            if eq_marcador != "?":
                g["equipo"] = eq_marcador
            elif eq_jugador != "?":
                g["equipo"] = eq_jugador  # fallback si no tenemos marcador parcial

        self.d["tarjetas"] = tars
        self.d.update({
            "entrenador_local":entl, "entrenador_visitante":entv,
            "segundo_entrenador_local":sent_l, "segundo_entrenador_visitante":sent_v,
            "delegado_campo_local":dc_l, "delegado_campo_visitante":dc_v,
            "delegado_equipo_local":de_l, "delegado_equipo_visitante":de_v,
            "titulares_local":tl, "titulares_visitante":tv,
            "suplentes_local":sl, "suplentes_visitante":sv,
            "convocados_sin_jugar_local":csl, "convocados_sin_jugar_visitante":csv,
            "jugadores_local":jl, "jugadores_visitante":jv,
            "sustituciones_local":stl, "sustituciones_visitante":stv,
            "minutos_jugadores":{**ml,**mv},
            "portero_local":portl, "portero_visitante":portv,
            "dorsales_local":dors_l, "dorsales_visitante":dors_v,
        })

    def _bloque(self, lines):
        tit=[]; sup=[]; sust=[]; entrenador=None; seg_ent=None; del_campo=None; del_equipo=None
        est="X"; cue_next=None; i=0; n=len(lines)
        # Para detección de portero: dorsal → nombre en titulares
        dorsal_tit = {}   # {nombre: dorsal_int}
        _last_dors = None
        while i < n:
            l = lines[i]
            # Transiciones de sección
            if   l == "Titulares":      est="TIT"; cue_next=None; _last_dors=None; i+=1; continue
            elif l == "Suplentes":      est="SUP"; cue_next=None; _last_dors=None; i+=1; continue
            elif l == "Cuerpo Técnico": est="CUE"; cue_next=None; i+=1; continue
            elif l == "Sustituciones":  est="SUS"; cue_next=None; i+=1; continue
            elif l in ("Tarjetas","Sanciones","PATROCINADORES OFICIALES",
                       "BABESLE OFIZIALAK","HORNITZAILE OFIZIALAK"):
                est="X"; i+=1; continue

            # Cuerpo Técnico: capturar entrenador, 2º entrenador y delegados
            if est == "CUE":
                if any(l.startswith(p) for p in _FOOTER): i+=1; continue
                if l.startswith("Entrenador:") or l == "Entrenador":
                    inline = l[len("Entrenador:"):].strip() if ":" in l else ""
                    if inline and _nom(inline) and inline != "No presenta":
                        entrenador = inline; cue_next = None
                    else:
                        cue_next = "ent"
                    i+=1; continue
                elif l.startswith("2ºEntrenador") or l == "2ºEntrenador":
                    inline = l.split(":",1)[1].strip() if ":" in l else ""
                    if inline and _nom(inline) and inline != "No presenta":
                        seg_ent = inline; cue_next = None
                    else:
                        cue_next = "sent"
                    i+=1; continue
                elif l.startswith("DEL. Campo:"):
                    inline = l[len("DEL. Campo:"):].strip()
                    if inline and _nom(inline): del_campo = inline
                    else: cue_next = "dc"
                    i+=1; continue
                elif l.startswith("DEL. Equipo:"):
                    inline = l[len("DEL. Equipo:"):].strip()
                    if inline and _nom(inline): del_equipo = inline
                    else: cue_next = "de"
                    i+=1; continue
                elif l.startswith("AUXILIAR") or l == "No presenta":
                    cue_next = None; i+=1; continue
                elif cue_next == "ent" and _nom(l) and l != "No presenta":
                    entrenador = l; cue_next = None
                elif cue_next == "sent" and _nom(l) and l != "No presenta":
                    seg_ent = l; cue_next = None
                elif cue_next == "dc" and _nom(l):
                    del_campo = l; cue_next = None
                elif cue_next == "de" and _nom(l):
                    del_equipo = l; cue_next = None
                elif _nom(l) and cue_next:
                    cue_next = None
                i+=1; continue

            # Filtro general para otros estados
            if any(l.startswith(p) for p in _FOOTER + _CUERPO): i+=1; continue

            if est == "TIT":
                if _dors(l):
                    _last_dors = int(l)
                elif _nom(l):
                    tit.append(l)
                    if _last_dors is not None:
                        dorsal_tit[l] = _last_dors
                    _last_dors = None
            elif est == "SUP":
                if not _dors(l) and _nom(l): sup.append(l)
            elif est == "SUS":
                # Patrón: [i-3]=dorsal_entra,[i-2]=nombre_entra,[i-1]=dorsal_sale,[i]=(MIN'),[i+1]=nombre_sale
                if _min_(l) and i >= 2 and i+1 < n:
                    ne, ds, ns = lines[i-2], lines[i-1], lines[i+1]
                    mn = _min_val(l)
                    if _nom(ne) and not _dors(ne) and _dors(ds) and _nom(ns) and not _dors(ns):
                        sust.append({"min":mn, "entra":ne, "sale":ns})
            i += 1

        mins = {j: self.MIN for j in tit}
        for s in sust:
            mins[s["sale"]]  = s["min"]
            mins[s["entra"]] = self.MIN - s["min"]
        mins = {k: max(0,v) for k,v in mins.items()}

        jug = list(tit)
        for s in sust:
            if s["entra"] not in jug: jug.append(s["entra"])

        # Convocados que no jugaron = suplentes no en jugadores
        conv_sin_jugar = [s for s in sup if s not in jug]

        # Deteccion de portero: dorsal 1 o 13 entre titulares; si no, primero del acta
        portero = None
        for nombre, dors in dorsal_tit.items():
            if dors in (1, 13):
                portero = nombre
                break
        if portero is None and tit:
            portero = tit[0]

        return tit, sup, sust, jug, mins, conv_sin_jugar, entrenador, seg_ent, del_campo, del_equipo, portero, dorsal_tit

    def _rfef_incidencias(self, lines):
        """
        Las actas RFEF no usan el bloque inline 'Tarjetas' con patron (min') nombre.
        Las sanciones vienen en texto largo bajo 'INCIDENCIAS':
          '- SD Eibar :'
          'En el minuto 29 el jugador (6) NOMBRE fue amonestado ...'
          '- SD Leioa :'
          'En el minuto 12 el jugador (12) NOMBRE fue expulsado ...'
          'En el minuto 90+4 el delegado NOMBRE fue expulsado ...'
        Este metodo parsea esas lineas y SOBRESCRIBE self.d['tarjetas'] y 'suspendidos'.
        """
        loc = self.d.get("equipo_local", "")
        vis = self.d.get("equipo_visitante", "")
        jl = set(self.d.get("jugadores_local", []))
        jv = set(self.d.get("jugadores_visitante", []))
        entl = self.d.get("entrenador_local")
        entv = self.d.get("entrenador_visitante")
        de_l = self.d.get("delegado_equipo_local")
        de_v = self.d.get("delegado_equipo_visitante")
        dc_l = self.d.get("delegado_campo_local")
        dc_v = self.d.get("delegado_campo_visitante")

        def _equipo_de(nombre, ctx_eq=None):
            if nombre in jl: return "local"
            if nombre in jv: return "visitante"
            if nombre in (entl, dc_l, de_l): return "local"
            if nombre in (entv, dc_v, de_v): return "visitante"
            return ctx_eq or "?"

        def _destinatario(nombre):
            if nombre in (entl, entv): return "entrenador"
            if nombre in {n for n in (dc_l,dc_v,de_l,de_v) if n}: return "staff"
            return "jugador"

        tars = []
        suspendidos = []

        # Patron: "En el minuto 45+4 el jugador (N) APELLIDO, NOMBRE fue amonestado ..."
        # Patron: "En el minuto 12 el jugador (N) APELLIDO, NOMBRE fue expulsado ..."
        # Patron: "En el minuto 90+4 el delegado APELLIDO, NOMBRE fue expulsado ..."
        pat_jug = re.compile(
            r"En el minuto\s+(\d+(?:\+\d+)?)\s+el\s+(?:jugador|entrenador)\s+\(\d+\)\s+(.+?)\s+fue\s+(amonestado|expulsado)",
            re.IGNORECASE
        )
        pat_staff = re.compile(
            r"En el minuto\s+(\d+(?:\+\d+)?)\s+el\s+(?:delegado|segundo entrenador|preparador|auxiliar)\s+(.+?)\s+fue\s+(amonestado|expulsado)",
            re.IGNORECASE
        )

        # Patron de linea de contexto de equipo: "- SD Eibar :" o "SD Eibar :"
        def _eq_ctx(linea):
            """Devuelve 'local'/'visitante'/None segun la linea de contexto de equipo."""
            s = linea.strip().lstrip("-").strip()
            if s.endswith(":"): s = s[:-1].strip()
            if loc and s == loc: return "local"
            if vis and s == vis: return "visitante"
            return None

        in_incidencias = False
        current_eq_ctx = None
        for l in lines:
            s = l.strip()
            if s in ("INCIDENCIAS", "JUGADORES", "AMONESTACIONES",
                     "EXPULSIONES", "DIRIGENTES y TECNICOS",
                     "DIRIGENTES y T\u00c9CNICOS", "OTRAS INCIDENCIAS"):
                in_incidencias = True
                continue
            if not in_incidencias:
                continue

            # Linea de contexto de equipo
            ctx = _eq_ctx(s)
            if ctx:
                current_eq_ctx = ctx
                continue

            for pat in (pat_jug, pat_staff):
                m = pat.search(s)
                if m:
                    min_str, nombre, accion = m.group(1), m.group(2).strip(), m.group(3).lower()
                    # Limpiar espacios dobles en nombre
                    nombre = re.sub(r'\s+', ' ', nombre).strip()
                    minuto = int(min_str.split("+")[0])
                    eq = _equipo_de(nombre, current_eq_ctx)
                    dest = _destinatario(nombre)
                    tipo = "amarilla" if accion == "amonestado" else "roja"
                    tars.append({
                        "minuto": minuto,
                        "jugador": nombre,
                        "equipo": eq,
                        "tipo": tipo,
                        "destinatario": dest,
                    })
                    if tipo == "roja":
                        suspendidos.append(nombre)
                    break

        if tars:
            self.d["tarjetas"] = tars
            self.d["suspendidos"] = list(dict.fromkeys(suspendidos))

    def _rfef_normalizar_mayusculas(self):
        """
        En actas RFEF los nombres mezclan mayusculas y minusculas segun como
        los introdujo cada club. Normalizar todo a MAYUSCULAS para consistencia
        con el resto de fuentes (alava, euskadi, etc.).
        """
        def _up(v):
            if isinstance(v, str): return v.upper()
            return v

        def _up_list(lst):
            return [_up(x) for x in lst]

        def _up_dict_keys(d):
            return {_up(k): v for k, v in d.items()}

        def _up_dict_vals(d):
            return {k: _up(v) for k, v in d.items()}

        # Campos de texto simples
        for campo in ("entrenador_local", "entrenador_visitante",
                      "segundo_entrenador_local", "segundo_entrenador_visitante",
                      "delegado_campo_local", "delegado_campo_visitante",
                      "delegado_equipo_local", "delegado_equipo_visitante",
                      "equipo_local", "equipo_visitante"):
            self.d[campo] = _up(self.d.get(campo))

        # Árbitros
        self.d["arbitros"] = _up_list(self.d.get("arbitros", []))

        # Listas de jugadores
        for campo in ("titulares_local", "titulares_visitante",
                      "suplentes_local", "suplentes_visitante",
                      "jugadores_local", "jugadores_visitante",
                      "convocados_sin_jugar_local", "convocados_sin_jugar_visitante",
                      "suspendidos"):
            self.d[campo] = _up_list(self.d.get(campo, []))

        # Sustituciones
        for campo in ("sustituciones_local", "sustituciones_visitante"):
            self.d[campo] = [
                {**s, "entra": _up(s["entra"]), "sale": _up(s["sale"])}
                for s in self.d.get(campo, [])
            ]

        # Goleadores
        self.d["goleadores"] = [
            {**g, "jugador": _up(g["jugador"])}
            for g in self.d.get("goleadores", [])
        ]

        # Tarjetas
        self.d["tarjetas"] = [
            {**t, "jugador": _up(t["jugador"])}
            for t in self.d.get("tarjetas", [])
        ]

        # minutos_jugadores: claves son nombres
        self.d["minutos_jugadores"] = _up_dict_keys(self.d.get("minutos_jugadores", {}))

        # porteros y dorsales
        for campo in ("portero_local", "portero_visitante"):
            if campo in self.d:
                self.d[campo] = _up(self.d[campo])
        for campo in ("dorsales_local", "dorsales_visitante"):
            if campo in self.d:
                self.d[campo] = _up_dict_keys(self.d[campo])

    def _fix_tarjetas_tipo(self):
        """
        Detectar doble amarilla (2 tarjetas al mismo jugador = doble_amarilla).
        Para fuentes distintas de rfef: el TXT no distingue roja directa, todas parten
        de 'amarilla'. Para rfef: _rfef_incidencias ya asigno 'roja' donde corresponde,
        no sobreescribir esas entradas.
        """
        count2 = defaultdict(int)
        for t in self.d["tarjetas"]:
            # Solo forzar amarilla si no es ya roja (rfef la asigna correctamente)
            if t.get("tipo") != "roja":
                t["tipo"] = "amarilla"
            j = t["jugador"]
            count2[j] += 1
            if t.get("tipo") == "amarilla":
                if count2[j] == 2:
                    t["tipo"] = "doble_amarilla"
                elif count2[j] > 2:
                    t["tipo"] = "post_expulsion"
        # Suspendidos por doble_amarilla o roja directa
        self.d["suspendidos"] = list(dict.fromkeys(
            t["jugador"] for t in self.d["tarjetas"]
            if t.get("tipo") in ("doble_amarilla", "roja")
        ))

    def _guardar(self):
        # ── APLICAR CORRECCIONES MANUALES ───────────────────────────────────
        acta_id = self.d.get("acta_id", "")
        if acta_id in CORRECCIONES_MANUALES:
            corr = CORRECCIONES_MANUALES[acta_id]
            self.d["goles_local"] = corr.get("goles_local", self.d.get("goles_local", 0))
            self.d["goles_visitante"] = corr.get("goles_visitante", self.d.get("goles_visitante", 0))
        
        # ── IDENTIFICAR EQUIPOS DE GOLEADORES ────────────────────────────────────
        # Construir conjunto de jugadores por equipo usando los titulares + suplentes
        jugadores_locales = set(self.d.get("jugadores_local", []))
        jugadores_visitantes = set(self.d.get("jugadores_visitante", []))
        
        # Identificar goleadores cuyo equipo aún es "?"
        # Y detectar propias por posición: jugador en equipo ≠ equipo del gol
        for gol in self.d["goleadores"]:
            jugador     = gol.get("jugador", "")
            eq_marcador = gol.get("equipo", "?")
            if eq_marcador == "?":
                if jugador in jugadores_locales:
                    gol["equipo"] = "local"
                elif jugador in jugadores_visitantes:
                    gol["equipo"] = "visitante"
            # Detectar propia por pertenencia: jugador en equipo contrario al del gol
            if not gol.get("propia"):
                eq_gol = gol.get("equipo", "?")
                if eq_gol == "local"     and jugador in jugadores_visitantes:
                    gol["propia"] = True
                elif eq_gol == "visitante" and jugador in jugadores_locales:
                    gol["propia"] = True

        # ── MARCADOR REAL del widget (HTML crudo) + reconciliar propias ─────
        # El fallback de plantilla deja los goles EN PROPIA en el equipo del
        # jugador (el que ENCAJA): sin el marcador autoritativo no hay conflicto
        # visible y el marcador sale mal (p.ej. 2-4 en vez de 3-3). Si tenemos
        # el widget decodificado, volteamos el sobrante al rival y marcamos
        # propia (la detección por plantilla de arriba ya la activa sola).
        wscore = self._widget_score() if getattr(self, "raw_html", None) else None
        if (wscore is not None and acta_id not in CORRECCIONES_MANUALES):
            wl, wv = wscore
            # Señal explícita de la web (lgolpp): el beneficiado es el RIVAL
            # del equipo del jugador. Prioridad máxima sobre el marcador.
            prop_raw = self._goles_propias_raw()
            for g in self.d["goleadores"]:
                j = g.get("jugador", "") or ""
                if (g.get("minuto"), j.strip().upper()) in prop_raw:
                    if j in jugadores_locales:
                        g["equipo"] = "visitante"; g["propia"] = True
                    elif j in jugadores_visitantes:
                        g["equipo"] = "local"; g["propia"] = True
                    else:
                        g["propia"] = True
            # Reconciliar: el fallback de plantilla deja el gol en propia en el
            # equipo del jugador (el que ENCAJA). Si el marcador autoritativo no
            # cuadra con los goles asignados, voltear el sobrante al rival.
            cuenta = {"local": 0, "visitante": 0}
            for g in self.d["goleadores"]:
                e = g.get("equipo")
                if e in cuenta:
                    cuenta[e] += 1
            for lado, deseado in (("local", wl), ("visitante", wv)):
                sobrante = cuenta[lado] - deseado
                if sobrante > 0:
                    for g in [x for x in self.d["goleadores"]
                              if x.get("equipo") == lado
                              and not x.get("propia")][-sobrante:]:
                        g["equipo"] = "visitante" if lado == "local" else "local"
                        g["propia"] = True
            # propia re-verificada tras el volteo (jugador en equipo contrario)
            for g in self.d["goleadores"]:
                eq = g.get("equipo"); j = g.get("jugador", "") or ""
                if eq == "local" and j in jugadores_visitantes:
                    g["propia"] = True
                elif eq == "visitante" and j in jugadores_locales:
                    g["propia"] = True
            self.d["goles_local"]     = wl
            self.d["goles_visitante"] = wv
            self.d["_marcador_widget"] = True

        # Calcular el marcador contando goles por equipo (después de identificar)
        goles = self.d["goleadores"]
        goles_con_equipo = [g for g in goles if g.get("equipo") in ("local", "visitante")]

        # Solo recalcular si hay goleadores y NO hay corrección manual
        # (ni marcador autoritativo del widget, que no se debe pisar)
        if (goles_con_equipo and acta_id not in CORRECCIONES_MANUALES
                and not self.d.get("_marcador_widget")):
            gl_calc = sum(1 for g in goles_con_equipo if g.get("equipo") == "local")
            gv_calc = sum(1 for g in goles_con_equipo if g.get("equipo") == "visitante")
            self.d["goles_local"]     = gl_calc
            self.d["goles_visitante"] = gv_calc
        
        # ── CALCULAR RESULTADO ───────────────────────────────────────────────────
        gl = self.d.get("goles_local", 0)
        gv = self.d.get("goles_visitante", 0)
        
        if gl > gv:
            self.d["resultado"] = "W"
        elif gl < gv:
            self.d["resultado"] = "L"
        elif gl == gv and (gl > 0 or gv > 0):
            self.d["resultado"] = "D"
        else:
            # 0-0: es válido si hay titulares
            self.d["resultado"] = "D" if (self.d.get("titulares_local") or self.d.get("titulares_visitante")) else "pendiente"
        
        # ── GUARDAR JSON ─────────────────────────────────────────────────────────
        with open(os.path.join(self.json_dir, f"{self.d['acta_id']}.json"),
                  "w", encoding="utf-8") as f:
            json.dump(self.d, f, indent=2, ensure_ascii=False)


def _reparsear_una_acta(args):
    """Reparsea un único TXT -> JSON. Vive a nivel de módulo (no dentro de
    main()) porque ProcessPoolExecutor necesita poder importar la función
    por nombre para mandarla a cada proceso worker.
    Cada acta es 100% independiente (lee su propio TXT, escribe su propio
    JSON), así que repartirlas entre procesos no cambia el resultado, solo
    la velocidad. Los errores se capturan aquí (no se relanzan) para que
    una acta problemática no tumbe el resto ni se pierda del recuento,
    igual que hacía el bucle secuencial original."""
    ruta_txt, json_dir, fuente_key = args
    try:
        Parser(ruta_txt, json_dir=json_dir, fuente=fuente_key).process()
        return (os.path.basename(ruta_txt), True, None)
    except Exception as e:
        return (os.path.basename(ruta_txt), False, str(e))

# ═══════════════════════════════════════════════════════════════
#  CORRECCIONES MANUALES  —  Partidos con incidencias documentadas
#  Formato: "acta_id": {"goles_local": X, "goles_visitante": Y}
#  Usar SOLO para actas donde el TXT está malformado y tienes certeza del resultado
# ═══════════════════════════════════════════════════════════════
CORRECCIONES_MANUALES = {
    "1370207": {"goles_local": 3, "goles_visitante": 1},  # SANTA MARÍA-VITORIA A.D. vs REKABERRI, C.D. — TXT malformado
}

# ═══════════════════════════════════════════════════════════════
#  CLUBES  —  Mapa nombre_en_acta → nombre_club_matriz
#  Añadir aquí cada equipo que aparezca en las actas.
#  Los que no estén se dejan solos (sin matriz).
# ═══════════════════════════════════════════════════════════════
CLUB_MAP = {
    # Formato:  "Nombre tal como aparece en el acta": "Nombre del club matriz",
    # Ejemplo con equipos A y B del mismo club:
    # "Abetxuko A":  "Abetxuko",
    # "Abetxuko B":  "Abetxuko",
    # "Abetxuko":    "Abetxuko",
}

# ═══════════════════════════════════════════════════════════════
#  ENTRENADORES  —  Mapa variante_mal_escrita → nombre_canónico
#  Añadir aquí cada entrenador con grafías distintas en las actas.
#  Las variantes se normalizan ANTES de acumular estadísticas,
#  así aparecen unificados en la tabla de entrenadores.
# ═══════════════════════════════════════════════════════════════
ENTRENADORES_MAP = {
    # Formato:  "Como aparece mal en el acta": "Nombre canónico correcto",
    # El nombre canónico es el que tiene más partidos o el más completo.
    "RUIZ DE GALINA GARCIA, PABLO":  "RUIZ DE GAUNA GARCIA, PABLO",
    "RUIZ DE GAUNA, PABLO":          "RUIZ DE GAUNA GARCIA, PABLO",
    "RUIZ DE GAUNA GARCIA , PABLO":  "RUIZ DE GAUNA GARCIA, PABLO",
    "RUIZ DE GAUNA GARCÍA, PABLO":   "RUIZ DE GAUNA GARCIA, PABLO",
    "RUIZ DE GAUNA GARCÍA , PABLO":  "RUIZ DE GAUNA GARCIA, PABLO",
    "PRECIADO GALAN, JOSÉ ANTONIO":  "RUIZ DE GAUNA GARCIA, PABLO",
    "PRECIADO GALAN, JOSE ANTONIO":  "RUIZ DE GAUNA GARCIA, PABLO",
}

# ═══════════════════════════════════════════════════════════════
#  PROVINCIA_MAP  —  nombre_canon_club → provincia
#  Clave: nombre normalizado (mayúsculas, sin puntos ni comas extra).
#  Las ediciones hechas en la UI se guardan en localStorage del HTML
#  y tienen prioridad sobre este mapa estático.
# ═══════════════════════════════════════════════════════════════
PROVINCIA_MAP = {
    # ── Álava / Araba ────────────────────────────────────────────
    "ABETXUKO ADC":                  "Álava",
    "AJURIA ABENDAÑO CD":            "Álava",
    "ALEGRÍA CD":                    "Álava",
    "ALIPENDI CD":                   "Álava",
    "AMURRIO CLUB":                  "Álava",
    "ARIZNABARRA":                   "Álava",
    "ARIZNABARRA CD":                "Álava",
    "ARRUPE-CHAMINADE CDDF":         "Álava",
    "BAIGENE CORAZONISTAS":          "Álava",
    "BETOÑO CD":                     "Álava",
    "CENTENIAL FUTBOL CLUB":         "Álava",
    "CHAMINADE MARIANISTAS KE AD":   "Álava",
    "COLEGIO SAN PRUDENCIO AD":      "Álava",
    "CORAZONISTAS DE VITORIA CD":    "Álava",
    "DEPORTIVO ALAVES":              "Álava",
    "DEPORTIVO ALAVES SAD":          "Álava",
    "ELPROEX ETXEZARRA":             "Álava",
    "ELPROEX ARIZNABARRA":           "Álava",
    "ETXEZAR RA ZURIA DE VITORIACDF":"Álava",
    "IBAELAKUA CDF":                 "Álava",
    "IPAR ARRIAGA GASTEIZ CD":       "Álava",
    "IRU-BAT SANTA LUCIA SD":        "Álava",
    "KASKAGORRRI AMURRIOKO FT":      "Álava",
    "KOSTKAS CD":                    "Álava",
    "LAKUA ARRIAGA CD":              "Álava",
    "LAKUA DE VITORIA-GASTEIZ CDDF": "Álava",
    "LAKUA DE VITORIA-GASTEIZ CDF":  "Álava",
    "LANTARON CD":                   "Álava",
    "LAUDEIO F SAN ROKEZAR CD":      "Álava",
    "MARITURRIKOANK KT":             "Álava",
    "MERCEDARIAS KE AD":             "Álava",
    "NANCALRES CD":                  "Álava",
    "OLARIZU CD":                    "Álava",
    "REKABBERRRI CD":                "Álava",
    "SALVATIERRA SD":                "Álava",
    "SAN MARTIN CDF":                "Álava",
    "SAN VIATOR AD":                 "Álava",
    "SANTA MARUÍA-VITORIA AD":       "Álava",
    "URGATZI KK":                    "Álava",
    "URKI CD":                       "Álava",
    "VASCONIA CD":                   "Álava",
    "ZARAMAGA CF":                   "Álava",
    "ZUIA 02 CDF Y":                 "Álava",
    "ZUIA 02 CDF y":                 "Álava",

    # ── Bizkaia ──────────────────────────────────────────────────
    "AMOREBIETA":                    "Bizkaia",
    "ARRARTIA CD":                   "Bizkaia",
    "ATHLETIC CLUB":                 "Bizkaia",
    "BARAKALDO CF":                  "Bizkaia",
    "BATZAR RE FUTBOL-5 AD":         "Bizkaia",
    "CULTURAL DPVA DURANGO S":       "Bizkaia",
    "DANOK BAT":                     "Bizkaia",
    "DANOK BAT CLUB":                "Bizkaia",
    "DEUSTO SD":                     "Bizkaia",
    "GERNIKA SD":                    "Bizkaia",
    "GETXO CD":                      "Bizkaia",
    "INDAUTXU SD":                   "Bizkaia",
    "LEIOA SD":                      "Bizkaia",
    "LOYOLA INDAUCHU CLUB":          "Bizkaia",
    "PORTUAGALETE":                  "Bizkaia",
    "ROMO FC":                       "Bizkaia",
    "SAN IGNACIO CD":                "Bizkaia",
    "SANTUTXU FC":                   "Bizkaia",

    # ── Gipuzkoa ─────────────────────────────────────────────────
    "ANAITASUNA CD":                 "Gipuzkoa",
    "ANTIGUOKO KIROL ELKARTEA":      "Gipuzkoa",
    "AÑORGA KKE":                    "Gipuzkoa",
    "ARETXABALETA KE UDA":           "Gipuzkoa",
    "ARETXABALETA UD":               "Gipuzkoa",
    "BEASAIN SD":                    "Gipuzkoa",
    "BERGARA KE":                    "Gipuzkoa",
    "EIBAR SD":                      "Gipuzkoa",
    "HERNANI CD":                    "Gipuzkoa",
    "HONDARRIBIA FE":                "Gipuzkoa",
    "INDARTSU":                      "Gipuzkoa",
    "LAGUN ONAK CD":                 "Gipuzkoa",
    "OIARTZUN KE":                   "Gipuzkoa",
    "REAL SOCIEDAD DE FUTBOL":       "Gipuzkoa",
    "TOLOSA CLUB DE FUTBOL":         "Gipuzkoa",
    "ZARAUTZ KE":                    "Gipuzkoa",
}

# ═══════════════════════════════════════════════════════════════
#  LOGOS  —  URLs de escudos conocidas (añadir más aquí)
# ═══════════════════════════════════════════════════════════════
LOGOS_FILE = os.path.join(OUTPUT_DIR, "team_logos.json")

# Mapa nombre_equipo → URL pública del escudo en FAF
LOGOS_CONOCIDOS = {
    "Abetxuko":   "https://www.faf-aff.eus/pnfg/pimg/Clubes/00100_0009920549_abetxuko.png",
    "Ariznabarra": "https://www.faf-aff.eus/pnfg/pimg/MigracionPV/escudosFAF/6.jpg",
    "San Viator":  "https://www.faf-aff.eus/pnfg/pimg/Clubes/00100_0009900867_san_viator__1_.png",
}

def scrape_logos(driver=None):
    """
    Descarga los escudos definidos en LOGOS_CONOCIDOS y los guarda como data-URI en caché.
    Para añadir un nuevo equipo basta con añadir su entrada en LOGOS_CONOCIDOS.
    """
    import urllib.request

    # 1. Cargar caché existente
    logos = {}
    try:
        with open(LOGOS_FILE, "r", encoding="utf-8") as f:
            logos = json.load(f)
        print(f"[+] Logos cargados desde caché: {len(logos)} equipos")
    except:
        pass

    # 2. Descargar los que falten en caché
    nuevos = 0
    for equipo, url in LOGOS_CONOCIDOS.items():
        if equipo in logos:
            continue
        try:
            ext = url.rsplit('.', 1)[-1].lower()
            ctype = "image/jpeg" if ext in ("jpg", "jpeg") else "image/png"
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENTS[0]})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = resp.read()
                ct = resp.headers.get("Content-Type", ctype).split(";")[0].strip()
                b64 = base64.b64encode(data).decode("utf-8")
                logos[equipo] = f"data:{ct};base64,{b64}"
                print(f"  [+] Logo descargado: {equipo}")
                nuevos += 1
        except Exception as e:
            print(f"  [!] No se pudo descargar logo de {equipo}: {e}")

    # 3. Guardar caché actualizada
    if nuevos:
        with open(LOGOS_FILE, "w", encoding="utf-8") as f:
            json.dump(logos, f, ensure_ascii=False)
        print(f"[+] Caché de logos actualizada ({len(logos)} equipos)")
    elif not logos:
        print("[~] Sin logos disponibles — se usarán iniciales como avatares")

    return logos


# ═══════════════════════════════════════════════════════════════
#  HTML  —  token approach para evitar bugs de f-string
# ═══════════════════════════════════════════════════════════════
TOKEN = "___ACTAS_JSON_DATA___"
TOKEN_LOGOS = "___TEAM_LOGOS_DATA___"
TOKEN_CLUBS = "___CLUB_MAP_DATA___"
TOKEN_ENTRENADORES = "___ENTRENADORES_MAP_DATA___"
TOKEN_PROVINCIA = "___PROVINCIA_MAP_DATA___"
TOKEN_CAT_CFG = "___CAT_CFG_DATA___"
TOKEN_DISCREPANCIAS = "___DISCREPANCIAS_DATA___"
TOKEN_LIGAS_TC      = "___LIGAS_CON_TABLA_DATA___"

def generar_html():
    """Genera el HTML con todos los datos embebidos (todas las fuentes combinadas).
    Si existe FAF_Stats_Data.json, carga datos de allí para preservar cambios locales."""
    
    # ── Intentar cargar datos del JSON si existe ────────────────────────────
    json_data_path = os.path.join(HTML_DIR, "FAF_Stats_Data.json")
    datos_json = {}
    
    if os.path.exists(json_data_path):
        try:
            with open(json_data_path, "r", encoding="utf-8") as f:
                datos_json = json.load(f)
            print(f"[*] Cargados datos locales desde: {json_data_path}")
        except Exception as e:
            print(f"[~] No se pudieron cargar datos del JSON: {e}")
    
    actas_validas = []
    print("[*] Cargando actas...")
    for clave, fcfg in FUENTES.items():
        jdir = fcfg["json_dir"]
        if not os.path.isdir(jdir):
            print(f"  [!] Directorio no existe: {jdir}")
            continue
        actas_fuente = 0
        for fn in sorted(f for f in os.listdir(jdir) if f.endswith(".json")):
            try:
                with open(os.path.join(jdir, fn), encoding="utf-8") as f:
                    d = json.load(f)
                if d.get("equipo_local") and d.get("equipo_visitante"):
                    # Garantizar que siempre tiene el campo fuente
                    if "fuente" not in d:
                        d["fuente"] = clave
                    actas_validas.append(d)
                    actas_fuente += 1
                    #DEBUG: Acta 1370129
                    if d.get("acta_id") == "1370129":
                        print(f"  [+] Acta 1370129 cargada: {d.get('equipo_local')} vs {d.get('equipo_visitante')}, resultado={d.get('resultado')}")
            except Exception as e:
                if fn.endswith("1370129.json"):
                    print(f"  [!] Error cargando 1370129.json: {e}")
                pass
        if actas_fuente > 0:
            print(f"  [+] {clave}: {actas_fuente} actas cargadas")

    # ── DEDUPE CROSS-FUENTE ─────────────────────────────────────────────────
    # El mismo partido puede estar en RFEF (N_) y en la territorial (R_/etc.).
    # Nos quedamos con la versión con MÁS datos y guardamos las descartadas
    # por fuente para que el runner NO las vuelva a descargar.
    antes = len(actas_validas)
    actas_validas, drop_por_fuente = dedupe_actas(actas_validas)
    descartadas = sum(len(v) for v in drop_por_fuente.values())
    if descartadas:
        print(f"  [*] Dedupe cross-fuente: {antes} -> {len(actas_validas)} "
              f"({descartadas} actas duplicadas descartadas)")
    for fkey, ids in drop_por_fuente.items():
        dup_file = os.path.join(os.path.dirname(FUENTES[fkey]["empty_file"]),
                                "duplicados_descartadas.json")
        antiguas = load_duplicados(dup_file)
        save_duplicados(antiguas | ids, dup_file)
        print(f"      {fkey}: {len(ids)} duplicadas registradas en {dup_file}")

    # ── DETECTAR Y REGISTRAR PARTIDOS FALTANTES ────────────────────────────
    partidos_faltantes = {}
    for fuente_key, fuente_cfg in FUENTES.items():
        jdir = fuente_cfg["json_dir"]
        if os.path.isdir(jdir):
            try:
                gestor = GestorLiga(jdir)
                faltantes = gestor.obtener_partidos_faltantes()
                if faltantes:
                    partidos_faltantes[fuente_key] = faltantes
                    # Guardar a archivo específico por fuente
                    faltantes_file = os.path.join(fuente_cfg["output_dir"], "partidos_faltantes.json")
                    try:
                        with open(faltantes_file, "w", encoding="utf-8") as f:
                            json.dump(faltantes, f, ensure_ascii=False, indent=2)
                        print(f"[+] {fuente_key}: {len(faltantes)} partidos faltantes registrados")
                    except:
                        pass
            except Exception as e:
                pass
    

    db_js   = json.dumps(actas_validas, ensure_ascii=False, separators=(',', ':'))
    gen     = time.strftime("%d/%m/%Y %H:%M")
    total   = len(actas_validas)
    n_jug   = len({j for a in actas_validas
                   for j in list(a.get("jugadores_local", [])) + list(a.get("jugadores_visitante", []))})

    # Cargar logos (descarga los que falten y usa caché)
    logos = scrape_logos()
    logos_js = json.dumps(logos, ensure_ascii=False, separators=(',', ':'))

    # Mapa de clubes (nombre_en_acta → club_matriz)
    club_map_js = json.dumps(CLUB_MAP, ensure_ascii=False, separators=(',', ':'))

    # Mapa de entrenadores (variante_mal_escrita → nombre_canónico)
    entrenadores_map_js = json.dumps(ENTRENADORES_MAP, ensure_ascii=False, separators=(',', ':'))

    # Mapa de provincias (nombre_canon_club → provincia)
    provincia_map_js = json.dumps(PROVINCIA_MAP, ensure_ascii=False, separators=(',', ':'))

    # Config de categorías (renombres y grupos definidos en el HTML anterior, vacío por defecto al inicio)
    cat_cfg_js = json.dumps({}, ensure_ascii=False, separators=(',', ':'))

    # Discrepancias de tablas cruzadas (generadas por Modo 12)
    try:
        disc_path = os.path.join(BASE_DIR, "2", "tablas_cruzadas_discrepancias.json")
        with open(disc_path, encoding="utf-8") as f:
            disc_data = json.load(f)
    except:
        disc_data = []
    disc_js = json.dumps(disc_data, ensure_ascii=False, separators=(',', ':'))

    # Ligas que SÍ han sido analizadas por Modo 12 (tienen tabla cruzada descargada)
    # Se deriva de las discrepancias: cualquier (categoria, temporada) que aparezca
    # en disc_data ha sido analizada — incluso si no tiene discrepancias pendientes.
    # Adicionalmente, cargamos tablas_cruzadas.json para incluir ligas sin discrepancias.
    ligas_con_tabla = set()
    for d in disc_data:
        cat  = d.get("categoria", "")
        temp = d.get("temporada", "")
        if cat:
            ligas_con_tabla.add(f"{cat}|||{temp}")
    try:
        tc_path = os.path.join(BASE_DIR, "2", "tablas_cruzadas.json")
        with open(tc_path, encoding="utf-8") as f:
            tc_data = json.load(f)
        for t in tc_data:
            cat  = t.get("categoria", "")
            temp = t.get("temporada", "")
            if cat:
                ligas_con_tabla.add(f"{cat}|||{temp}")
    except:
        pass
    ligas_con_tabla_js = json.dumps(sorted(ligas_con_tabla), ensure_ascii=False, separators=(',', ':'))

    # ── Template HTML (sin f-string, usa TOKEN para los datos) ─────────────
    tpl = r"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FAF Stats</title>
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{--bg:#07090e;--s1:#0d1017;--s2:#141921;--b:#1a2235;--b2:#222e45;
  --acc:#00f0a0;--a2:#ff4f37;--a3:#f5c842;--a4:#4d8bff;--a5:#b06fff;
  --tx:#dde3f0;--mu:#4a5a7a;--r:8px;--hw:#00f0a0;--dr:#f5c842;--lw:#ff4f37}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--tx);font-family:'Inter',sans-serif;font-size:14px;min-height:100vh}
body::before{content:'';position:fixed;inset:0;
  background:radial-gradient(ellipse 80% 50% at 10% -10%,rgba(0,240,160,.07) 0%,transparent 50%),
             radial-gradient(ellipse 60% 40% at 90% 110%,rgba(77,139,255,.05) 0%,transparent 50%);
  pointer-events:none;z-index:0}
header{position:sticky;top:0;z-index:100;height:56px;background:rgba(7,9,14,.96);
  backdrop-filter:blur(20px);border-bottom:1px solid var(--b);
  display:flex;align-items:center;gap:14px;padding:0 20px}
.logo{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:5px;
  background:linear-gradient(135deg,var(--acc),#009960);-webkit-background-clip:text;
  -webkit-text-fill-color:transparent;white-space:nowrap}
.logo-m{font-size:10px;color:var(--mu);font-family:'JetBrains Mono',monospace;line-height:1.3;white-space:nowrap}
nav{display:flex;gap:1px;flex:1;overflow-x:auto;scrollbar-width:none;padding:6px 0}
nav::-webkit-scrollbar{display:none}
.nb{background:none;border:none;color:var(--mu);padding:6px 13px;border-radius:6px;
  cursor:pointer;font-family:'Inter',sans-serif;font-size:12px;font-weight:500;
  white-space:nowrap;transition:.15s;position:relative}
.nb:hover{color:var(--tx);background:rgba(255,255,255,.04)}
.nb.on{color:var(--acc);font-weight:600}
.nb.on::after{content:'';position:absolute;bottom:-6px;left:13px;right:13px;height:2px;background:var(--acc);border-radius:2px}
.bdg{background:var(--acc);color:#000;font-size:9px;font-weight:700;border-radius:8px;padding:1px 5px;margin-left:4px;font-family:'JetBrains Mono',monospace}
.app{position:relative;z-index:1;max-width:1440px;margin:0 auto;padding:20px 18px}
.page{display:none}.page.on{display:block;animation:fi .2s ease}
@keyframes fi{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.hgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:22px}
.hc{background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:14px 16px;position:relative;overflow:hidden}
.hc::before{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.hc.g::before{background:linear-gradient(90deg,var(--acc),#006640)}
.hc.b::before{background:linear-gradient(90deg,var(--a4),#1a3a80)}
.hc.y::before{background:linear-gradient(90deg,var(--a3),#7a6000)}
.hc.r::before{background:linear-gradient(90deg,var(--a2),#7a1a0a)}
.hc.p::before{background:linear-gradient(90deg,var(--a5),#4a1a80)}
.hv{font-family:'Bebas Neue',sans-serif;font-size:34px;line-height:1}
.hl{font-size:10px;color:var(--mu);margin-top:3px;text-transform:uppercase;letter-spacing:.6px}
.st{font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:2px;
  color:var(--tx);margin:20px 0 12px;display:flex;align-items:center;gap:10px}
.st::after{content:'';flex:1;height:1px;background:var(--b)}
.fb{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap;align-items:center}
.fb select,.fb input{background:var(--s1);border:1px solid var(--b);color:var(--tx);
  padding:7px 11px;border-radius:var(--r);font-family:'Inter',sans-serif;font-size:13px;
  cursor:pointer;outline:none;transition:border-color .15s;min-width:0}
.fb select:hover,.fb input:hover,.fb select:focus,.fb input:focus{border-color:rgba(0,240,160,.4)}
.fb input{flex:1;min-width:160px}
.tw{overflow-x:auto;border-radius:var(--r);border:1px solid var(--b)}
table{width:100%;border-collapse:collapse}
thead tr{background:var(--s2)}
th{padding:9px 13px;text-align:left;font-family:'Bebas Neue',sans-serif;font-size:11px;
  letter-spacing:1px;color:var(--mu);white-space:nowrap;cursor:pointer;user-select:none;transition:color .15s}
th:hover{color:var(--acc)}
td{padding:9px 13px;border-top:1px solid rgba(255,255,255,.04);font-size:13px;white-space:nowrap}
tr:hover td{background:rgba(255,255,255,.025)}
.num{font-family:'JetBrains Mono',monospace;text-align:right}
.pts{font-family:'Bebas Neue',sans-serif;font-size:19px;color:var(--acc)}
.gdp{color:var(--hw)}.gdn{color:var(--lw)}
.p1 td:first-child{color:#ffd700!important;font-weight:700}
.p2 td:first-child{color:#c0c0c0!important;font-weight:700}
.p3 td:first-child{color:#cd7f32!important;font-weight:700}
/* Zona ascenso/descenso en clasificación */
tr.zn-camp td:first-child{color:#ffd700!important;font-weight:700}
tr.zn-asc  td{background:rgba(0,240,160,.07)!important}
tr.zn-asc  td:first-child{color:var(--hw)!important;font-weight:700}
tr.zn-prom td{background:rgba(77,139,255,.07)!important}
tr.zn-prom td:first-child{color:var(--a4)!important;font-weight:700}
tr.zn-desc td{background:rgba(255,79,55,.07)!important}
tr.zn-desc td:first-child{color:var(--a2)!important;font-weight:700}
tr.zn-desc2 td{background:rgba(176,111,255,.07)!important}
tr.zn-desc2 td:first-child{color:var(--a5)!important;font-weight:700}
.zona-badge{display:inline-block;font-size:9px;font-weight:700;border-radius:4px;padding:1px 5px;margin-left:6px;font-family:'JetBrains Mono',monospace;vertical-align:middle;white-space:nowrap}
.zb-asc{background:rgba(0,240,160,.18);border:1px solid rgba(0,240,160,.4);color:var(--hw)}
.zb-prom{background:rgba(77,139,255,.18);border:1px solid rgba(77,139,255,.4);color:var(--a4)}
.zb-desc{background:rgba(255,79,55,.18);border:1px solid rgba(255,79,55,.4);color:var(--a2)}
.zb-desc2{background:rgba(176,111,255,.18);border:1px solid rgba(176,111,255,.4);color:var(--a5)}
.zb-nofil{background:rgba(245,200,66,.14);border:1px solid rgba(245,200,66,.4);color:var(--a3)}
.fd{display:inline-block;width:8px;height:8px;border-radius:50%;margin:0 1px}
.fd.W{background:var(--hw)}.fd.D{background:var(--dr)}.fd.L{background:var(--lw)}
.mc{background:var(--s1);border:1px solid var(--b);border-radius:var(--r);
  padding:11px 15px;margin-bottom:7px;display:flex;align-items:center;gap:10px;
  cursor:pointer;transition:.15s}
.mc:hover{border-color:rgba(0,240,160,.3);background:var(--s2);transform:translateX(2px)}
.mm{font-size:11px;color:var(--mu);font-family:'JetBrains Mono',monospace;min-width:65px;line-height:1.4}
.mts{flex:1;display:flex;align-items:center;gap:8px}
.mt{font-weight:600;font-size:13px;flex:1;overflow:hidden;text-overflow:ellipsis}
.mt.h{text-align:right}
.ms{font-family:'Bebas Neue',sans-serif;font-size:22px;background:var(--s2);
  border:1px solid var(--b2);border-radius:5px;padding:2px 12px;
  white-space:nowrap;min-width:70px;text-align:center}
.ms.hw{border-color:rgba(0,240,160,.4);color:var(--hw)}
.ms.aw{border-color:rgba(255,79,55,.35);color:var(--lw)}
.ms.dr{border-color:rgba(245,200,66,.35);color:var(--dr)}
.mcat{font-size:10px;color:var(--mu);background:var(--s2);padding:2px 7px;
  border-radius:8px;border:1px solid var(--b);white-space:nowrap;flex-shrink:0}
.fbadge{font-size:9px;font-weight:700;padding:1px 5px;border-radius:4px;white-space:nowrap;flex-shrink:0;font-family:'JetBrains Mono',monospace}
.fbadge.eus{background:rgba(245,200,66,.15);border:1px solid rgba(245,200,66,.4);color:var(--a3)}
.fbadge.alv{background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.3);color:var(--a4)}
.fbadge.gip{background:rgba(176,111,255,.12);border:1px solid rgba(176,111,255,.3);color:var(--a5)}
.fbadge.biz{background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2)}
.fbadge.rfef{background:rgba(255,50,50,.18);border:1px solid rgba(220,0,0,.4);color:#ff4040}
.gr{display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid rgba(255,255,255,.05)}
.gr:first-child{border-top:none}
.grk{font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--mu);min-width:26px}
.gv{font-family:'Bebas Neue',sans-serif;font-size:20px;color:var(--acc)}
.bar{height:3px;background:var(--b2);border-radius:2px;margin-top:4px;overflow:hidden}
.bf{height:100%;border-radius:2px;background:var(--acc);transition:width .5s ease}
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:10px;margin-bottom:16px}
.sc{background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 14px;position:relative;overflow:hidden}
.sc::before{content:'';position:absolute;top:0;left:0;right:0;height:2px;background:var(--acc)}
.sc.r::before{background:var(--a2)}.sc.y::before{background:var(--a3)}
.sc.b::before{background:var(--a4)}.sc.p::before{background:var(--a5)}
.sv{font-family:'Bebas Neue',sans-serif;font-size:30px;line-height:1}
.sl{font-size:10px;color:var(--mu);margin-top:2px;text-transform:uppercase;letter-spacing:.5px}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
@media(max-width:900px){.g2,.g3{grid-template-columns:1fr}}
.card{background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:18px}
.jh{margin-bottom:5px;padding:5px 0;font-family:'Bebas Neue',sans-serif;font-size:13px;
  letter-spacing:1.5px;color:var(--mu);border-bottom:1px solid var(--b);display:flex;gap:10px}
.pl{padding:5px 0;border-top:1px solid rgba(255,255,255,.04);font-size:12px;display:flex;align-items:center;gap:6px}
.pl:first-child{border-top:none}
.phdr{display:flex;align-items:center;gap:16px;padding:16px;background:var(--s2);border-radius:10px;margin-bottom:18px;border:1px solid var(--b)}
.av{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,var(--acc),#004428);
  display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:24px;color:#000;flex-shrink:0}
.pnm{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:1px;line-height:1}
.ptm{font-size:12px;color:var(--mu);margin-top:3px}
.h2hg{display:grid;grid-template-columns:1fr auto 1fr;gap:16px;align-items:center;
  background:var(--s1);border:1px solid var(--b);border-radius:12px;padding:20px;margin-bottom:14px}
.h2ht{font-family:'Bebas Neue',sans-serif;font-size:18px;text-align:center;line-height:1.3}
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.8);backdrop-filter:blur(8px);
  z-index:200;display:none;align-items:center;justify-content:center;padding:16px}
.modal-bg.open{display:flex}
.modal{background:var(--s1);border:1px solid var(--b);border-radius:14px;padding:24px;
  max-width:740px;width:100%;max-height:90vh;overflow-y:auto}
.mhdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.mtit{font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:1px}
.mcl{background:none;border:none;color:var(--mu);cursor:pointer;font-size:22px;padding:4px 8px;border-radius:4px;transition:.15s}
.mcl:hover{color:var(--tx);background:var(--b)}
.mscore{font-family:'Bebas Neue',sans-serif;font-size:54px;text-align:center;margin:10px 0 6px;line-height:1}
.twocol{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:16px}
.coltit{font-family:'Bebas Neue',sans-serif;font-size:12px;letter-spacing:1px;color:var(--mu);margin-bottom:6px;border-bottom:1px solid var(--b);padding-bottom:4px}
.sr{display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid rgba(255,255,255,.04)}
.sr:first-child{border-top:none}
.srk{font-family:'Bebas Neue',sans-serif;font-size:15px;color:var(--mu);min-width:22px}
.empty{text-align:center;padding:50px 20px;color:var(--mu);font-size:15px}
#toast-a{position:fixed;bottom:16px;right:16px;display:flex;flex-direction:column;gap:6px;z-index:999}
.toast{background:var(--s2);border:1px solid var(--b);border-radius:8px;padding:9px 14px;font-size:13px;animation:ti .25s ease;max-width:260px}
.toast.ok{border-color:rgba(0,240,160,.4);color:var(--acc)}.toast.err{border-color:rgba(255,79,55,.4);color:var(--a2)}
@keyframes ti{from{transform:translateX(16px);opacity:0}to{transform:translateX(0);opacity:1}}
.team-logo{width:32px;height:32px;object-fit:contain;border-radius:4px;flex-shrink:0}
.team-logo-sm{width:22px;height:22px;object-fit:contain;border-radius:3px;flex-shrink:0}
.team-logo-lg{width:52px;height:52px;object-fit:contain;border-radius:6px;flex-shrink:0}
.team-logo-xl{width:68px;height:68px;object-fit:contain;flex-shrink:0}
.team-av{width:52px;height:52px;border-radius:8px;background:linear-gradient(135deg,var(--acc),#004428);
  display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:22px;color:#000;flex-shrink:0}
.dorsal{font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--a3);background:rgba(245,200,66,.12);
  border:1px solid rgba(245,200,66,.25);border-radius:4px;padding:1px 5px;min-width:22px;text-align:center;flex-shrink:0}
.dorsal-conflict{color:var(--a2);background:rgba(255,79,55,.12);border-color:rgba(255,79,55,.3)}
.fav-star{background:none;border:none;cursor:pointer;font-size:15px;padding:0 2px;line-height:1;
  opacity:.35;transition:opacity .15s,transform .15s;flex-shrink:0;user-select:none}
.fav-star:hover{opacity:.7;transform:scale(1.15)}
.fav-star.on{opacity:1;filter:drop-shadow(0 0 4px #f5c842)}
.fav-badge{background:var(--a3);color:#000;font-size:9px;font-weight:700;border-radius:8px;
  padding:1px 5px;margin-left:4px;font-family:'JetBrains Mono',monospace}
/* ─────────────────── BOTÓN CALENDARIO ─────────────────── */
.cal-btn{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;
  color:var(--acc);background:linear-gradient(135deg,rgba(0,240,160,.12),rgba(77,139,255,.12));
  border:1.5px solid var(--acc);border-radius:6px;padding:5px 12px;margin-left:10px;cursor:pointer;
  transition:all 0.25s ease;font-family:'Inter',sans-serif;white-space:nowrap;text-decoration:none}
.cal-btn:hover{background:linear-gradient(135deg,rgba(0,240,160,.2),rgba(77,139,255,.2));
  box-shadow:0 0 12px rgba(0,240,160,.25),inset 0 0 8px rgba(255,255,255,.05);transform:translateY(-1px)}
.cal-btn:active{transform:translateY(0)}
/* ─────────────────── MODAL CALENDARIO ─────────────────── */
.cal-modal-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.75);
  z-index:9999;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(2px);animation:fadeIn 0.25s ease}
.cal-modal{background:var(--s1);border:1.5px solid var(--acc);border-radius:12px;
  max-width:95vw;max-height:90vh;overflow-y:auto;padding:24px;color:var(--tx);font-family:'Inter',sans-serif;
  box-shadow:0 20px 60px rgba(0,0,0,.5),0 0 40px rgba(0,240,160,.1);animation:slideUp 0.3s ease}
.cal-modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;
  padding-bottom:16px;border-bottom:2px solid var(--b)}
.cal-modal-title{font-size:18px;font-weight:700;color:var(--acc);font-family:'Bebas Neue',sans-serif;letter-spacing:1px}
.cal-modal-close{background:none;border:none;color:var(--mu);font-size:24px;cursor:pointer;
  padding:0;width:32px;height:32px;display:flex;align-items:center;justify-content:center;
  border-radius:6px;transition:all 0.2s;line-height:1}
.cal-modal-close:hover{background:rgba(255,255,255,.1);color:var(--acc)}
.cal-container{display:grid;grid-template-columns:1fr 2fr;gap:24px}
@media(max-width:768px){.cal-container{grid-template-columns:1fr}}
.cal-section-title{color:var(--a3);font-size:14px;border-bottom:2px solid var(--b);
  padding-bottom:10px;margin-bottom:12px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px}
.cal-jornadas-btns{display:flex;gap:6px;margin-bottom:16px;flex-wrap:wrap}
.cal-jornada-btn{background:var(--s2);border:1.5px solid var(--b);color:var(--mu);
  padding:6px 12px;border-radius:6px;cursor:pointer;font-size:11px;font-weight:600;
  transition:all 0.2s;font-family:'JetBrains Mono',monospace}
.cal-jornada-btn:hover{border-color:var(--acc);color:var(--acc);background:rgba(0,240,160,.08)}
.cal-jornada-btn.active{background:var(--acc);color:#000;border-color:var(--acc);font-weight:700}
.cal-btn-faltantes{border-color:var(--a2) !important;color:var(--a2) !important}
.cal-btn-faltantes:hover{border-color:var(--a2);color:var(--a2);background:rgba(255,79,55,.1) !important}
.cal-btn-faltantes.active{background:var(--a2) !important;color:#000 !important;border-color:var(--a2) !important}
.cal-partido{background:var(--s2);padding:10px;margin-bottom:8px;border-radius:6px;
  border-left:4px solid var(--b);transition:all 0.2s;cursor:pointer}
.cal-partido:hover{background:var(--b);border-left-color:var(--acc);transform:translateX(4px)}
.cal-partido.pendiente{border-left-color:var(--a2);background:rgba(255,79,55,.08)}
.cal-partido.pendiente:hover{background:rgba(255,79,55,.15)}
.cal-partido-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}
.cal-partido-equipos{flex:1;font-size:11px;font-weight:600}
.cal-partido-local{margin-bottom:3px}
.cal-partido-visitante{margin-bottom:3px}
.cal-partido-resultado{font-size:16px;font-weight:700;min-width:60px;text-align:center;margin:0 12px}
.cal-partido-resultado.local-win{color:var(--hw)}
.cal-partido-resultado.visitante-win{color:var(--a2)}
.cal-partido-resultado.empate{color:var(--a3)}
.cal-partido-resultado.pendiente{color:var(--a2);font-size:12px}
.cal-clasificacion{font-size:11px;max-height:450px;overflow-y:auto;border-radius:6px;border:1px solid var(--b)}
.cal-clasificacion table{width:100%;border-collapse:collapse}
.cal-clasificacion thead{position:sticky;top:0;background:var(--s2);z-index:10}
.cal-clasificacion th{text-align:center;padding:7px;color:var(--a3);font-weight:700;font-size:10px;
  text-transform:uppercase;letter-spacing:0.5px;border-bottom:1.5px solid var(--b)}
.cal-clasificacion td{padding:7px;text-align:center;border-bottom:1px solid rgba(255,255,255,.05)}
.cal-clasificacion td:first-child{text-align:left;font-weight:600}
.cal-clasificacion tr:nth-child(2) td{background:rgba(0,240,160,.06);font-weight:700}
.cal-clasificacion tr:nth-child(3) td{background:rgba(77,139,255,.06)}
.cal-clasificacion tr:nth-child(4) td{background:rgba(176,111,255,.06)}
.cal-clasificacion tr:hover td{background:rgba(255,255,255,.05)}
.cal-clasificacion .pos{color:var(--a3);font-weight:700;font-family:'Bebas Neue',sans-serif;font-size:13px}
.cal-clasificacion .pts{color:var(--acc);font-weight:700;font-family:'Bebas Neue',sans-serif;font-size:13px}
.cal-sin-partidos{text-align:center;padding:20px;color:var(--mu);font-style:italic;font-size:12px}
.cal-fecha{font-size:9px;color:var(--mu);margin-top:2px}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes slideUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
/* ─────────────────── BOTÓN MÓVIL/PC ─────────────────── */
#view-toggle-btn{background:none;border:1.5px solid var(--b2);color:var(--mu);
  padding:5px 10px;border-radius:6px;cursor:pointer;font-size:18px;flex-shrink:0;
  transition:all .2s;line-height:1;display:flex;align-items:center;justify-content:center;
  width:34px;height:34px}
#view-toggle-btn:hover{border-color:var(--acc);color:var(--acc);background:rgba(0,240,160,.08)}
/* Modo móvil forzado */
body.mobile-forced .app{max-width:480px;padding:12px 10px}
body.mobile-forced header{padding:0 12px;gap:8px}
body.mobile-forced .logo{font-size:20px;letter-spacing:3px}
body.mobile-forced .logo-m{display:none}
body.mobile-forced nav{gap:0}
body.mobile-forced .nb{padding:5px 8px;font-size:11px}
body.mobile-forced .hgrid{grid-template-columns:repeat(2,1fr)!important;gap:7px}
body.mobile-forced .hv{font-size:24px}
body.mobile-forced .g2,.mobile-forced .g3{grid-template-columns:1fr!important}
body.mobile-forced .twocol{grid-template-columns:1fr!important}
body.mobile-forced table td,body.mobile-forced table th{padding:6px 8px;font-size:11px}
body.mobile-forced .tw{font-size:11px}
body.mobile-forced .mc{padding:8px 10px;gap:7px}
body.mobile-forced .mm{min-width:50px;font-size:10px}
body.mobile-forced .ms{font-size:18px;padding:2px 8px;min-width:54px}
body.mobile-forced .mt{font-size:12px}
body.mobile-forced .mscore{font-size:38px}
body.mobile-forced .fb{gap:5px}
body.mobile-forced .fb select,body.mobile-forced .fb input{font-size:12px;padding:5px 8px}
body.mobile-forced .st{font-size:15px}
body.mobile-forced .sr{gap:7px;padding:5px 0}
body.mobile-forced .cal-container{grid-template-columns:1fr!important}
body.mobile-forced .modal-bg{padding:6px}
body.mobile-forced .modal{max-width:100%;width:100%;padding:14px;border-radius:10px;max-height:95vh}
body.mobile-forced .mtit{font-size:16px}
body.mobile-forced .cal-modal-overlay{padding:6px}
body.mobile-forced .cal-modal{max-width:100%;width:100%;padding:14px;border-radius:10px;max-height:95vh}
body.mobile-forced .sg{flex-wrap:wrap;gap:6px}
body.mobile-forced .sc{min-width:70px}
body.mobile-forced .sv{font-size:22px}
</style>
</head>
<body>
<header>
  <div>
    <div class="logo">FAF Stats</div>
    <div class="logo-m">TMETA_TOTAL actas · TMETA_JUG jugadores · TMETA_GEN</div>
  </div>
  <nav>
    <button class="nb on" onclick="SP('cl')">Clasificación</button>
    <button class="nb"    onclick="SP('pa')">Partidos</button>
    <button class="nb"    onclick="SP('go')">Estadísticas</button>
    <button class="nb"    onclick="SP('ju')">Jugadores</button>
    <button class="nb"    onclick="SP('eq')">Equipos</button>
    <button class="nb"    onclick="SP('cb')">Clubes</button>
    <button class="nb"    onclick="SP('ent')">Entrenadores</button>
    <button class="nb"    onclick="SP('arb')">Árbitros</button>
    <button class="nb"    onclick="SP('h2')">H2H</button>
    <button class="nb"    onclick="SP('sc')">Scouting<span class="fav-badge" id="fav-nav-badge" style="display:none"></span></button>
    <button class="nb"    onclick="SP('dl')">⬇ Descargas</button>
    <button class="nb"    onclick="SP('cfg')">⚙ Config</button>
  </nav>
  <button id="view-toggle-btn" title="Cambiar a vista móvil / PC" onclick="toggleMobileView()">📱</button>
</header>
<div class="app">

<div class="page on" id="p-cl">
  <div class="fb">
    <select id="cl-grupo" onchange="onGrupoChange('cl')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="cl-cat" onchange="rCl()"><option value="">Todas las categorías</option></select>
    <select id="cl-temp" onchange="rCl()"><option value="">Todas las temporadas</option></select>
    <select id="cl-prov" onchange="rCl()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option></select>
    <input type="text" id="cl-s" placeholder="🔍 Buscar equipo..." oninput="rCl()">
  </div>
  <div id="cl-c"></div>
</div>

<div class="page" id="p-pa">
  <div class="fb">
    <select id="pa-grupo" onchange="onGrupoChange('pa')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="pa-cat" onchange="rPa()"><option value="">Todas las categorías</option></select>
    <select id="pa-eq"  onchange="rPa()"><option value="">Todos los equipos</option></select>
    <select id="pa-jor" onchange="rPa()"><option value="">Todas las jornadas</option></select>
    <input type="text" id="pa-s" placeholder="🔍 Buscar..." oninput="rPa()">
  </div>
  <div id="pa-c"></div>
</div>

<div class="page" id="p-go">
  <div class="fb">
    <select id="go-grupo" onchange="onGrupoChange('go')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="go-cat" onchange="rGo()"><option value="">Todas las categorías</option></select>
    <select id="go-temp" onchange="rGo()"><option value="">Todas las temporadas</option></select>
    <select id="go-prov" onchange="rGo()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option></select>
    <select id="go-fed" onchange="rGo()" title="Jugadores que hayan jugado alguna vez en esta federación">
      <option value="">Todas las federaciones</option>
      <option value="alava">🟢 Ha jugado en Álava (FAF)</option>
      <option value="bizkaia">🔵 Ha jugado en Bizkaia (FVF)</option>
      <option value="gipuzkoa">🟣 Ha jugado en Gipuzkoa (RFGF)</option>
      <option value="euskadi">⭐ Ha jugado en Euskadi</option>
      <option value="rfef">🔴 Ha jugado en Nacional (RFEF)</option>
    </select>
    <select id="go-eq"  onchange="rGo()"><option value="">Todos los equipos</option></select>
    <select id="go-anio" onchange="rGo()" style="max-width:170px" title="Filtrar por año de nacimiento inferido">
      <option value="">Todos los años nac.</option>
      <option value="2007">Nacidos 2007</option>
      <option value="2008">Nacidos 2008</option>
      <option value="2009">Nacidos 2009</option>
      <option value="2010">Nacidos 2010</option>
      <option value="2011">Nacidos 2011</option>
      <option value="2012">Nacidos 2012</option>
      <option value="le2006">≤ 2006 (senior sin formativo)</option>
    </select>
  </div>
  <div class="g2">
    <div>
      <div class="st">⚽ Goleadores</div>
      <div class="fb" style="margin-bottom:8px">
        <input type="number" id="go-gol-mins" placeholder="Mín. minutos" style="max-width:150px" min="0" oninput="rGo()" title="Solo goleadores con al menos estos minutos jugados">
        <select id="go-gol-ord" onchange="rGo()" style="max-width:170px">
          <option value="goles">Goles ↓</option>
          <option value="glspp">Goles/partido ↓</option>
        </select>
      </div>
      <div class="card" id="go-l"></div>
    </div>
    <div>
      <div class="st">🧤 Porteros – Menos goleados</div>
      <div class="fb" style="margin-bottom:8px">
        <input type="number" id="go-port-mins" placeholder="Mín. minutos" value="500" style="max-width:160px" min="0" oninput="rGo()" title="Solo porteros con al menos estos minutos jugados">
      </div>
      <div class="card" id="go-p"></div>
    </div>
  </div>
  <div class="g2" style="margin-top:16px">
    <div>
      <div class="st">🔥 Más GF equipo estando en campo (media/partido)</div>
      <div class="fb" style="margin-bottom:8px">
        <input type="number" id="go-min-mins" placeholder="Mín. minutos" style="max-width:160px" min="0" oninput="rGo()">
      </div>
      <div class="card" id="go-gf"></div>
    </div>
    <div>
      <div class="st">🛡 Menos GC equipo estando en campo (media/partido)</div>
      <div class="fb" style="margin-bottom:8px">
        <input type="number" id="go-gc-mins" placeholder="Mín. minutos" style="max-width:160px" min="0" oninput="rGo()" title="Solo jugadores con al menos estos minutos jugados">
      </div>
      <div class="card" id="go-gc"></div>
    </div>
  </div>
  <div class="st" style="margin-top:16px">📊 Estadísticas completas por jugador</div>
  <div class="fb">
    <select id="go-st-ord" onchange="rGoTable()">
      <option value="gfMedia">GF/P equipo ↓</option>
      <option value="gcMedia">GC/P equipo ↓</option>
      <option value="goles">Goles ↓</option>
      <option value="glspp">Gls/P ↓</option>
      <option value="mins">Minutos ↓</option>
    </select>
    <input type="number" id="go-st-mins" placeholder="Mín. minutos jugados" min="0" oninput="rGoTable()" style="max-width:180px">
  </div>
  <div class="tw"><table><thead><tr>
    <th onclick="sortGoTable(this,0)">#</th>
    <th onclick="sortGoTable(this,1)">Jugador ↕</th>
    <th onclick="sortGoTable(this,2)">Equipo ↕</th>
    <th onclick="sortGoTable(this,3)">MIN ↕</th>
    <th onclick="sortGoTable(this,4)">⚽ ↕</th>
    <th onclick="sortGoTable(this,5)" style="color:var(--hw)">Gls/P ↕</th>
    <th onclick="sortGoTable(this,6)" title="Goles a favor del equipo media/partido estando en campo" style="color:var(--hw)">GF/P ↕</th>
    <th onclick="sortGoTable(this,7)" title="Goles en contra del equipo media/partido estando en campo" style="color:var(--a2)">GC/P ↕</th>
    <th onclick="sortGoTable(this,8)">PJ ↕</th>
  </tr></thead><tbody id="go-st-b"></tbody></table></div>
</div>

<div class="page" id="p-ju">
  <div class="fb">
    <select id="ju-grupo" onchange="onGrupoChange('ju')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="ju-cat" onchange="rJu()"><option value="">Todas las categorías</option></select>
    <select id="ju-temp" onchange="rJu()"><option value="">Todas las temporadas</option></select>
    <select id="ju-prov" onchange="rJu()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option></select>
    <select id="ju-fed" onchange="rJu()" title="Jugadores que hayan jugado alguna vez en esta federación">
      <option value="">Todas las federaciones</option>
      <option value="alava">🟢 Ha jugado en Álava (FAF)</option>
      <option value="bizkaia">🔵 Ha jugado en Bizkaia (FVF)</option>
      <option value="gipuzkoa">🟣 Ha jugado en Gipuzkoa (RFGF)</option>
      <option value="euskadi">⭐ Ha jugado en Euskadi</option>
      <option value="rfef">🔴 Ha jugado en Nacional (RFEF)</option>
    </select>
    <select id="ju-eq"  onchange="rJu()"><option value="">Todos los equipos</option></select>
    <input type="text" id="ju-s" placeholder="🔍 Buscar jugador..." oninput="clearTimeout(_juDbt);_juDbt=setTimeout(rJu,180)">
    <input type="number" id="ju-min-mins" placeholder="Mín. minutos" min="0" oninput="rJu()" style="max-width:150px" title="Filtrar por mínimo de minutos jugados">
    <select id="ju-anio" onchange="rJu()" style="max-width:150px" title="Filtrar por año de nacimiento inferido">
      <option value="">Todos los años</option>
      <option value="2007">Nacidos 2007</option>
      <option value="2008">Nacidos 2008</option>
      <option value="2009">Nacidos 2009</option>
      <option value="2010">Nacidos 2010</option>
      <option value="2011">Nacidos 2011</option>
      <option value="2012">Nacidos 2012</option>
      <option value="le2006">≤ 2006 (senior sin formativo)</option>
    </select>
    <select id="ju-solo-port" onchange="rJu()" style="max-width:160px">
      <option value="">Todos los jugadores</option>
      <option value="port">Solo porteros 🧤</option>
    </select>
    <select id="ju-ord" onchange="rJu()">
      <option value="mins" selected>Minutos ↓</option>
      <option value="pj">Partidos ↓</option>
      <option value="goles">Goles ↓</option>
      <option value="tit">Titulares ↓</option>
      <option value="minpp">Min/P ↓</option>
      <option value="glspp">Gls/P ↓</option>
      <option value="pres">Presencia% ↓</option>
      <option value="nojug">No jugados ↓</option>
      <option value="name">Nombre A-Z</option>
      <option value="gfMedia">GF/P campo ↓</option>
      <option value="gcMedia">GC/P campo ↑</option>
      <option value="gfVsEq">GF/P vs Equipo ↓</option>
      <option value="gcVsEq">GC/P vs Equipo ↑</option>
    </select>
  </div>
  <div class="tw"><table><thead><tr>
    <th onclick="sortJu('#')" title="Posición">#</th>
    <th onclick="sortJu('nombre')" title="Nombre">Jugador ↕</th>
    <th onclick="sortJu('equipo')" title="Equipo">Equipo ↕</th>
    <th onclick="sortJu('pj')" title="Partidos jugados">PJ ↕</th>
    <th onclick="sortJu('tit')" title="Partidos como titular">Tit ↕</th>
    <th onclick="sortJu('nojug')" title="Partidos sin jugar" style="color:var(--a2)">No jug. ↕</th>
    <th onclick="sortJu('mins')">MIN ↕</th>
    <th onclick="sortJu('goles')">⚽ ↕</th>
    <th onclick="sortJu('minpp')" title="Minutos por partido">Min/P ↕</th>
    <th onclick="sortJu('glspp')" title="Goles por partido" style="color:var(--hw)">Gls/P ↕</th>
    <th onclick="sortJu('pres')" title="% presencia en partidos del equipo">Pres.% ↕</th>
    <th onclick="sortJu('gfMedia')" title="Goles a favor del equipo por partido mientras el jugador estaba en campo" style="color:var(--hw)">GF/P ↕</th>
    <th onclick="sortJu('gcMedia')" title="Goles en contra del equipo por partido mientras el jugador estaba en campo" style="color:var(--a2)">GC/P ↕</th>
    <th onclick="sortJu('gfVsEq')" title="GF/P en campo vs media general del equipo. Positivo = el equipo marca más con él en campo" style="color:var(--hw)">GF/P±Eq ↕</th>
    <th onclick="sortJu('gcVsEq')" title="GC/P en campo vs media general del equipo. Negativo = el equipo encaja menos con él en campo" style="color:var(--a2)">GC/P±Eq ↕</th>
  </tr></thead><tbody id="ju-b"></tbody></table></div>
  <div id="ju-pag" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-top:10px;font-size:13px;color:var(--mu)">
    <span id="ju-pag-info"></span>
    <div id="ju-pag-btns" style="display:flex;gap:4px;flex-wrap:wrap"></div>
  </div>
</div>

<div class="page" id="p-eq">
  <div class="fb">
    <select id="eq-grupo" onchange="onGrupoChange('eq')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="eq-cat" onchange="rEqCat()"><option value="">Todas las categorías</option></select>
    <select id="eq-temp" onchange="rEqTemp()"><option value="">Todas las temporadas</option></select>
    <select id="eq-sel" onchange="rEq()"><option value="">Seleccionar equipo...</option></select>
  </div>
  <div id="eq-c"></div>
</div>

<div class="page" id="p-h2">
  <div class="fb">
    <select id="h2-a" onchange="rH2()"><option value="">Equipo A...</option></select>
    <select id="h2-b" onchange="rH2()"><option value="">Equipo B...</option></select>
  </div>
  <div id="h2-c"></div>
</div>

<div class="page" id="p-cb">
  <div class="fb">
    <select id="cb-prov" onchange="rCb()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option><option value="_sin">Sin provincia</option></select>
    <input type="text" id="cb-s" placeholder="🔍 Buscar club..." oninput="rCb()">
  </div>
  <div id="cb-c"></div>
</div>

<div class="page" id="p-sc">
  <!-- ── FILTROS ── -->
  <div class="fb" style="flex-wrap:wrap;gap:6px">
    <select id="sc-grupo" onchange="onGrupoChange('sc')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="sc-cat"  onchange="rSc()"><option value="">Todas las categorías</option></select>
    <select id="sc-temp" onchange="rSc()"><option value="">Todas las temporadas</option></select>
    <select id="sc-prov" onchange="rSc()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option></select>
    <select id="sc-fed"  onchange="rSc()" title="Jugadores que hayan jugado en esta federación">
      <option value="">Todas las federaciones</option>
      <option value="alava">🟢 Álava (FAF)</option>
      <option value="bizkaia">🔵 Bizkaia (FVF)</option>
      <option value="gipuzkoa">🟣 Gipuzkoa (RFGF)</option>
      <option value="euskadi">⭐ Euskadi</option>
      <option value="rfef">🔴 Nacional (RFEF)</option>
    </select>
    <select id="sc-eq"   onchange="rSc()"><option value="">Todos los equipos</option></select>
    <select id="sc-pos"  onchange="rSc()">
      <option value="">Todos los jugadores</option>
      <option value="port">Solo porteros 🧤</option>
      <option value="campo">Solo campo</option>
    </select>
    <input type="number" id="sc-min-mins" placeholder="Mín. minutos" min="0" oninput="rSc()" style="max-width:140px" title="Mínimo de minutos acumulados">
    <input type="number" id="sc-min-pj"   placeholder="Mín. partidos" min="0" oninput="rSc()" style="max-width:140px" title="Mínimo de partidos jugados">
    <select id="sc-anio" onchange="rSc()" style="max-width:150px" title="Filtrar por año de nacimiento inferido">
      <option value="">Todos los años</option>
      <option value="2007">Nacidos 2007</option>
      <option value="2008">Nacidos 2008</option>
      <option value="2009">Nacidos 2009</option>
      <option value="2010">Nacidos 2010</option>
      <option value="2011">Nacidos 2011</option>
      <option value="2012">Nacidos 2012</option>
      <option value="le2006">≤ 2006 (senior sin formativo)</option>
    </select>
    <input type="text"   id="sc-s"        placeholder="🔍 Buscar jugador..." oninput="rSc()" style="max-width:200px">
  </div>

  <!-- ── EN SEGUIMIENTO ── -->
  <div id="sc-fav-sec" style="margin-bottom:20px;display:none">
    <div class="st" style="display:flex;align-items:center;gap:10px">
      ⭐ En seguimiento <span class="fav-badge" id="sc-fav-count">0</span>
      <span style="font-size:11px;color:var(--mu);font-weight:400;margin-left:4px">Jugadores marcados para seguir</span>
    </div>
    <div id="sc-fav" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:10px;margin-top:8px"></div>
  </div>

  <!-- ── RANKINGS TOP ── -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:20px" id="sc-rankings">
    <div>
      <div class="st">⏱ Top minutos</div>
      <div class="card" id="sc-m"></div>
    </div>
    <div>
      <div class="st">⚽ Top goleadores</div>
      <div class="card" id="sc-top-gol"></div>
    </div>
    <div>
      <div class="st">📡 Bajo el radar <span style="font-size:10px;color:var(--mu);font-weight:400" title="Alta presencia, pocos goles conocidos — jugadores con muchos minutos pero poca visibilidad">ℹ</span></div>
      <div class="card" id="sc-radar"></div>
    </div>
    <div>
      <div class="st">📋 Plantilla</div>
      <div class="card" id="sc-r"><div class="empty">Selecciona un equipo</div></div>
    </div>
  </div>

  <!-- ── TABLA COMPLETA ── -->
  <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:8px">
    <div class="st" style="margin:0">📊 Asistencia completa</div>
    <select id="sc-ord" onchange="rSc()" style="font-size:12px;padding:4px 8px;background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:6px">
      <option value="pres">Presencia% ↓</option>
      <option value="mins">Minutos ↓</option>
      <option value="goles">Goles ↓</option>
      <option value="pj">Partidos ↓</option>
      <option value="tit">Titulares ↓</option>
      <option value="glspp">Gls/P ↓</option>
      <option value="minpp">Min/P ↓</option>
      <option value="gfMedia">GF/P equipo ↓</option>
      <option value="gcMedia">GC/P equipo ↑</option>
      <option value="score">🎯 Score scout ↓</option>
      <option value="name">Nombre A-Z</option>
    </select>
    <span id="sc-total-count" style="font-size:12px;color:var(--mu)"></span>
  </div>
  <div class="tw"><table><thead><tr>
    <th style="width:28px">#</th>
    <th>Jugador</th>
    <th>Equipo</th>
    <th title="Partidos del equipo" style="color:var(--mu)">PJ eq.</th>
    <th title="Partidos jugados">PJ</th>
    <th title="Partidos sin jugar" style="color:var(--a2)">No jug.</th>
    <th title="Partidos como titular">Tit</th>
    <th>MIN</th>
    <th title="Minutos por partido">Min/P</th>
    <th>⚽</th>
    <th title="Goles por partido" style="color:var(--hw)">Gls/P</th>
    <th title="Goles a favor del equipo por partido estando en campo" style="color:var(--hw)">GF/P</th>
    <th title="Goles en contra del equipo por partido estando en campo" style="color:var(--a2)">GC/P</th>
    <th title="Porcentaje de presencia en partidos del equipo">Pres.%</th>
    <th title="Score de interés scout (minutos, presencia, goles, GF/P)" style="color:var(--a3)">🎯</th>
    <th style="width:30px">⭐</th>
  </tr></thead><tbody id="sc-b"></tbody></table></div>
</div>

<div class="page" id="p-ac">
  <div class="fb">
    <select id="ac-cat" onchange="rAc()"><option value="">Todas las categorías</option></select>
    <input type="text" id="ac-s" placeholder="🔍 Buscar..." oninput="rAc()">
  </div>
  <div id="ac-l"></div>
</div>

<div class="page" id="p-ent">
  <div class="fb">
    <select id="ent-grupo" onchange="onGrupoChange('ent')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="ent-cat" onchange="rEnt()"><option value="">Todas las categorías</option></select>
    <select id="ent-temp" onchange="rEnt()"><option value="">Todas las temporadas</option></select>
    <select id="ent-prov" onchange="rEnt()"><option value="">Todas las provincias</option><option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option><option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option></select>
    <input type="number" id="ent-min-pj" placeholder="Mín. partidos" value="20" min="0" style="max-width:140px" oninput="rEnt()" title="Solo entrenadores con al menos estos partidos">
    <input type="text" id="ent-s" placeholder="🔍 Buscar entrenador..." oninput="rEnt()">
    <select id="ent-ord" onchange="rEnt()">
      <option value="pj">Partidos ↓</option>
      <option value="win">Victorias ↓</option>
      <option value="pts">Puntos ↓</option>
      <option value="pct">% Victoria ↓</option>
      <option value="ptsp">Pts/P ↓</option>
      <option value="gfpp">GF/P ↓ (más goles a favor)</option>
      <option value="gcpp">GC/P ↑ (menos goles recibidos)</option>
      <option value="name">Nombre A-Z</option>
    </select>
  </div>
  <div class="tw"><table><thead><tr>
    <th>#</th><th>Entrenador</th><th>Equipo</th><th>Cat.</th>
    <th title="Partidos">PJ</th><th title="Victorias" style="color:var(--hw)">V</th>
    <th title="Empates" style="color:var(--dr)">E</th>
    <th title="Derrotas" style="color:var(--lw)">D</th>
    <th title="Puntos">Pts</th><th title="% victorias">%V</th>
    <th title="Puntos por partido" style="color:var(--acc)">Pts/P</th>
    <th title="Goles a favor por partido" style="color:var(--hw)">GF/P</th>
    <th title="Goles en contra por partido" style="color:var(--a2)">GC/P</th>
  </tr></thead><tbody id="ent-b"></tbody></table></div>
</div>

<div class="page" id="p-arb">
  <div class="fb">
    <select id="arb-grupo" onchange="onGrupoChange('arb')"><option value="">Todos los grupos</option><option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option></select>
    <select id="arb-cat" onchange="rArb()"><option value="">Todas las categorías</option></select>
    <select id="arb-temp" onchange="rArb()"><option value="">Todas las temporadas</option></select>
    <input type="text" id="arb-s" placeholder="🔍 Buscar árbitro..." oninput="rArb()">
    <select id="arb-ord" onchange="rArb()">
      <option value="pj">Partidos ↓</option>
      <option value="goles">Goles/P ↓</option>
      <option value="tarj">Tarjetas/P ↓</option>
      <option value="name">Nombre A-Z</option>
    </select>
  </div>
  <div class="tw"><table><thead><tr>
    <th>#</th><th>Árbitro</th><th>Cat.</th>
    <th>PJ</th><th>Goles/P</th>
    <th title="Tarjetas amarillas">🟨/P</th>
    <th title="Tarjetas rojas (total)">🟥/P</th>
    <th title="Rojas directas">🟥 Dir</th>
    <th>Total tarj.</th>
  </tr></thead><tbody id="arb-b"></tbody></table></div>
</div>

<div class="page" id="p-cfg">
  <div style="display:flex;gap:8px;margin-bottom:18px;border-bottom:1px solid var(--b);padding-bottom:12px">
    <button id="cfg-tab-cat" class="nb on" onclick="cfgTab('cat')" style="font-size:13px">🏷 Categorías</button>
    <button id="cfg-tab-hom" class="nb" onclick="cfgTab('hom')" style="font-size:13px">👥 Homónimos</button>
    <button id="cfg-tab-mrg" class="nb" onclick="cfgTab('mrg')" style="font-size:13px">🔀 Merge personas</button>
    <button id="cfg-tab-sug" class="nb" onclick="cfgTab('sug')" style="font-size:13px">🤖 Sugerencias</button>
    <button id="cfg-tab-disc" class="nb" onclick="cfgTab('disc')" style="font-size:13px">⚠ Discrepancias <span id="cfg-disc-badge" class="bdg" style="display:none">0</span></button>
  </div>

  <div id="cfg-panel-cat">
    <div class="st">🏷 Configuración de Categorías</div>
    <div style="font-size:13px;color:var(--mu);margin-bottom:16px;line-height:1.7;background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 16px">
      Aquí puedes <b style="color:var(--tx)">renombrar</b> cualquier categoría (para que quede más claro) y asignarle un <b style="color:var(--acc)">grupo</b> (Senior / Juvenil / Cadete).<br>
      El sistema detecta automáticamente el grupo por el nombre, pero puedes corregirlo si está mal.<br>
      <span style="font-size:11px;color:var(--a3)">Los cambios se guardan en el navegador. El renombre se aplica en todos los apartados al instante.</span>
    </div>
    <div class="fb" style="margin-bottom:12px">
      <input type="text" id="cfg-cat-s" placeholder="🔍 Filtrar categorías..." oninput="rCfgCat()" style="max-width:300px">
      <select id="cfg-cat-grupo-filt" onchange="rCfgCat()" style="max-width:180px">
        <option value="">Todos los grupos</option>
        <option value="SENIOR">Senior</option>
        <option value="JUVENIL">Juvenil</option>
        <option value="CADETE">Cadete</option>
        <option value="_auto">Sin asignar</option>
      </select>
      <button onclick="resetCatCfg()" style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:12px;border-radius:6px;padding:6px 12px;cursor:pointer">Resetear todo</button>
    </div>
    <div id="cfg-cat-list"></div>
  </div>

  <div id="cfg-panel-hom" style="display:none">
    <div class="st">👥 Homónimos detectados</div>
    <div style="font-size:13px;color:var(--mu);margin-bottom:16px;line-height:1.7;background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 16px">
      El sistema detecta automáticamente jugadores que comparten nombre pero parecen ser personas distintas (porque aparecen en dos equipos sin relación de filial alternando en la misma temporada).<br>
      Revisa cada caso y marca si la separación es <b style="color:var(--hw)">correcta</b> (son dos jugadores distintos) o si en realidad <b style="color:var(--a2)">es el mismo jugador</b> y hay que unirlos.
      <br><span style="font-size:11px;color:var(--a3)">Los cambios se guardan en el navegador y se aplican al instante sin regenerar el HTML.</span>
    </div>
    <div class="fb" style="margin-bottom:12px">
      <input type="text" id="cfg-s" placeholder="🔍 Filtrar por nombre..." oninput="rCfg()" style="max-width:300px">
      <select id="cfg-filter" onchange="rCfg()" style="max-width:200px">
        <option value="">Todos</option>
        <option value="pending">Sin revisar</option>
        <option value="split">Marcados como distintos ✓</option>
        <option value="merge">Marcados como mismo jugador</option>
      </select>
      <button onclick="resetHomCfg()" style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:12px;border-radius:6px;padding:6px 12px;cursor:pointer">Resetear todo</button>
    </div>
    <div id="cfg-hom-list"></div>
  </div>

  <div id="cfg-panel-mrg" style="display:none">
    <div class="st">🔀 Merge manual de personas</div>
    <div style="font-size:13px;color:var(--mu);margin-bottom:16px;line-height:1.7;background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 16px">
      Fusiona jugadores o entrenadores cuyo nombre aparece escrito de forma distinta en actas de diferentes federaciones (ej: tildes, orden de apellidos, abreviaturas).<br>
      Elige el <b style="color:var(--hw)">nombre canónico</b> (el correcto, al que se unificarán las estadísticas) y el <b style="color:var(--a2)">nombre variante</b> (el que desaparece absorbido). Todas las estadísticas del variante se acumulan en el canónico.<br>
      <span style="font-size:11px;color:var(--a3)">Los merges se guardan en el navegador y se aplican al instante. No modifican los JSON del disco.</span>
    </div>
    <div style="background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:16px;margin-bottom:18px">
      <div style="font-size:12px;font-weight:700;color:var(--acc);margin-bottom:12px;text-transform:uppercase;letter-spacing:.8px">Nuevo merge</div>
      <div style="display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:end;flex-wrap:wrap">
        <div>
          <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Nombre canónico (correcto) ✓</div>
          <input type="text" id="mrg-canon" placeholder="Buscar nombre canónico..." oninput="mrgAutocomplete('mrg-canon','mrg-canon-list')"
            style="width:100%;background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:13px;outline:none">
          <div id="mrg-canon-list" style="position:relative"></div>
        </div>
        <div>
          <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Nombre variante (absorber) ✕</div>
          <input type="text" id="mrg-variant" placeholder="Buscar nombre variante..." oninput="mrgAutocomplete('mrg-variant','mrg-variant-list')"
            style="width:100%;background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:13px;outline:none">
          <div id="mrg-variant-list" style="position:relative"></div>
        </div>
        <div>
          <button onclick="doPersonMerge()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:13px;font-weight:700;border-radius:6px;padding:8px 18px;cursor:pointer;white-space:nowrap">Fusionar →</button>
        </div>
      </div>
      <div id="mrg-preview" style="margin-top:10px;font-size:12px;color:var(--mu)"></div>
    </div>
    <div class="fb" style="margin-bottom:12px">
      <input type="text" id="mrg-s" placeholder="🔍 Filtrar merges guardados..." oninput="rCfgMrg()" style="max-width:300px">
      <button onclick="resetPersonMerges()" style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:12px;border-radius:6px;padding:6px 12px;cursor:pointer">Borrar todos</button>
    </div>
    <div id="cfg-mrg-list"></div>
  </div>

  <div id="cfg-panel-sug" style="display:none">
    <div class="st">🤖 Sugerencias de merge por trayectoria</div>
    <div style="font-size:13px;color:var(--mu);margin-bottom:16px;line-height:1.7;background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 16px">
      El motor detecta pares de jugadores con <b style="color:var(--a4)">nombres similares</b> donde uno tiene historial <b style="color:var(--a4)">Juvenil/Cadete</b> y el otro aparece en <b style="color:var(--hw)">Senior</b> (3ªRFEF o inferior) sin pasar por formativo — algo raro que sugiere que son el mismo jugador con nombre escrito distinto entre federaciones.<br>
      <span style="font-size:11px;color:var(--a3)">Revisa la trayectoria de cada par y decide. Solo se muestran candidatos no ya mergeados.</span>
    </div>
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:14px;flex-wrap:wrap">
      <button onclick="calcSugerencias()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:13px;font-weight:700;border-radius:6px;padding:8px 18px;cursor:pointer">🔍 Analizar ahora</button>
      <span id="sug-status" style="font-size:12px;color:var(--mu)">Pulsa Analizar para detectar candidatos.</span>
    </div>
    <div id="cfg-sug-list"></div>
  </div>

  <div id="cfg-panel-disc" style="display:none">
    <div class="st">⚠ Discrepancias entre tablas cruzadas y actas</div>
    <div style="font-size:13px;color:var(--mu);margin-bottom:16px;line-height:1.7;background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 16px">
      Resultados donde la <b style="color:var(--a3)">tabla cruzada oficial</b> de la FAF muestra un marcador distinto al que figura en el <b style="color:var(--a4)">acta descargada</b>, o partidos que aparecen en la tabla pero no tienen acta en disco.<br>
      Ejecuta el <b style="color:var(--acc)">Modo 12</b> desde la CMD para actualizar este listado. Para cada discrepancia puedes elegir cuál resultado es el correcto: el de la tabla cruzada o el del acta.
      <br><span style="font-size:11px;color:var(--a3)">Las resoluciones se guardan en el navegador y se preservan en la próxima ejecución del Modo 12.</span>
    </div>
    <div class="fb" style="margin-bottom:12px">
      <input type="text" id="disc-s" placeholder="🔍 Filtrar por equipo o categoría..." oninput="rCfgDisc()" style="max-width:320px">
      <select id="disc-estado-filt" onchange="rCfgDisc()" style="max-width:200px">
        <option value="">Todos</option>
        <option value="discrepancia">Solo discrepancias</option>
        <option value="sin_acta">Solo sin acta</option>
        <option value="pendiente">Sin resolver</option>
        <option value="resuelto">Resueltos</option>
      </select>
      <button onclick="resetDiscResoluciones()" style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:12px;border-radius:6px;padding:6px 12px;cursor:pointer">Borrar resoluciones</button>
    </div>
    <div id="cfg-disc-list"></div>
  </div>
</div>
<div class="page" id="p-dl">
  <div class="st" style="margin-bottom:18px">⬇ Descargas</div>

  <!-- ── Sub-tabs ── -->
  <div style="display:flex;gap:8px;margin-bottom:20px;border-bottom:1px solid var(--b);padding-bottom:12px">
    <button id="dl-tab-clubes"  class="nb on"  onclick="dlTab('clubes')"  style="font-size:13px">🏟 Clubes</button>
    <button id="dl-tab-cats"    class="nb"     onclick="dlTab('cats')"    style="font-size:13px">🏷 Categorías</button>
  </div>

  <div id="dl-panel-clubes">
    <div style="font-size:13px;color:var(--mu);margin-bottom:14px">
      Listado de todos los clubes con su provincia asignada. Puedes descargar el CSV o copiarlo.
    </div>
    <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:center">
      <input type="text" id="dl-club-s" placeholder="🔍 Filtrar..." oninput="rDlClubes()" style="max-width:260px;background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:13px;outline:none">
      <select id="dl-club-prov" onchange="rDlClubes()" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:13px;outline:none">
        <option value="">Todas las provincias</option>
        <option>Álava</option><option>Bizkaia</option><option>Gipuzkoa</option>
        <option>Navarra</option><option>La Rioja</option><option>Vasca</option><option>Nacional</option><option value="_sin">Sin asignar</option>
      </select>
      <button onclick="dlCsvClubes()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:12px;font-weight:700;border-radius:6px;padding:6px 14px;cursor:pointer">⬇ CSV</button>
      <button onclick="copyCsvClubes()" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);font-size:12px;border-radius:6px;padding:6px 14px;cursor:pointer">📋 Copiar</button>
      <span id="dl-club-count" style="font-size:12px;color:var(--mu)"></span>
    </div>
    <div class="tw"><table id="dl-club-tbl">
      <thead><tr>
        <th onclick="dlSortClubes(0)" style="cursor:pointer"># ↕</th>
        <th onclick="dlSortClubes(1)" style="cursor:pointer">Club ↕</th>
        <th onclick="dlSortClubes(2)" style="cursor:pointer">Provincia ↕</th>
      </tr></thead>
      <tbody id="dl-club-body"></tbody>
    </table></div>
  </div>

  <div id="dl-panel-cats" style="display:none">
    <div style="font-size:13px;color:var(--mu);margin-bottom:14px">
      Listado de todas las categorías con grupo, temporadas disputadas, máximo de jornadas y rango de actas.
    </div>
    <div style="display:flex;gap:8px;margin-bottom:14px;flex-wrap:wrap;align-items:center">
      <input type="text" id="dl-cat-s" placeholder="🔍 Filtrar..." oninput="rDlCats()" style="max-width:260px;background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:13px;outline:none">
      <select id="dl-cat-grupo" onchange="rDlCats()" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:13px;outline:none">
        <option value="">Todos los grupos</option>
        <option value="SENIOR">Senior</option><option value="JUVENIL">Juvenil</option><option value="CADETE">Cadete</option>
      </select>
      <button onclick="dlExcelCats()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:12px;font-weight:700;border-radius:6px;padding:6px 14px;cursor:pointer">⬇ Excel</button>
      <button onclick="dlCsvCats()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:12px;font-weight:700;border-radius:6px;padding:6px 14px;cursor:pointer">⬇ CSV</button>
      <button onclick="document.getElementById('upload-excel-cats').click()" style="background:rgba(255,170,0,.15);border:1px solid rgba(255,170,0,.4);color:#ffaa00;font-size:12px;font-weight:700;border-radius:6px;padding:6px 14px;cursor:pointer">⬆ Subir Excel</button>
      <input type="file" id="upload-excel-cats" accept=".xlsx,.xls" style="display:none" onchange="uploadExcelCats(event)">
      <button onclick="copyCsvCats()" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);font-size:12px;border-radius:6px;padding:6px 14px;cursor:pointer">📋 Copiar</button>
      <span id="dl-cat-count" style="font-size:12px;color:var(--mu)"></span>
    </div>
    <div class="tw"><table id="dl-cat-tbl">
      <thead><tr>
        <th onclick="dlSortCats(0)" style="cursor:pointer"># ↕</th>
        <th onclick="dlSortCats(1)" style="cursor:pointer">Categoría ↕</th>
        <th onclick="dlSortCats(2)" style="cursor:pointer">Grupo ↕</th>
        <th onclick="dlSortCats(3)" style="cursor:pointer">Provincia ↕</th>
        <th onclick="dlSortCats(4)" style="cursor:pointer">Temporada ↕</th>
        <th onclick="dlSortCats(5)" style="cursor:pointer" title="Número de jornadas disputadas (máximo equipo)">Jornadas ↕</th>
        <th onclick="dlSortCats(6)" style="cursor:pointer" title="ID de acta más bajo en esta categoría">Acta mín ↕</th>
        <th onclick="dlSortCats(7)" style="cursor:pointer" title="ID de acta más alto en esta categoría">Acta máx ↕</th>
        <th onclick="dlSortCats(8)" style="cursor:pointer" title="¿Tiene ascenso? ↕">Ascenso ↕</th>
        <th onclick="dlSortCats(9)" style="cursor:pointer" title="Cuántos ascienden ↕">Ascienden ↕</th>
        <th onclick="dlSortCats(10)" style="cursor:pointer" title="¿A qué liga? ↕">A Liga ↕</th>
        <th onclick="dlSortCats(11)" style="cursor:pointer" title="¿Tiene descenso? ↕">Descenso ↕</th>
        <th onclick="dlSortCats(12)" style="cursor:pointer" title="Cuántos descienden ↕">Descienden ↕</th>
        <th onclick="dlSortCats(13)" style="cursor:pointer" title="¿A qué liga? ↕">A Liga ↕</th>
      </tr></thead>
      <tbody id="dl-cat-body"></tbody>
    </table></div>
  </div>
</div>
<div class="modal-bg" id="modal-bg" onclick="if(event.target===this)this.classList.remove('open')">
  <div class="modal"><div id="modal-c"></div></div>
</div>
<div id="toast-a"></div>

<script>
const ACTAS = ___ACTAS_JSON_DATA___;
const TEAM_LOGOS = ___TEAM_LOGOS_DATA___;
const CLUB_MAP = ___CLUB_MAP_DATA___;
const ENTRENADORES_MAP = ___ENTRENADORES_MAP_DATA___;
const PROVINCIA_MAP_BASE = ___PROVINCIA_MAP_DATA___;
const CAT_CFG_BASE = ___CAT_CFG_DATA___;
const DISCREPANCIAS_BASE = ___DISCREPANCIAS_DATA___;
// Set de "cat|||temp" que han sido analizadas por Modo 12 (tienen tabla cruzada)
const LIGAS_CON_TABLA = new Set(___LIGAS_CON_TABLA_DATA___);
const DB = {};
ACTAS.forEach(a => { if(a.acta_id) DB[a.acta_id] = a; });

// ═══════════════════════════════════════════════════════════════
// VISTA MÓVIL / PC TOGGLE
// ═══════════════════════════════════════════════════════════════
(function initViewToggle(){
  const STORAGE_KEY = 'faf_view_mode';
  const saved = localStorage.getItem(STORAGE_KEY);
  if(saved === 'mobile') _applyMobileForced(true, false);
})();
function _applyMobileForced(on, save){
  const btn = document.getElementById('view-toggle-btn');
  if(on){
    document.body.classList.add('mobile-forced');
    if(btn){ btn.textContent='🖥️'; btn.title='Cambiar a vista PC'; }
  } else {
    document.body.classList.remove('mobile-forced');
    if(btn){ btn.textContent='📱'; btn.title='Cambiar a vista móvil'; }
  }
  if(save !== false) localStorage.setItem('faf_view_mode', on ? 'mobile' : 'pc');
}
function toggleMobileView(){
  const isMobile = document.body.classList.contains('mobile-forced');
  _applyMobileForced(!isMobile);
}

// ═══════════════════════════════════════════════════════════════
// OPTIMIZACIÓN: RESTAURAR DESDE localStorage SI EXISTEN
// Si abriste este HTML desde otro dispositivo/mail, restaura TODO aquí
// ═══════════════════════════════════════════════════════════════
(function restoreFromLocalStorage() {
  try {
    const cached = localStorage.getItem('faf_actas_full_cache');
    if(cached) {
      const restored = JSON.parse(cached);
      if(Array.isArray(restored) && restored.length > 0) {
        // Restaurar todos los datos desde localStorage
        ACTAS.length = 0;
        ACTAS.push(...restored);
        // Reconstruir índice DB
        Object.keys(DB).forEach(k => delete DB[k]);
        ACTAS.forEach(a => { if(a.acta_id) DB[a.acta_id] = a; });
        // Reiniciar cache global para evitar duplicados
        if(typeof _invalidarMotor === 'function') _invalidarMotor();
        console.log(`[localStorage] ✓✓✓ RESTAURADO: ${restored.length} actas desde caché local`);
      }
    }
  } catch(e) {
    console.warn('[localStorage] Error al restaurar:', e.message);
  }
})();

// ── ENTRENADOR OVERRIDES (asignación manual para actas sin entrenador) ────────
// Persiste en localStorage: { "acta_id|local"|"acta_id|visitante": "NOMBRE ENTRENADOR" }
// Se aplica EN MEMORIA sobre ACTAS/DB para que todo el motor de estadísticas
// (clasificaciones, fichas de entrenador, etc.) lo tenga en cuenta al instante.
// NOTA: esto NO modifica los .json/.txt en disco — es una corrección local
// guardada en el navegador, igual que el resto de overrides de la app.
const ENT_OVERRIDES_KEY = 'faf_entrenador_overrides';
function loadEntOverrides(){ try{ return JSON.parse(localStorage.getItem(ENT_OVERRIDES_KEY)||'{}'); }catch(e){ return {}; } }
function saveEntOverrides(m){ localStorage.setItem(ENT_OVERRIDES_KEY, JSON.stringify(m)); }
function _entOvrKey(actaId, esLocal){ return actaId+'|'+(esLocal?'local':'visitante'); }

// Aplica los overrides guardados sobre ACTAS/DB (mutación in-place)
function aplicarEntrenadorOverrides(){
  const ov = loadEntOverrides();
  if(!Object.keys(ov).length) return;
  ACTAS.forEach(a=>{
    if(!a.acta_id) return;
    const kL = _entOvrKey(a.acta_id, true);
    const kV = _entOvrKey(a.acta_id, false);
    if(ov[kL]) a.entrenador_local = ov[kL];
    if(ov[kV]) a.entrenador_visitante = ov[kV];
  });
}
aplicarEntrenadorOverrides();

// Asigna un entrenador a un acta sin entrenador (lado local o visitante).
// Guarda el override, lo aplica en memoria e invalida el motor de stats.
function asignarEntrenadorActa(actaId, esLocal, nombre){
  nombre = (nombre||'').trim();
  if(!nombre){ toast('Introduce un nombre de entrenador','err'); return; }
  const a = DB[actaId];
  if(!a){ toast('Acta no encontrada','err'); return; }
  const ov = loadEntOverrides();
  ov[_entOvrKey(actaId, esLocal)] = nombre;
  saveEntOverrides(ov);
  if(esLocal) a.entrenador_local = nombre;
  else a.entrenador_visitante = nombre;
  _invalidarMotor();
  toast(`Entrenador asignado: ${nombre}`, 'ok');
  // Re-renderizar la vista de equipo si está activa
  if(typeof rEq === 'function') rEq();
}

// Elimina un override de entrenador (vuelve a "Sin entrenador")
function quitarEntrenadorOverride(actaId, esLocal){
  const a = DB[actaId];
  const ov = loadEntOverrides();
  const k = _entOvrKey(actaId, esLocal);
  delete ov[k];
  saveEntOverrides(ov);
  if(a){
    if(esLocal) a.entrenador_local = '';
    else a.entrenador_visitante = '';
  }
  _invalidarMotor();
  toast('Asignación eliminada','ok');
  if(typeof rEq === 'function') rEq();
}

// Abre un pequeño popover para elegir/escribir el entrenador de un acta sin entrenador.
// candidatos: lista de nombres de entrenadores que ya han entrenado a este equipo.
function abrirAsignarEntrenador(actaId, esLocal, candidatos, anchorEl){
  // Cerrar cualquier popover previo
  document.querySelectorAll('.ent-assign-pop').forEach(p=>p.remove());
  const pop = document.createElement('div');
  pop.className = 'ent-assign-pop';
  pop.style.cssText = 'position:absolute;z-index:300;background:var(--s2);border:1px solid var(--acc);border-radius:8px;'+
    'padding:10px;box-shadow:0 8px 24px rgba(0,0,0,.5);min-width:220px;font-size:12px';
  const opts = (candidatos||[]).map(n=>
    `<div class="ent-assign-opt" data-nombre="${n.replace(/"/g,'&quot;')}" style="padding:6px 8px;border-radius:5px;cursor:pointer;color:var(--tx)"
      onmouseover="this.style.background='rgba(0,240,160,.1)'" onmouseout="this.style.background=''">${n}</div>`
  ).join('');
  pop.innerHTML = `
    <div style="font-size:11px;color:var(--mu);margin-bottom:6px;font-weight:700">Asignar entrenador</div>
    ${opts || '<div style="font-size:11px;color:var(--mu);margin-bottom:6px">Sin candidatos previos</div>'}
    <div style="border-top:1px solid var(--b);margin-top:6px;padding-top:6px">
      <input type="text" placeholder="Otro nombre..." class="ent-assign-input"
        style="width:100%;background:var(--s1);border:1px solid var(--b);color:var(--tx);padding:5px 8px;border-radius:5px;font-size:12px;outline:none;box-sizing:border-box">
      <div style="display:flex;gap:6px;margin-top:6px">
        <button class="ent-assign-ok" style="flex:1;background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:11px;font-weight:700;border-radius:5px;padding:5px;cursor:pointer">✓ Asignar</button>
        <button class="ent-assign-cancel" style="background:var(--s1);border:1px solid var(--b);color:var(--mu);font-size:11px;border-radius:5px;padding:5px 10px;cursor:pointer">✕</button>
      </div>
    </div>`;
  document.body.appendChild(pop);
  // Posicionar cerca del elemento que abrió el popover
  const r = anchorEl.getBoundingClientRect();
  pop.style.top = (window.scrollY + r.bottom + 4) + 'px';
  pop.style.left = (window.scrollX + r.left) + 'px';

  const input = pop.querySelector('.ent-assign-input');
  pop.querySelectorAll('.ent-assign-opt').forEach(el=>{
    el.addEventListener('click', ()=>{
      asignarEntrenadorActa(actaId, esLocal, el.dataset.nombre);
      pop.remove();
    });
  });
  pop.querySelector('.ent-assign-ok').addEventListener('click', ()=>{
    asignarEntrenadorActa(actaId, esLocal, input.value);
    pop.remove();
  });
  pop.querySelector('.ent-assign-cancel').addEventListener('click', ()=> pop.remove());
  input.addEventListener('keydown', e=>{ if(e.key==='Enter'){ asignarEntrenadorActa(actaId, esLocal, input.value); pop.remove(); } });
  // Cerrar al hacer clic fuera
  setTimeout(()=>{
    document.addEventListener('click', function _close(ev){
      if(!pop.contains(ev.target)){ pop.remove(); document.removeEventListener('click', _close); }
    });
  }, 0);
}
// Persiste en localStorage: renombres, grupos y provincias de categorías.
// CAT_OVERRIDES_KEY = { catOriginal: { nombre: 'Nombre nuevo', grupo: 'SENIOR'|'JUVENIL'|'CADETE', provincia: 'Álava'|'Bizkaia'|'Gipuzkoa'|'Vasca'|'Nacional' } }
const CAT_OVERRIDES_KEY = 'faf_cat_overrides';
function loadCatOverrides(){ try{ return JSON.parse(localStorage.getItem(CAT_OVERRIDES_KEY)||'{}'); }catch{return{};} }
function saveCatOverrides(d){ localStorage.setItem(CAT_OVERRIDES_KEY, JSON.stringify(d)); }

// Devuelve el nombre visible de una categoría (aplica renombre si existe)
function catNombre(cat){
  if(!cat) return cat;
  const ov = loadCatOverrides();
  return (ov[cat] && ov[cat].nombre) ? ov[cat].nombre : cat;
}

// Version abreviada en castellano para columnas compactas (ficha entrenador, plantilla...)
// letra: 'A'|'B'|'C'|'' - si se pasa y no es 'A', se aniade al final (ej. "Juv. Honor B")
function catAbrev(cat, letra){
  if(!cat) return '\u2014';
  const base = catNombre(cat);
  const n = base.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  let abrev;
  if(n.includes('juvenil') && n.includes('vasca'))              abrev='Juv. Vasca';
  else if(n.includes('cadete')  && n.includes('vasca'))         abrev='Cad. Vasca';
  else if(n.includes('juvenil') && n.includes('honor'))         abrev='Juv. Honor';
  else if(n.includes('cadete')  && n.includes('honor'))         abrev='Cad. Honor';
  else if(n.includes('preferente') && n.includes('juvenil'))    abrev='Pref. Juv.';
  else if(n.includes('primera')    && n.includes('juvenil'))    abrev='1\xaa Juvenil';
  else if(n.includes('preferente') && n.includes('cadete'))     abrev='Pref. Cad.';
  else if(n.includes('primera')    && n.includes('cadete'))     abrev='1\xaa Cadete';
  else if(n.includes('juvenil'))                                 abrev='Juvenil';
  else if(n.includes('cadete'))                                  abrev='Cadete';
  else if(n.includes('division de honor')||n.includes('div honor')) abrev='Div. Honor';
  else if(n.includes('preferente'))                              abrev='Preferente';
  else if(n.includes('1a regional')||(n.includes('primera')&&n.includes('regional'))) abrev='1\xaa Regional';
  else if(n.includes('2a regional')||(n.includes('segunda')&&n.includes('regional'))) abrev='2\xaa Regional';
  else if(n.includes('3a regional')||(n.includes('tercera')&&n.includes('regional'))) abrev='3\xaa Regional';
  else if(n.includes('regional'))                                abrev='Regional';
  else if(n.includes('primera rfef')||n.includes('1a rfef'))    abrev='1\xaa RFEF';
  else if(n.includes('segunda rfef')||n.includes('2a rfef'))    abrev='2\xaa RFEF';
  else if(n.includes('tercera rfef')||n.includes('3a rfef')||n.includes('tercera federacion')) abrev='3\xaa RFEF';
  else abrev = base.length > 14 ? base.slice(0,13).trimEnd()+'\u2026' : base;
  if(letra && letra !== 'A') abrev += ' ' + letra;
  return abrev;
}

// ── ORDEN DE CATEGORÍAS NACIONALES (Senior) ───────────────────────────────────
// Asigna un número de orden para categorías nacionales senior.
// Cuanto menor el número, mayor la categoría.
// Dentro de cada nivel, las fases/grupos van después de la liga regular.
// Devuelve [nivel_primario, nivel_secundario] para comparación.
function _nivelNacional(cat){
  // Normalizar: minúsculas, sin tildes/diacríticos, sin ordinal femenino/masculino, espacios simples
  const n = (cat||'').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'')   // quitar tildes
    .replace(/\u00aa/g,'a').replace(/\u00ba/g,'o')      // ª→a  º→o
    .replace(/\s+/g,' ').trim();
  // ── helpers de fase ──────────────────────────────────────────────
  const esFase = n.includes('play') || n.includes('playoff') || n.includes('ascen') ||
                 n.includes('final') || n.includes('fase') || n.includes('promoc') ||
                 n.includes('liguilla');
  const subfase = esFase ? 1 : 0;  // 0 = liga regular, 1 = fases/play-off
  // Grupo (A, B, C…) → orden secundario dentro del mismo nivel+fase
  const mGrp = n.match(/\bgrupo\s*([a-z0-9]+)\b/) || n.match(/\bgrp\.?\s*([a-z0-9]+)\b/);
  const grpOrd = mGrp ? mGrp[1].charCodeAt(0) : 0;

  // ── 1ª División (Primera División / Primera Iberdrola) ───────────
  // Cubre: "Primera División", "1a División", "1ª Division", "Primera Iberdrola"
  if( (n.includes('primera') && (n.includes('divis') || n.includes('division'))) ||
      n.includes('primera iberdrola') ||
      /\b1a?\s*div/.test(n) )
    return [10, subfase, grpOrd];

  // ── 2ª División ──────────────────────────────────────────────────
  if( (n.includes('segunda') && (n.includes('divis') || n.includes('division'))) ||
      /\b2a?\s*div/.test(n) )
    return [20, subfase, grpOrd];

  // ── 1ª Federación (Primera Federación / Primera RFEF) ───────────
  // Cubre: "Primera RFEF", "1a RFEF", "1ª RFEF", "Primera Federacion", "1ª Fed"
  if( n.includes('primera rfef') || /\b1a?\s*rfef\b/.test(n) ||
      (n.includes('primera') && n.includes('federaci')) ||
      /\b1a?\s*fed/.test(n) )
    return [30, subfase, grpOrd];

  // ── 2ª Federación (Segunda Federación / Segunda RFEF) ───────────
  if( n.includes('segunda rfef') || /\b2a?\s*rfef\b/.test(n) ||
      (n.includes('segunda') && n.includes('federaci')) ||
      /\b2a?\s*fed/.test(n) )
    return [40, subfase, grpOrd];

  // ── 3ª Federación / Tercera Federación / Tercera ────────────────
  // OJO: "tercera" en regional/juvenil/cadete no es nacional → excluir
  if( n.includes('tercera rfef') || /\b3a?\s*rfef\b/.test(n) ||
      (n.includes('tercera') && n.includes('federaci')) ||
      (n.includes('tercera') && !n.includes('regional') && !n.includes('juvenil') && !n.includes('cadete')) )
    return [50, subfase, grpOrd];

  // ── División de Honor Senior (NO juvenil/cadete/junior) ──────────
  if( (n.includes('division') && n.includes('honor') ||
       n.includes('div') && n.includes('honor')) &&
      !n.includes('juvenil') && !n.includes('cadete') && !n.includes('junior') )
    return [60, subfase, grpOrd];

  // Resto: sin nivel nacional reconocido → va al final
  return [999, subfase, grpOrd];
}

// Comparador de dos categorías con lógica nacional-primero cuando corresponde
function _cmpCats(a, b){
  const provA = getCatProvincia(a), provB = getCatProvincia(b);
  const nacA = provA === 'Nacional', nacB = provB === 'Nacional';
  const senA = getCatGrupo(a) === 'SENIOR', senB = getCatGrupo(b) === 'SENIOR';

  // Si ambas son nacionales senior → orden jerárquico
  if(nacA && senA && nacB && senB){
    const [n1a,n2a,n3a] = _nivelNacional(a);
    const [n1b,n2b,n3b] = _nivelNacional(b);
    if(n1a !== n1b) return n1a - n1b;
    if(n2a !== n2b) return n2a - n2b;
    if(n3a !== n3b) return n3a - n3b;
    return a.localeCompare(b);
  }
  // Fallback: alfabético
  return a.localeCompare(b);
}

// Ordena un array de categorías con la lógica nacional senior primero
function sortCats(arr){
  return [...arr].sort(_cmpCats);
}

// Badges HTML para categorías nacionales (se muestran antes del nombre en la clasificación)
const _LOGOS_NAC = {
  10: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#ff4040;background:rgba(255,50,50,.15);border:1.5px solid rgba(255,50,50,.55);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="1\xaa Divisi\xf3n">1\xaa DIV</span>`,
  20: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#ff7832;background:rgba(255,120,50,.13);border:1.5px solid rgba(255,120,50,.5);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="2\xaa Divisi\xf3n">2\xaa DIV</span>`,
  30: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#f5c842;background:rgba(245,200,66,.13);border:1.5px solid rgba(245,200,66,.5);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="1\xaa RFEF">1\xaa RFEF</span>`,
  40: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#4dc8dc;background:rgba(77,200,220,.12);border:1.5px solid rgba(77,200,220,.45);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="2\xaa RFEF">2\xaa RFEF</span>`,
  50: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#96dc4d;background:rgba(150,220,77,.12);border:1.5px solid rgba(150,220,77,.45);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="3\xaa RFEF">3\xaa RFEF</span>`,
  60: `<span style="display:inline-flex;align-items:center;justify-content:center;font-size:9px;font-weight:900;font-family:'JetBrains Mono',monospace;color:#b06fff;background:rgba(176,111,255,.13);border:1.5px solid rgba(176,111,255,.5);border-radius:4px;padding:1px 6px;margin-right:7px;letter-spacing:.3px;vertical-align:middle;line-height:16px" title="Divisi\xf3n de Honor">DIV.HON</span>`,
};

// Devuelve el logo SVG para una categoría (solo si es nacional senior con nivel reconocido)
function getCatLogoNac(cat){
  if(getCatProvincia(cat)!=='Nacional' || getCatGrupo(cat)!=='SENIOR') return '';
  const [nivel] = _nivelNacional(cat);
  return _LOGOS_NAC[nivel] || '';
}

// Mapa categoria → fuente (derivado de las actas, fuente más frecuente gana)
// Se construye una sola vez al cargar
const _CAT_FUENTE_MAP = (()=>{
  const cnt = {};
  ACTAS.forEach(a=>{
    if(!a.categoria || !a.fuente) return;
    if(!cnt[a.categoria]) cnt[a.categoria]={};
    cnt[a.categoria][a.fuente]=(cnt[a.categoria][a.fuente]||0)+1;
  });
  const m={};
  Object.entries(cnt).forEach(([cat,fuentes])=>{
    // La fuente con más actas gana
    m[cat]=Object.entries(fuentes).sort((a,b)=>b[1]-a[1])[0][0];
  });
  return m;
})();

// Convierte fuente → provincia
function _fuenteAProvincia(fuente){
  if(fuente==='alava')    return 'Álava';
  if(fuente==='gipuzkoa') return 'Gipuzkoa';
  if(fuente==='bizkaia')  return 'Bizkaia';
  if(fuente==='navarra')  return 'Navarra';
  if(fuente==='rioja')    return 'La Rioja';
  if(fuente==='cantabria') return 'Cantabria';
  if(fuente==='euskadi')  return 'Vasca';
  if(fuente==='rfef')     return 'Nacional';
  return '';
}

// Detecta automáticamente la provincia de una categoría por su fuente en ACTAS
// (fallback al nombre si no hay datos)
function _autoProvincia(cat){
  if(!cat) return '';
  const fuente = _CAT_FUENTE_MAP[cat];
  if(fuente) return _fuenteAProvincia(fuente);
  // fallback por nombre
  const n = cat.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/\u00aa/g,'a').replace(/\u00ba/g,'o').replace(/\s+/g,' ').trim();
  if(n.includes('alav') || n.includes('araba')) return 'Álava';
  if(n.includes('bizkaia') || n.includes('vizcaya') || n.includes('bizkai')) return 'Bizkaia';
  if(n.includes('gipuzkoa') || n.includes('guipuzcoa') || n.includes('gipuzko')) return 'Gipuzkoa';
  if(n.includes('navarra') || n.includes('nafarroa')) return 'Navarra';
  if(n.includes('rioja')) return 'La Rioja';
  if(n.includes('cantabria')) return 'Cantabria';
  if(n.includes('vasca') || n.includes('vasco') || n.includes('euskadi') || n.includes('euskal')) return 'Vasca';
  // Las copas/torneos de federación (FAF-AFF, FVF, RFGF...) son territoriales: la provincia
  // la da la FUENTE de descarga; si aún no hay actas, jamás 'Nacional' por el nombre.
  if(n.includes('torneo federaci') || n.includes('federazio txapelketa') ||
     n.includes('federazioa txapelketa') || n.includes('federazio torneoa') ||
     n.includes('kopa federazioa') || n.includes('federaziotarren kopa') ||
     n.includes('lurraldeko') || /\bcopa\s+federacio/i.test(n)) return '';
  if(n.includes('nacional') || n.includes('rfef') || n.includes('espana') ||
     n.includes('liga nacional')) return 'Nacional';
  // "Primera/Segunda/Tercera Federación" son nacionales aunque no lleven "rfef"
  if( (n.includes('primera') || n.includes('segunda') || n.includes('tercera') ||
       /\b[123]a\b/.test(n)) && n.includes('federaci') ) return 'Nacional';
  // 'division de honor' en juveniles es nacional; en cadete NO existe nacional → no asignar Nacional por nombre
  if(n.includes('division') && n.includes('honor') && n.includes('juvenil')) return 'Nacional';
  return '';
}

// Devuelve la provincia de una categoría (siempre automático desde fuente de las actas)
function getCatProvincia(cat){
  return _autoProvincia(cat);
}

// Detecta automáticamente el grupo de una categoría por su nombre
function _autoGrupo(cat){
  if(!cat) return '';
  const n = cat.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
    .replace(/\u00aa/g,'a').replace(/\u00ba/g,'o').replace(/\s+/g,' ').trim();
  // IMPORTANTE: comprobar juvenil/cadete ANTES que palabras genéricas de senior
  // para que "División de Honor Juvenil", "Liga Nacional Juvenil" etc. se clasifiquen bien.
  if(n.includes('juvenil')) return 'JUVENIL';
  if(n.includes('cadete'))  return 'CADETE';
  if(n.includes('senior') || n.includes('regional') || n.includes('preferente') ||
     n.includes('honor adulto') || n.includes('primera division') || n.includes('segunda division') ||
     n.includes('division de honor') || n.includes('1a division') || n.includes('2a division') ||
     n.includes('primera rfef') || n.includes('segunda rfef') || n.includes('tercera rfef') ||
     n.includes('primera federaci') || n.includes('segunda federaci') || n.includes('tercera federaci') ||
     n.includes('tercera federacion') || n.includes('2a rfef') || n.includes('1a rfef') || n.includes('3a rfef') ||
     (!n.includes('infan') &&
      !n.includes('alevin') &&
      !n.includes('benjamin') &&
      !n.includes('prebenjamin') && !n.includes('sala') && !n.includes('futsal') &&
      !/\bfs\b/.test(n) &&
      !n.includes('femenin') &&
      (n.includes('regional') || n.includes('senior') || n.includes('nacional') ||
       n.includes('preferente') || n.includes('autonomica') || n.includes('autonomico') ||
       n.includes('provincial') || n.includes('1a') || n.includes('2a') || n.includes('3a') ||
       n.includes('primera') || n.includes('segunda') || n.includes('tercera'))) )
    return 'SENIOR';
  return '';
}

// Devuelve el grupo de una categoría (override usuario > auto-detección)
function getCatGrupo(cat){
  if(!cat) return '';
  const ov = loadCatOverrides();
  if(ov[cat] && ov[cat].grupo) return ov[cat].grupo;
  return _autoGrupo(cat);
}

// Guarda cambios de una categoría
function setCatConfig(catOrig, campo, valor){
  const ov = loadCatOverrides();
  if(!ov[catOrig]) ov[catOrig] = {};
  if(valor) ov[catOrig][campo] = valor;
  else delete ov[catOrig][campo];
  if(!ov[catOrig].nombre && !ov[catOrig].grupo && !ov[catOrig].provincia) delete ov[catOrig];
  saveCatOverrides(ov);
  
  // Guardar cambios en localStorage inmediatamente
  localStorage.setItem('faf_cat_overrides', JSON.stringify(ov));
  localStorage.setItem('faf_cache_timestamp', Date.now().toString());
  
  // Invalidar cache del motor
  _invalidarMotor();
  rCfgCat();
  updSels();
  console.log('✓ Cambio de configuración guardado en localStorage');
}

function resetCatCfg(){
  if(!confirm('¿Resetear toda la configuración de categorías?')) return;
  localStorage.removeItem(CAT_OVERRIDES_KEY);
  _invalidarMotor();
  rCfgCat();
  updSels();
  toast('Configuración de categorías reseteada','ok');
}

// Render del panel de categorías en Configuración
function rCfgCat(){
  const srch = (document.getElementById('cfg-cat-s')?.value||'').toLowerCase();
  const filtGrupo = document.getElementById('cfg-cat-grupo-filt')?.value||'';
  const ov = loadCatOverrides();
  // Obtener todas las categorías únicas (sin sala)
  const allCats = sortCats([...new Set(ACTAS.map(a=>a.categoria).filter(c=>c&&!isSala(c)))]);
  const filtered = allCats.filter(c=>{
    const nombre = catNombre(c);
    if(srch && !c.toLowerCase().includes(srch) && !nombre.toLowerCase().includes(srch)) return false;
    const g = getCatGrupo(c);
    if(filtGrupo === '_auto' && (ov[c]?.grupo)) return false;
    if(filtGrupo === '_auto' && !_autoGrupo(c) && !(ov[c]?.grupo)) return false;
    if(filtGrupo && filtGrupo !== '_auto' && g !== filtGrupo) return false;
    return true;
  });

  const GRUPO_COLORS = {SENIOR:'var(--hw)',JUVENIL:'var(--a4)',CADETE:'var(--a5)'};
  const GRUPO_BG = {SENIOR:'rgba(0,240,160,.12)',JUVENIL:'rgba(77,139,255,.12)',CADETE:'rgba(176,111,255,.12)'};
  const GRUPO_BORDER = {SENIOR:'rgba(0,240,160,.35)',JUVENIL:'rgba(77,139,255,.35)',CADETE:'rgba(176,111,255,.35)'};

  if(!filtered.length){
    document.getElementById('cfg-cat-list').innerHTML='<div class="empty">No hay categorías con ese filtro.</div>';
    return;
  }

  const PROV_COLORS = {'Álava':'var(--hw)','Bizkaia':'var(--a4)','Gipuzkoa':'var(--a5)','Vasca':'var(--acc)','Nacional':'#ff4040'};
  const PROV_BG = {'Álava':'rgba(0,240,160,.12)','Bizkaia':'rgba(77,139,255,.12)','Gipuzkoa':'rgba(176,111,255,.12)','Vasca':'rgba(245,200,66,.12)','Nacional':'rgba(255,64,64,.12)'};
  const PROV_BORDER = {'Álava':'rgba(0,240,160,.35)','Bizkaia':'rgba(77,139,255,.35)','Gipuzkoa':'rgba(176,111,255,.35)','Vasca':'rgba(245,200,66,.35)','Nacional':'rgba(255,64,64,.35)'};

  const html = filtered.map(cat=>{
    const g = getCatGrupo(cat);
    const p = getCatProvincia(cat);
    const nombre = catNombre(cat);
    const esRenombrada = ov[cat]?.nombre && ov[cat].nombre !== cat;
    const esGrupoManual = !!ov[cat]?.grupo;
    const esProvManual = !!ov[cat]?.provincia;
    const catEsc = cat.replace(/'/g,"\\'").replace(/"/g,'&quot;');
    const grupoBtn = (grp, label) => {
      const activo = g === grp;
      return `<button onclick="setCatConfig('${catEsc}','grupo','${grp}')"
        style="padding:5px 12px;border-radius:5px;cursor:pointer;font-size:12px;font-weight:${activo?700:400};
        background:${activo?GRUPO_BG[grp]:'rgba(255,255,255,.04)'};
        border:1px solid ${activo?GRUPO_BORDER[grp]:'rgba(255,255,255,.1)'};
        color:${activo?GRUPO_COLORS[grp]:'var(--mu)'}">${label}</button>`;
    };
    const provBtn = (pv, label) => {
      const activo = p === pv;
      return `<button onclick="setCatConfig('${catEsc}','provincia','${pv}')"
        style="padding:5px 12px;border-radius:5px;cursor:pointer;font-size:12px;font-weight:${activo?700:400};
        background:${activo?PROV_BG[pv]:'rgba(255,255,255,.04)'};
        border:1px solid ${activo?PROV_BORDER[pv]:'rgba(255,255,255,.1)'};
        color:${activo?PROV_COLORS[pv]:'var(--mu)'}">${label}</button>`;
    };
    const partidos = ACTAS.filter(a=>a.categoria===cat).length;
    const provAuto = getCatProvincia(cat);
    const PROV_COLORS2 = {'Álava':'var(--hw)','Bizkaia':'var(--a4)','Gipuzkoa':'var(--a5)','Vasca':'var(--acc)','Nacional':'#ff4040'};
    const provBadgeHtml = provAuto
      ? `<span style="font-size:11px;font-weight:700;color:${PROV_COLORS2[provAuto]||'var(--mu)'};background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:4px;padding:2px 8px">${provAuto}</span>`
      : `<span style="font-size:11px;color:var(--a3)">⚠ Sin provincia detectada</span>`;
    return `<div style="background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:14px 16px;margin-bottom:10px">
      <div style="display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap">
        <div style="flex:1;min-width:200px">
          <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Nombre original</div>
          <div style="font-weight:600;font-size:14px;color:var(--tx)">${cat}</div>
          ${partidos?`<div style="font-size:10px;color:var(--mu);margin-top:2px">${partidos} partidos</div>`:''}
          <div style="margin-top:6px">${provBadgeHtml}</div>
        </div>
        <div style="flex:1;min-width:200px">
          <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Nombre visible <span style="color:var(--a3)">(editable)</span></div>
          <input type="text" value="${nombre.replace(/"/g,'&quot;')}" placeholder="Nombre visible..."
            onchange="setCatConfig('${catEsc}','nombre',this.value.trim())"
            style="width:100%;background:var(--s2);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:13px;outline:none">
          ${esRenombrada?`<div style="font-size:10px;color:var(--acc);margin-top:2px">✓ Renombrada</div>`:''}
        </div>
        <div>
          <div style="font-size:11px;color:var(--mu);margin-bottom:4px">Grupo ${!esGrupoManual&&g?'<span style="color:var(--mu);font-size:9px">(auto)</span>':''}</div>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${grupoBtn('SENIOR','👤 Senior')}
            ${grupoBtn('JUVENIL','⚽ Juvenil')}
            ${grupoBtn('CADETE','🎓 Cadete')}
            ${g?`<button onclick="setCatConfig('${catEsc}','grupo','')"
              style="padding:5px 10px;border-radius:5px;cursor:pointer;font-size:11px;background:rgba(255,79,55,.08);border:1px solid rgba(255,79,55,.2);color:var(--mu)">✕ Quitar</button>`:''}
          </div>
          ${!g?`<div style="font-size:10px;color:var(--a3);margin-top:4px">⚠ Sin grupo asignado</div>`:''}
        </div>
      </div>
    </div>`;
  }).join('');

  const sinGrupo = allCats.filter(c=>!getCatGrupo(c)).length;
  document.getElementById('cfg-cat-list').innerHTML = `
    <div style="display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap">
      <div class="sc" style="flex:none;min-width:90px"><div class="sv">${allCats.length}</div><div class="sl">Categorías</div></div>
      <div class="sc" style="flex:none;min-width:90px;border-top-color:var(--hw)"><div class="sv" style="color:var(--hw)">${allCats.filter(c=>getCatGrupo(c)==='SENIOR').length}</div><div class="sl">Senior</div></div>
      <div class="sc" style="flex:none;min-width:90px;border-top-color:var(--a4)"><div class="sv" style="color:var(--a4)">${allCats.filter(c=>getCatGrupo(c)==='JUVENIL').length}</div><div class="sl">Juvenil</div></div>
      <div class="sc" style="flex:none;min-width:90px;border-top-color:var(--a5)"><div class="sv" style="color:var(--a5)">${allCats.filter(c=>getCatGrupo(c)==='CADETE').length}</div><div class="sl">Cadete</div></div>
      ${sinGrupo?`<div class="sc" style="flex:none;min-width:90px;border-top-color:var(--a3)"><div class="sv" style="color:var(--a3)">${sinGrupo}</div><div class="sl">Sin grupo</div></div>`:''}
    </div>
    ${html}`;
}

// Tab switcher en config
function cfgTab(tab){
  document.getElementById('cfg-panel-cat').style.display = tab==='cat'?'':'none';
  document.getElementById('cfg-panel-hom').style.display = tab==='hom'?'':'none';
  document.getElementById('cfg-panel-mrg').style.display = tab==='mrg'?'':'none';
  document.getElementById('cfg-panel-sug').style.display = tab==='sug'?'':'none';
  document.getElementById('cfg-panel-disc').style.display = tab==='disc'?'':'none';
  document.getElementById('cfg-tab-cat').classList.toggle('on', tab==='cat');
  document.getElementById('cfg-tab-hom').classList.toggle('on', tab==='hom');
  document.getElementById('cfg-tab-mrg').classList.toggle('on', tab==='mrg');
  document.getElementById('cfg-tab-sug').classList.toggle('on', tab==='sug');
  document.getElementById('cfg-tab-disc').classList.toggle('on', tab==='disc');
  if(tab==='cat') rCfgCat();
  else if(tab==='hom') rCfg();
  else if(tab==='mrg') rCfgMrg();
  else if(tab==='sug') rCfgSug();
  else if(tab==='disc') rCfgDisc();
}

// ── DISCREPANCIAS (Config > Discrepancias) ─────────────────────────────────────
const DISC_RES_KEY      = 'faf_disc_resoluciones';
const DISC_GOLED_KEY    = 'faf_disc_goleadores';   // correcciones de goleadores guardadas
function loadDiscResoluciones(){ try{ return JSON.parse(localStorage.getItem(DISC_RES_KEY)||'{}'); }catch(e){ return {}; } }
function saveDiscResoluciones(m){ localStorage.setItem(DISC_RES_KEY, JSON.stringify(m)); }
function loadDiscGoleadores(){ try{ return JSON.parse(localStorage.getItem(DISC_GOLED_KEY)||'{}'); }catch(e){ return {}; } }
function saveDiscGoleadores(m){ localStorage.setItem(DISC_GOLED_KEY, JSON.stringify(m)); }
function _discKey(d){ return d.cod_grupo+'|||'+d.equipo_local+'|||'+d.equipo_visitante; }

function getDiscrepancias(){
  const res = loadDiscResoluciones();
  return (DISCREPANCIAS_BASE||[]).map(d=>{
    const k = _discKey(d);
    return {...d, resolucion: res[k] || d.resolucion || null};
  });
}

// ── Helpers de revisión ──────────────────────────────────────────────────────
// Un acta está "revisada" si no tiene ninguna discrepancia pendiente (sin resolución)
// asociada a ella (buscamos por acta_id) Y su liga (cat+temp) ha sido analizada por Modo 12.
function _actaRevisada(acta_id){
  if(!acta_id) return false;
  // Buscar el acta en la base de datos para obtener cat+temp
  const acta = DB[String(acta_id)];
  if(!acta) return false;
  const cat  = acta.categoria || '';
  const temp = acta.temporada  || '';
  // Si la liga no ha sido analizada por Modo 12, NO puede considerarse revisada
  if(!LIGAS_CON_TABLA.has(`${cat}|||${temp}`)) return false;
  const disc = getDiscrepancias();
  const afecta = disc.filter(d => String(d.acta_id) === String(acta_id));
  if(!afecta.length) return true;   // sin discrepancias conocidas → OK
  return afecta.every(d => !!d.resolucion || d.estado !== 'discrepancia');
}

// Una liga (cat+temp) está "revisada" si:
//   • Ha sido analizada por Modo 12 (tiene tabla cruzada descargada)
//   • Ninguna discrepancia pendiente (sin resolver) para esa cat+temp
//   • Ningún partido sin_acta para esa cat+temp
function _ligaRevisada(cat, temp){
  // Si no hay tabla cruzada descargada para esta liga, NO puede estar revisada
  const clave = `${cat}|||${temp||''}`;
  // Probar con temp exacta; si no, buscar cualquier entrada con esa cat
  const tieneTabla = LIGAS_CON_TABLA.has(clave) ||
    (!temp && [...LIGAS_CON_TABLA].some(k => k.startsWith(`${cat}|||`)));
  if(!tieneTabla) return false;
  const disc = getDiscrepancias();
  const deEstaLiga = disc.filter(d =>
    d.categoria === cat &&
    (!temp || !d.temporada || d.temporada === temp)
  );
  // Sin discrepancias Y con tabla analizada → OK
  if(!deEstaLiga.length) return true;
  const pendiente = deEstaLiga.some(d =>
    (d.estado === 'discrepancia' && !d.resolucion) || d.estado === 'sin_acta'
  );
  return !pendiente;
}

function setDiscResolucion(key, valor){
  const res = loadDiscResoluciones();
  if(valor){ res[key]=valor; } else { delete res[key]; }
  saveDiscResoluciones(res);
  _rDiscBadge();
  rCfgDisc();
  toast(valor?'Resolución guardada: '+valor:'Resolución eliminada','ok');
}

function resetDiscResoluciones(){
  if(!confirm('¿Borrar todas las resoluciones de discrepancias?')) return;
  localStorage.removeItem(DISC_RES_KEY);
  localStorage.removeItem(DISC_GOLED_KEY);
  _rDiscBadge();
  rCfgDisc();
  toast('Resoluciones borradas','ok');
}

function _rDiscBadge(){
  const disc = getDiscrepancias();
  const pend = disc.filter(d=>!d.resolucion && d.estado==='discrepancia').length;
  const badge = document.getElementById('cfg-disc-badge');
  if(!badge) return;
  if(pend>0){ badge.textContent=pend; badge.style.display=''; badge.style.background='var(--a2)'; }
  else if(disc.length>0){ badge.textContent=disc.length; badge.style.display=''; badge.style.background='var(--mu)'; }
  else { badge.style.display='none'; }
}

// ── Modal visor de acta / corrector ──────────────────────────────────────────
let _discModalKey = null;
let _discModalData = null;

function discAbrirVisor(k){
  const disc = getDiscrepancias();
  const d = disc.find(x=>_discKey(x)===k);
  if(!d) return;
  _discModalKey  = k;
  _discModalData = d;
  _discRenderModal(d);
  document.getElementById('disc-modal-overlay').style.display='flex';
}

function discCerrarVisor(){
  document.getElementById('disc-modal-overlay').style.display='none';
  _discModalKey=null; _discModalData=null;
}

function _discRenderModal(d){
  const goleadoresGuardados = loadDiscGoleadores()[_discModalKey] || null;
  const goleadores = goleadoresGuardados || d.goleadores_acta || [];
  const jLocal   = d.jugadores_local    || [];
  const jVisit   = d.jugadores_visitante || [];
  const todosJug = [...jLocal.map(n=>({n,eq:'L'})), ...jVisit.map(n=>({n,eq:'V'}))];

  // Calcular marcador desde goleadores actuales
  const resTabla = d.resultado_tabla || '?';
  let glCalc=0, gvCalc=0;
  goleadores.forEach(g=>{ if(g.equipo==='local'||g.equipo==='L') glCalc++; else gvCalc++; });
  const resGol = `${glCalc}-${gvCalc}`;

  // Tabla de goleadores actual
  const filas = goleadores.map((g,i)=>{
    const eqLabel = (g.equipo==='local'||g.equipo==='L') ? `<span style="color:var(--a4)">${d.equipo_local}</span>` : `<span style="color:var(--a2)">${d.equipo_visitante}</span>`;
    const eqVal   = (g.equipo==='local'||g.equipo==='L') ? 'local' : 'visitante';
    const optsJug = todosJug.map(j=>`<option value="${j.n}"${j.n===g.jugador?' selected':''}>${j.n}</option>`).join('');
    const optsEq  = `<option value="local"${eqVal==='local'?' selected':''}>Local (${d.equipo_local})</option>`+
                    `<option value="visitante"${eqVal==='visitante'?' selected':''}>Visit. (${d.equipo_visitante})</option>`;
    return `<tr style="border-bottom:1px solid var(--b)">
      <td style="padding:4px 8px;color:var(--mu);font-size:12px">${g.minuto||'?'}'</td>
      <td style="padding:4px 8px">
        <select onchange="discGolJugador(${i},this.value)" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:4px;padding:3px 6px;font-size:12px;max-width:220px">
          ${optsJug}
        </select>
      </td>
      <td style="padding:4px 8px">
        <select onchange="discGolEquipo(${i},this.value)" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:4px;padding:3px 6px;font-size:12px">
          ${optsEq}
        </select>
      </td>
      <td style="padding:4px 8px">
        <button onclick="discGolEliminar(${i})" style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);border-radius:4px;padding:2px 8px;font-size:11px;cursor:pointer">✕</button>
      </td>
    </tr>`;
  }).join('');

  const addOptJug = todosJug.map(j=>`<option value="${j.n}|local">${j.n} (Local)</option>`).join('')+
                    todosJug.map(j=>`<option value="${j.n}|visitante">${j.n} (Visit.)</option>`).join('');

  document.getElementById('disc-modal-body').innerHTML=`
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px;gap:12px;flex-wrap:wrap">
      <div>
        <div style="font-size:15px;font-weight:700;color:var(--tx)">${d.equipo_local} <span style="color:var(--mu)">vs</span> ${d.equipo_visitante}</div>
        <div style="font-size:11px;color:var(--mu);margin-top:3px">${d.categoria||''} ${d.temporada?'· T.'+d.temporada:''} · Grupo ${d.cod_grupo}${d.jornada?' · J.'+d.jornada:''}${d.fecha?' · '+d.fecha:''}</div>
      </div>
      <button onclick="discCerrarVisor()" style="background:var(--s2);border:1px solid var(--b);color:var(--mu);border-radius:6px;padding:4px 12px;cursor:pointer;font-size:13px">✕ Cerrar</button>
    </div>

    <!-- Marcadores lado a lado -->
    <div style="display:flex;gap:12px;margin-bottom:18px;flex-wrap:wrap">
      <div style="flex:1;min-width:120px;background:rgba(245,200,66,.08);border:1px solid rgba(245,200,66,.3);border-radius:8px;padding:12px;text-align:center">
        <div style="font-size:10px;color:var(--a3);margin-bottom:4px;font-weight:700">🗂 TABLA CRUZADA (oficial)</div>
        <div style="font-size:36px;font-weight:900;font-family:'Bebas Neue',sans-serif;color:var(--a3)">${resTabla}</div>
      </div>
      <div style="flex:1;min-width:120px;background:rgba(77,139,255,.08);border:1px solid rgba(77,139,255,.3);border-radius:8px;padding:12px;text-align:center">
        <div style="font-size:10px;color:var(--a4);margin-bottom:4px;font-weight:700">📄 ACTA #${d.acta_id||'?'}</div>
        <div style="font-size:36px;font-weight:900;font-family:'Bebas Neue',sans-serif;color:var(--a4)">${d.resultado_acta||'?'}</div>
      </div>
      <div style="flex:1;min-width:120px;background:rgba(0,240,160,.07);border:1px solid rgba(0,240,160,.25);border-radius:8px;padding:12px;text-align:center">
        <div style="font-size:10px;color:var(--acc);margin-bottom:4px;font-weight:700">⚽ GOLEADORES (calc.)</div>
        <div style="font-size:36px;font-weight:900;font-family:'Bebas Neue',sans-serif;color:var(--acc)">${resGol}</div>
      </div>
    </div>

    <!-- Botones de resolución -->
    <div style="background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px;margin-bottom:16px">
      <div style="font-size:12px;color:var(--mu);margin-bottom:8px;font-weight:600">¿Cuál es el resultado correcto?</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button id="disc-btn-tabla" onclick="discElegirTabla()" style="background:${(getDiscrepancias().find(x=>_discKey(x)===_discModalKey)||{}).resolucion===('tabla:'+resTabla)?'rgba(245,200,66,.25)':'rgba(245,200,66,.09)'};border:1px solid rgba(245,200,66,.5);color:var(--a3);font-size:13px;font-weight:700;border-radius:6px;padding:7px 16px;cursor:pointer">
          🗂 Tabla: ${resTabla}</button>
        <button id="disc-btn-acta" onclick="discElegirActa()" style="background:${(getDiscrepancias().find(x=>_discKey(x)===_discModalKey)||{}).resolucion===('acta:'+d.resultado_acta)?'rgba(77,139,255,.25)':'rgba(77,139,255,.09)'};border:1px solid rgba(77,139,255,.5);color:var(--a4);font-size:13px;font-weight:700;border-radius:6px;padding:7px 16px;cursor:pointer">
          📄 Acta: ${d.resultado_acta}</button>
        <button onclick="discGolUsarTabla()" style="background:rgba(0,240,160,.09);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:13px;font-weight:700;border-radius:6px;padding:7px 16px;cursor:pointer" title="Usar resultado de tabla y recalcular goleadores con los editados abajo">
          ⚽ Usar tabla + goleadores editados</button>
      </div>
    </div>

    <!-- Editor de goleadores -->
    <div style="background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;flex-wrap:wrap;gap:8px">
        <div style="font-size:12px;font-weight:700;color:var(--tx)">⚽ Goleadores del acta</div>
        <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
          <select id="disc-add-jug" style="background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:4px;padding:4px 8px;font-size:12px">
            <option value="">— Añadir goleador —</option>
            ${addOptJug}
          </select>
          <input type="number" id="disc-add-min" placeholder="min" min="1" max="120" style="width:60px;background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:4px;padding:4px 6px;font-size:12px">
          <button onclick="discGolAnadir()" style="background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.4);color:var(--acc);font-size:12px;font-weight:700;border-radius:5px;padding:4px 10px;cursor:pointer">+ Añadir</button>
          <button onclick="discGolGuardar()" style="background:rgba(0,240,160,.2);border:1px solid rgba(0,240,160,.6);color:var(--acc);font-size:12px;font-weight:700;border-radius:5px;padding:4px 12px;cursor:pointer">💾 Guardar</button>
        </div>
      </div>
      ${goleadores.length===0
        ? '<div style="font-size:12px;color:var(--mu);padding:8px 0">No hay goleadores registrados en el acta.</div>'
        : `<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse">
            <thead><tr style="border-bottom:1px solid var(--b2)">
              <th style="padding:4px 8px;font-size:11px;color:var(--mu);text-align:left">Min</th>
              <th style="padding:4px 8px;font-size:11px;color:var(--mu);text-align:left">Jugador</th>
              <th style="padding:4px 8px;font-size:11px;color:var(--mu);text-align:left">Equipo</th>
              <th style="padding:4px 8px;font-size:11px;color:var(--mu)"></th>
            </tr></thead>
            <tbody id="disc-gol-tbody">${filas}</tbody>
          </table></div>`
      }
      <div id="disc-gol-tbody-wrap"${goleadores.length===0?'':' style="display:none"'}></div>
    </div>
  `;
}

// Mutaciones en los goleadores (en memoria mientras el modal está abierto)
function _discGolActual(){
  return loadDiscGoleadores()[_discModalKey] || JSON.parse(JSON.stringify(_discModalData.goleadores_acta||[]));
}
function _discGolSync(){
  // Re-renderizar la fila del modal body para reflejar cambios sin cerrar
  if(!_discModalData) return;
  const d = getDiscrepancias().find(x=>_discKey(x)===_discModalKey) || _discModalData;
  _discRenderModal(d);
}

function discGolJugador(idx, nombre){
  const gols = _discGolActual();
  if(gols[idx]) gols[idx].jugador = nombre;
  const m = loadDiscGoleadores(); m[_discModalKey]=gols; saveDiscGoleadores(m);
  _discGolSync();
}
function discGolEquipo(idx, eq){
  const gols = _discGolActual();
  if(gols[idx]) gols[idx].equipo = eq;
  const m = loadDiscGoleadores(); m[_discModalKey]=gols; saveDiscGoleadores(m);
  _discGolSync();
}
function discGolEliminar(idx){
  const gols = _discGolActual();
  gols.splice(idx,1);
  const m = loadDiscGoleadores(); m[_discModalKey]=gols; saveDiscGoleadores(m);
  _discGolSync();
}
function discGolAnadir(){
  const sel = document.getElementById('disc-add-jug');
  const min = document.getElementById('disc-add-min');
  if(!sel||!sel.value) return;
  const parts = sel.value.split('|');
  const nombre = parts[0], equipo = parts[1]||'local';
  const gols = _discGolActual();
  gols.push({jugador:nombre, equipo:equipo, minuto: parseInt(min?.value)||''});
  const m = loadDiscGoleadores(); m[_discModalKey]=gols; saveDiscGoleadores(m);
  _discGolSync();
}
function discGolGuardar(){
  toast('Goleadores guardados','ok');
  _discGolSync();
}
function discGolUsarTabla(){
  const gols = _discGolActual();
  let gl=0, gv=0;
  gols.forEach(g=>{ if(g.equipo==='local'||g.equipo==='L') gl++; else gv++; });
  const res = `${gl}-${gv}`;
  setDiscResolucion(_discModalKey, 'tabla:'+res);
  discCerrarVisor();
}
function discElegirTabla(){
  const d = _discModalData;
  setDiscResolucion(_discModalKey, 'tabla:'+d.resultado_tabla);
  discCerrarVisor();
}
function discElegirActa(){
  const d = _discModalData;
  setDiscResolucion(_discModalKey, 'acta:'+d.resultado_acta);
  discCerrarVisor();
}

// ── Clasificación provisional con partidos sin acta ──────────────────────────
function _discClasifProvisional(){
  // Toma los partidos sin_acta y añade su resultado a la clasificación ACTAS normal
  const sinActa = getDiscrepancias().filter(d=>d.estado==='sin_acta');
  if(!sinActa.length) return null;

  // Reutilizar misma lógica que clasificación pero extendida
  const extra = sinActa.map(d=>{
    const partes = (d.resultado_tabla||'0-0').split('-');
    const gl = parseInt(partes[0])||0;
    const gv = parseInt(partes[1])||0;
    return {
      equipo_local: d.equipo_local,
      equipo_visitante: d.equipo_visitante,
      goles_local: gl, goles_visitante: gv,
      categoria: d.categoria, temporada: d.temporada,
      _provisional: true
    };
  });
  return extra;
}

function rCfgDisc(){
  _rDiscBadge();
  const cont = document.getElementById('cfg-disc-list');
  if(!cont) return;

  function _discActaUrl(d){
    // Construye la URL del acta según el prefijo del acta_id
    const aid = String(d.acta_id||'');
    let base, cod_prim='1000120', num=aid;
    if(aid.startsWith('E_')){ base='https://www.euskadifutbol.eus/pnfg/NPcd/NFG_CmpPartido'; num=aid.slice(2); }
    else if(aid.startsWith('G_')){ base='https://www.gipuzkoafutbola.eus/pnfg/NPcd/NFG_CmpPartido'; num=aid.slice(2); }
    else if(aid.startsWith('B_')){ base='https://www.fvf-bff.eus/pnfg/NPcd/NFG_CmpPartido'; num=aid.slice(2); }
    else if(aid.startsWith('N_')){ base='https://marcadores.rfef.es/pnfg/NPcd/NFG_CmpPartido'; num=aid.slice(2); }
    else if(aid.startsWith('R_')){ base='https://www.frfutbol.com/pnfg/NPcd/NFG_CmpPartido'; num=aid.slice(2); }
    else { base='https://www.faf-aff.eus/pnfg/NPcd/NFG_CmpPartido'; }
    if(!num) return null;
    return `${base}?cod_primaria=${cod_prim}&CodActa=${num}`;
  }
  function _discTablaUrl(d){
    const cg = d.cod_grupo;
    if(!cg) return null;
    return `https://www.faf-aff.eus/pnfg/NPcd/NFG_VisTablaCruzada?cod_primaria=1000120&CodGrupo=${cg}`;
  }

  const srch   = (document.getElementById('disc-s')?.value||'').toLowerCase();
  const estado = document.getElementById('disc-estado-filt')?.value||'';

  let disc = getDiscrepancias();
  if(srch) disc=disc.filter(d=>
    d.equipo_local.toLowerCase().includes(srch)||
    d.equipo_visitante.toLowerCase().includes(srch)||
    (d.categoria||'').toLowerCase().includes(srch)||
    (d.temporada||'').includes(srch)
  );
  if(estado==='discrepancia') disc=disc.filter(d=>d.estado==='discrepancia');
  else if(estado==='sin_acta') disc=disc.filter(d=>d.estado==='sin_acta');
  else if(estado==='pendiente') disc=disc.filter(d=>!d.resolucion&&d.estado==='discrepancia');
  else if(estado==='resuelto') disc=disc.filter(d=>!!d.resolucion);

  if(!disc.length){
    const msg=(DISCREPANCIAS_BASE||[]).length===0
      ?'<div class="empty">No hay discrepancias cargadas. Ejecuta el Modo 12 desde la CMD para analizar tablas cruzadas.</div>'
      :'<div class="empty">Sin discrepancias con ese filtro.</div>';
    cont.innerHTML=msg; return;
  }

  const all=getDiscrepancias();

  // ── Bloque "Partidos sin acta" (clasificación provisional) ──────────────
  const sinActaTodos = all.filter(d=>d.estado==='sin_acta');
  let sinActaHtml = '';
  if(sinActaTodos.length && (!estado || estado==='sin_acta')){
    // Mini tabla por categoría/temporada
    const grupos = {};
    sinActaTodos.forEach(d=>{
      const gk = `${d.categoria||'?'} · ${d.temporada||'?'}`;
      if(!grupos[gk]) grupos[gk]=[];
      grupos[gk].push(d);
    });
    const gTablas = Object.entries(grupos).map(([gk,lista])=>{
      const filas = lista.map(d=>`
        <tr style="border-bottom:1px solid rgba(255,255,255,.04)">
          <td style="padding:5px 8px;font-size:12px;color:var(--tx)">${d.equipo_local}</td>
          <td style="padding:5px 8px;font-size:12px;color:var(--mu)">vs</td>
          <td style="padding:5px 8px;font-size:12px;color:var(--tx)">${d.equipo_visitante}</td>
          <td style="padding:5px 8px;font-size:22px;font-weight:800;font-family:'Bebas Neue',sans-serif;color:var(--a3)">${d.resultado_tabla}</td>
          <td style="padding:5px 8px;font-size:11px;color:var(--mu)">J.${d.jornada||'?'}</td>
          <td style="padding:5px 8px"><span style="font-size:10px;background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.3);color:var(--a3);border-radius:4px;padding:2px 7px">⏳ Sin acta</span></td>
        </tr>`).join('');
      return `<div style="margin-bottom:10px">
        <div style="font-size:11px;font-weight:700;color:var(--a3);margin-bottom:6px;padding:4px 8px;background:rgba(245,200,66,.06);border-radius:4px">${gk}</div>
        <div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse">
          <thead><tr style="border-bottom:1px solid var(--b2)">
            <th style="padding:4px 8px;font-size:10px;color:var(--mu);text-align:left">Local</th>
            <th></th>
            <th style="padding:4px 8px;font-size:10px;color:var(--mu);text-align:left">Visitante</th>
            <th style="padding:4px 8px;font-size:10px;color:var(--mu);text-align:left">Resultado (tabla)</th>
            <th style="padding:4px 8px;font-size:10px;color:var(--mu);text-align:left">Jornada</th>
            <th></th>
          </tr></thead>
          <tbody>${filas}</tbody>
        </table></div>
      </div>`;
    }).join('');

    sinActaHtml = `<div style="background:rgba(245,200,66,.04);border:1px solid rgba(245,200,66,.2);border-left:3px solid var(--a3);border-radius:8px;padding:14px 16px;margin-bottom:16px">
      <div style="font-size:13px;font-weight:700;color:var(--a3);margin-bottom:10px">⏳ Partidos pendientes de acta (${sinActaTodos.length})</div>
      <div style="font-size:12px;color:var(--mu);margin-bottom:12px;line-height:1.6">
        Estos partidos aparecen en la tabla cruzada oficial pero aún no tienen acta descargada.<br>
        Sus resultados se incorporan provisionalmente a la clasificación hasta que se descargue el acta.
      </div>
      ${gTablas}
    </div>`;
  }

  const resumen=`<div style="display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap">
    <div class="sc" style="flex:none;min-width:80px"><div class="sv">${all.length}</div><div class="sl">Total</div></div>
    <div class="sc" style="flex:none;min-width:80px;border-top-color:var(--a2)"><div class="sv" style="color:var(--a2)">${all.filter(d=>d.estado==='discrepancia').length}</div><div class="sl">Discrepancias</div></div>
    <div class="sc" style="flex:none;min-width:80px;border-top-color:var(--a3)"><div class="sv" style="color:var(--a3)">${all.filter(d=>d.estado==='sin_acta').length}</div><div class="sl">Sin acta</div></div>
    <div class="sc" style="flex:none;min-width:80px;border-top-color:var(--a4)"><div class="sv" style="color:var(--a4)">${all.filter(d=>!d.resolucion&&d.estado==='discrepancia').length}</div><div class="sl">Pendientes</div></div>
    <div class="sc" style="flex:none;min-width:80px;border-top-color:var(--hw)"><div class="sv" style="color:var(--hw)">${all.filter(d=>!!d.resolucion).length}</div><div class="sl">Resueltos</div></div>
  </div>`;

  const items=disc.map(d=>{
    const k=_discKey(d);
    const sinActa=d.estado==='sin_acta';
    const resuelto=!!d.resolucion;
    const bord=resuelto?'var(--hw)':sinActa?'var(--a3)':'var(--a2)';
    const bg=resuelto?'rgba(0,240,160,.04)':sinActa?'rgba(245,200,66,.04)':'rgba(255,79,55,.05)';
    const etq=resuelto
      ?`<span style="font-size:10px;font-weight:700;color:var(--hw);background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.35);border-radius:4px;padding:1px 7px">✓ ${d.resolucion}</span>`
      :sinActa?`<span style="font-size:10px;font-weight:700;color:var(--a3);background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.35);border-radius:4px;padding:1px 7px">⏳ SIN ACTA</span>`
      :`<span style="font-size:10px;font-weight:700;color:var(--a2);background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.35);border-radius:4px;padding:1px 7px">⚡ DISCREPANCIA</span>`;

    const kEsc=k.replace(/\\/g,'\\\\').replace(/'/g,"\\'");

    const rHtml=sinActa
      ?`<div style="display:flex;gap:14px;align-items:center;margin:10px 0">
          <div style="text-align:center"><div style="font-size:10px;color:var(--mu);margin-bottom:2px">TABLA CRUZADA</div>
            <div style="font-size:24px;font-weight:800;font-family:'Bebas Neue',sans-serif;color:var(--a3)">${d.resultado_tabla}</div></div>
          <div style="color:var(--mu);font-size:16px">→</div>
          <div style="text-align:center"><div style="font-size:10px;color:var(--mu);margin-bottom:2px">ACTA</div>
            <div style="font-size:13px;color:var(--a3);font-style:italic">sin acta descargada</div></div>
        </div>`
      :`<div style="display:flex;gap:14px;align-items:center;margin:10px 0">
          <div style="text-align:center"><div style="font-size:10px;color:var(--mu);margin-bottom:2px">TABLA CRUZADA</div>
            <div style="font-size:24px;font-weight:800;font-family:'Bebas Neue',sans-serif;color:var(--a3)">${d.resultado_tabla}</div></div>
          <div style="color:var(--a2);font-size:18px;font-weight:700">≠</div>
          <div style="text-align:center"><div style="font-size:10px;color:var(--mu);margin-bottom:2px">ACTA #${d.acta_id||'?'}</div>
            <div style="font-size:24px;font-weight:800;font-family:'Bebas Neue',sans-serif;color:var(--a4)">${d.resultado_acta||'?'}</div></div>
        </div>`;

    // Botones resolución rápida (sin modal)
    const bots=sinActa?'':`
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.06)">
        <span style="font-size:12px;color:var(--mu)">¿Cuál es el correcto?</span>
        <button onclick="setDiscResolucion('${kEsc}','tabla:${d.resultado_tabla}')"
          style="background:${d.resolucion==='tabla:'+d.resultado_tabla?'rgba(245,200,66,.22)':'rgba(245,200,66,.08)'};border:1px solid ${d.resolucion==='tabla:'+d.resultado_tabla?'rgba(245,200,66,.6)':'rgba(245,200,66,.25)'};color:var(--a3);font-size:12px;font-weight:700;border-radius:6px;padding:6px 13px;cursor:pointer">
          🗂 Tabla: ${d.resultado_tabla}</button>
        <button onclick="setDiscResolucion('${kEsc}','acta:${d.resultado_acta}')"
          style="background:${d.resolucion==='acta:'+d.resultado_acta?'rgba(77,139,255,.22)':'rgba(77,139,255,.08)'};border:1px solid ${d.resolucion==='acta:'+d.resultado_acta?'rgba(77,139,255,.6)':'rgba(77,139,255,.25)'};color:var(--a4);font-size:12px;font-weight:700;border-radius:6px;padding:6px 13px;cursor:pointer">
          📄 Acta: ${d.resultado_acta}</button>
        <button onclick="discAbrirVisor('${kEsc}')"
          style="background:rgba(176,111,255,.1);border:1px solid rgba(176,111,255,.35);color:var(--a5);font-size:12px;font-weight:700;border-radius:6px;padding:6px 13px;cursor:pointer">
          🔍 Ver detalle / editar goleadores</button>
        ${resuelto?`<button onclick="setDiscResolucion('${kEsc}',null)"
          style="background:rgba(255,79,55,.07);border:1px solid rgba(255,79,55,.2);color:var(--mu);font-size:12px;border-radius:6px;padding:6px 11px;cursor:pointer">✕ Quitar</button>`:''}
      </div>`;

    return `<div style="background:${bg};border:1px solid ${bord}33;border-left:3px solid ${bord};border-radius:8px;padding:14px 16px;margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:4px">
        <div>
          <div style="font-size:13px;font-weight:700;color:var(--tx)">${d.equipo_local} <span style="color:var(--mu);font-weight:400">vs</span> ${d.equipo_visitante}</div>
          <div style="font-size:11px;color:var(--mu);margin-top:2px">${d.categoria||''} ${d.temporada?'· T.'+d.temporada:''} · Grupo ${d.cod_grupo}${d.jornada?' · J.'+d.jornada:''}</div>
          <div style="display:flex;gap:8px;margin-top:5px;flex-wrap:wrap">
            ${(()=>{ const u=_discActaUrl(d); return u&&!sinActa?`<a href="${u}" target="_blank" rel="noopener" style="font-size:11px;font-weight:600;color:var(--a4);background:rgba(77,139,255,.1);border:1px solid rgba(77,139,255,.3);border-radius:4px;padding:2px 8px;text-decoration:none;white-space:nowrap">📄 Ver acta</a>`:''; })()}
            ${(()=>{ const u=_discTablaUrl(d); return u?`<a href="${u}" target="_blank" rel="noopener" style="font-size:11px;font-weight:600;color:var(--a3);background:rgba(245,200,66,.1);border:1px solid rgba(245,200,66,.3);border-radius:4px;padding:2px 8px;text-decoration:none;white-space:nowrap">🗂 Ver tabla cruzada</a>`:''; })()}
          </div>
        </div>
        ${etq}
      </div>
      ${rHtml}${bots}
    </div>`;
  }).join('');

  cont.innerHTML=resumen+sinActaHtml+items;
}

// Badge inicial al cargar página
(function(){ _rDiscBadge(); })();
function onGrupoChange(prefix){
  const grupo = document.getElementById(prefix+'-grupo')?.value||'';
  const catSel = document.getElementById(prefix+'-cat');
  if(!catSel) return;
  const allCats = sortCats([...new Set(ACTAS.map(a=>a.categoria).filter(c=>c&&!isSala(c)))]);
  const filtradas = grupo ? allCats.filter(c=>getCatGrupo(c)===grupo) : allCats;
  const cur = catSel.value;
  catSel.innerHTML = `<option value="">Todas las categorías</option>` +
    filtradas.map(c=>`<option value="${c}"${c===cur?' selected':''}>${catNombre(c)}</option>`).join('');
  // Si la categoría seleccionada ya no está en el grupo, resetear
  if(cur && !filtradas.includes(cur)) catSel.value = '';
  // Llamar al render de la sección correspondiente
  const renders = {cl:rCl,pa:rPa,go:rGo,ju:rJu,eq:rEqCat,sc:rSc,ent:rEnt,arb:rArb};
  renders[prefix]?.();
}

// ── ENTRENADORES HELPERS ──────────────────────────────────────────────────────

// ── ENTRENADOR AUTO-MERGE ENGINE ──────────────────────────────────────────────
// Detecta automáticamente variantes del mismo entrenador en el mismo club.
// Criterio: dos nombres muy similares (misma primera palabra tras la coma +
// apellidos con distancia de edición pequeña) que aparecen en el MISMO club
// → se unifican al más frecuente (el que tiene más partidos).
// El mapa manual ENTRENADORES_MAP siempre tiene prioridad.

let _entNormCache = null;  // { variante_limpia: nombre_canonico }

function _normStr(s){
  // Normaliza para comparación: mayúsculas, sin tildes, sin espacios extra
  return (s||'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
               .replace(/\s+/g,' ').replace(/\s+,/g,',').trim();
}

function _levenshtein(a, b){
  // Distancia de edición simple (O(n*m))
  if(!a.length) return b.length;
  if(!b.length) return a.length;
  const dp = Array.from({length:a.length+1},(_,i)=>
    Array.from({length:b.length+1},(_,j)=>i===0?j:j===0?i:0));
  for(let i=1;i<=a.length;i++)
    for(let j=1;j<=b.length;j++)
      dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]:1+Math.min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1]);
  return dp[a.length][b.length];
}

function _buildEntNormCache(){
  if(_entNormCache) return;
  _entNormCache = {};

  // 1. Primero aplicar el mapa manual (máxima prioridad)
  for(const [k,v] of Object.entries(ENTRENADORES_MAP)){
    _entNormCache[_normStr(k)] = _limpiarNombreEnt(v);
  }

  // 2. Construir inventario: nombre_limpio -> {equipos: {eq: count}, total: count}
  const inv = {};   // { nombre_norm: { nombre_display, count, equipos: {eq: count} } }
  ACTAS.forEach(a=>{
    [[a.entrenador_local, a.equipo_local],[a.entrenador_visitante, a.equipo_visitante]].forEach(([ent, eq])=>{
      if(!ent || !eq) return;
      const display = _limpiarNombreEnt(ent);
      const norm = _normStr(display);
      // Si ya tiene resolución manual, no tocar
      if(_entNormCache[norm]) return;
      if(!inv[norm]) inv[norm]={nombre_display:display, count:0, equipos:{}};
      inv[norm].count++;
      inv[norm].equipos[eq]=(inv[norm].equipos[eq]||0)+1;
    });
  });

  // 3. Para cada par de nombres: si son muy similares Y comparten equipo → fusionar
  const nombres = Object.keys(inv);
  const fusiones = {};  // { norm_menor_frec: norm_mayor_frec }

  for(let i=0;i<nombres.length;i++){
    for(let j=i+1;j<nombres.length;j++){
      const nA = nombres[i], nB = nombres[j];
      if(fusiones[nA]||fusiones[nB]) continue;  // ya fusionado

      // ¿Comparten al menos un equipo?
      const eqsA = Object.keys(inv[nA].equipos);
      const eqsB = Object.keys(inv[nB].equipos);
      const equipoComun = eqsA.find(e=>eqsB.includes(e));
      if(!equipoComun) continue;

      // ¿Son suficientemente similares?
      // Criterio: distancia de edición <= 4 O uno contiene al otro (nombre incompleto)
      const dist = _levenshtein(nA, nB);
      const maxLen = Math.max(nA.length, nB.length);
      const similar = dist <= 4 || (maxLen > 8 && dist / maxLen < 0.15) ||
                      nA.includes(nB.substring(0,Math.min(nB.length,15))) ||
                      nB.includes(nA.substring(0,Math.min(nA.length,15)));
      if(!similar) continue;

      // Fusionar: el más frecuente es el canónico
      const [canon, variante] = inv[nA].count >= inv[nB].count ? [nA, nB] : [nB, nA];
      fusiones[variante] = canon;
    }
  }

  // 4. Aplicar fusiones al cache
  for(const [variante, canon] of Object.entries(fusiones)){
    const canonDisplay = inv[canon].nombre_display;
    _entNormCache[variante] = canonDisplay;
    // También asegurarse de que la variante de display quede mapeada
    const varDisplay = inv[variante]?.nombre_display;
    if(varDisplay) _entNormCache[_normStr(varDisplay)] = canonDisplay;
  }
}

function _limpiarNombreEnt(nombre){
  if(!nombre) return nombre;
  return nombre.replace(/\s+/g,' ').replace(/\s+,/g,',').trim();
}

// Normaliza un nombre de entrenador aplicando el mapa manual + auto-detección
// de variantes similares en el mismo club.
function normEnt(nombre){
  if(!nombre) return nombre;
  const display = _limpiarNombreEnt(nombre);
  const norm = _normStr(display);

  // Primero intentar mapa manual (sin cache, para mayor velocidad en arranque)
  if(ENTRENADORES_MAP[display]) return ENTRENADORES_MAP[display];
  for(const [k,v] of Object.entries(ENTRENADORES_MAP)){
    if(_normStr(k)===norm) return _limpiarNombreEnt(v);
  }

  // Luego el cache de auto-merge (se construye la primera vez que se necesita)
  _buildEntNormCache();
  return _entNormCache[norm] || display;
}


// ═══════════════════════════════════════════════════════════════
//  MOTOR DE SUGERENCIAS DE MERGE POR TRAYECTORIA  (v3 — índice por prefijo)
// ═══════════════════════════════════════════════════════════════
// Estrategia O(N) en vez de O(N²):
//  1. Un solo pase de ACTAS → mapa jugador→{grupos,equipos,temps}
//  2. Indexar por los primeros 4 chars del apellido normalizado
//  3. Solo comparar jugadores que comparten prefijo (grupos pequeños)
//  4. Máx. 200 candidatos mostrados, ordenados por confianza
// ─────────────────────────────────────────────────────────────

const SUG_SKIP_KEY = 'faf_sug_skip';
function loadSugSkip(){ try{ return JSON.parse(localStorage.getItem(SUG_SKIP_KEY)||'{}'); }catch(e){ return {}; } }
function saveSugSkip(m){ localStorage.setItem(SUG_SKIP_KEY, JSON.stringify(m)); }
function sugSkipKey(a,b){ return [a,b].sort().join('|||'); }
let _sugCache = null;

function _sugNorm(s){
  return (s||'').toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')
               .replace(/[^A-Z0-9 ,]/g,'').replace(/\s+/g,' ').trim();
}

// Construye trayectoria resumida de un jugador: [{temp, grupos, equipos, PJ}]
function _buildTrayectoria(nombre){
  const merges = loadPersonMerges();
  const aliases = new Set([nombre]);
  Object.entries(merges).forEach(([v,c])=>{ if(c===nombre) aliases.add(v); });

  const byTemp = {};
  ACTAS.forEach(a=>{
    if(isSala(a.categoria)) return;
    const inL = (a.jugadores_local||[]).some(n=>aliases.has(n));
    const inV = !inL && (a.jugadores_visitante||[]).some(n=>aliases.has(n));
    if(!inL && !inV) return;
    const temp = a.temporada||'?';
    const eq   = inL ? a.equipo_local : a.equipo_visitante;
    const grp  = getCatGrupo(a.categoria)||'?';
    if(!byTemp[temp]) byTemp[temp]={grupos:new Set(),equipos:new Set(),PJ:0,cats:new Set()};
    byTemp[temp].grupos.add(grp);
    byTemp[temp].equipos.add(eq||'?');
    byTemp[temp].cats.add(a.categoria||'?');
    byTemp[temp].PJ++;
  });
  return Object.entries(byTemp)
    .map(([temp,d])=>({temp, grupos:[...d.grupos], equipos:[...d.equipos], cats:[...d.cats], PJ:d.PJ}))
    .sort((a,b)=>a.temp.localeCompare(b.temp));
}

// Renderiza una trayectoria como HTML compacto
function _renderTray(tray, nombre){
  if(!tray.length) return `<span style="color:var(--mu);font-size:11px">Sin partidos</span>`;
  const rows = tray.map(t=>{
    const col = t.grupos.some(g=>g==='SENIOR') ? 'var(--hw)' :
                t.grupos.some(g=>g==='JUVENIL') ? 'var(--a4)' :
                t.grupos.some(g=>g==='CADETE')  ? 'var(--a5)' : 'var(--mu)';
    const grpLabel = t.grupos.join('+');
    const eqs = t.equipos.slice(0,2).join(', ')+(t.equipos.length>2?'…':'');
    return `<div style="display:flex;gap:6px;align-items:center;font-size:11px;padding:2px 0;border-bottom:1px solid rgba(255,255,255,.04)">
      <span style="color:var(--mu);min-width:55px">${t.temp}</span>
      <span style="font-weight:700;color:${col};min-width:60px">${grpLabel}</span>
      <span style="color:var(--tx);flex:1">${eqs}</span>
      <span style="color:var(--mu)">${t.PJ}PJ</span>
    </div>`;
  }).join('');
  return `<div style="font-weight:600;font-size:12px;color:var(--tx);margin-bottom:4px">${nombre}</div>${rows}`;
}

// Calcula la confianza del par
function _confianza(tA, tB, distNorm){
  const eqsA = new Set(tA.flatMap(x=>x.equipos));
  const eqsB = new Set(tB.flatMap(x=>x.equipos));
  const equipoComun = [...eqsA].some(e=>eqsB.has(e));
  let clubComunMat = false;
  if(typeof getClubKey==='function'){
    const matsA = new Set([...eqsA].map(e=>getClubKey(e)));
    const matsB = new Set([...eqsB].map(e=>getClubKey(e)));
    clubComunMat = [...matsA].some(m=>matsB.has(m));
  }
  const tempsA = tA.filter(x=>x.grupos.some(g=>g==='JUVENIL'||g==='CADETE')).map(x=>x.temp);
  const tempsB_sen = tB.filter(x=>x.grupos.some(g=>g==='SENIOR')).map(x=>x.temp);
  const tempsA_sen = tA.filter(x=>x.grupos.some(g=>g==='SENIOR')).map(x=>x.temp);
  const tempsB = tB.filter(x=>x.grupos.some(g=>g==='JUVENIL'||g==='CADETE')).map(x=>x.temp);
  let transicionOK = false;
  const ultimoFormA = tempsA.length ? Math.max(...tempsA.map(t=>parseInt(t.split('-')[0])||0)) : 0;
  const primerSenB  = tempsB_sen.length ? Math.min(...tempsB_sen.map(t=>parseInt(t.split('-')[0])||0)) : 9999;
  const ultimoFormB = tempsB.length ? Math.max(...tempsB.map(t=>parseInt(t.split('-')[0])||0)) : 0;
  const primerSenA  = tempsA_sen.length ? Math.min(...tempsA_sen.map(t=>parseInt(t.split('-')[0])||0)) : 9999;
  if(ultimoFormA>0 && primerSenB>0 && primerSenB>=ultimoFormA) transicionOK=true;
  if(ultimoFormB>0 && primerSenA>0 && primerSenA>=ultimoFormB) transicionOK=true;
  if((equipoComun||clubComunMat) && distNorm<=3 && transicionOK) return 'ALTA';
  if(distNorm<=3 && transicionOK) return 'ALTA';
  if((equipoComun||clubComunMat) && distNorm<=5) return 'MEDIA';
  if(transicionOK && distNorm<=4) return 'MEDIA';
  return 'BAJA';
}

function calcSugerencias(){
  document.getElementById('sug-status').textContent = '⏳ Analizando trayectorias…';
  document.getElementById('cfg-sug-list').innerHTML = '';
  _sugCache = null;

  // Pequeño timeout para que el DOM se actualice antes del cálculo pesado
  setTimeout(()=>{
    const {jug} = GS();
    const merges = loadPersonMerges();
    const skip   = loadSugSkip();

    // Separar jugadores con formativo y sin formativo (solo senior)
    const conForm=[], soloSen=[];
    Object.keys(jug).forEach(nombre=>{
      if(normPerson(nombre)!==nombre) return;  // ya es variante de otro → ignorar
      const tray = _buildTrayectoria(nombre);
      const tieneForm = tray.some(t=>t.grupos.some(g=>g==='JUVENIL'||g==='CADETE'));
      const tieneSen  = tray.some(t=>t.grupos.some(g=>g==='SENIOR'));
      if(tieneForm) conForm.push({nombre, tray, norm:_sugNorm(nombre)});
      else if(tieneSen) soloSen.push({nombre, tray, norm:_sugNorm(nombre)});
    });

    // Generar pares candidatos
    const candidatos=[];
    const vistos=new Set();

    for(const a of conForm){
      for(const b of soloSen){
        if(a.nombre===b.nombre) continue;
        if(normPerson(a.nombre)===b.nombre || normPerson(b.nombre)===a.nombre) continue;
        const sk = sugSkipKey(a.nombre, b.nombre);
        if(skip[sk]) continue;
        const dist = _levenshtein(a.norm, b.norm);
        const maxL = Math.max(a.norm.length, b.norm.length);
        if(dist > 6 && dist/maxL > 0.25) continue;
        const key = [a.nombre,b.nombre].sort().join('|||');
        if(vistos.has(key)) continue;
        vistos.add(key);
        const conf = _confianza(a.tray, b.tray, dist);
        candidatos.push({
          form: a, sen: b, dist, conf,
          confOrd: conf==='ALTA'?0:conf==='MEDIA'?1:2
        });
      }
    }

    candidatos.sort((a,b)=>a.confOrd-b.confOrd||a.dist-b.dist);
    _sugCache = candidatos;

    const st = document.getElementById('sug-status');
    if(!candidatos.length){
      st.textContent = '✅ No se detectaron candidatos nuevos.';
      document.getElementById('cfg-sug-list').innerHTML = '<div class="empty">Ningún par sospechoso encontrado. O ya están todos mergeados.</div>';
      return;
    }
    st.textContent = `${candidatos.length} candidato${candidatos.length!==1?'s':''} detectado${candidatos.length!==1?'s':''}.`;
    rCfgSug();
  }, 30);
}

function rCfgSug(){
  const cont = document.getElementById('cfg-sug-list');
  if(!cont) return;
  if(!_sugCache){
    cont.innerHTML = '<div class="empty">Pulsa "Analizar ahora" para empezar.</div>'; return;
  }
  if(!_sugCache.length){
    cont.innerHTML = '<div class="empty">Sin candidatos pendientes.</div>'; return;
  }
  cont.innerHTML = _sugCache.map((c,i)=>{
    const conf = c.conf;
    const canon   = c.form.nombre;
    const variant = c.sen.nombre;
    const CONF_COL = {ALTA:'var(--hw)',MEDIA:'var(--a3)',BAJA:'var(--mu)'};
    const CONF_BG  = {ALTA:'rgba(0,240,160,.08)',MEDIA:'rgba(255,193,7,.06)',BAJA:'rgba(255,255,255,.03)'};
    return `
    <div id="sug-card-${i}" style="background:${CONF_BG[conf]};border:1px solid ${CONF_COL[conf]}33;border-radius:10px;padding:14px 16px;margin-bottom:14px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap">
        <span style="font-weight:700;font-size:12px;color:${CONF_COL[conf]};background:${CONF_COL[conf]}22;border:1px solid ${CONF_COL[conf]}44;border-radius:5px;padding:2px 10px">
          ${conf === 'ALTA' ? '🔴 ALTA' : conf === 'MEDIA' ? '🟡 MEDIA' : '⚪ BAJA'} confianza
        </span>
        <span style="font-size:11px;color:var(--mu)">Distancia nombre: ${c.dist} caracteres</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
        <div style="background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:10px">
          <div style="font-size:10px;color:var(--a4);font-weight:700;margin-bottom:6px;text-transform:uppercase">Con formativo (canónico sugerido)</div>
          ${_renderTray(c.form.tray, c.form.nombre)}
        </div>
        <div style="background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:10px">
          <div style="font-size:10px;color:var(--hw);font-weight:700;margin-bottom:6px;text-transform:uppercase">Solo senior (variante sospechosa)</div>
          ${_renderTray(c.sen.tray, c.sen.nombre)}
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
        <span style="font-size:12px;color:var(--mu)">¿Es el mismo jugador?</span>
        <button onclick="sugAceptar(${i},'${canon.replace(/'/g,"\\'")}','${variant.replace(/'/g,"\\'")}',${i})"
          style="background:rgba(0,240,160,.18);border:1px solid rgba(0,240,160,.5);color:var(--acc);font-size:12px;font-weight:700;border-radius:6px;padding:6px 14px;cursor:pointer">
          ✅ Sí, fusionar
        </button>
        <button onclick="sugAceptarInverso(${i},'${canon.replace(/'/g,"\\'")}','${variant.replace(/'/g,"\\'")}',${i})"
          style="background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.35);color:var(--a4);font-size:12px;border-radius:6px;padding:6px 14px;cursor:pointer">
          ↩ Sí, pero con otro canónico
        </button>
        <button onclick="sugSaltar(${i},'${canon.replace(/'/g,"\\'")}','${variant.replace(/'/g,"\\'")}',${i})"
          style="background:rgba(255,79,55,.10);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:12px;border-radius:6px;padding:6px 14px;cursor:pointer">
          ❌ No, son distintos
        </button>
      </div>
    </div>`;
  }).join('');
}

function sugAceptar(idx, canon, variant){
  if(canon===variant){ toast('Nombres iguales','err'); return; }
  const merges = loadPersonMerges();
  merges[variant] = canon;
  Object.keys(merges).forEach(k=>{ if(merges[k]===variant) merges[k]=canon; });
  savePersonMerges(merges);
  _personNamesCache=null; _personAliasesCache=null; _ANIO_CACHE=null; _invalidarMotor();
  if(_sugCache) _sugCache.splice(idx,1);
  const st=document.getElementById('sug-status');
  if(st) st.textContent=`${_sugCache?_sugCache.length:0} candidatos restantes.`;
  toast(`Merge aplicado: "${variant}" → "${canon}"`, 'ok');
  rCfgSug();
}

function sugAceptarInverso(idx, canon, variant){
  // El usuario quiere el otro como canónico (el "solo senior" como base)
  sugAceptar(idx, variant, canon);
}

function sugSaltar(idx, canon, variant){
  const skip = loadSugSkip();
  skip[sugSkipKey(canon,variant)] = true;
  saveSugSkip(skip);
  if(_sugCache) _sugCache.splice(idx,1);
  const st=document.getElementById('sug-status');
  if(st) st.textContent=`${_sugCache?_sugCache.length:0} candidatos restantes.`;
  toast('Par descartado — no volverá a aparecer','ok');
  rCfgSug();
}

// ── CLUB HELPERS ──────────────────────────────────────────────────────────────

// Merges manuales guardados en localStorage: { normClub: nombreCanonElegido }
// Cuando el usuario fusiona dos clubs, el que "se absorbe" apunta al principal.
const MERGE_KEY = 'faf_club_merges';
function loadMerges(){ try{ return JSON.parse(localStorage.getItem(MERGE_KEY)||'{}'); }catch(e){ return {}; } }
function saveMerges(m){ localStorage.setItem(MERGE_KEY, JSON.stringify(m)); }

// ── PERSON MERGE ENGINE ───────────────────────────────────────────────────────
// Fusión manual de jugadores/entrenadores con nombre distinto entre federaciones.
// Formato: { "NOMBRE_VARIANTE": "NOMBRE_CANONICO" }
// La variante queda absorbida por el canónico en todas las estadísticas.
const PERSON_MERGE_KEY = 'faf_person_merges';
function loadPersonMerges(){ try{ return JSON.parse(localStorage.getItem(PERSON_MERGE_KEY)||'{}'); }catch(e){ return {}; } }
function savePersonMerges(m){ localStorage.setItem(PERSON_MERGE_KEY, JSON.stringify(m)); }

// Resuelve el nombre canónico de una persona (jugador o entrenador).
// Sigue cadenas de merges (A→B→C devuelve C). Máx. 10 pasos para evitar ciclos.
function normPerson(nombre){
  if(!nombre) return nombre;
  const merges = loadPersonMerges();
  let cur = nombre.trim();
  for(let i=0;i<10;i++){
    const next = merges[cur];
    if(!next || next===cur) break;
    cur = next;
  }
  return cur;
}

// Devuelve el Set de todos los nombres (variantes + canon) que se unifican bajo 'canon'.
// Útil para buscar partidos de un jugador por todos sus nombres en las actas.
let _personAliasesCache = null;
function _buildPersonAliasesCache(){
  _personAliasesCache = {};  // { canon: Set<variante1, variante2, ..., canon> }
  const merges = loadPersonMerges();
  // Para cada variante → canon, añadir la variante al set del canon
  Object.entries(merges).forEach(([variant, canon]) => {
    if(!_personAliasesCache[canon]) _personAliasesCache[canon] = new Set([canon]);
    _personAliasesCache[canon].add(variant);
  });
}
function _personAliases(canon){
  if(!_personAliasesCache) _buildPersonAliasesCache();
  return _personAliasesCache[canon] || new Set([canon]);
}

// Dado un acta y un nombre canónico, devuelve el nombre ORIGINAL con el que aparece
// el jugador en esa acta (puede ser el canon o cualquier variante fusionada).
// Devuelve null si no aparece.
function _jugNombreEnActa(a, nombreCanon){
  const aliases = _personAliases(nombreCanon);
  for(const alias of aliases){
    const orig = _nombreOrig(alias);  // resuelve [1]/[2] si aplica
    if((a.jugadores_local||[]).includes(orig) || (a.jugadores_visitante||[]).includes(orig)){
      return orig;
    }
  }
  return null;
}

// Devuelve todos los nombres de personas conocidos (jugadores + entrenadores) para autocomplete
function _allPersonNames(){
  const s = new Set();
  ACTAS.forEach(a=>{
    (a.jugadores_local||[]).forEach(n=>{ if(n) s.add(n); });
    (a.jugadores_visitante||[]).forEach(n=>{ if(n) s.add(n); });
    if(a.entrenador_local) s.add(a.entrenador_local);
    if(a.entrenador_visitante) s.add(a.entrenador_visitante);
    if(a.segundo_entrenador_local) s.add(a.segundo_entrenador_local);
    if(a.segundo_entrenador_visitante) s.add(a.segundo_entrenador_visitante);
  });
  return [...s].sort();
}
let _personNamesCache = null;
  _personAliasesCache = null;
function getAllPersonNames(){ if(!_personNamesCache) _personNamesCache=_allPersonNames(); return _personNamesCache; }

// Autocomplete para los inputs de merge
function mrgAutocomplete(inputId, listId){
  const input = document.getElementById(inputId);
  const list  = document.getElementById(listId);
  if(!input || !list) return;
  const q = input.value.trim().toUpperCase();
  if(q.length < 2){ list.innerHTML=''; mrgUpdatePreview(); return; }
  const matches = getAllPersonNames().filter(n=>n.toUpperCase().includes(q)).slice(0,10);
  if(!matches.length){ list.innerHTML=''; mrgUpdatePreview(); return; }
  list.innerHTML = `<div style="position:absolute;z-index:200;width:100%;background:var(--s2);border:1px solid var(--b);border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,.4);max-height:220px;overflow-y:auto;margin-top:2px">
    ${matches.map(n=>`<div onclick="mrgSelect('${inputId}','${listId}','${n.replace(/'/g,"\\'")}');event.stopPropagation()"
      style="padding:8px 12px;cursor:pointer;font-size:13px;border-bottom:1px solid rgba(255,255,255,.05)"
      onmouseover="this.style.background='rgba(0,240,160,.08)'" onmouseout="this.style.background=''">${n}</div>`).join('')}
  </div>`;
}

function mrgSelect(inputId, listId, nombre){
  const el = document.getElementById(inputId);
  if(el) el.value = nombre;
  const listEl = document.getElementById(listId);
  if(listEl) listEl.innerHTML='';
  mrgUpdatePreview();
}

// Muestra un preview con las estadísticas de cada nombre seleccionado
function mrgUpdatePreview(){
  const canon   = (document.getElementById('mrg-canon')?.value||'').trim();
  const variant = (document.getElementById('mrg-variant')?.value||'').trim();
  const prev    = document.getElementById('mrg-preview');
  if(!prev) return;
  if(!canon && !variant){ prev.innerHTML=''; return; }
  function _stats(nombre){
    if(!nombre) return null;
    let PJ=0, goles=0, equipos=new Set();
    ACTAS.forEach(a=>{
      const enL=(a.jugadores_local||[]).includes(nombre);
      const enV=(a.jugadores_visitante||[]).includes(nombre);
      const esEntL=a.entrenador_local===nombre||a.segundo_entrenador_local===nombre;
      const esEntV=a.entrenador_visitante===nombre||a.segundo_entrenador_visitante===nombre;
      if(enL||enV){ PJ++; goles+=(a.goleadores||[]).filter(g=>g.jugador===nombre&&!g.propia).length; equipos.add(enL?a.equipo_local:a.equipo_visitante); }
      else if(esEntL||esEntV){ PJ++; equipos.add(esEntL?a.equipo_local:a.equipo_visitante); }
    });
    return {PJ, goles, equipos:[...equipos].slice(0,4)};
  }
  const sc = _stats(canon);
  const sv = _stats(variant);
  const fmt = (s,n,col)=> s ? `<span style="font-weight:700;color:${col}">${n}</span> — ${s.PJ}PJ · ${s.goles}⚽ · <span style="font-size:11px;color:var(--mu)">${s.equipos.join(', ')}</span>` : `<span style="color:var(--mu)">${n} (no encontrado)</span>`;
  prev.innerHTML = `${fmt(sc,canon||'—','var(--hw)')} &nbsp;→ fusionar con → &nbsp;${fmt(sv,variant||'—','var(--a2)')}`;
}

// Ejecuta el merge de personas
function doPersonMerge(){
  const canon   = (document.getElementById('mrg-canon')?.value||'').trim();
  const variant = (document.getElementById('mrg-variant')?.value||'').trim();
  if(!canon || !variant){ toast('Introduce ambos nombres','err'); return; }
  if(canon === variant){ toast('Los nombres son iguales','err'); return; }
  const merges = loadPersonMerges();
  // Guardar variant → canon; redirigir cadenas previas
  merges[variant] = canon;
  // Cualquier cosa que apuntara al variant ahora apunta al canon
  Object.keys(merges).forEach(k=>{ if(merges[k]===variant) merges[k]=canon; });
  savePersonMerges(merges);
  // Invalidar caches del motor
  _personNamesCache = null;
  _personAliasesCache = null;
  _ANIO_CACHE = null;
  _invalidarMotor();
  document.getElementById('mrg-canon').value='';
  document.getElementById('mrg-variant').value='';
  document.getElementById('mrg-preview').innerHTML='';
  rCfgMrg();
  toast(`Merge guardado: "${variant}" → "${canon}"`, 'ok');
}

// Deshace un merge de persona
function undoPersonMerge(variant){
  const merges = loadPersonMerges();
  delete merges[variant];
  savePersonMerges(merges);
  _personNamesCache = null;
  _personAliasesCache = null;
  _ANIO_CACHE = null;
  _invalidarMotor();
  rCfgMrg();
  toast('Merge eliminado','ok');
}

// Borra todos los merges de personas
function resetPersonMerges(){
  if(!confirm('¿Eliminar todos los merges de personas guardados?')) return;
  localStorage.removeItem(PERSON_MERGE_KEY);
  _personNamesCache = null;
  _personAliasesCache = null;
  _ANIO_CACHE = null;
  _invalidarMotor();
  rCfgMrg();
  toast('Todos los merges eliminados','ok');
}

// Renderiza la lista de merges guardados
function rCfgMrg(){
  const srch = (document.getElementById('mrg-s')?.value||'').trim().toUpperCase();
  const merges = loadPersonMerges();
  const entries = Object.entries(merges).filter(([k,v])=>!srch||k.toUpperCase().includes(srch)||v.toUpperCase().includes(srch));
  const cont = document.getElementById('cfg-mrg-list');
  if(!cont) return;
  if(!entries.length){
    cont.innerHTML=`<div class="empty">No hay merges guardados${srch?' con ese filtro':''}.</div>`;
    return;
  }
  const statsFor = nombre=>{
    let PJ=0,goles=0;
    ACTAS.forEach(a=>{
      const enL=(a.jugadores_local||[]).includes(nombre), enV=(a.jugadores_visitante||[]).includes(nombre);
      const esEntL=a.entrenador_local===nombre, esEntV=a.entrenador_visitante===nombre;
      if(enL||enV){ PJ++; goles+=(a.goleadores||[]).filter(g=>g.jugador===nombre&&!g.propia).length; }
      else if(esEntL||esEntV){ PJ++; }
    });
    return {PJ,goles};
  };
  const total = Object.keys(merges).length;
  cont.innerHTML=`<div style="font-size:12px;color:var(--mu);margin-bottom:10px">${total} merge${total!==1?'s':''} guardado${total!==1?'s':''}</div>`
    + entries.sort((a,b)=>a[1].localeCompare(b[1])||a[0].localeCompare(b[0])).map(([variant,canon])=>{
      const sv=statsFor(variant), sc=statsFor(canon);
      const vEsc=variant.replace(/'/g,"\\'");
      return `<div style="background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px 14px;margin-bottom:8px;display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <span style="font-weight:700;color:var(--a2);font-size:13px">${variant}</span>
            <span style="font-size:11px;color:var(--mu)">${sv.PJ}PJ · ${sv.goles}⚽</span>
            <span style="color:var(--mu);font-size:16px">→</span>
            <span style="font-weight:700;color:var(--hw);font-size:13px">${canon}</span>
            <span style="font-size:11px;color:var(--mu)">${sc.PJ}PJ · ${sc.goles}⚽</span>
          </div>
        </div>
        <button onclick="undoPersonMerge('${vEsc}')"
          style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:11px;border-radius:5px;padding:4px 10px;cursor:pointer;flex-shrink:0">✕ Deshacer</button>
      </div>`;
    }).join('');
}

// Cerrar autocomplete al hacer clic fuera
document.addEventListener('click', function(){
  ['mrg-canon-list','mrg-variant-list'].forEach(id=>{ const el=document.getElementById(id); if(el) el.innerHTML=''; });
});

// ── PROVINCIA ENGINE ──────────────────────────────────────────────────────────
// Provincia guardada en localStorage por el usuario (prioridad sobre mapa base)
const PROV_OVERRIDES_KEY = 'faf_provincia_overrides';
function loadProvOverrides(){ try{ return JSON.parse(localStorage.getItem(PROV_OVERRIDES_KEY)||'{}'); }catch(e){ return {}; } }
function saveProvOverrides(m){ localStorage.setItem(PROV_OVERRIDES_KEY, JSON.stringify(m)); }

const PROVINCIAS = ['Álava', 'Bizkaia', 'Gipuzkoa', 'Navarra', 'La Rioja', 'Vasca', 'Nacional'];

// ── AÑO DE NACIMIENTO ENGINE ──────────────────────────────────────────────────
// Overrides manuales: { nombreNorm: año_int }  — prevalecen siempre
const ANIO_KEY = 'faf_anio_nacimiento';
function loadAnioOverrides(){ try{ return JSON.parse(localStorage.getItem(ANIO_KEY)||'{}'); }catch(e){ return {}; } }
function saveAnioOverrides(m){ localStorage.setItem(ANIO_KEY, JSON.stringify(m)); }
function _normNombreAnio(n){ return (n||'').trim().toUpperCase(); }

// ── Posición y pie dominante ──────────────────────────────────────────────────
const POSICION_KEY   = 'faf_posicion_jugador';
const PIE_KEY        = 'faf_pie_dominante';
const POSICIONES = [
  {v:'',    l:'Sin posición'},
  {v:'POR', l:'POR — Portero'},
  {v:'LTD', l:'LTD — Lateral derecho'},
  {v:'LTI', l:'LTI — Lateral izquierdo'},
  {v:'DFC', l:'DFC — Defensa central'},
  {v:'MC',  l:'MC — Medio centro'},
  {v:'MP',  l:'MP — Media punta'},
  {v:'ED',  l:'ED — Extremo derecho'},
  {v:'EI',  l:'EI — Extremo izquierdo'},
  {v:'DEL', l:'DEL — Delantero'},
];
const PIES = [
  {v:'',     l:'Sin dato'},
  {v:'D',    l:'Diestro'},
  {v:'Z',    l:'Zurdo'},
];
function loadPosiciones(){ try{ return JSON.parse(localStorage.getItem(POSICION_KEY)||'{}'); }catch(e){ return {}; } }
function savePosiciones(m){ localStorage.setItem(POSICION_KEY, JSON.stringify(m)); }
function loadPies(){ try{ return JSON.parse(localStorage.getItem(PIE_KEY)||'{}'); }catch(e){ return {}; } }
function savePies(m){ localStorage.setItem(PIE_KEY, JSON.stringify(m)); }
function _normNombrePos(n){ return (n||'').trim().toUpperCase(); }
function getPosicion(nombre){ const m=loadPosiciones(); return m[_normNombrePos(nombre)]||''; }
function getPie(nombre){ const m=loadPies(); return m[_normNombrePos(nombre)]||''; }
function setPosicion(nombre, pos){
  const m=loadPosiciones(); const norm=_normNombrePos(nombre);
  if(pos) m[norm]=pos; else delete m[norm];
  savePosiciones(m);
}
function setPie(nombre, pie){
  const m=loadPies(); const norm=_normNombrePos(nombre);
  if(pie) m[norm]=pie; else delete m[norm];
  savePies(m);
}
function posicionBadge(pos){
  if(!pos) return '';
  const colores={POR:'#f5c842',LTD:'#4d8bff',LTI:'#4d8bff',DFC:'#00f0a0',MC:'#b06fff',MP:'#b06fff',ED:'#ff9040',EI:'#ff9040',DEL:'#f24141'};
  const col=colores[pos]||'#888';
  return `<span style="font-size:10px;font-weight:700;color:${col};background:${col}22;border:1px solid ${col}55;border-radius:4px;padding:1px 6px;white-space:nowrap;font-family:'JetBrains Mono',monospace">${pos}</span>`;
}
function pieBadge(pie){
  if(!pie) return '';
  const col=pie==='Z'?'#b06fff':'#4d8bff';
  const lbl=pie==='Z'?'Zurdo':'Diestro';
  return `<span style="font-size:10px;font-weight:600;color:${col};background:${col}22;border:1px solid ${col}44;border-radius:4px;padding:1px 6px;white-space:nowrap">${lbl}</span>`;
}
// Widget inline para la ficha del jugador
function posicionPieWidget(nombre){
  const safe=nombre.replace(/\\\\/g,'\\\\\\\\').replace(/'/g,"\\\\'");
  const posActual=getPosicion(nombre);
  const pieActual=getPie(nombre);
  const optsPos=POSICIONES.map(p=>`<option value="${p.v}"${p.v===posActual?' selected':''}>${p.l}</option>`).join('');
  const optsPie=PIES.map(p=>`<option value="${p.v}"${p.v===pieActual?' selected':''}>${p.l}</option>`).join('');
  return `<div style="display:flex;align-items:center;gap:10px;margin-top:6px;flex-wrap:wrap">
    <span style="font-size:11px;color:var(--mu);font-family:'JetBrains Mono',monospace">Posición:</span>
    <select id="pos-sel-inp" onchange="(function(v){setPosicion('${safe}',v);toast(v?'Posición: '+v:'Posición eliminada','ok');})(this.value)"
      style="background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:5px;padding:2px 6px;font-size:12px;outline:none;cursor:pointer">
      ${optsPos}
    </select>
    <span style="font-size:11px;color:var(--mu);font-family:'JetBrains Mono',monospace;margin-left:4px">Pie:</span>
    <select id="pie-sel-inp" onchange="(function(v){setPie('${safe}',v);toast(v?'Pie: '+v:'Pie eliminado','ok');})(this.value)"
      style="background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:5px;padding:2px 6px;font-size:12px;outline:none;cursor:pointer">
      ${optsPie}
    </select>
  </div>`;
}

// Cache precalculado de años: { nombreNorm: {anio, fuente, prefijo?} | null }
// Se construye una sola vez al cargar/actualizar. Los filtros lo usan sin recalcular.
let _ANIO_CACHE = null;

// Precalcula los años de nacimiento de TODOS los jugadores en un solo recorrido de ACTAS.
// Mucho más eficiente que llamar inferirAnio(n) por cada jugador (que haría N×|ACTAS|).
function precalcularAnios(){
  _ANIO_CACHE = {};
  // Paso 1: construir historial { nombreNorm: { tInicio: { grupos:Set, equipos:Set } } }
  // en UN solo recorrido de ACTAS
  const hist = {};
  ACTAS.forEach(a=>{
    const grpForm = _grupoCategoria(a.categoria);
    const grpSen  = getCatGrupo(a.categoria);
    const grp = grpForm || (grpSen==='SENIOR' ? 'SENIOR' : null);
    if(!grp) return;
    const tInicio = _tempInicio(a.temporada) || 0;
    [[a.jugadores_local, a.equipo_local],[a.jugadores_visitante, a.equipo_visitante]].forEach(([jugs,eq])=>{
      (jugs||[]).forEach(nombre=>{
        const norm = _normNombreAnio(nombre);
        if(!hist[norm]) hist[norm] = {};
        if(!hist[norm][tInicio]) hist[norm][tInicio] = {grupos:new Set(), equipos:new Set(), pj:{}};
        hist[norm][tInicio].grupos.add(grp);
        hist[norm][tInicio].equipos.add(eq||'');
        hist[norm][tInicio].pj[grp] = (hist[norm][tInicio].pj[grp]||0) + 1;
      });
    });
  });

  // Paso 2: para cada jugador con override manual, usar directamente
  const overrides = loadAnioOverrides();

  // Paso 3: calcular año para cada jugador conocido
  const {jug} = GS();
  Object.keys(jug).forEach(nombre=>{
    const norm = _normNombreAnio(nombre);
    // Override manual tiene prioridad absoluta
    if(overrides[norm] !== undefined){
      _ANIO_CACHE[norm] = {anio: overrides[norm], fuente:'manual'};
      return;
    }
    const h = hist[norm];
    if(!h){ _ANIO_CACHE[norm] = null; return; }

    let tempJuv=0, tempCad=0;
    let anosForm=[], anosSen=[];
    const anosFormEfectivo={};
    let nivelMaxForm=0, huboSeniorAntes=false;
    // Ordenar cronológicamente (igual que inferirAnio)
    const entradasP = Object.entries(h)
      .map(([tStr,d])=>({t:parseInt(tStr),gs:d.grupos,pj:d.pj||{}}))
      .sort((a,b)=>a.t-b.t);
    entradasP.forEach(({t,gs,pj})=>{
      // Resolver nivel dominante si hay CADETE + JUVENIL en el mismo año
      let gsEfectivo=gs;
      if(gs.has('CADETE')&&gs.has('JUVENIL')){
        const pjCad=pj['CADETE']||0, pjJuv=pj['JUVENIL']||0;
        if(pjJuv<=5&&pjJuv<pjCad)      gsEfectivo=new Set(['CADETE']);
        else if(pjCad<=5&&pjCad<pjJuv) gsEfectivo=new Set(['JUVENIL']);
      }
      let nivelForm=0;
      if(gsEfectivo.has('CADETE'))  nivelForm=Math.max(nivelForm,1);
      if(gsEfectivo.has('JUVENIL')) nivelForm=Math.max(nivelForm,2);
      if(nivelForm>0){
        anosForm.push(t);
        const esRetroceso=(nivelForm<nivelMaxForm)||huboSeniorAntes;
        if(!esRetroceso){
          if(gsEfectivo.has('CADETE')&&!gsEfectivo.has('JUVENIL')) tempCad++;
          if(gsEfectivo.has('JUVENIL'))                             tempJuv++;
          nivelMaxForm=Math.max(nivelMaxForm,nivelForm);
          anosFormEfectivo[t]=gsEfectivo;
        }
      }
      if(gs.has('SENIOR')){ anosSen.push(t); huboSeniorAntes=true; }
    });
    // Detectar huecos en la secuencia formativa efectiva
    if(anosForm.length>=2){
      const anosFormOrd=Object.keys(anosFormEfectivo).map(Number).sort((a,b)=>a-b);
      const anosSenSet=new Set(anosSen);
      for(let i=1;i<anosFormOrd.length;i++){
        const gap=anosFormOrd[i]-anosFormOrd[i-1]-1;
        if(gap>0&&gap<=3){
          for(let g=1;g<=gap;g++){
            const anoHueco=anosFormOrd[i-1]+g;
            if(!anosSenSet.has(anoHueco)){
              const gsAntes=anosFormEfectivo[anosFormOrd[i-1]];
              if(gsAntes&&gsAntes.has('JUVENIL')) tempJuv++;
              else tempCad++;
            }
          }
        }
      }
    }

    const POS_MAX=5;
    let anio=null, prefijo='';
    if(tempCad>0||tempJuv>0){
      const posBase=tempJuv>0?Math.max(2,tempCad)+tempJuv:tempCad;
      const ultimaForm=Math.max(...anosForm);
      if(anosSen.length>0){
        const senPost=anosSen.filter(t=>t>ultimaForm);
        if(senPost.length>0){
          const primeraSen=Math.min(...senPost);
          const gap=primeraSen-ultimaForm;
          if(gap===1&&posBase<POS_MAX){ anio=ultimaForm-13-(posBase+1); }
          else if(gap>1){ anio=ultimaForm-13-posBase; prefijo='~'; }
          else { anio=ultimaForm-13-posBase; }
        } else { anio=ultimaForm-13-posBase; }
      } else { anio=ultimaForm-13-posBase; }
    } else if(anosSen.length>0){
      anio=Math.min(...anosSen)-18; prefijo='≤';
    }
    _ANIO_CACHE[norm] = anio===null ? null : (prefijo ? {anio,fuente:'inferido',prefijo} : {anio,fuente:'inferido'});
  });
}

// Devuelve el resultado de inferirAnio desde cache (sin recalcular)
function getAnioNacCached(nombre){
  if(!_ANIO_CACHE) precalcularAnios();
  return _ANIO_CACHE[_normNombreAnio(nombre)] || null;
}

// Determina si una categoría es Juvenil, Cadete o Infantil (para historial formativo)
function _grupoCategoria(cat){
  const c=(cat||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  if(c.includes('juvenil')) return 'JUVENIL';
  if(c.includes('cadete'))  return 'CADETE';
  if(c.includes('infantil'))return 'INFANTIL';
  return null;
}

// Temporada "2025-2026" → año de inicio → 2025
function _tempInicio(temp){
  const m=(temp||'').match(/(\d{4})/);
  return m ? parseInt(m[1]) : null;
}

// Convierte fecha "DD-MM-YYYY" a "YYYY-MM-DD" para comparación lexicográfica correcta
function _fechaOrd(fecha){
  const m=(fecha||'').match(/^(\d{2})-(\d{2})-(\d{4})$/);
  return m ? `${m[3]}-${m[2]}-${m[1]}` : (fecha||'');
}

/**
 * Infiere el año de nacimiento de un jugador a partir de su historial de actas.
 *
 * MODELO:
 *   La carrera formativa tiene 5 posiciones (1=2.ºcadete … 5=3.ºjuvenil).
 *   pos_base:
 *     - solo cadete  → tempCad  (1 o 2)
 *     - tiene juvenil → max(2, tempCad) + tempJuv  (asume al menos 2 años de cadete)
 *
 *   Sin senior: anio = ultimaForm - 13 - pos_base
 *   Con senior, primera_sen justo al año siguiente (gap=1) y pos_base<5:
 *     anio = ultimaForm - 13 - (pos_base + 1)   ← asume 1 año más de form no registrado
 *   Con senior, gap=1 y pos_base>=5:
 *     anio = ultimaForm - 13 - pos_base          ← ya en el máximo formativo
 *   Con senior, gap>1:
 *     anio = ultimaForm - 13 - pos_base, prefijo='~'  ← aproximado
 *   Solo senior (sin historial formativo):
 *     {anio:2006, prefijo:'≤'}
 *
 * Devuelve {anio, fuente, prefijo?} o null si no hay datos.
 */
function inferirAnio(nombre){
  // 1. Override manual → prioridad absoluta
  const overrides = loadAnioOverrides();
  const norm = _normNombreAnio(nombre);
  if(overrides[norm] !== undefined) return {anio: overrides[norm], fuente:'manual'};

  // 2. Recopilar historial por temporada (año de inicio), incluyendo senior
  // También contar partidos por grupo para resolver ambigüedad cuando un jugador
  // juega en dos categorías el mismo año (ej: cadete + juvenil puntual).
  const hist = {};
  ACTAS.forEach(a=>{
    const grpForm = _grupoCategoria(a.categoria);
    const grpSen  = getCatGrupo(a.categoria);
    const grp = grpForm || (grpSen==='SENIOR' ? 'SENIOR' : null);
    if(!grp) return;
    const enL = (a.jugadores_local||[]).includes(nombre);
    const enV = (a.jugadores_visitante||[]).includes(nombre);
    if(!enL && !enV) return;
    const tInicio = _tempInicio(a.temporada) || 0;
    const eq = enL ? a.equipo_local : a.equipo_visitante;
    if(!hist[tInicio]) hist[tInicio]={grupos:new Set(), equipos:new Set(), pj:{}};
    hist[tInicio].grupos.add(grp);
    hist[tInicio].equipos.add(eq||'');
    hist[tInicio].pj[grp] = (hist[tInicio].pj[grp]||0) + 1;
  });

  if(!Object.keys(hist).length) return null;

  // 3. Clasificar temporadas ordenadas cronológicamente
  // Nivel numérico: CADETE=1, JUVENIL=2, SENIOR=3
  // Si en una temporada el nivel formativo retrocede respecto al máximo
  // ya alcanzado (o si ya hubo senior antes), es una cesión puntual →
  // NO cuenta para incrementar posición en la carrera formativa.
  //
  // REGLA AMBIGÜEDAD: si un jugador aparece en CADETE y JUVENIL el mismo año,
  // el nivel dominante es el grupo donde jugó MÁS partidos. El grupo minoritario
  // (≤5 partidos Y menos que el mayoritario) se considera aparición puntual y
  // no sube el nivel de esa temporada.

  const entradas = Object.entries(hist)
    .map(([tStr,h])=>({t:parseInt(tStr), grupos:h.grupos, pj:h.pj}))
    .sort((a,b)=>a.t-b.t);

  let tempJuv=0, tempCad=0;
  let anosForm=[], anosSen=[];
  const anosFormEfectivo = {}; // año → gsEfectivo (solo temporadas no-retroceso)
  let nivelMaxForm   = 0;   // nivel formativo máximo alcanzado (1=cadete, 2=juvenil)
  let huboSeniorAntes = false;

  entradas.forEach(({t, grupos:gs, pj})=>{
    // Resolver nivel dominante cuando hay ambas categorías formativas
    let gsEfectivo = gs;
    if(gs.has('CADETE') && gs.has('JUVENIL')){
      const pjCad = pj['CADETE']||0;
      const pjJuv = pj['JUVENIL']||0;
      // El grupo con menos partidos es puntual si jugó ≤5 y menos que el otro
      if(pjJuv <= 5 && pjJuv < pjCad){
        gsEfectivo = new Set(['CADETE']);   // juvenil puntual → contar como cadete
      } else if(pjCad <= 5 && pjCad < pjJuv){
        gsEfectivo = new Set(['JUVENIL']);  // cadete puntual → contar como juvenil
      }
      // Si ambos tienen muchos partidos, dejar ambos (edge case raro)
    }

    let nivelForm = 0;
    if(gsEfectivo.has('CADETE'))  nivelForm = Math.max(nivelForm, 1);
    if(gsEfectivo.has('JUVENIL')) nivelForm = Math.max(nivelForm, 2);

    if(nivelForm > 0){
      anosForm.push(t);
      // Retroceso: nivel < máximo ya visto, o ya pasó por senior antes
      const esRetroceso = (nivelForm < nivelMaxForm) || huboSeniorAntes;
      if(!esRetroceso){
        if(gsEfectivo.has('CADETE') && !gsEfectivo.has('JUVENIL')) tempCad++;
        if(gsEfectivo.has('JUVENIL'))                               tempJuv++;
        nivelMaxForm = Math.max(nivelMaxForm, nivelForm);
        anosFormEfectivo[t] = gsEfectivo; // guardar grupo efectivo para detección de huecos
      }
      // Si es retroceso, la temporada existe en anosForm pero NO suma a posición
    }
    if(gs.has('SENIOR')){ anosSen.push(t); huboSeniorAntes = true; }
  });

  // ── Detectar huecos en la secuencia formativa ───────────────────────────────
  // Si entre dos temporadas formativas consecutivas hay años sin registrar,
  // esos años también existieron (lesión, año sin jugar, datos no disponibles).
  // Los contamos para no subestimar la posición en la carrera.
  //
  // Estrategia: ordenar las temporadas formativas efectivas (sin retrocesos)
  // y contar los años de hueco entre ellas que sean razonables (≤3 años de gap,
  // y que no se solapen con años de senior conocidos).
  //
  // Ejemplo: jugó juvenil 2023 y 2025 → hueco 2024 → +1 al posBase.
  if(anosForm.length >= 2){
    // Usar solo años efectivos (sin retrocesos) para detectar huecos reales
    const anosFormOrdenados = Object.keys(anosFormEfectivo).map(Number).sort((a,b)=>a-b);
    const anosSenSet = new Set(anosSen);
    for(let i=1; i<anosFormOrdenados.length; i++){
      const gap = anosFormOrdenados[i] - anosFormOrdenados[i-1] - 1;
      if(gap > 0 && gap <= 3){
        // Sumar años de hueco que no coincidan con años de senior conocidos
        for(let g=1; g<=gap; g++){
          const anoHueco = anosFormOrdenados[i-1] + g;
          if(!anosSenSet.has(anoHueco)){
            // El hueco cae dentro del ciclo formativo → sumarlo
            // Si ya estaba en juvenil antes del hueco, sumar a tempJuv
            const gsAntes = anosFormEfectivo[anosFormOrdenados[i-1]];
            if(gsAntes && gsAntes.has('JUVENIL')) tempJuv++;
            else tempCad++;
          }
        }
      }
    }
  }

  const POS_MAX = 5; // 3.er juvenil
  let anio = null;
  let prefijo = '';
  const fuente = 'inferido';

  if(tempCad > 0 || tempJuv > 0){
    const posBase = tempJuv > 0 ? Math.max(2, tempCad) + tempJuv : tempCad;
    const ultimaForm = Math.max(...anosForm);

    if(anosSen.length > 0){
      const senPost = anosSen.filter(t => t > ultimaForm);
      if(senPost.length > 0){
        const primeraSen = Math.min(...senPost);
        const gap = primeraSen - ultimaForm;
        if(gap === 1 && posBase < POS_MAX){
          // Pasó a senior sin terminar el ciclo → hubo temporada formativa no registrada
          anio = ultimaForm - 13 - (posBase + 1);
        } else if(gap > 1){
          anio = ultimaForm - 13 - posBase;
          prefijo = '~';
        } else {
          anio = ultimaForm - 13 - posBase;
        }
      } else {
        // Senior anterior o coincidente con la última form → ignorar para posición
        anio = ultimaForm - 13 - posBase;
      }
    } else {
      anio = ultimaForm - 13 - posBase;
    }
  } else if(anosSen.length > 0){
    anio = Math.min(...anosSen) - 18;
    prefijo = '≤';
  }

  if(anio === null) return null;

  return prefijo ? {anio, fuente, prefijo} : {anio, fuente};
}

// Devuelve el año de nacimiento (override > inferido > null)
function getAnioNac(nombre){
  const r = inferirAnio(nombre);
  return r ? r.anio : null;
}

// Guarda override manual para un jugador y actualiza el cache en tiempo real
function setAnioNac(nombre, anio){
  const overrides = loadAnioOverrides();
  const norm = _normNombreAnio(nombre);
  if(anio) overrides[norm] = parseInt(anio);
  else delete overrides[norm];
  saveAnioOverrides(overrides);
  // Actualizar la entrada del cache directamente (sin recalcular todo)
  // para que el filtro de año en la tab Jugadores sea inmediato tras editar
  if(_ANIO_CACHE) _ANIO_CACHE[norm] = inferirAnio(nombre);
}

// Renderiza el widget de año de nacimiento en el perfil del jugador
function anioNacWidget(nombre){
  const inf = inferirAnio(nombre);
  const overrides = loadAnioOverrides();
  const norm = _normNombreAnio(nombre);
  const tieneOverride = overrides[norm] !== undefined;
  const anioActual = inf ? inf.anio : '';
  const prefijo = inf ? (inf.prefijo||'') : '';
  const fuente = inf ? inf.fuente : 'sin datos';
  const colorFuente = fuente==='manual' ? 'var(--hw)' : fuente==='inferido' ? 'var(--a4)' : 'var(--mu)';
  const iconFuente  = fuente==='manual' ? '✏️' : fuente==='inferido' ? '🔍' : '❓';
  const safe = nombre.replace(/\\\\/g,'\\\\\\\\').replace(/'/g,"\\\\'");
  const prefijoHtml = prefijo ? `<span style="font-size:12px;color:var(--mu);font-family:'JetBrains Mono',monospace;margin-right:2px" title="Cota superior: jugador senior sin historial formativo visible">${prefijo}</span>` : '';
  return `<div style="display:flex;align-items:center;gap:8px;margin-top:6px;flex-wrap:wrap">
    <span style="font-size:11px;color:var(--mu);font-family:'JetBrains Mono',monospace">Año nac.:</span>
    ${prefijoHtml}<input id="anio-nac-inp" type="number" min="2000" max="2015" value="${anioActual}"
      style="width:72px;background:var(--s2);border:1px solid ${tieneOverride?'var(--hw)':'var(--b)'};color:${colorFuente};border-radius:5px;padding:2px 6px;font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:700;outline:none"
      title="${fuente==='manual'?'Año introducido manualmente':prefijo?'Jugador senior sin historial formativo visible — nacido en '+anioActual+' o antes':'Año inferido del historial'}"
      onchange="(function(v){setAnioNac('${safe}',v);document.getElementById('anio-nac-inp').style.borderColor='var(--hw)';document.getElementById('anio-nac-src').textContent='✏️ manual';document.getElementById('anio-nac-src').style.color='var(--hw)';toast('Año guardado: '+v,'ok');})(this.value)"
      onkeydown="if(event.key==='Enter')this.dispatchEvent(new Event('change'))">
    <span id="anio-nac-src" style="font-size:10px;color:${colorFuente}">${iconFuente} ${fuente}</span>
    ${tieneOverride?`<button onclick="setAnioNac('${safe}','');document.getElementById('anio-nac-inp').value='${inf&&inf.fuente!=='manual'?inf.anio:''}';document.getElementById('anio-nac-inp').style.borderColor='var(--b)';document.getElementById('anio-nac-src').textContent='🔍 inferido';document.getElementById('anio-nac-src').style.color='var(--a4)';toast('Año manual eliminado','ok')" style="font-size:10px;background:rgba(242,65,65,.15);border:1px solid rgba(242,65,65,.4);color:var(--a2);border-radius:4px;padding:1px 7px;cursor:pointer">✕ quitar</button>`:''}
  </div>`;
}

// Devuelve la provincia de un equipo/club (normalizado), o '' si desconocida.
// Prioridad: override usuario > PROVINCIA_MAP_BASE (clave normalizada mayúsculas).
// Cache: clubNorm → provincia detectada desde actas
const _PROV_ACTAS_CACHE = {};
// Fuentes locales (tienen provincia real); rfef solo aplica si no hay ninguna local
const _FUENTES_LOCALES = ['alava','gipuzkoa','bizkaia','navarra','rioja','euskadi','cantabria'];
function _provDesdeActas(clubNorm){
  if(_PROV_ACTAS_CACHE[clubNorm] !== undefined) return _PROV_ACTAS_CACHE[clubNorm];
  // Contar cuántas actas de cada fuente tiene este club
  const cnt = {};
  ACTAS.forEach(a=>{
    const lNorm = (a.equipo_local||'').replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
    const vNorm = (a.equipo_visitante||'').replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
    const match = lNorm===clubNorm || vNorm===clubNorm
      || lNorm.replace(/\s+[ABCD]$/,'')===clubNorm || vNorm.replace(/\s+[ABCD]$/,'')===clubNorm;
    if(match && a.fuente){
      cnt[a.fuente]=(cnt[a.fuente]||0)+1;
    }
  });
  if(!Object.keys(cnt).length){ _PROV_ACTAS_CACHE[clubNorm]=''; return ''; }
  // Priorizar fuentes locales sobre rfef: si el club aparece en alguna fuente local,
  // usar la más frecuente de ellas (un equipo de Álava también puede jugar en rfef,
  // pero su provincia real es Álava, no Nacional).
  const locales = Object.entries(cnt)
    .filter(([f])=>_FUENTES_LOCALES.includes(f))
    .sort((a,b)=>b[1]-a[1]);
  const fuente = locales.length ? locales[0][0]
    : Object.entries(cnt).sort((a,b)=>b[1]-a[1])[0][0];
  const prov = _fuenteAProvincia(fuente);
  _PROV_ACTAS_CACHE[clubNorm] = prov;
  return prov;
}

function getProvincia(clubCanon){
  if(!clubCanon) return '';
  const norm = clubCanon.replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
  const overrides = loadProvOverrides();
  if(overrides[norm]) return overrides[norm];
  if(PROVINCIA_MAP_BASE[norm]) return PROVINCIA_MAP_BASE[norm];
  // Intentar con strip filial
  const sinFilial = norm.replace(/\s+[ABCD]$/, '').trim();
  if(overrides[sinFilial]) return overrides[sinFilial];
  if(PROVINCIA_MAP_BASE[sinFilial]) return PROVINCIA_MAP_BASE[sinFilial];
  // Fallback: detectar desde las actas por fuente de descarga
  return _provDesdeActas(norm) || _provDesdeActas(sinFilial);
}

// Cambia la provincia de un club y recarga la vista de clubes.
function setProvinciaClub(clubCanon, nuevaProv){
  const norm = clubCanon.replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
  const overrides = loadProvOverrides();
  if(nuevaProv) overrides[norm] = nuevaProv;
  else delete overrides[norm];
  saveProvOverrides(overrides);
  rCb();
  toast('Provincia actualizada: ' + clubCanon + ' → ' + (nuevaProv||'Sin asignar'), 'ok');
}

// Badge coloreado de provincia
function provinciaBadge(prov){
  if(!prov) return '<span style="font-size:10px;color:var(--mu);font-style:italic">Sin provincia</span>';
  const colores = {'Álava':'#f5c842','Bizkaia':'#4d8bff','Gipuzkoa':'#00f0a0','Navarra':'#c040ff','La Rioja':'#ff8c00','Vasca':'#a0c840','Nacional':'#ff4040'};
  const col = colores[prov] || '#b06fff';
  return `<span style="font-size:10px;font-weight:700;color:${col};background:${col}22;border:1px solid ${col}55;border-radius:4px;padding:1px 7px;white-space:nowrap">${prov}</span>`;
}

// Selector de provincia inline (dropdown que al cambiar guarda)
function provinciaSelector(clubCanon, actual){
  const opts = ['','Álava','Bizkaia','Gipuzkoa','Navarra','La Rioja','Vasca','Nacional'].map(p=>
    `<option value="${p}"${p===actual?' selected':''}>${p||'Sin asignar'}</option>`
  ).join('');
  const safe = clubCanon.replace(/'/g,'&apos;');
  return `<select onchange="setProvinciaClub('${safe}',this.value)" onclick="event.stopPropagation()"
    style="background:var(--s1);border:1px solid var(--b);color:var(--tx);padding:2px 6px;border-radius:5px;font-size:11px;cursor:pointer;outline:none">
    ${opts}</select>`;
}

// Normaliza: quita puntos, comas, espacios extra, mayúsculas.
// "ABETXUKO, A.D.C." → "ABETXUKO ADC"
function normName(n){
  if(!n) return '';
  return n.replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
}

// Quita el sufijo filial final (" A" / " B" / " C" / " D") del nombre normalizado.
// "ABETXUKO ADC B" → "ABETXUKO ADC"
function stripFilial(norm){
  const m = norm.match(/^(.+?)\s+([ABCD])$/);
  return m ? m[1].trim() : norm;
}

// Devuelve la clave de club normalizada para un equipo:
// aplica merges manuales (con resolución de cadenas), luego CLUB_MAP, luego stripFilial.
function getClubKey(eq){
  if(!eq) return '';
  const norm = normName(eq);
  const merges = loadMerges();
  // Resolver cadena de merges (evitar bucles infinitos con max 10 pasos)
  let cur = norm;
  for(let i=0;i<10;i++){
    const next = merges[cur] || merges[stripFilial(cur)];
    if(!next || next===cur) break;
    cur = next;
  }
  if(cur !== norm) return cur;
  if(CLUB_MAP[norm]) return normName(CLUB_MAP[norm]);
  return stripFilial(norm);
}

// Cache de nombres canónicos: normEq → nombre a mostrar (Title Case, sin sufijo filial)
let _clubCanonCache = null;
function _buildCanonCache(){
  const groups = {}; // clubKey → [nombres originales limpios]
  ACTAS.forEach(a=>{
    [a.equipo_local,a.equipo_visitante].filter(Boolean).forEach(eq=>{
      const key = getClubKey(eq);
      const limpio = eq.replace(/[.,]/g,'').replace(/\s+/g,' ').trim();
      if(!groups[key]) groups[key]=[];
      if(!groups[key].includes(limpio)) groups[key].push(limpio);
    });
  });
  _clubCanonCache = {};
  Object.entries(groups).forEach(([key, names])=>{
    // Canon = el nombre sin sufijo filial (A/B/C/D) más corto
    const noFilial = names.filter(n=>!/\s+[ABCD]$/i.test(n));
    const pool = noFilial.length ? noFilial : names;
    const canon = pool.slice().sort((a,b)=>a.length-b.length)[0];
    names.forEach(n=>{ _clubCanonCache[normName(n)] = canon; });
    // También mapear la clave normalizada
    _clubCanonCache[key] = canon;
  });
}
function getClubCanon(eq){
  if(!_clubCanonCache) _buildCanonCache();
  const norm = normName(eq);
  return _clubCanonCache[norm] || _clubCanonCache[getClubKey(eq)] || eq.replace(/[.,]/g,'').replace(/\s+/g,' ').trim();
}

// Resetea caches (necesario tras cambiar merges)
function _resetClubCaches(){
  _clubCanonCache = null;
  _clubsCache = null;
  // Limpiar cache de provincias detectadas desde actas
  Object.keys(_PROV_ACTAS_CACHE).forEach(k=>delete _PROV_ACTAS_CACHE[k]);
}

// Devuelve src del escudo buscando por todas las variantes del nombre
function getLogoSrc(eq){
  if(!eq) return null;
  const tries = [
    eq,
    eq.replace(/[.,]/g,'').replace(/\s+/g,' ').trim(),
    getClubCanon(eq),
    getClubKey(eq),
  ];
  for(const t of tries){ if(t && TEAM_LOGOS[t]) return TEAM_LOGOS[t]; }
  return null;
}

// ── LOGO HELPER ───────────────────────────────────────────────────────────────
function logoHtml(eq, cls='team-logo'){
  if(!eq) return '';
  const src = getLogoSrc(eq);
  if(src) return `<img class="${cls}" src="${src}" alt="${eq}" title="${eq}">`;
  // Fallback: iniciales coloreadas
  const ini=eq.trim().split(/\s+/).map(w=>w[0]).join('').toUpperCase().slice(0,3);
  const colors=['#00f0a0','#4d8bff','#f5c842','#ff4f37','#b06fff','#00c8ff','#ff9f00'];
  const hc=eq.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
  const col=colors[hc%colors.length];
  const sz=cls==='team-logo-xl'?'68px':cls==='team-logo-lg'?'52px':cls==='team-logo-sm'?'22px':'32px';
  const fs=cls==='team-logo-xl'?'20px':cls==='team-logo-lg'?'16px':cls==='team-logo-sm'?'8px':'11px';
  return `<div style="width:${sz};height:${sz};border-radius:6px;background:linear-gradient(135deg,${col}22,${col}44);border:1px solid ${col}66;display:flex;align-items:center;justify-content:center;font-family:'Bebas Neue',sans-serif;font-size:${fs};color:${col};flex-shrink:0;text-align:center" title="${eq}">${ini}</div>`;
}

// ── CLUBES ENGINE ─────────────────────────────────────────────────────────────

// Extrae el sufijo filial de un equipo dado el nombre canónico del club.
// "Abetxuko B" con canon "Abetxuko" → "B"
// "Abetxuko" con canon "Abetxuko"   → "" (equipo principal, sin sufijo)
function getFilialSuffix(eqLimpio, canonNombre){
  const normEq  = eqLimpio.replace(/[.,]/g,'').replace(/\s+/g,' ').trim();
  const normCan = canonNombre.replace(/[.,]/g,'').replace(/\s+/g,' ').trim();
  let rest = normEq;
  if(normEq.toUpperCase().startsWith(normCan.toUpperCase())){
    rest = normEq.slice(normCan.length).trim();
  }
  if(/^[A-D]$/i.test(rest)) return rest.toUpperCase();
  const m = normEq.match(/\s+([A-D])$/i);
  if(m) return m[1].toUpperCase();
  return '';
}

// Detecta el nivel (A, B, C) de un equipo dentro de su club
// Devuelve 'A', 'B', 'C', 'D' o '' si es el equipo único / principal
function getFilialLetra(eqLimpio, canonNombre){
  return getFilialSuffix(eqLimpio, canonNombre) || '';
}

// ── DETECCIÓN AUTOMÁTICA DE FILIALES POR CATEGORÍA ────────────────────────────
// Para un equipo dado, detecta si es el A, B o C de su club mirando qué otros
// equipos del mismo club compiten en la misma liga/temporada y en ligas superiores/inferiores.
// Devuelve { letra: 'A'|'B'|'C'|'', nivel: 1|2|3|0, grupo: 'SENIOR'|'JUVENIL'|'CADETE'|'' }
function detectarNivelEquipo(eq, cat, temp){
  const canon = getClubCanon(eq);
  const clubs = getClubes();
  const c = clubs[canon];
  if(!c) return {letra:'',nivel:0,grupo:''};

  const grupo = getCatGrupo(cat) || '';
  // Todos los equipos del mismo club en el mismo grupo y temporada
  const equiposClub = Object.keys(c.equipos).filter(e => {
    if(e === eq) return false;
    // Ver si aparece en alguna acta del mismo grupo y temp
    return ACTAS.some(a =>
      (a.equipo_local===e||a.equipo_visitante===e) &&
      (!temp||a.temporada===temp) &&
      (!grupo||getCatGrupo(a.categoria)===grupo)
    );
  });

  if(equiposClub.length === 0){
    // Equipo único del club en este grupo → es el A
    return {letra:'A',nivel:1,grupo};
  }

  // Intentar detectar por sufijo explícito
  const propioSuf = getFilialSuffix(eq.replace(/[.,]/g,'').replace(/\s+/g,' ').trim(), canon);
  if(propioSuf) return {letra:propioSuf, nivel:propioSuf.charCodeAt(0)-64, grupo};

  // Inferir por categoría: el equipo en la categoría más alta = A
  // Construir mapa equipo→cat ranking
  const NIVEL_CAT_WORDS = [
    // De mayor a menor: vasca, honor, primera, preferente, …
    ['vasca'],['honor'],['primera'],['preferente'],['segunda'],['tercera'],['regional']
  ];
  function rankCat(catStr){
    const n = (catStr||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    for(let i=0;i<NIVEL_CAT_WORDS.length;i++){
      if(NIVEL_CAT_WORDS[i].some(k=>n.includes(k))) return NIVEL_CAT_WORDS.length-i;
    }
    return 0;
  }
  function bestCat(eqN){
    const cats = ACTAS
      .filter(a=>(a.equipo_local===eqN||a.equipo_visitante===eqN)&&(!temp||a.temporada===temp)&&(!grupo||getCatGrupo(a.categoria)===grupo))
      .map(a=>a.categoria||'');
    if(!cats.length) return {cat:'',rank:0};
    const best = cats.reduce((b,c2)=>{const r=rankCat(c2);return r>b.rank?{cat:c2,rank:r}:b},{cat:'',rank:0});
    return best;
  }

  const todos = [eq, ...equiposClub];
  const ranking = todos.map(e=>({eq:e, ...bestCat(e)})).sort((a,b)=>b.rank-a.rank||a.eq.localeCompare(b.eq));
  const idx = ranking.findIndex(r=>r.eq===eq);
  if(idx<0) return {letra:'A',nivel:1,grupo};
  const letras = ['A','B','C','D','E'];
  const letra = letras[idx]||String(idx+1);
  return {letra, nivel:idx+1, grupo};
}

// ── ALTAS / BAJAS / ACABAN / SE MANTIENEN ─────────────────────────────────────
// Calcula movimientos de jugadores para un equipo en una temporada/cat.
// Compara la plantilla de esta temporada con la anterior.
// Devuelve { altas: [...], bajas: [...], acaban: [...], mantienen: [...] }
//
// Reglas:
//  ALTAS:
//   - Viene de equipo filial/absorbido del mismo club → traslado/subido/cedido (nunca fichaje)
//   - Viene de filial del mismo club con ≤5 partidos en temp anterior → 'subida_puntual' (no se muestra como ALTA)
//   - Viene de club externo → fichaje
//   - No se encontró antes → nuevo
//  BAJAS:
//   - Ahora juega en otro equipo del mismo club (incluyendo absorbidos) → ascendido/cedido interno (nunca salida)
//   - Ahora juega en club externo → salida
//   - No aparece en ningún equipo esta temp → salida sin destino
//  ACABAN (último año de categoría):
//   - Solo jugadores cuyo año de nacimiento inferido indica que es su ÚLTIMO año posible en esa categoría
//   - NO marcar a jugadores que aún tienen edad para seguir
//   - NO marcar a jugadores que ya están en BAJAS (se han ido)
//  SE MANTIENEN:
//   - Estaban la temp anterior, siguen ahora, y AÚN tienen edad para jugar la próxima temp en esa categoría
//   - Excluir a los que están en ACABAN
function calcularMovimientos(eq, cat, temp){
  if(!temp) return {altas:[],bajas:[],acaban:[],mantienen:[]};
  const grupo = getCatGrupo(cat)||'';

  // Temporada anterior y siguiente
  const allTemps = [...new Set(ACTAS.filter(a=>!isSala(a.categoria)).map(a=>a.temporada).filter(Boolean))].sort();
  const idxTemp = allTemps.indexOf(temp);
  const tempAnt = idxTemp>0 ? allTemps[idxTemp-1] : null;

  // ── Helpers ──────────────────────────────────────────────────────────────────

  // Cuenta partidos de un jugador en un equipo durante una temporada
  function contarPartidos(nombre, eqN, temporada){
    return ACTAS.filter(a=>
      (a.equipo_local===eqN||a.equipo_visitante===eqN) &&
      a.temporada===temporada &&
      ((a.jugadores_local||[]).includes(nombre)||(a.jugadores_visitante||[]).includes(nombre))
    ).length;
  }

  // Devuelve todos los equipos del club (propios + absorbidos) con sus actas
  function equiposDelClub(canonNombre){
    const clubs = getClubes();
    const cInfo = clubs[canonNombre];
    if(!cInfo) return [];
    // Equipos del canon principal
    const eqs = Object.keys(cInfo.equipos);
    // Añadir equipos de clubes absorbidos (cargar merges localmente)
    const mergesLocal = loadMerges();
    const absorbidosNorm = Object.entries(mergesLocal).filter(([k,v])=>v===canonNombre).map(([k])=>k);
    absorbidosNorm.forEach(absNorm=>{
      Object.values(clubs).forEach(c=>{
        if(normName(c.nombre||'')===absNorm){
          Object.keys(c.equipos).forEach(e=>{ if(!eqs.includes(e)) eqs.push(e); });
        }
      });
    });
    return eqs;
  }

  // Plantilla de un equipo (jugadores que aparecen en actas)
  function plantilla(eqN, catN, temporada){
    const jugs = new Set();
    ACTAS.filter(a=>
      (a.equipo_local===eqN||a.equipo_visitante===eqN) &&
      (!catN||a.categoria===catN) &&
      (!temporada||a.temporada===temporada)
    ).forEach(a=>{
      const isL=a.equipo_local===eqN;
      (isL?a.jugadores_local:a.jugadores_visitante||[]).forEach(n=>jugs.add(n));
    });
    return jugs;
  }

  // ── Año de inicio de temporada ────────────────────────────────────────────────
  function yearStart(t){ return parseInt((t||'').split('-')[0])||0; }

  // ── ¿Tiene el jugador edad para seguir en esta categoría la PRÓXIMA temporada? ─
  // Juvenil: 3 años posibles (nació yS-16, -17, -18). Último año: nació yS-18 o antes.
  //          Aún tiene edad si nació yS-17 o posterior.
  // Cadete:  2 años posibles (nació yS-14, -15). Último año: nació yS-15 o antes.
  //          Aún tiene edad si nació yS-14 o posterior.
  // Devuelve true si aún le queda al menos 1 año más de edad en ese grupo tras 'temp'.
  function tieneEdadSiguienteTemp(nombre, grupoN, temporada){
    const anioInf = inferirAnio(nombre);
    if(!anioInf) return false; // sin info → no mostrar en SE MANTIENEN
    const yS = yearStart(temporada);
    if(!yS) return false;
    if(grupoN==='JUVENIL'){
      return anioInf.anio >= yS-17;
    }
    if(grupoN==='CADETE'){
      // Aún tiene edad si nació yS-14 o posterior (1er año cadete → puede hacer 2º año)
      return anioInf.anio >= yS-14;
    }
    return false;
  }

  // ── Es último año de categoría según edad ─────────────────────────────────────
  function esUltimoAnio(nombre, grupoN, temporada){
    const anioInf = inferirAnio(nombre);
    if(!anioInf) return false;
    const yS = yearStart(temporada);
    if(!yS) return false;
    if(grupoN==='JUVENIL') return anioInf.anio <= yS-18;
    if(grupoN==='CADETE')  return anioInf.anio <= yS-15; // 2º año cadete: cumple 16 esta temp
    return false;
  }

  // ─────────────────────────────────────────────────────────────────────────────
  const plantActual = plantilla(eq, cat, temp);
  const canon = getClubCanon(eq);
  const todosEqClub = equiposDelClub(canon);

  if(!tempAnt) return {
    altas:[...plantActual].map(n=>({nombre:n,tipo:'nuevo',origen:''})),
    bajas:[],acaban:[],mantienen:[]
  };

  // Plantilla del mismo equipo la temporada anterior (misma cat)
  const plantAnt = new Set();
  const actasAntMismaCat = ACTAS.filter(a=>
    (a.equipo_local===eq||a.equipo_visitante===eq) && a.temporada===tempAnt && a.categoria===cat
  );
  if(actasAntMismaCat.length){
    actasAntMismaCat.forEach(a=>{
      const isL=a.equipo_local===eq;
      (isL?a.jugadores_local:a.jugadores_visitante||[]).forEach(n=>plantAnt.add(n));
    });
  }

  // ── ALTAS ─────────────────────────────────────────────────────────────────────
  const altas = [];
  [...plantActual].filter(n=>!plantAnt.has(n)).forEach(n=>{
    let origen = ''; let tipo = 'fichaje'; let subidaPuntual = false;

    // ¿Vino de otro equipo del mismo club (filial o absorbido)?
    for(const eqFilial of todosEqClub){
      if(eqFilial===eq) continue;
      const actasFilialAnt = ACTAS.filter(a=>
        (a.equipo_local===eqFilial||a.equipo_visitante===eqFilial) &&
        a.temporada===tempAnt
      );
      const estabaEnFilial = actasFilialAnt.some(a=>
        (a.jugadores_local||[]).includes(n)||(a.jugadores_visitante||[]).includes(n)
      );
      if(!estabaEnFilial) continue;

      const partidos = contarPartidos(n, eqFilial, tempAnt);
      const nivelAnt = detectarNivelEquipo(eqFilial, actasFilialAnt[0]?.categoria||cat, tempAnt);
      const nivelAct = detectarNivelEquipo(eq, cat, temp);

      // Si jugó ≤5 partidos en el equipo de origen, es subida puntual → no cuenta como ALTA
      if(partidos <= 5){
        subidaPuntual = true;
        break;
      }

      if(nivelAnt.nivel < nivelAct.nivel){
        tipo = 'subido'; origen = `${eqFilial} (${nivelAnt.letra}) del mismo club`;
      } else if(nivelAnt.nivel > nivelAct.nivel){
        tipo = 'cedido'; origen = `${eqFilial} (${nivelAnt.letra}) del mismo club`;
      } else {
        tipo = 'traslado'; origen = `${eqFilial} del mismo club`;
      }
      break;
    }

    if(subidaPuntual) return; // omitir subidas puntuales de la lista de altas

    if(tipo==='fichaje'){
      // Buscar en qué equipo externo jugaba la temporada anterior
      ACTAS.filter(a=>a.temporada===tempAnt&&!isSala(a.categoria)).forEach(a=>{
        if(origen) return;
        const enL=(a.jugadores_local||[]).includes(n);
        const enV=(a.jugadores_visitante||[]).includes(n);
        if(!enL&&!enV) return;
        const eqOrigen = enL?a.equipo_local:a.equipo_visitante;
        if(getClubCanon(eqOrigen)!==canon){
          origen = eqOrigen + (a.categoria?` (${(a.categoria||'').split('/')[0].trim()})` :'');
        }
      });
    }
    altas.push({nombre:n, tipo, origen});
  });

  // ── BAJAS ─────────────────────────────────────────────────────────────────────
  const bajas = [];
  [...plantAnt].filter(n=>!plantActual.has(n)).forEach(n=>{
    let destino = ''; let tipo = 'salida';

    // ¿Ahora juega en otro equipo del mismo club (filial o absorbido)?
    for(const eqFilial of todosEqClub){
      if(eqFilial===eq) continue;
      const actasFilialAct = ACTAS.filter(a=>
        (a.equipo_local===eqFilial||a.equipo_visitante===eqFilial) &&
        a.temporada===temp
      );
      const estaEnFilial = actasFilialAct.some(a=>
        (a.jugadores_local||[]).includes(n)||(a.jugadores_visitante||[]).includes(n)
      );
      if(!estaEnFilial) continue;

      const nivelEqActual = detectarNivelEquipo(eq, cat, temp);
      const nivelFilial   = detectarNivelEquipo(eqFilial, actasFilialAct[0]?.categoria||cat, temp);

      if(nivelFilial.nivel < nivelEqActual.nivel){
        // Va a equipo de nivel superior (ej: B → A)
        tipo = 'ascendido'; destino = `${eqFilial} (${nivelFilial.letra}) del mismo club`;
      } else if(nivelFilial.nivel > nivelEqActual.nivel){
        tipo = 'cedido'; destino = `${eqFilial} del mismo club`;
      } else {
        tipo = 'traslado_interno'; destino = `${eqFilial} del mismo club`;
      }
      break;
    }

    if(tipo==='salida'){
      // Buscar en club externo
      ACTAS.filter(a=>a.temporada===temp&&!isSala(a.categoria)).forEach(a=>{
        if(destino) return;
        const enL=(a.jugadores_local||[]).includes(n);
        const enV=(a.jugadores_visitante||[]).includes(n);
        if(!enL&&!enV) return;
        const eqDest = enL?a.equipo_local:a.equipo_visitante;
        if(getClubCanon(eqDest)!==canon){
          destino = eqDest + (a.categoria?` (${(a.categoria||'').split('/')[0].trim()})` :'');
        }
      });
    }
    bajas.push({nombre:n, tipo, destino});
  });

  // ── ACABAN y SE MANTIENEN ─────────────────────────────────────────────────────
  // Solo para categorías formativas con límite de edad estricto
  const acaban = [];
  const mantienen = [];
  const nombresBajas = new Set(bajas.map(b=>b.nombre));

  if(grupo==='JUVENIL'||grupo==='CADETE'){
    [...plantActual].forEach(n=>{
      // Solo evaluar jugadores que SIGUEN en el equipo (no están en bajas)
      if(nombresBajas.has(n)) return;

      const temporadasEnGrupo = allTemps.filter(t=>{
        return ACTAS.some(a=>
          (a.equipo_local===eq||a.equipo_visitante===eq) &&
          a.temporada===t &&
          getCatGrupo(a.categoria)===grupo &&
          ((a.jugadores_local||[]).includes(n)||(a.jugadores_visitante||[]).includes(n))
        );
      });

      const ultimoAnio = esUltimoAnio(n, grupo, temp);
      const quedaEdad  = tieneEdadSiguienteTemp(n, grupo, temp);

      if(ultimoAnio){
        // Es su último año posible en esta categoría según edad
        acaban.push({nombre:n, temporadasEnGrupo: temporadasEnGrupo.length});
      } else if(quedaEdad){
        // Tiene edad para seguir la próxima temporada → SE MANTIENE
        mantienen.push({nombre:n, temporadasEnGrupo: temporadasEnGrupo.length});
      }
      // Si no hay info de edad (anioInf null) → no mostrar en ninguna columna
    });
  }

  // Ordenar: externos primero (fichajes/nuevos), internos después (traslados/subidos/cedidos)
  const tiposExternosAlta  = new Set(['fichaje','nuevo']);
  const tiposExternosBaja  = new Set(['salida']);
  altas.sort((a,b)=>{
    const aExt = tiposExternosAlta.has(a.tipo) ? 0 : 1;
    const bExt = tiposExternosAlta.has(b.tipo) ? 0 : 1;
    return aExt - bExt;
  });
  bajas.sort((a,b)=>{
    const aExt = tiposExternosBaja.has(a.tipo) ? 0 : 1;
    const bExt = tiposExternosBaja.has(b.tipo) ? 0 : 1;
    return aExt - bExt;
  });

  return {altas, bajas, acaban, mantienen};
}

// Render HTML del bloque ALTAS/BAJAS/ACABAN/SE MANTIENEN para mostrar en rEq
function renderMovimientos(eq, cat, temp, grupo){
  const {altas, bajas, acaban, mantienen} = calcularMovimientos(eq, cat, temp);
  if(!altas.length && !bajas.length && !acaban.length && !mantienen.length) return '';

  const TIPO_COLOR = {
    'fichaje':'var(--acc)', 'subido':'var(--a4)', 'cedido':'var(--a3)',
    'traslado':'var(--mu)', 'traslado_interno':'var(--mu)',
    'ascendido':'var(--hw)', 'salida':'var(--mu)'
  };
  const TIPO_ICON = {
    'fichaje':'🆕', 'subido':'⬆️', 'cedido':'↩️', 'traslado':'↔️',
    'traslado_interno':'↔️', 'ascendido':'⬆️', 'salida':'📤'
  };
  const TIPO_LABEL = {
    'fichaje':'FICHAJE', 'subido':'ASCENDIDO', 'cedido':'CEDIDO',
    'traslado':'TRASLADO', 'traslado_interno':'TRASLADO',
    'ascendido':'ASCENDIDO AL A', 'salida':'SALIDA'
  };

  const rowAlta = a => `<div class="pl" style="cursor:pointer" onclick="openPlayer('${a.nombre.replace(/'/g,"\\'")}')">
    <span style="font-size:13px">${TIPO_ICON[a.tipo]||'➕'}</span>
    <div style="flex:1">
      <span style="font-weight:600;color:var(--acc)">${a.nombre}</span>
      ${a.origen?`<span style="font-size:11px;color:var(--mu);margin-left:6px">← ${a.origen}</span>`:''}
    </div>
    <span style="font-size:10px;font-weight:700;color:${TIPO_COLOR[a.tipo]||'var(--acc)'};background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:4px;padding:1px 6px">${TIPO_LABEL[a.tipo]||a.tipo.toUpperCase()}</span>
  </div>`;

  const rowBaja = b => `<div class="pl" style="cursor:pointer" onclick="openPlayer('${b.nombre.replace(/'/g,"\\'")}')">
    <span style="font-size:13px">${TIPO_ICON[b.tipo]||'➖'}</span>
    <div style="flex:1">
      <span style="font-weight:600;color:var(--a2)">${b.nombre}</span>
      ${b.destino?`<span style="font-size:11px;color:var(--mu);margin-left:6px">→ ${b.destino}</span>`:''}
    </div>
    <span style="font-size:10px;font-weight:700;color:${TIPO_COLOR[b.tipo]||'var(--a2)'};background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);border-radius:4px;padding:1px 6px">${TIPO_LABEL[b.tipo]||b.tipo.toUpperCase()}</span>
  </div>`;

  const rowAcaba = a => `<div class="pl" style="cursor:pointer" onclick="openPlayer('${a.nombre.replace(/'/g,"\\'")}')">
    <span style="font-size:13px">🎓</span>
    <div style="flex:1">
      <span style="font-weight:600;color:var(--a3)">${a.nombre}</span>
      <span style="font-size:11px;color:var(--mu);margin-left:6px">${a.temporadasEnGrupo} temp. en ${(grupo||'').toLowerCase()}</span>
    </div>
    <span style="font-size:10px;font-weight:700;color:var(--a3);background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.3);border-radius:4px;padding:1px 6px">ÚLTIMO AÑO</span>
  </div>`;

  const rowMantiene = a => `<div class="pl" style="cursor:pointer" onclick="openPlayer('${a.nombre.replace(/'/g,"\\'")}')">
    <span style="font-size:13px">🔄</span>
    <div style="flex:1">
      <span style="font-weight:600;color:var(--hw)">${a.nombre}</span>
      <span style="font-size:11px;color:var(--mu);margin-left:6px">${a.temporadasEnGrupo} temp. en ${(grupo||'').toLowerCase()}</span>
    </div>
    <span style="font-size:10px;font-weight:700;color:var(--hw);background:rgba(100,220,100,.08);border:1px solid rgba(100,220,100,.25);border-radius:4px;padding:1px 6px">CONTINÚA</span>
  </div>`;

  let html = `<div class="st" style="margin-top:18px">🔄 Movimientos${temp?' — '+temp:''}</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:18px">`;

  if(altas.length){
    html += `<div class="card">
      <div class="coltit" style="color:var(--acc)">⬆️ ALTAS (${altas.length})</div>
      ${altas.map(rowAlta).join('')}
    </div>`;
  }
  if(bajas.length){
    html += `<div class="card">
      <div class="coltit" style="color:var(--a2)">⬇️ BAJAS (${bajas.length})</div>
      ${bajas.map(rowBaja).join('')}
    </div>`;
  }
  if(acaban.length){
    html += `<div class="card">
      <div class="coltit" style="color:var(--a3)">🎓 ACABAN (${acaban.length})</div>
      ${acaban.map(rowAcaba).join('')}
    </div>`;
  }
  if(mantienen.length){
    html += `<div class="card">
      <div class="coltit" style="color:var(--hw)">🔄 SE MANTIENEN (${mantienen.length})</div>
      ${mantienen.map(rowMantiene).join('')}
    </div>`;
  }
  html += '</div>';
  return html;
}

let _clubsCache = null;
function getClubes(){
  if(_clubsCache) return _clubsCache;
  if(!_clubCanonCache) _buildCanonCache();
  const clubs = {}; // { canon: { nombre, equipos, historia } }
  ACTAS.forEach(a=>{
    [a.equipo_local, a.equipo_visitante].forEach(eq=>{
      if(!eq) return;
      const canon = getClubCanon(eq);
      if(!clubs[canon]) clubs[canon]={ nombre:canon, equipos:{}, historia:[] };
      const eqLimpio = eq.replace(/[.,]/g,'').replace(/\s+/g,' ').trim();
      clubs[canon].equipos[eqLimpio] = true;
      const temp = a.temporada || '?';
      const cat  = a.categoria || '?';
      const key  = `${temp}|${eqLimpio}|${cat}`;
      if(!clubs[canon]._seen) clubs[canon]._seen = new Set();
      if(!clubs[canon]._seen.has(key)){
        clubs[canon]._seen.add(key);
        clubs[canon].historia.push({ temp, eq:eqLimpio, cat });
      }
    });
  });
  Object.values(clubs).forEach(c=>{
    c.historia.sort((a,b)=>b.temp.localeCompare(a.temp));
    delete c._seen;
  });
  _clubsCache = clubs;
  return clubs;
}

// ── RENDER CLUBES ─────────────────────────────────────────────────────────────
function rCb(){
  const srch = (document.getElementById('cb-s')?.value||'').toLowerCase();
  const filtProv = document.getElementById('cb-prov')?.value||'';
  const clubs = getClubes();
  let entries = Object.values(clubs).filter(c=>{
    if(srch && !c.nombre.toLowerCase().includes(srch)) return false;
    const prov = getProvincia(c.nombre);
    if(filtProv === '_sin') return !prov;
    if(filtProv && prov !== filtProv) return false;
    return true;
  });
  entries.sort((a,b)=>a.nombre.localeCompare(b.nombre));
  if(!entries.length){ document.getElementById('cb-c').innerHTML='<div class="empty">Sin clubes</div>'; return; }

  // Agrupar historia por temporada para cada club
  let h = '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px">';
  entries.forEach(c=>{
    const eqs = Object.keys(c.equipos).sort();
    const haLogo = !!getLogoSrc(c.nombre);
    const logoEl = logoHtml(c.nombre, 'team-logo-lg');
    // Obtener clubs absorbidos para incluir su historia
    const mergesCard = loadMerges();
    const absNormsCard = Object.entries(mergesCard).filter(([k,v])=>v===normName(c.nombre)).map(([k])=>k);
    const absNombresCard = absNormsCard.map(normA=>Object.keys(clubs).find(k=>normName(k)===normA)||normA);
    // Historial combinado: propio + absorbidos
    const byTemp = {};
    c.historia.forEach(entry=>{
      if(!byTemp[entry.temp]) byTemp[entry.temp]=[];
      byTemp[entry.temp].push({eq:entry.eq, cat:entry.cat, origen:c.nombre, absorbido:false});
    });
    absNombresCard.forEach(absN=>{
      const cAbs=clubs[absN];
      if(cAbs) cAbs.historia.forEach(entry=>{
        if(!byTemp[entry.temp]) byTemp[entry.temp]=[];
        byTemp[entry.temp].push({eq:entry.eq, cat:entry.cat, origen:absN, absorbido:true});
      });
    });
    const temps = Object.keys(byTemp).sort((a,b)=>b.localeCompare(a));
    // Sufijos filiales presentes (A, B, C...) para mostrar en subtítulo de la tarjeta
    const sufijos = eqs.map(eq=>getFilialSuffix(eq, c.nombre)).filter(Boolean).sort();
    const sufijosBadges = sufijos.length
      ? sufijos.map(s=>`<span style="font-size:10px;font-weight:700;color:var(--a4);background:rgba(77,139,255,.15);border:1px solid rgba(77,139,255,.3);border-radius:4px;padding:1px 6px">${s}</span>`).join(' ')
      : '';
    // Badge de clubs absorbidos en la cabecera de la tarjeta
    const absCardBadge = absNombresCard.length
      ? `<span style="font-size:9px;color:var(--a3)" title="${absNombresCard.join(', ')}">+ ${absNombresCard.length} club${absNombresCard.length>1?'s':''} absorbido${absNombresCard.length>1?'s':''}</span>`
      : '';
    const tempRows = temps.map(t=>{
      const _GO={SENIOR:0,JUVENIL:1,CADETE:2};
      const _GC={SENIOR:'var(--hw)',JUVENIL:'var(--a4)',CADETE:'var(--a5)'};
      const _GL={SENIOR:'SENIOR',JUVENIL:'JUVENIL',CADETE:'CADETE'};
      const items=[...byTemp[t]].sort((a,b)=>{
        const ga=getCatGrupo(a.cat)||'',gb=getCatGrupo(b.cat)||'';
        const go=(_GO[ga]??9)-(_GO[gb]??9); if(go!==0)return go;
        const sa=getFilialSuffix(a.eq,a.absorbido?a.origen:c.nombre)||'A';
        const sb=getFilialSuffix(b.eq,b.absorbido?b.origen:c.nombre)||'A';
        return sa.localeCompare(sb);
      });
      const porGrupo={};
      items.forEach(i=>{
        const g=getCatGrupo(i.cat)||'OTRO';
        if(!porGrupo[g])porGrupo[g]=[];
        porGrupo[g].push(i);
      });
      const gruposPresentes=['SENIOR','JUVENIL','CADETE'].filter(g=>porGrupo[g]);
      let html='';
      gruposPresentes.forEach(g=>{
        const col=_GC[g]||'var(--mu)';
        // Separador de grupo — siempre visible
        html+='<div style="font-size:9px;font-weight:700;color:'+col+';letter-spacing:1px;margin:3px 0 1px;padding-left:2px">'+_GL[g]+'</div>';
        const row=porGrupo[g].map(i=>{
          const suf=getFilialSuffix(i.eq,i.absorbido?i.origen:c.nombre)||'A';
          const origenBadge=i.absorbido
            ?'<span style="font-size:9px;color:var(--a3);background:rgba(245,200,66,.1);border:1px solid rgba(245,200,66,.25);border-radius:3px;padding:0 4px;margin-left:3px">← '+i.origen.substring(0,12)+'</span>'
            :'';
          return '<span style="display:inline-flex;align-items:center;gap:4px;flex-shrink:0">'
            +'<span style="font-size:10px;font-weight:700;color:'+col+';background:'+col+'22;border:1px solid '+col+'55;border-radius:4px;padding:1px 6px">'+suf+'</span>'
            +'<span style="font-size:11px;color:'+(i.absorbido?'var(--mu)':'var(--tx)')+'">'+i.cat.split('/')[0].trim()+'</span>'
            +origenBadge+'</span>';
        }).join('<span style="color:var(--b2);padding:0 2px">·</span>');
        html+='<div style="display:flex;flex-wrap:wrap;gap:3px;align-items:center;margin-bottom:2px">'+row+'</div>';
      });
      return '<div style="padding:4px 0;border-top:1px solid rgba(255,255,255,.04)">'
        +'<span style="font-family:JetBrains Mono,monospace;color:var(--a3);font-size:10px;display:block;margin-bottom:2px">'+t+'</span>'
        +html+'</div>';
    }).join('');
    h += `<div class="card" style="cursor:pointer" onclick="openClub('${c.nombre.replace(/'/g,"\\'")}')">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
        ${logoEl}
        <div style="flex:1;min-width:0">
          <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.nombre}</div>
          <div style="font-size:11px;color:var(--mu);margin-top:4px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            ${sufijosBadges}${absCardBadge}${!haLogo?'<span style="color:var(--a2)">Sin escudo</span>':''}
          </div>
          <div style="margin-top:6px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">
            ${provinciaBadge(getProvincia(c.nombre))}
            ${provinciaSelector(c.nombre, getProvincia(c.nombre))}
          </div>
        </div>
        ${!haLogo?`<button style="background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:10px;border-radius:6px;padding:3px 8px;cursor:pointer;flex-shrink:0" onclick="event.stopPropagation();promptLogo('${c.nombre.replace(/'/g,"\\'")}')">+ Escudo</button>`:''}
      </div>
      <div style="border-top:1px solid var(--b);padding-top:8px">${tempRows||'<span style="font-size:11px;color:var(--mu)">Sin temporadas registradas</span>'}</div>
    </div>`;
  });
  h += '</div>';
  document.getElementById('cb-c').innerHTML = h;
}

function openClub(nombre){
  const clubs = getClubes();
  const c = clubs[nombre]; if(!c) return;
  const merges = loadMerges();
  // Obtener clubs absorbidos (su normName apunta al normName de este)
  const absorbidosNorm = Object.entries(merges).filter(([k,v])=>v===normName(nombre)).map(([k])=>k);
  // Resolver a nombre canónico si existe en clubs
  const absorbidosCanon = absorbidosNorm.map(normA=>{
    // buscar el club cuyo normName coincide
    return Object.keys(clubs).find(k=>normName(k)===normA) || normA;
  });

  const eqs = Object.keys(c.equipos).sort();
  const logoEl = logoHtml(nombre, 'team-logo-xl');
  const {jug} = GS();
  const jugClub = Object.entries(jug).filter(([,s])=>getClubCanon(s.equipo||'')===nombre).map(([n,s])=>({nombre:n,...s})).sort((a,b)=>b.mins-a.mins);

  // ── Historial combinado: propio + absorbidos ──────────────────────────────
  const byTemp = {};
  const addHistoria = (historia, origenNombre, esAbsorbido=false) => {
    historia.forEach(entry=>{
      if(!byTemp[entry.temp]) byTemp[entry.temp]=[];
      byTemp[entry.temp].push({eq:entry.eq, cat:entry.cat, origen:origenNombre, absorbido:esAbsorbido});
    });
  };
  addHistoria(c.historia, nombre, false);
  // Añadir trayectoria de cada absorbido
  absorbidosCanon.forEach(absNombre=>{
    const cAbs = clubs[absNombre];
    if(cAbs) addHistoria(cAbs.historia, absNombre, true);
  });

  const temps = Object.keys(byTemp).sort((a,b)=>b.localeCompare(a));
  const _GO2={SENIOR:0,JUVENIL:1,CADETE:2};
  const _GC2={SENIOR:'var(--hw)',JUVENIL:'var(--a4)',CADETE:'var(--a5)'};
  const _GL2={SENIOR:'SENIOR',JUVENIL:'JUVENIL',CADETE:'CADETE'};
  const tempRows = temps.map(t=>{
    const itemsOrd=[...byTemp[t]].sort((a,b)=>{
      const ga=getCatGrupo(a.cat)||'',gb=getCatGrupo(b.cat)||'';
      const go=(_GO2[ga]??9)-(_GO2[gb]??9); if(go!==0)return go;
      const sa=getFilialSuffix(a.eq,a.absorbido?a.origen:nombre)||'A';
      const sb=getFilialSuffix(b.eq,b.absorbido?b.origen:nombre)||'A';
      return sa.localeCompare(sb);
    });
    const porGrupo={};
    itemsOrd.forEach(i=>{
      const g=getCatGrupo(i.cat)||'OTRO';
      if(!porGrupo[g])porGrupo[g]=[];
      porGrupo[g].push(i);
    });
    const gruposPresentes=['SENIOR','JUVENIL','CADETE'].filter(g=>porGrupo[g]);
    let filas='';
    gruposPresentes.forEach(g=>{
      const col=_GC2[g]||'var(--mu)';
      // Separador de grupo — siempre visible
      filas+='<tr style="background:'+col+'0d"><td></td><td colspan="2" style="font-size:9px;font-weight:700;color:'+col+';letter-spacing:1px;padding:2px 8px">'+_GL2[g]+'</td></tr>';
      porGrupo[g].forEach(i=>{
        const suf=getFilialSuffix(i.eq,i.absorbido?i.origen:nombre)||'A';
        const eqLabel='<span style="font-weight:700;color:'+col+';background:'+col+'22;border:1px solid '+col+'55;border-radius:4px;padding:1px 7px">'+suf+'</span>';
        const absorBadge=i.absorbido
          ?'<span style="font-size:9px;font-weight:700;color:var(--a3);background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.3);border-radius:3px;padding:0 4px;margin-left:3px">← '+i.origen.substring(0,12)+'</span>'
          :'';
        filas+='<tr><td style="color:var(--a3);font-family:JetBrains Mono,monospace;font-size:11px">'+t+'</td>'
          +'<td style="font-size:12px">'+eqLabel+absorBadge+'</td>'
          +'<td style="font-size:11px;color:'+col+'">'+i.cat+'</td></tr>';
      });
    });
    return filas;
  }).join('');


  const sufijosMod = eqs.map(eq=>getFilialSuffix(eq, nombre)).filter(Boolean).sort();
  const sufijosModHtml = sufijosMod.length
    ? sufijosMod.map(s=>`<span style="font-size:11px;font-weight:700;color:var(--a4);background:rgba(77,139,255,.15);border:1px solid rgba(77,139,255,.3);border-radius:4px;padding:1px 7px">${s}</span>`).join(' ')
    : '<span style="font-size:11px;color:var(--mu)">Equipo único</span>';
  const otrosClubs = Object.keys(clubs).filter(k=>k!==nombre).sort();
  const mergeOpts = otrosClubs.map(k=>`<option value="${k.replace(/"/g,'&quot;')}">${k}</option>`).join('');

  // Badge de clubs absorbidos en la cabecera
  const absorbBadgesHtml = absorbidosCanon.length
    ? `<div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
        <span style="font-size:10px;color:var(--mu)">Absorbe a:</span>
        ${absorbidosCanon.map(an=>`<span style="font-size:11px;font-weight:700;color:var(--a3);background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.3);border-radius:4px;padding:1px 8px">${an}</span>`).join('')}
      </div>`
    : '';

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">🏟 Club</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;padding:16px;background:var(--s2);border-radius:10px;border:1px solid var(--b)">
      ${logoEl}
      <div style="flex:1">
        <div style="font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:1px">${nombre}</div>
        <div style="margin-top:6px;display:flex;align-items:center;gap:6px;flex-wrap:wrap">${sufijosModHtml}</div>
        ${absorbBadgesHtml}
        ${!haLogo?`<button style="margin-top:8px;background:rgba(255,79,55,.12);border:1px solid rgba(255,79,55,.3);color:var(--a2);font-size:11px;border-radius:6px;padding:4px 10px;cursor:pointer" onclick="promptLogo('${nombre.replace(/'/g,"\\'")}')">Añadir URL del escudo</button>`:`<div style="font-size:11px;color:var(--acc);margin-top:4px">✓ Escudo asignado</div>`}
      </div>
    </div>
    <div style="background:var(--s2);border:1px solid var(--b);border-radius:8px;padding:12px 14px;margin-bottom:14px">
      <div style="font-size:11px;color:var(--mu);margin-bottom:8px;font-family:'Bebas Neue',sans-serif;letter-spacing:1px">FUSIONAR CON OTRO CLUB</div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <select id="merge-sel" style="flex:1;background:var(--s1);border:1px solid var(--b);color:var(--tx);padding:6px 10px;border-radius:6px;font-size:12px;min-width:0">
          <option value="">Seleccionar club a absorber...</option>
          ${mergeOpts}
        </select>
        <button onclick="doMerge('${nombre.replace(/'/g,"\\'")}',document.getElementById('merge-sel').value)" style="background:rgba(77,139,255,.15);border:1px solid rgba(77,139,255,.4);color:var(--a4);font-size:12px;border-radius:6px;padding:6px 12px;cursor:pointer;white-space:nowrap">Fusionar →</button>
      </div>
      ${_getMergeInfo(nombre)}
    </div>
    <div class="st">Historial por temporada${absorbidosCanon.length?' <span style="font-size:11px;color:var(--a3);font-family:Inter,sans-serif;font-weight:400">· incluye clubs absorbidos (marcados ←)</span>':''}</div>
    <div class="tw" style="margin-bottom:16px"><table><thead><tr><th>Temporada</th><th colspan="6">Equipos y categorías</th></tr></thead><tbody>${tempRows}</tbody></table></div>
    <div class="st">Jugadores (${jugClub.length})</div>
    <div class="tw"><table><thead><tr>
      <th>Jugador</th><th>Equipo</th><th>PJ</th><th>Tit</th><th>MIN</th><th>⚽</th><th>Pres.%</th><th>⭐</th>
    </tr></thead><tbody>
    ${jugClub.map(d=>{
      const suf = getFilialSuffix(d.equipo||'', nombre);
      const eqCell = suf
        ? `<span style="font-size:10px;font-weight:700;color:var(--a4);background:rgba(77,139,255,.15);border:1px solid rgba(77,139,255,.3);border-radius:4px;padding:1px 6px">${suf}</span>`
        : `<span style="font-size:11px;color:var(--mu)">${d.equipo||''}</span>`;
      return `<tr onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}');document.getElementById('modal-bg').classList.remove('open')" style="cursor:pointer">
      <td style="font-weight:600;color:var(--acc)">${d.nombre}</td>
      <td>${eqCell}</td>
      <td class="num">${d.PJ}</td><td class="num">${d.tit}</td>
      <td class="num">${d.mins}</td><td class="num">${d.goles||0}</td>
      <td class="num">${d.pres}%</td>
      <td onclick="event.stopPropagation()">${starBtn(d.nombre)}</td>
    </tr>`;
    }).join('')||'<tr><td colspan="8" class="empty">Sin datos</td></tr>'}
    </tbody></table></div>`;
  document.getElementById('modal-bg').classList.add('open');
}

function _getMergeInfo(nombre){
  const merges = loadMerges();
  const absorbidos = Object.entries(merges).filter(([k,v])=>v===normName(nombre)).map(([k])=>k);
  if(!absorbidos.length) return '';
  return `<div style="margin-top:8px;font-size:11px;color:var(--mu)">Clubs absorbidos: ${absorbidos.map(k=>`<span style="color:var(--a4)">${k}</span> <button onclick="undoMerge('${k.replace(/'/g,"\\'")}','${nombre.replace(/'/g,"\\'")}');event.stopPropagation()" style="background:none;border:none;color:var(--a2);cursor:pointer;font-size:10px">✕</button>`).join(', ')}</div>`;
}

function toast(msg, tipo='ok'){
  const a=document.getElementById('toast-a'); if(!a) return;
  const d=document.createElement('div');
  d.className='toast '+(tipo||'');
  d.textContent=msg;
  a.appendChild(d);
  setTimeout(()=>d.remove(), 3000);
}

function doMerge(principal, absorbido){
  if(!absorbido){ alert('Selecciona un club a absorber'); return; }
  if(absorbido===principal){ alert('No puedes fusionar un club consigo mismo'); return; }
  const merges = loadMerges();
  const normPrin = normName(principal);
  const normAbs  = normName(absorbido);
  // Mapear el absorbido y todas sus variantes filiales (A/B/C/D)
  const toMap = [normAbs, normAbs+' A', normAbs+' B', normAbs+' C', normAbs+' D'];
  // También registrar todos los equipos del club absorbido que estén en las actas
  const clubs = getClubes();
  const absCanon = getClubCanon(absorbido);
  if(clubs[absCanon]){
    Object.keys(clubs[absCanon].equipos).forEach(eq => {
      toMap.push(normName(eq));
    });
  }
  toMap.forEach(n => { merges[n] = normPrin; });
  // Redirigir cualquier referencia previa al absorbido
  Object.keys(merges).forEach(k=>{ if(merges[k]===normAbs) merges[k]=normPrin; });
  saveMerges(merges);
  _resetClubCaches();
  document.getElementById('modal-bg').classList.remove('open');
  rCb();
  toast('Clubs fusionados: ' + absorbido + ' → ' + principal, 'ok');
}

function undoMerge(normAbsorbido, principal){
  const merges = loadMerges();
  delete merges[normAbsorbido];
  saveMerges(merges);
  _resetClubCaches();
  document.getElementById('modal-bg').classList.remove('open');
  rCb();
  toast('Fusion deshecha', 'ok');
}

function promptLogo(clubNombre){
  const url = prompt('URL del escudo para "' + clubNombre + '":\\n(Se guardara en LOGOS_CONOCIDOS del script Python)');
  if(!url) return;
  alert('Aniade esta linea en LOGOS_CONOCIDOS del script Python:\\n\\n    "' + clubNombre + '": "' + url + '",\\n\\nLuego vuelve a ejecutar el script para regenerar el HTML.');
}

// ── DORSAL HELPERS ────────────────────────────────────────────────────────────
// Calcula para cada jugador el dorsal más usado en cada equipo esta temporada
// Devuelve {jugador: {equipo: dorsal_mas_usado}}
let _dorsalesCache = null;
function getDorsalesEquipo(){
  if(_dorsalesCache) return _dorsalesCache;
  // {equipo: {jugador: {dorsal: count}}}
  const conteo = {};
  ACTAS.forEach(a=>{
    const proc=(jugs, dorsMap, eq)=>{
      if(!eq) return;
      if(!conteo[eq]) conteo[eq]={};
      Object.entries(dorsMap||{}).forEach(([jug,dors])=>{
        if(!conteo[eq][jug]) conteo[eq][jug]={};
        conteo[eq][jug][dors]=(conteo[eq][jug][dors]||0)+1;
      });
    };
    proc(a.titulares_local, a.dorsales_local, a.equipo_local);
    proc(a.titulares_visitante, a.dorsales_visitante, a.equipo_visitante);
  });
  // Para cada equipo, calcular el dorsal más usado por jugador
  // y resolver conflictos (mismo dorsal a dos jugadores -> al que menos jugó, poner *)
  const result={}; // {equipo: {jugador: {dorsal, conflicto}}}
  Object.entries(conteo).forEach(([eq,jugs])=>{
    result[eq]={};
    // 1. Asignar dorsal más usado a cada jugador
    const asign={}; // {jugador: dorsal}
    Object.entries(jugs).forEach(([jug,dorsCount])=>{
      const best=Object.entries(dorsCount).sort((a,b)=>b[1]-a[1])[0];
      if(best) asign[jug]=parseInt(best[0]);
    });
    // 2. Detectar conflictos: dos jugadores con mismo dorsal
    const dorsal2jugs={}; // {dorsal: [jugadores]}
    Object.entries(asign).forEach(([jug,d])=>{
      if(!dorsal2jugs[d]) dorsal2jugs[d]=[];
      dorsal2jugs[d].push(jug);
    });
    // 3. Resolver conflictos: al que menos actas tiene, cambiarle al siguiente dorsal disponible
    const dorsalesUsados=new Set(Object.values(asign));
    const conflictos=new Set();
    Object.entries(dorsal2jugs).forEach(([d,jugsArr])=>{
      if(jugsArr.length>1){
        // Ordenar por total de apariciones (más→menos)
        const sorted=jugsArr.sort((a,b)=>{
          const ta=Object.values(conteo[eq][a]||{}).reduce((s,v)=>s+v,0);
          const tb=Object.values(conteo[eq][b]||{}).reduce((s,v)=>s+v,0);
          return tb-ta;
        });
        // El primero (más apariciones) se queda, los demás buscan otro dorsal
        sorted.slice(1).forEach(jug=>{
          conflictos.add(jug);
          // Buscar siguiente dorsal disponible no usado
          const dorsAlt=Object.entries(conteo[eq][jug]||{})
            .sort((a,b)=>b[1]-a[1])
            .map(([d])=>parseInt(d))
            .find(d2=>!dorsalesUsados.has(d2));
          if(dorsAlt){
            asign[jug]=dorsAlt;
            dorsalesUsados.add(dorsAlt);
          } else {
            // Asignar un dorsal libre alto
            let libre=100;
            while(dorsalesUsados.has(libre)) libre++;
            asign[jug]=libre;
            dorsalesUsados.add(libre);
          }
        });
      }
    });
    Object.entries(asign).forEach(([jug,d])=>{
      result[eq][jug]={dorsal:d, conflicto:conflictos.has(jug)};
    });
  });
  _dorsalesCache=result;
  return result;
}

function getDorsal(eq, jugador){
  const d=getDorsalesEquipo();
  return d[eq]?.[jugador];
}

function dorsalTag(dors, conflicto, small=false){
  if(!dors) return '';
  const sz=small?'font-size:10px':'';
  const cls=conflicto?'dorsal dorsal-conflict':'dorsal';
  return `<span class="${cls}" style="${sz}">${dors}${conflicto?'*':''}</span>`;
}


// ── FAVORITOS ─────────────────────────────────────────────────────────────────
const FAV_KEY = 'faf_favoritos';
let _favs = new Set(JSON.parse(localStorage.getItem(FAV_KEY)||'[]'));

function saveFavs(){
  localStorage.setItem(FAV_KEY, JSON.stringify([..._favs]));
}
function isFav(nombre){ return _favs.has(nombre); }
function toggleFav(nombre, e){
  if(e){e.stopPropagation();e.preventDefault();}
  if(_favs.has(nombre)) _favs.delete(nombre);
  else _favs.add(nombre);
  saveFavs();
  // Refrescar todas las estrellas visibles con este nombre
  document.querySelectorAll(`.fav-star[data-n]`).forEach(btn=>{
    if(btn.dataset.n===nombre){
      btn.classList.toggle('on', _favs.has(nombre));
      btn.title=_favs.has(nombre)?'Quitar de seguimiento':'Añadir a seguimiento';
    }
  });
  // Refrescar sección seguimiento si está visible
  if(document.getElementById('p-sc')?.classList.contains('on')) renderFavSc();
  // Badge en nav
  updFavBadge();
}
function starBtn(nombre){
  const on=isFav(nombre)?'on':'';
  const tip=isFav(nombre)?'Quitar de seguimiento':'Añadir a seguimiento';
  return `<button class="fav-star ${on}" data-n="${nombre.replace(/"/g,'&quot;')}" title="${tip}" onclick="toggleFav('${nombre.replace(/'/g,"\\'")}',event)">⭐</button>`;
}

// ── CONFIGURACIÓN HOMÓNIMOS ───────────────────────────────────────────────────
const HOM_CFG_KEY = 'faf_homonimos_cfg';
// { nombre_original: 'split' | 'merge' }
// 'split'  = confirmado: son DOS jugadores distintos (separar, mantener [1]/[2])
// 'merge'  = error: es el MISMO jugador (unir, quitar [1]/[2])

const HOM_TEMP_KEY = 'faf_homonimos_temp';
// { 'GARCIA|||2023-2024': '1' | '2' }  → fuerza que esa temporada vaya al [1] o [2]

function loadHomCfg(){ try{ return JSON.parse(localStorage.getItem(HOM_CFG_KEY)||'{}'); }catch{return{};} }
function saveHomCfg(d){ localStorage.setItem(HOM_CFG_KEY, JSON.stringify(d)); }
function loadHomTemp(){ try{ return JSON.parse(localStorage.getItem(HOM_TEMP_KEY)||'{}'); }catch{return{};} }
function saveHomTemp(d){ localStorage.setItem(HOM_TEMP_KEY, JSON.stringify(d)); }

function setHomTempDecision(nombre, temp, jugador){
  // jugador: '1', '2', o '' para quitar override
  const d = loadHomTemp();
  const k = nombre+'|||'+temp;
  if(jugador) d[k] = jugador;
  else delete d[k];
  saveHomTemp(d);
  _HOMONIMO_MAP = null; _invalidarMotor();
  rCfg();
}

function getHomTempOverride(nombre, temp){
  const d = loadHomTemp();
  return d[nombre+'|||'+temp] || '';
}
function setHomDecision(nombre, decision){
  const d=loadHomCfg(); d[nombre]=decision; saveHomCfg(d);
  // Invalidar caché del motor para que se recalcule con la nueva decisión
  _HOMONIMO_MAP=null; _invalidarMotor();
  rCfg();
}
function resetHomCfg(){ if(!confirm('¿Resetear todas las decisiones de homónimos?')) return; localStorage.removeItem(HOM_CFG_KEY); localStorage.removeItem(HOM_TEMP_KEY); _HOMONIMO_MAP=null; _invalidarMotor(); rCfg(); toast('Decisiones reseteadas','ok'); }

function rCfg(){
  // Asegurar que el motor ha corrido
  _resolverHomonimos();
  const cfg=loadHomCfg();
  const srch=(document.getElementById('cfg-s')?.value||'').toLowerCase();
  const filtro=document.getElementById('cfg-filter')?.value||'';

  // Recopilar todos los nombres detectados como homónimos
  // Incluir también los que tienen decisión manual guardada (p.ej. merge) aunque
  // el motor ya no los detecte como conflictivos tras aplicar la decisión
  const nombresDetectados = new Set(_HOMONIMO_NAMES);
  Object.keys(cfg).forEach(n => { if(cfg[n]) nombresDetectados.add(n); });
  const nombres=[...nombresDetectados].sort();

  const items=nombres.filter(n=>{
    if(srch && !n.toLowerCase().includes(srch)) return false;
    const dec=cfg[n]||'';
    if(filtro==='pending' && dec) return false;
    if(filtro==='split' && dec!=='split') return false;
    if(filtro==='merge' && dec!=='merge') return false;
    return true;
  });

  if(!items.length){
    document.getElementById('cfg-hom-list').innerHTML='<div class="empty">No hay homónimos detectados'+(srch||filtro?' con ese filtro':'')+'.</div>';
    return;
  }

  const html=items.map(nombre=>{
    const dec=cfg[nombre]||'';
    const esEnMotor = _HOMONIMO_NAMES.has(nombre);

    // ── Si está marcado como merge y el motor ya no lo detecta: mostrar card simplificada ──
    if(dec === 'merge' && !esEnMotor){
      const btnClearM = `<button onclick="setHomDecision('${nombre.replace(/'/g,"\\'")}','')"
        style="padding:7px 12px;border-radius:6px;cursor:pointer;font-size:11px;background:var(--s2);border:1px solid var(--b);color:var(--mu)" title="Quitar decisión">↺ Deshacer</button>`;
      return `<div style="background:var(--s1);border:1px solid rgba(255,79,55,.25);border-radius:10px;padding:14px 16px;margin-bottom:12px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">
        <div style="flex:1;min-width:0">
          <span style="font-family:'Bebas Neue',sans-serif;font-size:18px;letter-spacing:1px;color:var(--acc)">${nombre}</span>
          <span style="font-size:10px;font-weight:700;background:rgba(255,79,55,.18);border:1px solid rgba(255,79,55,.4);color:var(--a2);border-radius:4px;padding:1px 7px;margin-left:8px">MISMO JUGADOR ✓</span>
          <div style="font-size:11px;color:var(--mu);margin-top:4px">Unificado correctamente — ya no aparece como conflicto en los datos.</div>
        </div>
        ${btnClearM}
      </div>`;
    }

    // ── Reconstruir la evidencia: secuencia de partidos con equipo ──
    // Agrupar por temporada, ordenar cronológico
    const byTemp={};
    ACTAS.forEach(a=>{
      const res=(_HOMONIMO_MAP[a.acta_id]||{})[nombre];
      if(!res) return;
      const isL=(a.jugadores_local||[]).includes(nombre);
      const eq=isL?a.equipo_local:a.equipo_visitante;
      const temp=a.temporada||'?';
      if(!byTemp[temp]) byTemp[temp]=[];
      byTemp[temp].push({eq,jornada:a.jornada||0,fecha:a.fecha||'',res,acta:a.acta_id});
    });

    // Para la temporada con más cambios de equipo (la conflictiva), mostrar la secuencia
    // ordenada por jornada y agrupar bloques consecutivos por equipo
    const tempConflictiva=Object.entries(byTemp)
      .map(([t,ps])=>{
        const sorted=ps.slice().sort((a,b)=>a.jornada-b.jornada);
        // contar cambios de equipo
        let cambios=0;
        for(let i=1;i<sorted.length;i++) if(sorted[i].eq!==sorted[i-1].eq) cambios++;
        return {temp:t,sorted,cambios};
      })
      .sort((a,b)=>b.cambios-a.cambios)[0];

    let evidenciaHtml='';
    if(tempConflictiva){
      const {temp:tConf,sorted}=tempConflictiva;
      // Construir bloques consecutivos
      const bloques=[];
      sorted.forEach(p=>{
        const last=bloques[bloques.length-1];
        if(last&&last.eq===p.eq) last.jornadas.push(p.jornada);
        else bloques.push({eq:p.eq,res:p.res,jornadas:[p.jornada]});
      });
      const bHtml=bloques.map((b,i)=>{
        const color=b.res.endsWith('[1]')?'var(--a4)':'var(--a5)';
        const who=b.res.endsWith('[1]')?'[1]':'[2]';
        const arrow=i>0?`<span style="color:var(--mu);font-size:16px;margin:0 4px">→</span>`:'';
        return `${arrow}<span style="display:inline-block;background:${b.res.endsWith('[1]')?'rgba(77,139,255,.15)':'rgba(176,111,255,.15)'};border:1px solid ${color};border-radius:6px;padding:3px 10px;font-size:12px">
          <span style="color:${color};font-weight:700">${who}</span>
          <span style="color:var(--tx);margin-left:4px">${b.eq}</span>
          <span style="color:var(--mu);font-size:10px;margin-left:4px">(J${b.jornadas[0]}${b.jornadas.length>1?'–J'+b.jornadas[b.jornadas.length-1]:''})</span>
        </span>`;
      }).join('');
      evidenciaHtml=`
        <div style="margin-bottom:10px">
          <div style="font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--a3);margin-bottom:6px;font-weight:700">POR QUÉ LO DETECTÓ — Temporada ${tConf}</div>
          <div style="font-size:11px;color:var(--mu);margin-bottom:8px;line-height:1.6">
            El sistema vio que <b style="color:var(--tx)">${nombre}</b> apareció alternando entre dos equipos sin relación de filial en la misma temporada. Esta es la secuencia de bloques:
          </div>
          <div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:10px;background:var(--bg);border-radius:6px;border:1px solid var(--b)">${bHtml}</div>
          <div style="font-size:11px;color:var(--mu);margin-top:8px;line-height:1.5">
            Si un mismo jugador pasara de un equipo a otro y luego volviera alternando, es probable que sean <b style="color:var(--acc)">dos personas distintas</b>. Si fue un error en el acta o un traspaso real con vuelta, son <b style="color:var(--a2)">el mismo jugador</b>.
          </div>
        </div>`;
    }

    // Resumen de partidos por jugador resuelto
    const pj1=[], pj2=[];
    Object.entries(byTemp).forEach(([t,ps])=>{
      ps.sort((a,b)=>a.jornada-b.jornada).forEach(p=>{
        if(p.res===nombre+' [1]') pj1.push({...p,temp:t});
        else pj2.push({...p,temp:t});
      });
    });
    function resumenTemps(partidos, jugIdx){
      // jugIdx: 1 o 2 (a qué jugador pertenece actualmente este bloque)
      const otroIdx = jugIdx === 1 ? 2 : 1;
      const byT={};
      partidos.forEach(p=>{
        if(!byT[p.temp]) byT[p.temp]={eqs:new Set(),PJ:0};
        byT[p.temp].eqs.add(p.eq); byT[p.temp].PJ++;
      });
      return Object.entries(byT).sort((a,b)=>b[0].localeCompare(a[0]))
        .map(([t,d])=>{
          const ovrActual = getHomTempOverride(nombre, t);
          const esOvr = ovrActual === String(jugIdx);
          const btnNombre = nombre.replace(/'/g,"\\'");
          const tEsc = t.replace(/'/g,"\\'");
          const btnMover = dec==='split' ? `
            <button onclick="setHomTempDecision('${btnNombre}','${tEsc}','${otroIdx}')"
              title="Mover esta temporada al jugador [${otroIdx}]"
              style="font-size:10px;padding:1px 7px;border-radius:4px;cursor:pointer;margin-left:6px;
              background:rgba(255,200,50,.1);border:1px solid rgba(255,200,50,.3);color:rgba(255,200,50,.9)">
              → [${otroIdx}]</button>
            ${ovrActual?`<button onclick="setHomTempDecision('${btnNombre}','${tEsc}','')"
              title="Quitar corrección manual"
              style="font-size:10px;padding:1px 6px;border-radius:4px;cursor:pointer;margin-left:2px;
              background:rgba(255,79,55,.1);border:1px solid rgba(255,79,55,.25);color:var(--mu)">↺</button>`:''}
          ` : '';
          const ovrBadge = esOvr ? `<span style="font-size:9px;color:rgba(255,200,50,.9);margin-left:3px" title="Asignada manualmente">★</span>` : '';
          return `<div style="display:flex;align-items:center;flex-wrap:wrap;margin-bottom:2px">
            <span style="font-size:11px;color:var(--mu)">${t}:</span>
            <span style="font-size:12px;color:var(--tx);margin-left:4px">${[...d.eqs].join(', ')}</span>
            <span style="font-size:10px;color:var(--mu);margin-left:4px">(${d.PJ}p)</span>
            ${ovrBadge}${btnMover}
          </div>`;
        }).join('');
    }

    const decBadge=dec==='split'
      ?`<span style="font-size:10px;font-weight:700;background:rgba(0,240,160,.18);border:1px solid rgba(0,240,160,.4);color:var(--acc);border-radius:4px;padding:1px 7px;margin-left:8px">DISTINTOS ✓</span>`
      :dec==='merge'
      ?`<span style="font-size:10px;font-weight:700;background:rgba(255,79,55,.18);border:1px solid rgba(255,79,55,.4);color:var(--a2);border-radius:4px;padding:1px 7px;margin-left:8px">MISMO JUGADOR</span>`
      :`<span style="font-size:10px;color:var(--a3);border:1px solid rgba(245,200,66,.3);background:rgba(245,200,66,.08);border-radius:4px;padding:1px 7px;margin-left:8px">Sin revisar</span>`;

    const btnSplit=`<button onclick="setHomDecision('${nombre.replace(/'/g,"\\'")}','split')"
      style="flex:1;padding:9px 14px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;transition:.15s;
      ${dec==='split'?'background:rgba(0,240,160,.22);border:2px solid var(--acc);color:var(--acc)':'background:rgba(0,240,160,.06);border:1px solid rgba(0,240,160,.25);color:var(--mu)'}">
      ✓ Sí, son jugadores distintos</button>`;
    const btnMerge=`<button onclick="setHomDecision('${nombre.replace(/'/g,"\\'")}','merge')"
      style="flex:1;padding:9px 14px;border-radius:6px;cursor:pointer;font-size:13px;font-weight:600;transition:.15s;
      ${dec==='merge'?'background:rgba(255,79,55,.22);border:2px solid var(--a2);color:var(--a2)':'background:rgba(255,79,55,.06);border:1px solid rgba(255,79,55,.2);color:var(--mu)'}">
      ✗ No, es el mismo jugador</button>`;
    const btnClear=dec?`<button onclick="setHomDecision('${nombre.replace(/'/g,"\\'")}','')"
      style="padding:9px 12px;border-radius:6px;cursor:pointer;font-size:11px;background:var(--s2);border:1px solid var(--b);color:var(--mu)" title="Quitar decisión">↺</button>`:'';

    return `<div style="background:var(--s1);border:1px solid var(--b);border-radius:10px;padding:16px;margin-bottom:12px">
      <div style="display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin-bottom:14px">
        <span style="font-family:'Bebas Neue',sans-serif;font-size:19px;letter-spacing:1px;color:var(--acc)">${nombre}</span>
        ${decBadge}
      </div>
      ${evidenciaHtml}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div style="background:var(--s2);border:1px solid rgba(77,139,255,.3);border-radius:8px;padding:10px 12px">
          <div style="font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--a4);margin-bottom:6px;font-weight:700">JUGADOR [1] · ${pj1.length} partidos</div>
          <div style="line-height:2">${resumenTemps(pj1,1)||'<span style="color:var(--mu);font-size:11px">Sin datos</span>'}</div>
          ${pj1.length?`<button onclick="openPlayer('${nombre.replace(/'/g,"\\'")} [1]')" style="margin-top:8px;font-size:11px;background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.3);color:var(--a4);border-radius:5px;padding:3px 9px;cursor:pointer">Ver perfil →</button>`:''}
        </div>
        <div style="background:var(--s2);border:1px solid rgba(176,111,255,.3);border-radius:8px;padding:10px 12px">
          <div style="font-size:10px;font-family:'JetBrains Mono',monospace;color:var(--a5);margin-bottom:6px;font-weight:700">JUGADOR [2] · ${pj2.length} partidos</div>
          <div style="line-height:2">${resumenTemps(pj2,2)||'<span style="color:var(--mu);font-size:11px">Sin datos</span>'}</div>
          ${pj2.length?`<button onclick="openPlayer('${nombre.replace(/'/g,"\\'")} [2]')" style="margin-top:8px;font-size:11px;background:rgba(176,111,255,.12);border:1px solid rgba(176,111,255,.3);color:var(--a5);border-radius:5px;padding:3px 9px;cursor:pointer">Ver perfil →</button>`:''}
        </div>
      </div>
      <div style="display:flex;gap:8px;align-items:center">${btnSplit}${btnMerge}${btnClear}</div>
    </div>`;
  }).join('');

  const total=nombres.length;
  const revisados=nombres.filter(n=>cfg[n]).length;
  const mergeados=nombres.filter(n=>cfg[n]==='merge').length;
  const splits=nombres.filter(n=>cfg[n]==='split').length;
  const sinRevisar=total-revisados;
  document.getElementById('cfg-hom-list').innerHTML=`
    <div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap">
      <div class="sc" style="flex:none;min-width:100px"><div class="sv">${total}</div><div class="sl">Total</div></div>
      <div class="sc" style="flex:none;min-width:100px;border-top-color:var(--a3)"><div class="sv" style="color:var(--a3)">${sinRevisar}</div><div class="sl">Sin revisar</div></div>
      <div class="sc" style="flex:none;min-width:100px;border-top-color:var(--hw)"><div class="sv" style="color:var(--hw)">${splits}</div><div class="sl">Distintos ✓</div></div>
      <div class="sc" style="flex:none;min-width:100px;border-top-color:var(--a2)"><div class="sv" style="color:var(--a2)">${mergeados}</div><div class="sl">Mismo jug. ✓</div></div>
    </div>
    ${html}`;
}
function updFavBadge(){
  const b=document.getElementById('fav-nav-badge');
  if(b) b.textContent=_favs.size||'';
  b&&(_favs.size>0?b.style.display='':b.style.display='none');
}
function renderFavSc(){
  const sec=document.getElementById('sc-fav-sec');
  const cont=document.getElementById('sc-fav');
  const cnt=document.getElementById('sc-fav-count');
  if(!sec||!cont)return;
  if(_favs.size===0){sec.style.display='none';return;}
  sec.style.display='';
  if(cnt) cnt.textContent=_favs.size;
  const {jug}=GS();
  const items=[..._favs].map(n=>{
    const s=jug[n];
    if(!s)return`<div class="sr"><div style="flex:1;font-weight:600;color:var(--acc)">${n}</div>${starBtn(n)}</div>`;
    return`<div class="sr">
      <div style="flex:1">
        <div style="display:flex;align-items:center;gap:6px">
          <span style="font-weight:600;cursor:pointer;color:var(--acc)" onclick="openPlayer('${n.replace(/'/g,"\\'")}'">${n}</span>
          ${portTag(n)}
        </div>
        <div style="font-size:11px;color:var(--mu)">${s.equipo||'?'} · ${s.PJ}PJ · ${s.mins}min${s.goles?' · ⚽'+s.goles:''} · GF/P:<span style="color:var(--hw)">${(s.gfMedia||0).toFixed(2)}</span> GC/P:<span style="color:var(--a2)">${(s.gcMedia||0).toFixed(2)}</span></div>
      </div>
      ${starBtn(n)}
    </div>`;
  }).join('');
  cont.innerHTML=items;
}

// ── HOMONYM RESOLUTION ENGINE ─────────────────────────────────────────────────
// Detects players sharing a name but being two different people.
// Criterion: within the same season the sequence of clubs oscillates A→B→A
// between clubs with DIFFERENT club-matrix (non-filial). Filial moves (B→A→B
// of the same club) are legitimate promotion/relegation and are kept together.
//
// Output: _HOMONIMO_MAP  { acta_id: { nombre_original: nombre_resuelto } }
// Also:   _HOMONIMO_ALIAS { 'GARCIA [1]': 'GARCIA', 'GARCIA [2]': 'GARCIA' }
// And:    _HOMONIMO_NAMES  Set of names that were split

let _HOMONIMO_MAP = null;   // { actaId: { nombreOrig: nombreResuelto } }
let _HOMONIMO_ALIAS = {};   // { nombreResuelto: nombreOriginal }
let _HOMONIMO_NAMES = new Set();  // nombres originales que se dividieron

function _resolverHomonimos() {
  if (_HOMONIMO_MAP !== null) return;
  _HOMONIMO_MAP = {};
  _HOMONIMO_ALIAS = {};
  _HOMONIMO_NAMES = new Set();

  // ── helpers ──
  function _cm(eq) {
    if (typeof getClubKey === 'function') return getClubKey(eq);
    return (eq||'').replace(/[.,]/g,'').replace(/\s+/g,' ').trim()
                   .toUpperCase().replace(/\s+[ABCD]$/,'');
  }
  function _eqKey(eq) { return (eq||'').trim(); }

  // ── Paso 1: para cada nombre, construir secuencia cronológica por temporada ──
  // playerTemps[nombre][temp] = [ {actaId, eq, fecha, jornada}, ... ] ordenado cronológico
  const playerTemps = {};
  const actasOrdenadas = ACTAS.filter(a => a.equipo_local && a.equipo_visitante && !isSala(a.categoria))
    .slice().sort((a,b) => {
      const t = (a.temporada||'').localeCompare(b.temporada||'');
      if (t) return t;
      const j = (a.jornada||0) - (b.jornada||0);
      if (j) return j;
      return (a.fecha||'').localeCompare(b.fecha||'');
    });

  actasOrdenadas.forEach(a => {
    const temp = a.temporada||'?';
    [[a.jugadores_local, a.equipo_local],[a.jugadores_visitante, a.equipo_visitante]].forEach(([jugs, eq]) => {
      (jugs||[]).forEach(n => {
        if (!playerTemps[n]) playerTemps[n] = {};
        if (!playerTemps[n][temp]) playerTemps[n][temp] = [];
        playerTemps[n][temp].push({ actaId: a.acta_id, eq: _eqKey(eq), fecha: a.fecha||'', jornada: a.jornada||0 });
      });
    });
  });

  // ── Paso 2: detectar oscilación A→B→A entre clubes no-filiales ──
  // Returns true si la secuencia de equipos tiene ≥2 alternancias no-filiales
  function _esOscilacion(entries) {
    if (entries.length < 4) return false;
    const seq = [];
    entries.forEach(e => { if (!seq.length || seq[seq.length-1] !== e.eq) seq.push(e.eq); });
    if (seq.length < 4) return false;
    let alternancias = 0;
    for (let i = 2; i < seq.length; i++) {
      if (seq[i] === seq[i-2] && seq[i] !== seq[i-1]) {
        if (_cm(seq[i]) !== _cm(seq[i-1])) alternancias++;
      }
    }
    return alternancias >= 2;
  }

  // ── Paso 3: para cada nombre con oscilación, asignar IDs a jugador [1] o [2] ──
  // Estrategia de asignación:
  //   - Recorrer la secuencia cronológica de partidos
  //   - Cuando el equipo cambia entre dos clubes NO-filiales de forma oscilante,
  //     detectar el punto de "cruce": antes del cruce hay dos jugadores mezclados.
  //   - Jugador [1]: el que juega en el primer equipo de la secuencia al inicio.
  //   - Jugador [2]: el que juega en el otro equipo intercalado.
  //   - Si en una entrada un jugador estaba en equipo A y la siguiente en B (no-filial),
  //     se asigna al bloque alternante correspondiente.
  //
  // Para continuidad inter-temporadas: al acabar la temporada conflictiva, el [1]
  // y [2] quedan asociados a su último equipo conocido. En temporadas adyacentes,
  // si el nombre aparece en un solo equipo que coincide con el último equipo del [1] → [1],
  // si coincide con el [2] → [2]. Si no coincide con ninguno → [1] por defecto.

  // Registrar últimos equipos resueltos por jugador (para continuidad)
  const ultimoEq = {};  // { 'GARCIA [1]': 'Madrid', 'GARCIA [2]': 'Barca' }

  // Procesar temporada por temporada en orden cronológico
  const temporadasOrden = [...new Set(actasOrdenadas.map(a=>a.temporada||'?'))].sort();

  // Cargar decisiones manuales ('merge' / 'split')
  const _homCfg = loadHomCfg();

  Object.keys(playerTemps).forEach(nombre => {
    // Si el usuario marcó explícitamente "es el mismo jugador" → no separar nunca
    if (_homCfg[nombre] === 'merge') return;

    const porTemp = playerTemps[nombre];
    let hayConflicto = false;

    temporadasOrden.forEach(temp => {
      const entries = porTemp[temp];
      if (!entries || !entries.length) return;

      const esConflicto = _esOscilacion(entries);
      if (esConflicto) hayConflicto = true;

      if (!esConflicto) {
        // Sin conflicto esta temporada: comprobar si hay override manual de temporada
        const tempOvr = getHomTempOverride(nombre, temp);
        // Sin conflicto esta temporada: asignar por continuidad con temporadas previas
        // Si el nombre ya fue dividido antes, intentar continuar la línea
        const eq1 = ultimoEq[nombre+' [1]'];
        const eq2 = ultimoEq[nombre+' [2]'];
        if (eq1 || eq2) {
          // El equipo dominante de esta temporada (el que aparece en más entradas)
          const cuentaEq = {};
          entries.forEach(e => { cuentaEq[e.eq] = (cuentaEq[e.eq]||0)+1; });
          const eqDom = Object.entries(cuentaEq).sort((a,b)=>b[1]-a[1])[0][0];
          let resuelto;
          if (tempOvr === '1') resuelto = nombre+' [1]';
          else if (tempOvr === '2') resuelto = nombre+' [2]';
          else {
            // Comprobar qué [x] es más afín por club-matriz
            const cm1 = eq1 ? _cm(eq1) : null;
            const cm2 = eq2 ? _cm(eq2) : null;
            const cmDom = _cm(eqDom);
            if (cm1 && cmDom === cm1) resuelto = nombre+' [1]';
            else if (cm2 && cmDom === cm2) resuelto = nombre+' [2]';
            else resuelto = nombre+' [1]';  // por defecto el [1]
          }
          // Aplicar a todas las entradas de esta temporada
          entries.forEach(e => {
            if (!_HOMONIMO_MAP[e.actaId]) _HOMONIMO_MAP[e.actaId] = {};
            _HOMONIMO_MAP[e.actaId][nombre] = resuelto;
          });
          ultimoEq[resuelto] = eqDom;
        } else {
          // Nunca hubo conflicto previo y no hay ahora: no tocar
          // Si en el futuro hay conflicto se retro-corregirá al procesar esa temporada
        }
        return;
      }

      // ── Hay oscilación: separar en [1] y [2] ──
      // Identificar los dos equipos que oscilan (los más frecuentes que alternan)
      const seqUnica = [];
      entries.forEach(e => { if (!seqUnica.length || seqUnica[seqUnica.length-1] !== e.eq) seqUnica.push(e.eq); });

      // Encontrar el par oscilante: buscar el par (A,B) con más alternancias
      const pares = {};
      for (let i = 1; i < seqUnica.length; i++) {
        const par = [seqUnica[i-1], seqUnica[i]].sort().join('|||');
        pares[par] = (pares[par]||0) + 1;
      }
      const parDom = Object.entries(pares).sort((a,b)=>b[1]-a[1])[0][0].split('|||');
      const eqA = parDom[0], eqB = parDom[1];

      // El equipo del PRIMER partido de la secuencia → jugador [1]
      const eqPrimero = entries[0].eq;
      const eqJ1 = eqPrimero; // [1] empieza aquí
      const eqJ2 = (eqA === eqPrimero) ? eqB : eqA;

      // Override manual de temporada
      const tempOvrConfl = getHomTempOverride(nombre, temp);

      // Asignar cada partido a [1] o [2] según el equipo
      // Partidos en equipos fuera del par oscilante → al [1] por defecto
      entries.forEach(e => {
        let resuelto;
        if (tempOvrConfl === '1') resuelto = nombre+' [1]';
        else if (tempOvrConfl === '2') resuelto = nombre+' [2]';
        else {
          const cmE = _cm(e.eq);
          const cmJ1 = _cm(eqJ1), cmJ2 = _cm(eqJ2);
          if (cmE === cmJ1) resuelto = nombre+' [1]';
          else if (cmE === cmJ2) resuelto = nombre+' [2]';
          else resuelto = nombre+' [1]';
        }
        if (!_HOMONIMO_MAP[e.actaId]) _HOMONIMO_MAP[e.actaId] = {};
        _HOMONIMO_MAP[e.actaId][nombre] = resuelto;
      });

      // Registrar últimos equipos para continuidad
      const ultimosEntries = {};
      entries.forEach(e => { ultimosEntries[e.eq] = e; }); // sobrescribe → queda el último partido de cada eq
      ultimoEq[nombre+' [1]'] = eqJ1;
      ultimoEq[nombre+' [2]'] = eqJ2;
      _HOMONIMO_NAMES.add(nombre);
    });

    // Si hubo conflicto en alguna temporada, también retro-aplicar a temporadas anteriores
    // donde el nombre aparece en UN solo equipo: asignarlo al [1] o [2] que corresponda
    if (hayConflicto) {
      _HOMONIMO_NAMES.add(nombre);
      temporadasOrden.forEach(temp => {
        const entries = porTemp[temp];
        if (!entries || !entries.length) return;
        // Si ya tiene asignación → no tocar
        const yaAsignado = entries.some(e => _HOMONIMO_MAP[e.actaId]?.[nombre]);
        if (yaAsignado) return;
        // Asignar por afinidad de equipo con el último equipo conocido de [1] o [2]
        const cuentaEq = {};
        entries.forEach(e => { cuentaEq[e.eq] = (cuentaEq[e.eq]||0)+1; });
        const eqDom = Object.entries(cuentaEq).sort((a,b)=>b[1]-a[1])[0][0];
        const cm1 = ultimoEq[nombre+' [1]'] ? _cm(ultimoEq[nombre+' [1]']) : null;
        const cm2 = ultimoEq[nombre+' [2]'] ? _cm(ultimoEq[nombre+' [2]']) : null;
        const cmDom = _cm(eqDom);
        let resuelto;
        if (cm1 && cmDom === cm1) resuelto = nombre+' [1]';
        else if (cm2 && cmDom === cm2) resuelto = nombre+' [2]';
        else resuelto = nombre+' [1]';
        entries.forEach(e => {
          if (!_HOMONIMO_MAP[e.actaId]) _HOMONIMO_MAP[e.actaId] = {};
          _HOMONIMO_MAP[e.actaId][nombre] = resuelto;
        });
      });
      _HOMONIMO_ALIAS[nombre+' [1]'] = nombre;
      _HOMONIMO_ALIAS[nombre+' [2]'] = nombre;
    }
  });
}

// Devuelve el nombre resuelto de un jugador en un acta concreta
function _rn(actaId, nombre) {
  _resolverHomonimos();
  return (_HOMONIMO_MAP[actaId]?.[nombre]) || nombre;
}

// Dado un nombre resuelto (puede tener [1]/[2] o no), devuelve el original
function _nombreOrig(n) {
  return _HOMONIMO_ALIAS[n] || n;
}

// ── ENGINE ────────────────────────────────────────────────────────────────────
let _C = null;

// ── Cache de clasificación por cat+temp (para rEq, evita recorrer ACTAS N veces) ──
let _CL_CACHE = null;   // { 'cat|||temp': { equipo: {PJ,G,E,P,GF,GC,Pts}, ... }, ... }

function _buildClCache(){
  if(_CL_CACHE) return _CL_CACHE;
  _CL_CACHE = {};
  ACTAS.forEach(a=>{
    if(!a.equipo_local||!a.equipo_visitante) return;
    if(isSala(a.categoria)) return;
    const cat=a.categoria||'Sin cat', temp=a.temporada||'?';
    const key=cat+'|||'+temp;
    if(!_CL_CACHE[key]) _CL_CACHE[key]={};
    const t=_CL_CACHE[key];
    const L=a.equipo_local, V=a.equipo_visitante;
    const gl=a.goles_local||0, gv=a.goles_visitante||0;
    [L,V].forEach(e=>{if(!t[e])t[e]={PJ:0,G:0,E:0,P:0,GF:0,GC:0,Pts:0};});
    t[L].PJ++;t[V].PJ++;
    t[L].GF+=gl;t[L].GC+=gv;
    t[V].GF+=gv;t[V].GC+=gl;
    if(gl>gv){t[L].G++;t[L].Pts+=3;t[V].P++;}
    else if(gl<gv){t[V].G++;t[V].Pts+=3;t[L].P++;}
    else{t[L].E++;t[L].Pts++;t[V].E++;t[V].Pts++;}
  });
  return _CL_CACHE;
}

// Invalida el motor de stats Y el cache de años de nacimiento.
// Usar siempre esta función en lugar de asignar _C=null directamente.
function _invalidarMotor(){
  _C = null;
  _ANIO_CACHE = null;
  _CL_CACHE = null;
  _entNormCache = null;       // reset entrenadores auto-merge cache
  _personAliasesCache = null; // reset alias cache (por si acaso)
  _personNamesCache = null;
  _clubesData = null;         // reset caché de clubes (descargas)
  _catsData   = null;         // reset caché de categorías (descargas)
  _clubCanonCache = null;     // reset caché de nombres canónicos
}

function GS() {
  if (_C) return _C;
  _resolverHomonimos();
  const cl={}, gols={}, jug={}, pjEq={}, port={}, portCount={}, portMins={}, enf=[], ents={}, arbs={};
  
  // Deduplicar ACTAS por acta_id para evitar contar la misma acta múltiples veces
  const actasVistas = new Set();
  const ACTAS_UNIQ = ACTAS.filter(a => {
    if (actasVistas.has(a.acta_id)) return false;
    actasVistas.add(a.acta_id);
    return true;
  });
  
  ACTAS_UNIQ.forEach(a => {
    if (!a.equipo_local || !a.equipo_visitante) return;
    if (isSala(a.categoria)) return; // filtrar fútbol sala
    const cat = a.categoria||'Sin cat', L = a.equipo_local, V = a.equipo_visitante;
    const gl = a.goles_local||0, gv = a.goles_visitante||0;
    const temp = a.temporada||'';
    if (!cl[cat]) cl[cat] = {};
    [L,V].forEach(e => { if(!cl[cat][e]) cl[cat][e]={PJ:0,G:0,E:0,P:0,GF:0,GC:0,Pts:0,form:[]}; });
    cl[cat][L].PJ++; cl[cat][V].PJ++;
    cl[cat][L].GF+=gl; cl[cat][L].GC+=gv;
    cl[cat][V].GF+=gv; cl[cat][V].GC+=gl;
    if(gl>gv){cl[cat][L].G++;cl[cat][L].Pts+=3;cl[cat][L].form.push('W');cl[cat][V].P++;cl[cat][V].form.push('L');}
    else if(gl<gv){cl[cat][V].G++;cl[cat][V].Pts+=3;cl[cat][V].form.push('W');cl[cat][L].P++;cl[cat][L].form.push('L');}
    else{[L,V].forEach(e=>{cl[cat][e].E++;cl[cat][e].Pts++;cl[cat][e].form.push('D');});}
    pjEq[L]=(pjEq[L]||0)+1; pjEq[V]=(pjEq[V]||0)+1;
    if(!gols[cat]) gols[cat]={};
    (a.goleadores||[]).forEach(g=>{
      if(g.propia) return;  // No contar goles en propia puerta
      const gn = normPerson(_rn(a.acta_id, g.jugador));  // nombre unificado del goleador
      let eqGols='?';
      if((a.jugadores_local||[]).includes(g.jugador)) eqGols=L;
      else if((a.jugadores_visitante||[]).includes(g.jugador)) eqGols=V;
      if(eqGols==='?') return;  // Goleador no identificado en ningún equipo del acta → ignorar
      if(!gols[cat][gn]) gols[cat][gn]={goles:0,equipo:eqGols};
      gols[cat][gn].goles++;
      gols[cat][gn].equipo=eqGols;
    });
    // Portero: usar portero_local/visitante si existe, si no el primero de titulares
    const pLOrig = a.portero_local || (a.titulares_local||[])[0];
    const pVOrig = a.portero_visitante || (a.titulares_visitante||[])[0];
    const pL = pLOrig ? normPerson(_rn(a.acta_id, pLOrig)) : null;
    const pV = pVOrig ? normPerson(_rn(a.acta_id, pVOrig)) : null;
    if(pL){if(!port[pL])port[pL]={nombre:pL,equipo:L,GC:0,PJ:0};port[pL].GC+=gv;port[pL].PJ++;}
    if(pV){if(!port[pV])port[pV]={nombre:pV,equipo:V,GC:0,PJ:0};port[pV].GC+=gl;port[pV].PJ++;}
    // Acumular veces portero por jugador (para el icono 🧤) y minutos como portero
    if(pL){if(!portCount[pL])portCount[pL]=0;portCount[pL]++;
      if(!portMins[pL])portMins[pL]=0;
      // Minutos como portero: si fue sustituido, hasta su minuto de salida; si entró, desde su minuto de entrada
      const sustL=a.sustituciones_local||[];
      const salL=sustL.find(sx=>sx.sale===pLOrig);
      const entL=sustL.find(sx=>sx.entra===pLOrig);
      const minInL=entL?entL.min:0; const minOutL=salL?salL.min:90;
      portMins[pL]+=(minOutL-minInL);
    }
    if(pV){if(!portCount[pV])portCount[pV]=0;portCount[pV]++;
      if(!portMins[pV])portMins[pV]=0;
      const sustV=a.sustituciones_visitante||[];
      const salV=sustV.find(sx=>sx.sale===pVOrig);
      const entV=sustV.find(sx=>sx.entra===pVOrig);
      const minInV=entV?entV.min:0; const minOutV=salV?salV.min:90;
      portMins[pV]+=(minOutV-minInV);
    }
    const addJ=(jugs,tits,sust,eq,golesAFavor,golesEnContra)=>{
      const fechaActa = a.fecha||'';
      const tempActa  = a.temporada||'';
      (jugs||[]).forEach(nOrig=>{
        const nHom = _rn(a.acta_id, nOrig);  // nombre resuelto de homónimos
        const n = normPerson(nHom);            // nombre unificado por merge manual
        if(!jug[n]) jug[n]={equipo:eq,cat,PJ:0,tit:0,mins:0,goles:0,gfCon:0,gcCon:0,nojug:0,nombreOrig:_nombreOrig(n),equipos:new Set(),fuentes:new Set(),_ultimaFecha:'',_ultimaTemp:'',_ultimoEquipo:eq};
        jug[n].PJ++; if((tits||[]).includes(nOrig)) jug[n].tit++;
        jug[n].mins+=(a.minutos_jugadores||{})[nOrig]||0;
        jug[n].goles+=(a.goleadores||[]).filter(g=>g.jugador===nOrig&&!g.propia).length;
        // Calcular GF/GC en campo: solo los goles que ocurrieron mientras el jugador estaba en el campo
        let minIn=0,minOut=90;
        if((tits||[]).includes(nOrig)){
          const sal=(sust||[]).find(sx=>sx.sale===nOrig);
          if(sal) minOut=sal.min;
        } else {
          const ent=(sust||[]).find(sx=>sx.entra===nOrig);
          if(ent) minIn=ent.min;
        }
        const gcEnCampo=(golesEnContra||[]).filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
        const gfEnCampo=(golesAFavor||[]).filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
        jug[n].gfCon=(jug[n].gfCon||0)+gfEnCampo;
        jug[n].gcCon=(jug[n].gcCon||0)+gcEnCampo;
        if(!jug[n].equipo) jug[n].equipo=eq;
        jug[n].equipos.add(eq);
        if(a.fuente) jug[n].fuentes.add(a.fuente);
        // Actualizar equipo más reciente (usando temporada como clave primaria, fecha como secundaria)
        const tempIniJ = _tempInicio(tempActa) ?? -1;
        const ultimaTempIniJ = _tempInicio(jug[n]._ultimaTemp) ?? -1;
        const esMasReciente = tempIniJ > ultimaTempIniJ ||
          (tempIniJ === ultimaTempIniJ && _fechaOrd(fechaActa) >= _fechaOrd(jug[n]._ultimaFecha));
        if(esMasReciente){
          jug[n]._ultimaTemp   = tempActa;
          jug[n]._ultimaFecha  = fechaActa;
          jug[n]._ultimoEquipo = eq;
        }
      });
    };
    const golesLocal=(a.goleadores||[]).filter(g=>g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador)));
    const golesVisitante=(a.goleadores||[]).filter(g=>g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador)));
    addJ(a.jugadores_local,a.titulares_local,a.sustituciones_local,L,golesLocal,golesVisitante);
    addJ(a.jugadores_visitante,a.titulares_visitante,a.sustituciones_visitante,V,golesVisitante,golesLocal);
    // Convocados que fueron al banquillo pero no llegaron a jugar ni un minuto
    const addNoJug=(lista,eq)=>{
      (lista||[]).forEach(nOrig=>{
        const nHom=_rn(a.acta_id,nOrig);
        const n=normPerson(nHom);
        if(!jug[n]) jug[n]={equipo:eq,cat,PJ:0,tit:0,mins:0,goles:0,gfCon:0,gcCon:0,nojug:0,nombreOrig:_nombreOrig(n),equipos:new Set(),fuentes:new Set(),_ultimaFecha:'',_ultimaTemp:'',_ultimoEquipo:eq};
        jug[n].nojug=(jug[n].nojug||0)+1;
        jug[n].equipos.add(eq);
      });
    };
    addNoJug(a.convocados_sin_jugar_local,L);
    addNoJug(a.convocados_sin_jugar_visitante,V);
    enf.push({L,V,gl,gv,cat,jornada:a.jornada,fecha:a.fecha,id:a.acta_id});

    // ── Entrenadores ──
    const addEnt=(nombre,eq,esLocal)=>{
      if(!nombre||!eq)return;
      const k=normPerson(normEnt(nombre));
      if(!ents[k]) ents[k]={nombre:k,equipos:{},cat:'',equipoActual:'',_ultimaTemp:'',_ultimaFecha:'',PJ:0,V:0,E:0,D:0,Pts:0,GF:0,GC:0,temporadas:{},partidos:[]};
      // Actualizar categoría y equipo: usar los del partido más reciente (temporada, luego fecha)
      const fechaActaEnt=a.fecha||'';
      const tempIniEnt = _tempInicio(temp) ?? -1;
      const ultimaTempIniEnt = _tempInicio(ents[k]._ultimaTemp) ?? -1;
      const esMasRecienteEnt = tempIniEnt > ultimaTempIniEnt ||
        (tempIniEnt === ultimaTempIniEnt && _fechaOrd(fechaActaEnt) >= _fechaOrd(ents[k]._ultimaFecha));
      if(esMasRecienteEnt){
        ents[k].cat = cat;
        ents[k].equipoActual = eq;
        ents[k]._ultimaTemp = temp;
        ents[k]._ultimaFecha = fechaActaEnt;
      }
      const g1=esLocal?gl:gv, g2=esLocal?gv:gl;
      ents[k].PJ++; ents[k].GF+=g1; ents[k].GC+=g2;
      if(g1>g2){ents[k].V++;ents[k].Pts+=3;}
      else if(g1<g2){ents[k].D++;}
      else{ents[k].E++;ents[k].Pts++;}
      ents[k].equipos[eq]=(ents[k].equipos[eq]||0)+1;
      if(temp){
        if(!ents[k].temporadas[temp]) ents[k].temporadas[temp]={equipo:eq,cat,PJ:0,V:0,E:0,D:0,Pts:0,GF:0,GC:0};
        const ts=ents[k].temporadas[temp];
        ts.PJ++;ts.GF+=g1;ts.GC+=g2;
        if(g1>g2){ts.V++;ts.Pts+=3;}else if(g1<g2){ts.D++;}else{ts.E++;ts.Pts++;}
      }
      ents[k].partidos.push({id:a.acta_id,jornada:a.jornada,fecha:a.fecha,eq,rival:esLocal?V:L,g1,g2,cat,temp});
    };
    addEnt(a.entrenador_local,L,true);
    addEnt(a.entrenador_visitante,V,false);

    // ── Árbitros ──
    (a.arbitros||[]).concat(a.arbitro?[a.arbitro]:[]).filter(Boolean).forEach(arb=>{
      if(!arbs[arb]) arbs[arb]={nombre:arb,PJ:0,goles:0,
        amarillas:0,rojas:0,rojas_directas:0,
        am_jug:0,am_banq:0,ro_jug:0,ro_banq:0,
        cats:{},temporadas:{},partidos:[]};
      const tarj=a.tarjetas||[];
      const esBanq=t=>(t.destinatario==='entrenador'||t.destinatario==='staff');
      // amarillas: simples + 2×doble_amarilla
      const am     = tarj.filter(t=>t.tipo==='amarilla').length + tarj.filter(t=>t.tipo==='doble_amarilla').length*2;
      const am_jug = tarj.filter(t=>t.tipo==='amarilla'&&!esBanq(t)).length + tarj.filter(t=>t.tipo==='doble_amarilla'&&!esBanq(t)).length*2;
      const am_banq= tarj.filter(t=>t.tipo==='amarilla'&&esBanq(t)).length  + tarj.filter(t=>t.tipo==='doble_amarilla'&&esBanq(t)).length*2;
      // rojas: directas + doble_amarilla
      const ro      = tarj.filter(t=>t.tipo==='roja'||t.tipo==='doble_amarilla').length;
      const ro_dir  = tarj.filter(t=>t.tipo==='roja').length;
      const ro_jug  = tarj.filter(t=>(t.tipo==='roja'||t.tipo==='doble_amarilla')&&!esBanq(t)).length;
      const ro_banq = tarj.filter(t=>(t.tipo==='roja'||t.tipo==='doble_amarilla')&&esBanq(t)).length;
      arbs[arb].PJ++;
      arbs[arb].goles+=gl+gv;
      arbs[arb].amarillas+=am; arbs[arb].rojas+=ro; arbs[arb].rojas_directas+=ro_dir;
      arbs[arb].am_jug+=am_jug; arbs[arb].am_banq+=am_banq;
      arbs[arb].ro_jug+=ro_jug; arbs[arb].ro_banq+=ro_banq;
      arbs[arb].cats[cat]=(arbs[arb].cats[cat]||0)+1;
      if(temp){
        if(!arbs[arb].temporadas[temp]) arbs[arb].temporadas[temp]={PJ:0,goles:0,amarillas:0,rojas:0,rojas_directas:0,am_jug:0,am_banq:0,ro_jug:0,ro_banq:0};
        const ts=arbs[arb].temporadas[temp];
        ts.PJ++;ts.goles+=gl+gv;ts.amarillas+=am;ts.rojas+=ro;ts.rojas_directas+=ro_dir;
        ts.am_jug+=am_jug;ts.am_banq+=am_banq;ts.ro_jug+=ro_jug;ts.ro_banq+=ro_banq;
      }
      arbs[arb].partidos.push({id:a.acta_id,jornada:a.jornada,fecha:a.fecha,L,V,gl,gv,cat});
    });
  });
  Object.entries(jug).forEach(([n,s])=>{
    // Usar el equipo más reciente como equipo principal (para filtros sin temporada)
    if(s._ultimoEquipo) s.equipo = s._ultimoEquipo;
    delete s._ultimoEquipo; delete s._ultimaFecha; delete s._ultimaTemp;
    // pjEq = convocatorias totales conocidas (partidos jugados + convocado sin jugar).
    // No usar el PJ del equipo en bruto: mezclar etapas/temporadas distintas con un
    // único equipo "actual" puede dar pjEq < PJ y disparar presencias >100%.
    s.nojug=s.nojug||0;
    s.pjEq=s.PJ+s.nojug;
    s.pres=s.pjEq>0?Math.min(100,Math.round(s.PJ/s.pjEq*100)):0;
    s.gfMedia=s.PJ>0?((s.gfCon||0)/s.PJ):0;
    s.gcMedia=s.PJ>0?((s.gcCon||0)/s.PJ):0;
    s.portPJ=portCount[n]||0;
    s.portMins=portMins[n]||0;
  });
  _C={cl,gols,jug,port,portCount,portMins,enf,pjEq,ents,arbs};
  return _C;
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
const SALA_KEYWORDS = ['sala','futsal','futsala','femenina','femenino','femeninas','femeninos'];
function isSala(cat){
  if(!cat) return false;
  const n = cat.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  if(SALA_KEYWORDS.some(k=>n.includes(k))) return true;
  // Detectar " FS" / "(FS)" / "FS " / "-FS" como abreviatura de futbol sala
  if(/\bfs\b/.test(n)) return true;
  return false;
}
const cats=()=>sortCats([...new Set(ACTAS.map(a=>a.categoria).filter(Boolean))].filter(c=>!isSala(c)));
const temps=()=>[...new Set(ACTAS.map(a=>a.temporada).filter(Boolean))].sort((a,b)=>b.localeCompare(a));
const eqs=()=>[...new Set(ACTAS.filter(a=>!isSala(a.categoria)).flatMap(a=>[a.equipo_local,a.equipo_visitante].filter(Boolean)))].sort();
const jornadas=()=>[...new Set(ACTAS.filter(a=>!isSala(a.categoria)).map(a=>a.jornada).filter(j=>j!=null))].sort((a,b)=>a-b);
const eqByCat=cat=>[...new Set(ACTAS.filter(a=>!isSala(a.categoria)&&(!cat||a.categoria===cat)).flatMap(a=>[a.equipo_local,a.equipo_visitante].filter(Boolean)))].sort();

// ── jugadorPassProv: true si el jugador ha jugado alguna vez en un club de esa provincia
// s = entrada de jug{} (tiene s.equipos:Set o s.equipo:string si viene de path de temporada)
function jugadorPassProv(s, filtProv){
  if(!filtProv) return true;
  // Path GS(): tiene s.equipos (Set con todos los clubes históricos)
  const eqSet = s.equipos instanceof Set ? s.equipos : (s.equipos ? new Set(s.equipos) : new Set([s.equipo].filter(Boolean)));
  return [...eqSet].some(eq => getProvincia(getClubCanon(eq)) === filtProv);
}

function fill(id,opts,ph){
  const el=document.getElementById(id);if(!el)return;
  const cur=el.value;
  el.innerHTML=`<option value="">${ph}</option>`+opts.map(o=>`<option value="${o}">${catNombre(o)||o}</option>`).join('');
  if(cur&&opts.includes(cur))el.value=cur;
}
function fillRaw(id,opts,ph){
  // fill sin catNombre (para listas no-categoría)
  const el=document.getElementById(id);if(!el)return;
  const cur=el.value;
  el.innerHTML=`<option value="">${ph}</option>`+opts.map(o=>`<option value="${o}">${o}</option>`).join('');
  if(cur&&opts.includes(cur))el.value=cur;
}
function updSels(){
  const C=cats(),E=eqs(),J=jornadas(),T=temps();
  // Para los selectores de categoría, respetar el filtro de grupo activo
  ['cl','pa','go','ju','eq','sc','ent','arb'].forEach(prefix=>{
    const grupoEl = document.getElementById(prefix+'-grupo');
    const grupo = grupoEl?.value||'';
    const catEl = document.getElementById(prefix+'-cat');
    if(!catEl) return;
    const filtradas = grupo ? C.filter(c=>getCatGrupo(c)===grupo) : C;
    const cur = catEl.value;
    catEl.innerHTML = `<option value="">Todas las categorías</option>` +
      filtradas.map(c=>`<option value="${c}"${c===cur?' selected':''}>${catNombre(c)}</option>`).join('');
    if(cur && !filtradas.includes(cur)) catEl.value = '';
  });
  ['cl-temp','ju-temp','go-temp','ent-temp','arb-temp','eq-temp'].forEach(id=>fillRaw(id,T,'Todas las temporadas'));
  ['pa-eq','go-eq','ju-eq','h2-a','h2-b','sc-eq'].forEach(id=>fillRaw(id,E,'Todos los equipos'));
  fillRaw('pa-jor',J,'Todas las jornadas');
}
function c2(gl,gv){return gl>gv?'hw':gl<gv?'aw':'dr';}

// Devuelve true si el jugador actuó más veces como portero que como jugador de campo
function isPort(nombre){
  const {jug}=GS();
  const s=jug[nombre];
  if(!s)return false;
  // Criterio 1: ≥300 minutos como portero
  if((s.portMins||0)>=300) return true;
  // Criterio 2: ≥4 partidos de portero y supone ≥50% de sus partidos totales
  if((s.portPJ||0)>=4 && s.portPJ>=(s.PJ/2)) return true;
  return false;
}
function portTag(nombre){return isPort(nombre)?'<span style="font-size:13px;margin-left:4px" title="Portero">🧤</span>':'';}

// Auto-asigna POR a todos los jugadores con ≥300 minutos como portero
// Solo toca jugadores que aún NO tienen posición asignada
function autoAsignarPorteros(){
  const {jug}=GS();
  let asignados=0;
  Object.keys(jug).forEach(nombre=>{
    const s=jug[nombre];
    if(!s) return;
    // Criterio 1: ≥300 minutos acumulados como portero (dato preciso)
    const porMins=(s.portMins||0)>=300;
    // Criterio 2: ≥4 partidos jugados como portero (≈300 min si juegan partidos completos)
    // Como portero debe suponer al menos la mitad de sus partidos totales
    const porPJ=(s.portPJ||0)>=4 && (s.portPJ||0)>=(s.PJ/2);
    if((porMins||porPJ) && !getPosicion(nombre)){
      setPosicion(nombre,'POR');
      asignados++;
    }
  });
  return asignados;
}

// ── CLASIFICACION ─────────────────────────────────────────────────────────────
function _updateClFilters(){
  // Actualiza las opciones de cl-cat y cl-temp dinámicamente según los otros filtros activos
  const cat   = document.getElementById('cl-cat')?.value||'';
  const temp  = document.getElementById('cl-temp')?.value||'';
  const grupo = document.getElementById('cl-grupo')?.value||'';
  const prov  = document.getElementById('cl-prov')?.value||'';

  // Actas base: sin sala, con ambos equipos
  const base = ACTAS.filter(a=>!isSala(a.categoria)&&a.equipo_local&&a.equipo_visitante);

  // ── Actualizar opciones de cl-cat ──
  // Mostrar categorías presentes en las actas que coincidan con temp+grupo+prov actuales
  const catEl = document.getElementById('cl-cat');
  if(catEl){
    const catsDisp = [...new Set(
      base
        .filter(a=>(!temp||a.temporada===temp)&&(!grupo||getCatGrupo(a.categoria)===grupo))
        .filter(a=>!prov||(()=>{const cp=getCatProvincia(a.categoria);return cp==='Vasca'?prov!=='Nacional':(cp==='Nacional'?prov==='Nacional':cp===prov);})())
        .map(a=>a.categoria).filter(Boolean)
    )].sort();
    const curCat = catEl.value;
    catEl.innerHTML = `<option value="">Todas las categorías</option>` +
      catsDisp.map(c=>`<option value="${c}"${c===curCat?' selected':''}>${catNombre(c)}</option>`).join('');
    if(curCat && !catsDisp.includes(curCat)) catEl.value = '';
  }

  // ── Actualizar opciones de cl-temp ──
  // Mostrar temporadas presentes en las actas que coincidan con cat+grupo+prov actuales
  const tempEl = document.getElementById('cl-temp');
  if(tempEl){
    const catActual = catEl?.value||'';
    const tempsDisp = [...new Set(
      base
        .filter(a=>(!catActual||a.categoria===catActual)&&(!grupo||getCatGrupo(a.categoria)===grupo))
        .filter(a=>!prov||(()=>{const cp=getCatProvincia(a.categoria);return cp==='Vasca'?prov!=='Nacional':(cp==='Nacional'?prov==='Nacional':cp===prov);})())
        .map(a=>a.temporada).filter(Boolean)
    )].sort((a,b)=>b.localeCompare(a));
    const curTemp = tempEl.value;
    tempEl.innerHTML = `<option value="">Todas las temporadas</option>` +
      tempsDisp.map(t=>`<option value="${t}"${t===curTemp?' selected':''}>${t}</option>`).join('');
    if(curTemp && !tempsDisp.includes(curTemp)) tempEl.value = '';
  }
}

function rCl(){
  _updateClFilters();
  const cat=document.getElementById('cl-cat').value;
  const temp=document.getElementById('cl-temp')?.value||'';
  const srch=document.getElementById('cl-s').value.toLowerCase();
  const filtProv=document.getElementById('cl-prov')?.value||'';
  // Recalcular clasificación filtrada por temporada (no usar GS() cacheado)
  const actasFilt=ACTAS.filter(a=>
    !isSala(a.categoria)&&
    (!cat||a.categoria===cat)&&
    (!temp||a.temporada===temp)
  );
  const cl={};
  actasFilt.forEach(a=>{
    if(!a.equipo_local||!a.equipo_visitante)return;
    const c=a.categoria||'Sin cat',L=a.equipo_local,V=a.equipo_visitante;
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    if(!cl[c])cl[c]={};
    [L,V].forEach(e=>{if(!cl[c][e])cl[c][e]={PJ:0,G:0,E:0,P:0,GF:0,GC:0,Pts:0,form:[]};});
    cl[c][L].PJ++;cl[c][V].PJ++;
    cl[c][L].GF+=gl;cl[c][L].GC+=gv;
    cl[c][V].GF+=gv;cl[c][V].GC+=gl;
    if(gl>gv){cl[c][L].G++;cl[c][L].Pts+=3;cl[c][L].form.push('W');cl[c][V].P++;cl[c][V].form.push('L');}
    else if(gl<gv){cl[c][V].G++;cl[c][V].Pts+=3;cl[c][V].form.push('W');cl[c][L].P++;cl[c][L].form.push('L');}
    else{[L,V].forEach(e=>{cl[c][e].E++;cl[c][e].Pts++;cl[c][e].form.push('D');});}
  });
  let shown=cat?[cat]:sortCats(Object.keys(cl).filter(c=>!isSala(c)));
  const grupoFilt = document.getElementById('cl-grupo')?.value||'';
  shown = grupoFilt ? shown.filter(c=>getCatGrupo(c)===grupoFilt) : shown;
  // Filtro provincia: mostrar solo ligas cuya provincia de categoría coincide
  // "Vasca" aparece con cualquier filtro provincial vasco (es de todas las provincias vascas)
  // "Nacional" NO aparece al filtrar por provincia vasca (es una liga independiente)
  if(filtProv){
    shown = shown.filter(c=>{
      const cp = getCatProvincia(c);
      if(!cp) return false;                         // sin provincia asignada → no aparece
      if(cp === 'Nacional') return filtProv === 'Nacional'; // Nacional solo con filtro Nacional
      if(cp === 'Vasca') return filtProv !== 'Nacional';    // Vasca aparece con filtros vascos
      return cp === filtProv;
    });
  }
  let h='';
  // Si no hay filtro de temporada, agrupar por año
  if(!temp){
    const byYear={};
    actasFilt.forEach(a=>{
      if(a.temporada){const y=a.temporada;if(!byYear[y])byYear[y]=true;}
    });
    const years=Object.keys(byYear).sort((a,b)=>b.localeCompare(a));
    if(years.length>1){
      h+='<div style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">';
      h+='<span style="font-size:12px;color:var(--mu)">Ver por temporada:</span>';
      years.forEach(y=>{
        h+=`<button onclick="document.getElementById('cl-temp').value='${y}';rCl()" style="background:var(--s2);border:1px solid var(--b);color:var(--a3);font-size:11px;font-family:'JetBrains Mono',monospace;border-radius:6px;padding:3px 10px;cursor:pointer">${y}</button>`;
      });
      h+='</div>';
    }
  } else {
    h+=`<div style="margin-bottom:12px;font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--a3)">Temporada: <b>${temp}</b> <button onclick="document.getElementById('cl-temp').value='';rCl()" style="background:none;border:1px solid rgba(255,255,255,.15);color:var(--mu);font-size:10px;border-radius:5px;padding:2px 7px;cursor:pointer;margin-left:6px">✕ Todas</button></div>`;
  }
  shown.forEach(c=>{
    let rows=Object.entries(cl[c]||{})
      .filter(([eq])=>{
        if(srch && !eq.toLowerCase().includes(srch)) return false;
        // Si hay filtro provincia: mantener todas las filas (ya filtramos la tabla entera arriba)
        // pero resaltar los equipos de la provincia elegida si se quiere ver la tabla completa
        return true;
      })
      .sort((a,b)=>b[1].Pts-a[1].Pts||(b[1].GF-b[1].GC)-(a[1].GF-a[1].GC)||b[1].GF-a[1].GF);
    if(!rows.length)return;

    // ── Calcular zonas de ascenso/descenso según la categoría ─────────
    // Devuelve un array del mismo tamaño que rows con el tipo de zona de cada posición:
    // 'camp' (campeón/liga), 'asc' (ascenso directo), 'prom' (promoción), 'desc' (descenso), 'desc2' (descenso extra), '' (sin zona)
    // También devuelve el texto descriptivo del badge para cada zona.
    const zonaInfo = _calcZonas(c, rows, cl);

    const g = getCatGrupo(c);
    const prov = getCatProvincia(c);
    const GBADGE = {SENIOR:'rgba(0,240,160,.18)',JUVENIL:'rgba(77,139,255,.18)',CADETE:'rgba(176,111,255,.18)'};
    const GCOL   = {SENIOR:'var(--hw)',JUVENIL:'var(--a4)',CADETE:'var(--a5)'};
    const GICON  = {SENIOR:'👤',JUVENIL:'⚽',CADETE:'🎓'};
    const grupoBadge = g ? `<span style="font-size:10px;font-weight:700;color:${GCOL[g]};background:${GBADGE[g]};border:1px solid ${GCOL[g]}55;border-radius:4px;padding:1px 7px;margin-left:8px">${GICON[g]} ${g}</span>` : '';

    // ── Badge temporada ─────────────────────────────────────────────
    // Si hay filtro global de temp, ya se muestra abajo. Sin filtro, calcular las de esta cat.
    const tempsEsta = temp ? [] : [...new Set(actasFilt.filter(a=>a.categoria===c&&a.temporada).map(a=>a.temporada))].sort((a,b)=>b.localeCompare(a));
    const tempBadge = temp
      ? `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:700;color:var(--a3);background:rgba(245,200,66,.13);border:1px solid rgba(245,200,66,.35);border-radius:4px;padding:1px 8px;margin-left:8px">📅 ${temp}</span>`
      : tempsEsta.length
        ? tempsEsta.map(t=>`<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;color:var(--a3);background:rgba(245,200,66,.1);border:1px solid rgba(245,200,66,.25);border-radius:4px;padding:1px 7px;margin-left:4px;cursor:pointer" onclick="document.getElementById('cl-temp').value='${t}';rCl()" title="Filtrar por ${t}">📅 ${t}</span>`).join('')
        : '';

    // ── Badge provincia / comunidad ──────────────────────────────────
    // SVG escudos minimalistas inline
    const _SVG_ALAVA = `<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L13 4V9C13 12.5 7 15 7 15C7 15 1 12.5 1 9V4L7 1Z" fill="rgba(0,240,160,.25)" stroke="var(--hw)" stroke-width="1.2"/><path d="M4 8L6.5 10.5L10 6.5" stroke="var(--hw)" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
    const _SVG_GIPUZKOA = `<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L13 4V9C13 12.5 7 15 7 15C7 15 1 12.5 1 9V4L7 1Z" fill="rgba(176,111,255,.22)" stroke="var(--a5)" stroke-width="1.2"/><rect x="4" y="5.5" width="6" height="1.2" rx="0.6" fill="var(--a5)"/><rect x="4" y="8" width="6" height="1.2" rx="0.6" fill="var(--a5)"/><rect x="4" y="10.5" width="4" height="1.2" rx="0.6" fill="var(--a5)"/></svg>`;
    const _SVG_BIZKAIA  = `<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L13 4V9C13 12.5 7 15 7 15C7 15 1 12.5 1 9V4L7 1Z" fill="rgba(77,139,255,.2)" stroke="var(--a4)" stroke-width="1.2"/><path d="M4 8H10M7 5V11" stroke="var(--a4)" stroke-width="1.5" stroke-linecap="round"/></svg>`;
    const _SVG_EUSKADI  = `<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L13 4V9C13 12.5 7 15 7 15C7 15 1 12.5 1 9V4L7 1Z" fill="rgba(245,200,66,.15)" stroke="var(--a3)" stroke-width="1.2"/><path d="M1.5 5.5H12.5M1.5 10.5H12.5M7 1.5V14.5" stroke="var(--a3)" stroke-width="1.1" stroke-linecap="round" opacity="0.7"/></svg>`;
    const _SVG_NACIONAL = `<svg width="14" height="16" viewBox="0 0 14 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7 1L13 4V9C13 12.5 7 15 7 15C7 15 1 12.5 1 9V4L7 1Z" fill="rgba(255,64,64,.18)" stroke="#ff4040" stroke-width="1.2"/><circle cx="7" cy="8" r="2.5" stroke="#ff4040" stroke-width="1.2" fill="none"/><path d="M7 5.5V8L8.5 9.5" stroke="#ff4040" stroke-width="1.1" stroke-linecap="round"/></svg>`;
    const PROV_SVG   = {'Álava':_SVG_ALAVA,'Gipuzkoa':_SVG_GIPUZKOA,'Bizkaia':_SVG_BIZKAIA,'Vasca':_SVG_EUSKADI,'Nacional':_SVG_NACIONAL};
    const PROV_COL   = {'Álava':'var(--hw)','Gipuzkoa':'var(--a5)','Bizkaia':'var(--a4)','Vasca':'var(--a3)','Nacional':'#ff4040'};
    const PROV_BG2   = {'Álava':'rgba(0,240,160,.1)','Gipuzkoa':'rgba(176,111,255,.1)','Bizkaia':'rgba(77,139,255,.1)','Vasca':'rgba(245,200,66,.1)','Nacional':'rgba(255,64,64,.1)'};
    const PROV_BD2   = {'Álava':'rgba(0,240,160,.3)','Gipuzkoa':'rgba(176,111,255,.3)','Bizkaia':'rgba(77,139,255,.3)','Vasca':'rgba(245,200,66,.3)','Nacional':'rgba(255,64,64,.3)'};
    const provBadge = prov ? `<span style="display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:700;color:${PROV_COL[prov]};background:${PROV_BG2[prov]};border:1px solid ${PROV_BD2[prov]};border-radius:4px;padding:1px 8px 1px 5px;margin-left:8px">${PROV_SVG[prov]||''}${prov}</span>` : '';

    // ── Botón de calendario ─────────────────────────────────────
    const btnCalendario = `<button onclick="abrirCalendario('${c.replace(/'/g,"\\'")}','${temp}')" class="cal-btn" title="Ver calendario, partidos faltantes y cambiar jornada">📅 Calendario</button>`;

    // ── Tick de liga revisada ─────────────────────────────────────
    const ligaOk = _ligaRevisada(c, temp || (tempsEsta.length === 1 ? tempsEsta[0] : ''));
    const ligaTick = ligaOk
      ? `<span title="Liga revisada — sin discrepancias ni partidos pendientes" style="display:inline-flex;align-items:center;gap:3px;font-size:10px;font-weight:700;color:var(--hw);background:rgba(0,240,160,.13);border:1px solid rgba(0,240,160,.35);border-radius:4px;padding:1px 8px;margin-left:8px">✓ Revisada</span>`
      : '';

    h+=`<div class="st">${getCatLogoNac(c)}${catNombre(c)}${grupoBadge}${provBadge}${tempBadge}${ligaTick}${btnCalendario}</div><div class="tw" style="margin-bottom:22px"><table id="cl-tbl-${c.replace(/\W/g,'_')}"><thead><tr>
      <th>#</th><th onclick="sortClTable(this,1,'${c.replace(/'/g,"\\'")}')">Equipo ↕</th>
      <th onclick="sortClTable(this,2,'${c.replace(/'/g,"\\'")}')">PJ ↕</th>
      <th onclick="sortClTable(this,3,'${c.replace(/'/g,"\\'")}')">G ↕</th>
      <th onclick="sortClTable(this,4,'${c.replace(/'/g,"\\'")}')">E ↕</th>
      <th onclick="sortClTable(this,5,'${c.replace(/'/g,"\\'")}')">P ↕</th>
      <th onclick="sortClTable(this,6,'${c.replace(/'/g,"\\'")}')">GF ↕</th>
      <th onclick="sortClTable(this,7,'${c.replace(/'/g,"\\'")}')">GC ↕</th>
      <th onclick="sortClTable(this,8,'${c.replace(/'/g,"\\'")}')">DG ↕</th>
      <th onclick="sortClTable(this,9,'${c.replace(/'/g,"\\'")}')">Pts ↕</th>
      <th>Forma</th>
    </tr></thead><tbody>`;
    rows.forEach(([eq,s],idx)=>{
      const p=idx+1,dg=s.GF-s.GC;
      const zi = zonaInfo[idx];
      // clase de fila: usar zona si la hay, si no los podios clásicos
      const rc = zi.zona==='camp'?'zn-camp':zi.zona==='asc'?'zn-asc':zi.zona==='prom'?'zn-prom':zi.zona==='desc2'?'zn-desc2':zi.zona==='desc'?'zn-desc':(p===1?'p1':p===2?'p2':p===3?'p3':'');
      const forma=s.form.slice(-5).map(r=>`<span class="fd ${r}"></span>`).join('');
      const dgC=dg>0?'gdp':dg<0?'gdn':'';
      const badgeHtml = zi.badge ? `<span class="zona-badge ${zi.badgeCls}" title="${zi.title||''}">${zi.badge}</span>` : '';
      const nofil = zi.nofil ? `<span class="zona-badge zb-nofil" title="Filial bloqueada — su equipo A está en la liga superior">★ Filial</span>` : '';
      // Badge A/B/C nivel de filial en misma liga
      const canonEqCl = getClubCanon(eq);
      const hermanosCl = rows.filter(([e2])=>e2!==eq&&getClubCanon(e2)===canonEqCl);
      let nivelBadgeCl = '';
      if(hermanosCl.length>0){
        const NIVEL_COL2 = {A:'var(--acc)',B:'var(--a4)',C:'var(--a5)',D:'var(--a2)'};
        const nv = detectarNivelEquipo(eq, c, temp);
        if(nv.letra) nivelBadgeCl = `<span style="font-size:9px;font-weight:700;color:${NIVEL_COL2[nv.letra]||'var(--mu)'};background:rgba(255,255,255,.08);border:1px solid ${NIVEL_COL2[nv.letra]||'rgba(255,255,255,.2)'};border-radius:3px;padding:0 5px;margin-left:5px">${nv.letra}</span>`;
      }
      h+=`<tr class="${rc}" onclick="goTeam('${eq.replace(/'/g,"\\'")}','${c.replace(/'/g,"\\'")}','${temp}')" style="cursor:pointer">
        <td class="num">${p}</td><td style="font-weight:600">${eq}${badgeHtml}${nofil}</td>
        <td class="num">${s.PJ}</td><td class="num">${s.G}</td>
        <td class="num">${s.E}</td><td class="num">${s.P}</td>
        <td class="num" style="color:var(--hw);cursor:pointer;text-decoration:underline dotted" title="Ver goleadores de ${eq}" onclick="event.stopPropagation();showTeamScorers('${eq.replace(/'/g,"\\'")}','${c.replace(/'/g,"\\'")}','${temp}')">${s.GF}</td>
        <td class="num" style="color:var(--a2);cursor:pointer;text-decoration:underline dotted" title="Ver ratio GC por jugador de ${eq}" onclick="event.stopPropagation();showTeamGC('${eq.replace(/'/g,"\\'")}')">${s.GC}</td>
        <td class="num ${dgC}">${dg>0?'+':''}${dg}</td>
        <td class="pts">${s.Pts}</td><td>${forma}</td></tr>`;
    });
    h+='</tbody></table></div>';
  });
  document.getElementById('cl-c').innerHTML=h||'<div class="empty">Sin datos</div>';
}

// ── ZONAS ASCENSO/DESCENSO ────────────────────────────────────────────────────
// Normaliza el nombre de categoría para identificarla
function _normCat(c){
  return (c||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
}

// Detecta si una categoría existe en las actas (para determinar si Preferente existe)
function _catExists(keyword){
  return ACTAS.some(a=>a.categoria && _normCat(a.categoria).includes(keyword));
}

// Devuelve true si el equipo eqA (filial) tiene su equipo A en la liga superior catSup.
// eqA se detecta como filial si su nombre termina en " A" o " B" etc.
// El "A" correspondiente sería el mismo nombre sin ese sufijo, o con " A" → sin sufijo.
// Regla: equipo B no puede subir si su A está justo en la liga superior.
// Si ambos suben (eqA en posición de ascenso Y eqB en posición de ascenso) → sí pueden subir juntos.
function _filialBloqueada(eqB, posB, rows, catActual, catSup, cl){
  // ¿Es filial? nombre termina en " B", " C", " D" (o "- B" etc)
  const mFilial = eqB.match(/^(.+?)\s+([BCD])$/i);
  if(!mFilial) return false;
  const raiz = mFilial[1].trim();
  // Buscar el equipo A: nombre sin sufijo, o con " A"
  const candidatosA = [raiz, raiz+' A'];
  // ¿Está alguno en la liga superior?
  const equiposSup = catSup ? Object.keys((cl[catSup]||{})) : [];
  const eqA = candidatosA.find(c=>equiposSup.some(e=>e.toUpperCase()===c.toUpperCase()));
  if(!eqA) return false;
  // ¿Está el eqA en la liga superior (no bajando)?
  // Consideramos que si aparece en catSup es porque está ahí
  // Regla adicional: si eqA TAMBIÉN está en posición de descenso en catSup puede que bajen juntos → no bloquear
  // Para simplicidad: está bloqueado si eqA está en catSup
  return true;
}

// Calcula las zonas para una categoría dada.
// Devuelve array de {zona, badge, badgeCls, title, nofil} para cada posición.
function _calcZonas(cat, rows, cl){
  const n = rows.length;
  const nc = _normCat(cat);
  const result = rows.map(()=>({zona:'',badge:'',badgeCls:'',title:'',nofil:false}));
  if(n===0) return result;

  // ── Ayudante: marcar zona simple ─────────────────────────────────
  const mark = (idx, zona, badge, cls, title='')=>{
    if(idx<0||idx>=n) return;
    result[idx].zona=zona; result[idx].badge=badge;
    result[idx].badgeCls=cls; result[idx].title=title;
  };

  // ── JUVENIL VASCA (Liga Vasca Juvenil) ─────────────────────────────────
  // 1º gana la liga. Descienden 4 (uno por provincia) a Juvenil Honor de su provincia
  // No sube nadie (es la primera liga de juvenil)
  if(nc.includes('juvenil') && nc.includes('vasca')){
    mark(0,'camp','🏆 Liga','zb-asc','Campeón de Liga Vasca Juvenil');
    // Descenso: los últimos 4 (uno por provincia)
    const descStart = Math.max(1, n-4);
    for(let i=descStart;i<n;i++){
      const [eq] = rows[i];
      const prov = getProvincia(getClubCanon(eq))||'?';
      mark(i,'desc','↓ Honor '+prov,'zb-desc',`Desciende a Juvenil Honor ${prov}`);
    }
    return result;
  }

  // ── JUVENIL HONOR (Álava / provincial) ────────────────────────────
  // 1º sube a Juvenil Vasca (gana la liga)
  // 2º → promoción vs 2º Gipuzkoa y 2º Bizkaia para subir a Juvenil Vasca
  // 3º → sube a Juvenil Vasca (ascenso directo) - pero si 2º es filial B bloqueada, 2º promociona y 3º se queda
  // Descienden: 2 normales a Preferente Juvenil
  // ARRASTRE: si bajan 2+ de la misma provincia desde Juvenil Vasca, desciende 1 más
  // REGLA FILIAL A/B: Si baja el A, el B DESCIENDE AUTOMÁTICAMENTE aunque estuviese salvado
  //                   Si sube el B, no puede si su A está aquí en J.Honor
  if(nc.includes('juvenil') && (nc.includes('honor') || nc.includes('honour'))){
    // Categoría de destino descenso
    const hayPrefJuv = _catExists('preferente juvenil') || _catExists('preferente') && _catExists('juvenil');
    const catDesc = hayPrefJuv ? 'Preferente Juvenil' : 'Primera Juvenil';

    mark(0,'camp','↑ J.Vasca','zb-asc','Campeón — sube a Juvenil Vasca');

    // Contador de ascensos a Vasca: 1 (campeón) + 1 (promoción o directo) + 1 (directo si 2º no es filial)
    let ascensosVasca = 1;  // ya tenemos al campeón
    const catSup = Object.keys(cl).find(k=>_normCat(k).includes('juvenil')&&_normCat(k).includes('vasca'))||null;

    // 2º → promoción o directo según si es filial B bloqueada
    if(n>=2){
      const [eq2]=rows[1];
      const bloq2 = _filialBloqueada(eq2,1,rows,cat,catSup,cl);
      if(bloq2){
        // 2º es filial B bloqueada: va a promoción
        result[1].nofil=true;
        mark(1,'prom','⚑ Prom.','zb-prom','Promoción vs 2º Gipuzkoa y 2º Bizkaia (filial bloqueada)');
      } else {
        // 2º sube directo (no es filial o su A no está en Vasca)
        mark(1,'asc','↑ J.Vasca','zb-asc','Sube directo a Juvenil Vasca');
        ascensosVasca++;
      }
    }

    // 3º → intenta subir directo si aún cabe (máx 3 ascensos)
    if(n>=3 && ascensosVasca<3){
      const [eq3]=rows[2];
      const bloq3 = _filialBloqueada(eq3,2,rows,cat,catSup,cl);
      if(bloq3){
        // Filial B bloqueada
        result[2].nofil=true;
        mark(2,'asc','↑? Bloq.','zb-nofil','Filial bloqueada — su equipo A está en J.Honor');
      } else {
        // Sube directo
        mark(2,'asc','↑ J.Vasca','zb-asc','Ascenso directo a Juvenil Vasca');
        ascensosVasca++;
      }
    }

    // Descenso: últimos 2 normales
    // + ARRASTRE: si hay 2+ descensos desde J.Vasca de la misma provincia → desciende 1 más
    // REGLA A/B: si desciende un A, desciende también el B automáticamente
    const descensos = [];
    if(n>=2){
      descensos.push(n-1);
      mark(n-1,'desc','↓ '+catDesc,'zb-desc',`Desciende a ${catDesc}`);
      if(n>=3){
        descensos.push(n-2);
        mark(n-2,'desc','↓ '+catDesc,'zb-desc',`Desciende a ${catDesc}`);
      }
    }
    
    return result;
  }

  // ── PREFERENTE JUVENIL / PRIMERA JUVENIL ─────────────────────────
  // Sube 1º directo (gana la liga) a Juvenil Honor
  // Suben 2º, 3º (hasta 2 más) también a Juvenil Honor (máximo 3 ascensos)
  // REGLA FILIAL B: Si B quiere subir pero A está en J.Honor, B no sube → sube el siguiente
  if(nc.includes('primera juvenil') || (nc.includes('preferente') && nc.includes('juvenil'))){
    const catSup = Object.keys(cl).find(k=>{
      const nk=_normCat(k);
      return nk.includes('juvenil')&&nk.includes('honor')&&!nk.includes('vasca');
    })||null;

    mark(0,'camp','↑ J.Honor','zb-asc','Campeón — sube a Juvenil Honor');

    // Ascender 2 más (2º y 3º si caben y no son filiales bloqueadas)
    // Máximo 3 ascensos totales (1º + 2 más)
    let ascensos = 1;  // ya tenemos al campeón
    let intento = 1;
    
    while(intento < n && ascensos < 3){
      const [eq] = rows[intento];
      const bloq = _filialBloqueada(eq, intento, rows, cat, catSup||null, cl);
      
      if(!bloq){
        // Este SÍ sube
        mark(intento,'asc','↑ J.Honor','zb-asc','Sube a Juvenil Honor');
        ascensos++;
      } else {
        // Este NO sube por ser filial bloqueada - intentar siguiente
        result[intento].nofil=true;
        mark(intento,'asc','↑? Bloq.','zb-nofil','Filial bloqueada — su equipo A está en J.Honor');
      }
      
      intento++;
    }
    
    return result;
  }

  // ── DIVISIÓN DE HONOR (HJ - Histórica Juvenil) ───────────────────
  // Bajan 4 equipos a categorías inferiores
  // Suben 2 desde Campeonato de Liga Nacional
  if(nc.includes('division') && nc.includes('honor') && nc.includes('juvenil')){
    mark(0,'camp','🏆 Liga','zb-asc','Campeón de División de Honor');
    
    // Descenso: últimos 4 bajan a categorías inferiores
    const descStart = Math.max(1, n-4);
    for(let i=descStart;i<n;i++){
      mark(i,'desc','↓ Cat.Inf.','zb-desc','Desciende a categoría inferior');
    }
    return result;
  }

  // ── CAMPEONATO DE LIGA NACIONAL JUVENIL ──────────────────────────
  // Suben 2 equipos a División de Honor (se saltan filiales B)
  // Bajan 4 equipos
  if(nc.includes('campeonato') && nc.includes('liga') && nc.includes('nacional') && nc.includes('juvenil')){
    // Buscar los 2 primeros equipos que NO sean filiales B
    let ascendidos = 0;
    for(let i=0; i<n && ascendidos<2; i++){
      const [eq]=rows[i];
      // Detectar si es filial B: termina en " B" o "- B" etc
      const esFilialB = /\sB$/i.test(eq) || /-\s*B$/i.test(eq);
      
      if(!esFilialB){
        // Este sube a División de Honor
        if(ascendidos===0){
          mark(i,'camp','↑ Div.Honor','zb-asc','Campeón — sube a División de Honor');
        } else {
          mark(i,'asc','↑ Div.Honor','zb-asc','Sube a División de Honor');
        }
        ascendidos++;
      } else {
        // Es filial B → se marca pero no sube
        result[i].nofil=true;
        mark(i,'asc','↑? Bloq.','zb-nofil','Filial B bloqueada — su equipo A debe estar en otra categoría');
      }
    }
    
    // Descienden los últimos 4
    const descStart = Math.max(2, n-4);
    for(let i=descStart;i<n;i++){
      mark(i,'desc','↓ Cat.Inf.','zb-desc','Desciende a categoría inferior');
    }
    return result;
  }

  // ── CADETE VASCA ──────────────────────────────────────────────────
  // 1º gana la liga. No sube nadie (primera liga de cadete).
  // Descienden 4 a Cadete Honor de su provincia (uno por provincia).
  if(nc.includes('cadete') && nc.includes('vasca')){
    mark(0,'camp','🏆 Liga','zb-asc','Campeón de Cadete Vasca');
    const descStart = Math.max(1, n-4);
    for(let i=descStart;i<n;i++){
      const [eq]=rows[i];
      const prov=getProvincia(getClubCanon(eq))||'?';
      mark(i,'desc','↓ C.Honor '+prov,'zb-desc',`Desciende a Cadete Honor ${prov}`);
    }
    return result;
  }

  // ── CADETE HONOR (provincial) ─────────────────────────────────────
  // 1º sube a Cadete Vasca (gana la liga)
  // 2º → promoción vs 2º Bizkaia y 2º Gipuzkoa
  // Descienden 2 (+ arrastre si hay descenso de Cadete Vasca de esa provincia)
  // Regla filial
  if(nc.includes('cadete') && (nc.includes('honor') || nc.includes('honour'))){
    const catSup = Object.keys(cl).find(k=>_normCat(k).includes('cadete')&&_normCat(k).includes('vasca'))||null;

    mark(0,'camp','↑ C.Vasca','zb-asc','Campeón — sube a Cadete Vasca');

    if(n>=2){
      const [eq2]=rows[1];
      const bloq2=_filialBloqueada(eq2,1,rows,cat,catSup,cl);
      if(bloq2) result[1].nofil=true;
      mark(1,'prom','⚑ Prom.','zb-prom','Promoción de ascenso a Cadete Vasca vs 2º Bizkaia y 2º Gipuzkoa');
    }

    // Descenso: últimos 2
    if(n>=2){
      mark(n-1,'desc','↓ 1ª Cadete','zb-desc','Desciende a Primera Cadete');
      if(n>=3) mark(n-2,'desc','↓ 1ª Cadete','zb-desc','Desciende a Primera Cadete');
    }
    return result;
  }

  // ── PRIMERA CADETE / CADETE A / CADETE B ─────────────────────────
  // Sube 1 a Cadete Honor
  if(nc.includes('cadete') && !nc.includes('vasca') && !nc.includes('honor')){
    const catSup=Object.keys(cl).find(k=>{const nk=_normCat(k);return nk.includes('cadete')&&nk.includes('honor');});
    mark(0,'camp','↑ C.Honor','zb-asc','Campeón — sube a Cadete Honor');
    if(n>=2){
      const [eq2]=rows[1];
      const bloq2=_filialBloqueada(eq2,1,rows,cat,catSup||null,cl);
      if(bloq2) result[1].nofil=true;
    }
    return result;
  }

  return result;
}


let _clSort={};
function sortClTable(th,colIdx,cat){
  const tbl=th.closest('table');if(!tbl)return;
  const tbody=tbl.querySelector('tbody');if(!tbody)return;
  const rows=[...tbody.querySelectorAll('tr')];
  const key=cat+'_'+colIdx;
  if(_clSort[key]) _clSort[key]=!_clSort[key]; else _clSort[key]=false;
  const asc=_clSort[key];
  rows.sort((a,b)=>{
    const va=a.cells[colIdx]?.innerText.trim().replace('%','').replace('+','')||'';
    const vb=b.cells[colIdx]?.innerText.trim().replace('%','').replace('+','')||'';
    const na=parseFloat(va),nb=parseFloat(vb);
    let v=isNaN(na)||isNaN(nb)?va.localeCompare(vb):nb-na;
    return asc?-v:v;
  });
  // Renumerar
  rows.forEach((r,i)=>{if(r.cells[0])r.cells[0].innerText=i+1;tbody.appendChild(r);});
}

function showTeamScorers(eq, cat, temp){
  // cat y temp vienen del contexto de la tabla de clasificación donde se hizo clic.
  // Si no se pasan (llamada directa), se leen de los filtros activos como fallback.
  if(cat===undefined||cat===null) cat=document.getElementById('cl-cat')?.value||'';
  if(temp===undefined||temp===null) temp=document.getElementById('cl-temp')?.value||'';
  const golMap={};
  ACTAS.forEach(a=>{
    if(isSala(a.categoria)) return;
    if(cat && a.categoria!==cat) return;
    if(temp && a.temporada!==temp) return;
    const L=a.equipo_local, V=a.equipo_visitante;
    (a.goleadores||[]).forEach(g=>{
      const n=g.jugador; if(!n) return;
      if(g.propia) return;  // No contar goles en propia puerta
      let eqG='?';
      if((a.jugadores_local||[]).includes(n)) eqG=L;
      else if((a.jugadores_visitante||[]).includes(n)) eqG=V;
      if(eqG!==eq) return;
      if(!golMap[n]) golMap[n]={goles:0,equipo:eqG,cat:a.categoria||'?'};
      golMap[n].goles++;
    });
  });
  let gd=Object.entries(golMap).map(([n,d])=>({nombre:n,...d}));
  gd.sort((a,b)=>b.goles-a.goles);
  const mx=gd[0]?.goles||1;
  const rows=gd.map((g,i)=>`<div class="gr">
    <span class="grk">#${i+1}</span>
    <div style="flex:1">
      <div style="font-weight:600;cursor:pointer" onclick="openPlayer('${g.nombre}')">${g.nombre}</div>
      <div class="bar"><div class="bf" style="width:${g.goles/mx*100}%"></div></div>
    </div>
    <span class="gv">${g.goles}</span>
  </div>`).join('')||'<div class="empty">Sin goles registrados</div>';
  const tempLabel = temp ? ` <span style="font-size:11px;font-weight:400;color:var(--a3);margin-left:6px">📅 ${temp}</span>` : '';
  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">⚽ Goleadores — ${eq}${tempLabel}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    ${rows}`;
  document.getElementById('modal-bg').classList.add('open');
}


function showTeamGC(eq, minMins){
  // Usar los filtros activos de clasificación
  const cat=document.getElementById('cl-cat')?.value||'';
  const temp=document.getElementById('cl-temp')?.value||'';
  const minM=(minMins===undefined)?500:parseInt(minMins)||0;

  // Calcular GC precisos por jugador: solo goles recibidos mientras estaba en campo
  const gcMap={}; // nombre -> {gcEnCampo, PJ, mins}
  ACTAS.forEach(a=>{
    if(isSala(a.categoria)) return;
    if(cat && a.categoria!==cat) return;
    if(temp && a.temporada!==temp) return;
    const L=a.equipo_local,V=a.equipo_visitante;
    const goles=a.goleadores||[];
    const golesVisitante=goles.filter(g=>g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador)));
    const golesLocal=goles.filter(g=>g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador)));
    const calcGC=(jugs,tits,sust,golesContra,eqN)=>{
      if(eqN!==eq) return;
      (jugs||[]).forEach(n=>{
        let minIn=0,minOut=90;
        if((tits||[]).includes(n)){
          const salida=(sust||[]).find(s=>s.sale===n);
          if(salida) minOut=salida.min;
        } else {
          const entrada=(sust||[]).find(s=>s.entra===n);
          if(entrada) minIn=entrada.min;
        }
        let gcEnPartido=0;
        golesContra.forEach(g=>{if(g.minuto>=minIn && g.minuto<=minOut) gcEnPartido++;});
        if(!gcMap[n]) gcMap[n]={gcEnCampo:0,PJ:0,mins:0};
        gcMap[n].gcEnCampo+=gcEnPartido;
        gcMap[n].PJ++;
        gcMap[n].mins+=(a.minutos_jugadores||{})[n]||0;
      });
    };
    calcGC(a.jugadores_local,a.titulares_local,a.sustituciones_local,golesVisitante,L);
    calcGC(a.jugadores_visitante,a.titulares_visitante,a.sustituciones_visitante,golesLocal,V);
  });

  // Todos los jugadores (sin filtro de minutos) para contar excluidos
  const allJug=Object.entries(gcMap).filter(([,d])=>d.PJ>0);
  let gd=allJug
    .filter(([,d])=>d.mins>=minM)
    .map(([n,d])=>({nombre:n,...d,gcMedia:d.PJ>0?d.gcEnCampo/d.PJ:0}))
    .sort((a,b)=>a.gcMedia-b.gcMedia);
  const excluidos=allJug.length-gd.length;

  const mx=Math.max(...gd.map(d=>d.gcMedia),0.01);
  const eqEsc=eq.replace(/'/g,"\\'").replace(/"/g,'&quot;');
  const rows=gd.map((d,i)=>{
    const nEsc=d.nombre.replace(/'/g,"\\'");
    return `<div class="gr" style="cursor:pointer" onclick="showTeamGCDetail('${nEsc}','${eqEsc}','${cat.replace(/'/g,"\\'")}','${temp.replace(/'/g,"\\'")}',${minM})">
      <span class="grk">#${i+1}</span>
      <div style="flex:1">
        <div style="font-weight:600;display:flex;align-items:center;gap:6px">
          <span>${d.nombre}</span>${portTag(d.nombre)}
          <span style="font-size:10px;color:var(--mu)">${d.PJ}PJ · ${d.mins}min</span>
        </div>
        <div style="font-size:11px;margin-top:1px"><span style="color:var(--a4)">${d.gcEnCampo} GC en campo</span> <span style="font-size:10px;color:var(--mu)">· toca para ver partido a partido →</span></div>
        <div class="bar"><div class="bf" style="width:${d.gcMedia/mx*100}%;background:var(--a4)"></div></div>
      </div>
      <span class="gv" style="color:var(--a4)">${d.gcMedia.toFixed(2)}</span>
    </div>`;
  }).join('')||'<div class="empty">Sin jugadores con ≥'+minM+' min</div>';

  const exclHtml=excluidos>0?`<div style="font-size:11px;color:var(--mu);margin-top:8px;text-align:right">${excluidos} jugador${excluidos!==1?'es':''} excluido${excluidos!==1?'s':''} por filtro de minutos</div>`:'';

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <span class="mtit">🛡 GC/P en campo — ${eq}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button>
    </div>
    <div style="font-size:11px;color:var(--mu);margin-bottom:10px">Goles recibidos por partido estando en campo · de menor a mayor${cat?' · <b style=color:var(--a3)>'+cat+'</b>':''}${temp?' · <b style=color:var(--a3)>'+temp+'</b>':''}</div>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;padding:10px 12px;background:var(--s2);border:1px solid var(--b);border-radius:8px">
      <label style="font-size:12px;color:var(--mu);white-space:nowrap">Mín. minutos:</label>
      <input id="tgc-mins" type="number" min="0" value="${minM}" style="width:90px;background:var(--s1);border:1px solid var(--b);color:var(--tx);padding:5px 8px;border-radius:6px;font-size:13px">
      <button onclick="showTeamGC('${eqEsc}',parseInt(document.getElementById('tgc-mins').value)||0)" style="background:rgba(77,139,255,.15);border:1px solid rgba(77,139,255,.4);color:var(--a4);font-size:12px;border-radius:6px;padding:5px 12px;cursor:pointer">Aplicar</button>
      <span style="font-size:11px;color:var(--mu)">${gd.length} jugador${gd.length!==1?'es':''}</span>
    </div>
    ${rows}${exclHtml}`;
  document.getElementById('modal-bg').classList.add('open');
}

function showTeamGCDetail(nombre, eq, cat, temp, minM){
  // Reutiliza openGCDetail pero añade botón "← Volver" al ranking del equipo
  const partidos=ACTAS.filter(a=>{
    if(isSala(a.categoria)) return false;
    if(cat && a.categoria!==cat) return false;
    if(temp && a.temporada!==temp) return false;
    const enLocal=(a.jugadores_local||[]).includes(nombre);
    const enVisit=(a.jugadores_visitante||[]).includes(nombre);
    if(!enLocal && !enVisit) return false;
    const eqN=enLocal?a.equipo_local:a.equipo_visitante;
    if(eq && eqN!==eq) return false;
    return true;
  }).sort((a,b)=>(a.jornada||0)-(b.jornada||0));

  const filas=partidos.map(a=>{
    const isL=(a.jugadores_local||[]).includes(nombre);
    const rival=isL?a.equipo_visitante:a.equipo_local;
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    const golesFavor=isL?gl:gv;
    const golesContraTotal=isL?gv:gl;
    const tits=isL?a.titulares_local:a.titulares_visitante;
    const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
    const goles=a.goleadores||[];
    const mins=(a.minutos_jugadores||{})[nombre]||0;
    let minIn=0,minOut=90;
    if((tits||[]).includes(nombre)){
      const sal=(sust||[]).find(s=>s.sale===nombre);
      if(sal) minOut=sal.min;
    } else {
      const ent=(sust||[]).find(s=>s.entra===nombre);
      if(ent) minIn=ent.min;
    }
    const golesContraEq=goles.filter(g=>{
      if(isL) return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
      return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
    });
    const gcEnCampo=golesContraEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut);
    const gcFuera=golesContraEq.filter(g=>g.minuto<minIn||g.minuto>minOut);
    const esTit=(tits||[]).includes(nombre);
    const gcBadge=gcEnCampo.length>0?`<span style="color:var(--a2);font-weight:700">${gcEnCampo.length} GC</span>`:`<span style="color:var(--hw)">0 GC</span>`;
    const golesDetalle=gcEnCampo.map(g=>`<span style="font-size:10px;color:var(--a2);margin-left:4px">⚽${g.minuto}'</span>`).join('');
    const gcFueraDetalle=gcFuera.length?`<span style="font-size:10px;color:var(--mu);margin-left:6px">(${gcFuera.length} GC fuera)</span>`:'';
    return `<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--b);font-size:13px">
      <span style="font-size:11px;color:var(--mu);min-width:28px">J${a.jornada||'?'}</span>
      <span style="flex:1">
        <span style="cursor:pointer;color:var(--acc)" onclick="openMatch('${a.acta_id}')">${rival}</span>
        <span style="font-size:11px;color:var(--mu);margin-left:6px">${a.fecha||''}</span>
      </span>
      <span style="font-size:11px;color:${esTit?'var(--acc)':'var(--mu)'};min-width:30px">${esTit?'TIT':'SUB'}</span>
      <span style="font-size:11px;color:var(--mu);min-width:48px">${minIn}'→${minOut}' <span style="color:var(--a3)">${mins}min</span></span>
      <span style="min-width:80px">${gcBadge}${golesDetalle}</span>
      ${gcFueraDetalle}
      <span style="font-size:11px;color:var(--mu);min-width:36px">${golesFavor}-${golesContraTotal}</span>
    </div>`;
  });

  const totalGC=partidos.reduce((s,a)=>{
    const isL=(a.jugadores_local||[]).includes(nombre);
    const tits=isL?a.titulares_local:a.titulares_visitante;
    const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
    const goles=a.goleadores||[];
    let minIn=0,minOut=90;
    if((tits||[]).includes(nombre)){const sal=(sust||[]).find(sx=>sx.sale===nombre);if(sal)minOut=sal.min;}
    else{const ent=(sust||[]).find(sx=>sx.entra===nombre);if(ent)minIn=ent.min;}
    const golesContraEq=goles.filter(g=>{
      if(isL) return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
      return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
    });
    return s+golesContraEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
  },0);
  const totalMins=partidos.reduce((s,a)=>s+((a.minutos_jugadores||{})[nombre]||0),0);
  const gcMedia=partidos.length>0?(totalGC/partidos.length).toFixed(2):'-';
  const eqEsc=eq.replace(/'/g,"\\'").replace(/"/g,'&quot;');

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <button onclick="showTeamGC('${eqEsc}',${minM})" style="background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.35);color:var(--a4);font-size:12px;border-radius:6px;padding:4px 10px;cursor:pointer;margin-right:8px">← Volver</button>
      <span class="mtit">🛡 ${nombre}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button>
    </div>
    <div class="sg" style="margin:12px 0">
      <div class="sc"><div class="sv">${partidos.length}</div><div class="sl">Partidos</div></div>
      <div class="sc"><div class="sv" style="color:var(--a4)">${totalMins}</div><div class="sl">Min en campo</div></div>
      <div class="sc r"><div class="sv" style="color:var(--a2)">${totalGC}</div><div class="sl">GC en campo</div></div>
      <div class="sc" style="border-top:2px solid var(--a4)"><div class="sv" style="color:var(--a4)">${gcMedia}</div><div class="sl">GC/P en campo</div></div>
    </div>
    <div style="font-size:11px;color:var(--mu);margin-bottom:10px;padding:8px;background:var(--s2);border-radius:6px">
      Solo se cuentan los goles recibidos <b style="color:var(--acc)">mientras el jugador estaba en el campo</b>. Si salió en el descanso, los goles de la segunda parte no le computan.${cat?' <span style=color:var(--a3)>'+cat+'</span>':''}${temp?' · <span style=color:var(--a3)>'+temp+'</span>':''}
    </div>
    <div style="display:flex;gap:16px;font-size:11px;font-family:\'JetBrains Mono\',monospace;color:var(--mu);padding:6px 0;border-bottom:2px solid var(--b);margin-bottom:4px;font-weight:700">
      <span style="min-width:28px">Jor.</span>
      <span style="flex:1">Rival · Fecha</span>
      <span style="min-width:30px">Rol</span>
      <span style="min-width:48px">Tramo</span>
      <span style="min-width:80px">GC campo</span>
      <span style="min-width:36px">Res.</span>
    </div>
    <div>${filas.join('')||'<div class="empty">Sin partidos</div>'}</div>`;
  document.getElementById('modal-bg').classList.add('open');
}

// ── PARTIDOS ──────────────────────────────────────────────────────────────────
function rPa(){
  const cat=document.getElementById('pa-cat').value;
  const eq=document.getElementById('pa-eq').value;
  const jor=document.getElementById('pa-jor').value;
  const srch=document.getElementById('pa-s').value.toLowerCase();
  const list=ACTAS.filter(a=>
    (!cat||a.categoria===cat)&&(!eq||a.equipo_local===eq||a.equipo_visitante===eq)&&
    (!jor||String(a.jornada)===String(jor))&&
    (!srch||[a.equipo_local,a.equipo_visitante].join(' ').toLowerCase().includes(srch))
  ).sort((a,b)=>(b.jornada||0)-(a.jornada||0));
  const byJ={};
  list.forEach(a=>{const j=a.jornada||'?';if(!byJ[j])byJ[j]=[];byJ[j].push(a);});
  let h='';
  Object.keys(byJ).sort((a,b)=>b-a).forEach(j=>{
    h+=`<div class="jh"><span>Jornada ${j}</span><span style="font-size:10px;font-family:'JetBrains Mono',monospace">${byJ[j][0]?.fecha||''}</span></div>`;
    h+=byJ[j].map(a=>{
      if(!a.equipo_local)return'';
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const fbadge=a.fuente==='euskadi'?'<span class="fbadge eus">EUS</span>':a.fuente==='gipuzkoa'?'<span class="fbadge gip">GIP</span>':a.fuente==='bizkaia'?'<span class="fbadge biz">BIZ</span>':a.fuente==='rfef'?'<span class="fbadge rfef">RFEF</span>':'';
      return `<div class="mc" onclick="openMatch('${a.acta_id}')">
        <div class="mm">J${j}<br>${a.fecha||''}<br><span style="font-size:9px;color:var(--a4);font-family:'JetBrains Mono',monospace">#${a.acta_id}</span></div>
        <div class="mts">
          <div class="mt h">${a.equipo_local}</div>
          <div class="ms ${c2(gl,gv)}">${gl} — ${gv}</div>
          <div class="mt">${a.equipo_visitante}</div>
        </div>
        ${fbadge}<span class="mcat">${(a.categoria||'').split('/')[0].trim()}</span>
      </div>`;
    }).join('');
  });
  document.getElementById('pa-c').innerHTML=h||'<div class="empty">Sin partidos</div>';
}

// ── GOLEADORES / ESTADÍSTICAS ─────────────────────────────────────────────────
function rGo(){
  const cat=document.getElementById('go-cat').value;
  const temp=document.getElementById('go-temp')?.value||'';
  const grupo=document.getElementById('go-grupo')?.value||'';
  const eq=document.getElementById('go-eq').value;
  const filtProv=document.getElementById('go-prov')?.value||'';
  const filtFed=document.getElementById('go-fed')?.value||'';
  const minMins=parseInt(document.getElementById('go-min-mins')?.value||0)||0;
  const golMinMins=parseInt(document.getElementById('go-gol-mins')?.value||0)||0;
  const golOrd=document.getElementById('go-gol-ord')?.value||'goles';
  const filtAnioGo=document.getElementById('go-anio')?.value||'';
  const {gols,port,jug}=GS();
  // Helper: ¿la categoría de esta acta pertenece al grupo activo?
  function actaPassGrupo(a){ return !grupo || getCatGrupo(a.categoria||'')===grupo; }

  // Función helper: ¿el equipo pasa el filtro de provincia?
  function eqPassProv(eqN){
    if(!filtProv) return true;
    const prov = getProvincia(getClubCanon(eqN));
    return prov === filtProv;
  }
  // Función helper: ¿el jugador ha jugado alguna vez en la federación filtrada?
  function jugPassFed(n){
    if(!filtFed) return true;
    const s=jug[n];
    return s && s.fuentes && s.fuentes.has(filtFed);
  }

  // Función helper: ¿el jugador pasa el filtro de año de nacimiento?
  function jugPassAnio(n){
    if(!filtAnioGo) return true;
    const r=getAnioNacCached(n);
    if(filtAnioGo==='le2006') return r && r.prefijo && r.anio<=2006;
    return r && !r.prefijo && String(r.anio)===filtAnioGo;
  }

  // ── Goleadores: sumar goles + minutos por jugador ──
  const golMap={}; // nombre -> {goles, equipo, cat, mins, PJ}
  // Crear lista de actas con timestamp para saber cuál es la más reciente
  const actasConFecha=ACTAS.map((a,idx)=>({...a,actaIdx:idx}))
    .sort((a,b)=>{
      // Intentar ordenar por fecha, si no existe usar índice
      const fechaA=new Date(a.fecha||0).getTime();
      const fechaB=new Date(b.fecha||0).getTime();
      if(fechaA!==fechaB) return fechaB-fechaA; // Más reciente primero
      return b.actaIdx-a.actaIdx; // Si misma fecha, más reciente por índice
    });
  
  actasConFecha.forEach(a=>{
    if(isSala(a.categoria)) return;
    if(cat && a.categoria!==cat) return;
    if(temp && a.temporada!==temp) return;
    const L=a.equipo_local, V=a.equipo_visitante;
    // Acumular minutos de todos los jugadores de esta acta
    const acumMins=(jugs, eqN)=>{
      if(!eqPassProv(eqN)) return;
      (jugs||[]).forEach(nOrig=>{
        if(eq && eqN!==eq) return;
        const n=normPerson(_rn(a.acta_id,nOrig));
        if(!golMap[n]) golMap[n]={goles:0,equipo:eqN,cat:a.categoria||'?',mins:0,PJ:0};
        golMap[n].mins+=(a.minutos_jugadores||{})[nOrig]||0;
        golMap[n].PJ++;
        // CORREGIDO: Siempre actualizar al equipo y categoría más actuales (actas ya están ordenadas por fecha)
        golMap[n].equipo=eqN;
        golMap[n].cat=a.categoria||'?';
      });
    };
    if(!eq || a.equipo_local===eq)  acumMins(a.jugadores_local,  L);
    if(!eq || a.equipo_visitante===eq) acumMins(a.jugadores_visitante, V);
    // Contar goles — normalizar el nombre del goleador para que coincida con golMap
    (a.goleadores||[]).forEach(g=>{
      const nOrig=g.jugador;
      if(!nOrig) return;
      if(g.propia) return;  // No contar goles en propia puerta
      const n=normPerson(_rn(a.acta_id,nOrig));
      let eqG='?';
      if((a.jugadores_local||[]).includes(nOrig)) eqG=L;
      else if((a.jugadores_visitante||[]).includes(nOrig)) eqG=V;
      if(eq && eqG!==eq) return;
      if(eqG==='?') return;  // Goleador no identificado en ningún equipo del acta → ignorar
      if(!eqPassProv(eqG)) return;
      if(!golMap[n]) golMap[n]={goles:0,equipo:eqG,cat:a.categoria||'?',mins:0,PJ:0};
      golMap[n].goles++;
      // CORREGIDO: Siempre actualizar al equipo y categoría más actuales
      golMap[n].equipo=eqG;
      golMap[n].cat=a.categoria||'?';
    });
  });
  // Filtrar por mínimo de minutos y calcular Gls/P
  let gd=Object.entries(golMap)
    .filter(([n,d])=>d.goles>0 && d.mins>=golMinMins && jugPassFed(n) && jugPassAnio(n))
    .map(([n,d])=>({nombre:n,...d,glspp:d.PJ>0?d.goles/d.PJ:0}));
  // Ordenar
  if(golOrd==='glspp') gd.sort((a,b)=>b.glspp-a.glspp||b.goles-a.goles);
  else gd.sort((a,b)=>b.goles-a.goles||b.glspp-a.glspp);
  const mx=Math.max(...gd.map(g=>golOrd==='glspp'?g.glspp:g.goles),1);
  document.getElementById('go-l').innerHTML=gd.slice(0,25).map((g,i)=>`
    <div class="gr">
      <span class="grk">#${i+1}</span>
      <div style="flex:1">
        <div style="font-weight:600;cursor:pointer" onclick="openPlayer('${g.nombre.replace(/'/g,"\\'")}')">
          ${g.nombre}
        </div>
        <div style="font-size:11px;color:var(--mu);display:flex;gap:8px;align-items:center">
          <span>${g.equipo||'?'} · ${g.cat.split('/')[0].trim()}</span>
          <span style="color:var(--a3)">${g.mins}min</span>
          <span style="color:var(--hw);font-weight:600">${g.glspp.toFixed(2)} G/P</span>
        </div>
        <div class="bar"><div class="bf" style="width:${(golOrd==='glspp'?g.glspp:g.goles)/mx*100}%"></div></div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-family:'Bebas Neue',sans-serif;font-size:22px;color:var(--acc)">${g.goles}</div>
        <div style="font-size:10px;color:var(--mu)">goles</div>
      </div>
    </div>`).join('')||'<div class="empty">Sin datos${golMinMins>0?` (mín ${golMinMins} min)`:""}</div>';

  // ── Porteros menos goleados: solo porteros reales, filtro temporada y minutos ──
  const minMinsPort=parseInt(document.getElementById('go-port-mins')?.value);
  const minMinsPortVal=isNaN(minMinsPort)?500:minMinsPort;
  // Recalcular porteros con filtros de temporada/cat/eq
  // Usando las actas ya ordenadas por fecha (actasConFecha creadas arriba)
  const portMap={}; // nombre -> {GC, mins, equipo, PJ}
  actasConFecha.forEach(a=>{
    if(isSala(a.categoria)) return;
    if(cat && a.categoria!==cat) return;
    if(temp && a.temporada!==temp) return;
    const pL=a.portero_local||(a.titulares_local||[])[0];
    const pV=a.portero_visitante||(a.titulares_visitante||[])[0];
    const gl=a.goles_local||0, gv=a.goles_visitante||0;
    const minsL=(a.minutos_jugadores||{})[pL]||0;
    const minsV=(a.minutos_jugadores||{})[pV]||0;
    if(pL){
      if(eq && a.equipo_local!==eq) {}
      else if(filtProv && !eqPassProv(a.equipo_local)) {}
      else {
        if(!portMap[pL]) portMap[pL]={GC:0,mins:0,equipo:a.equipo_local,cat:a.categoria||'?',PJ:0};
        portMap[pL].GC+=gv; portMap[pL].mins+=minsL||90; portMap[pL].PJ++;
        // CORREGIDO: Siempre actualizar al equipo y categoría más actuales (actas ya ordenadas por fecha)
        portMap[pL].equipo=a.equipo_local;
        portMap[pL].cat=a.categoria||'?';
      }
    }
    if(pV){
      if(eq && a.equipo_visitante!==eq) {}
      else if(filtProv && !eqPassProv(a.equipo_visitante)) {}
      else {
        if(!portMap[pV]) portMap[pV]={GC:0,mins:0,equipo:a.equipo_visitante,cat:a.categoria||'?',PJ:0};
        portMap[pV].GC+=gl; portMap[pV].mins+=minsV||90; portMap[pV].PJ++;
        // CORREGIDO: Siempre actualizar al equipo y categoría más actuales (actas ya ordenadas por fecha)
        portMap[pV].equipo=a.equipo_visitante;
        portMap[pV].cat=a.categoria||'?';
      }
    }
  });
  // Filtrar solo porteros reales (isPort) y por minutos mínimos
  let pd=Object.entries(portMap)
    .filter(([n,p])=>isPort(n) && p.mins>=minMinsPortVal && jugPassFed(n) && jugPassAnio(n))
    .map(([n,p])=>({nombre:n,...p,gcPP:p.PJ>0?p.GC/p.PJ:0}));
  pd.sort((a,b)=>a.gcPP-b.gcPP);
  const mxg=Math.max(...pd.map(p=>p.GC),1);
  document.getElementById('go-p').innerHTML=pd.slice(0,20).map((p,i)=>`
    <div class="gr">
      <span class="grk">#${i+1}</span>
      <div style="flex:1">
        <div style="font-weight:600;cursor:pointer" onclick="openPlayer('${p.nombre}')">${p.nombre}</div>
        <div style="font-size:11px;color:var(--mu)">${p.equipo} · ${p.PJ}PJ · ${p.mins}min · ${p.gcPP.toFixed(2)} GC/p</div>
        <div class="bar"><div class="bf" style="width:${p.GC/mxg*100}%;background:var(--a2)"></div></div>
      </div>
      <span class="gv" style="color:var(--a2)">${p.GC}</span>
    </div>`).join('')||`<div class="empty">Sin porteros con ≥${minMinsPortVal} min</div>`;

  // ── GF/P y GC/P por jugador ──
  let jugData=Object.entries(jug).filter(([n,s])=>(!cat||s.cat===cat)&&(!eq||s.equipo===eq)&&(!filtProv||eqPassProv(s.equipo))&&jugPassFed(n)&&jugPassAnio(n)&&s.PJ>0&&(s.mins||0)>=minMins).map(([n,s])=>({nombre:n,...s}));
  // Top GF/partido
  let gfTop=[...jugData].sort((a,b)=>b.gfMedia-a.gfMedia).slice(0,20);
  const mxGF=gfTop[0]?.gfMedia||1;
  document.getElementById('go-gf').innerHTML=gfTop.map((d,i)=>`
    <div class="gr">
      <span class="grk">#${i+1}</span>
      <div style="flex:1">
        <div style="font-weight:600;cursor:pointer;display:flex;align-items:center;gap:4px" onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}')">
          <span>${d.nombre}</span>${portTag(d.nombre)}
        </div>
        <div style="font-size:11px;color:var(--mu)">${d.equipo||'?'} · ${d.PJ}PJ · ${d.mins}min</div>
        <div class="bar"><div class="bf" style="width:${d.gfMedia/mxGF*100}%;background:var(--hw)"></div></div>
      </div>
      <span class="gv" style="color:var(--hw)">${d.gfMedia.toFixed(2)}</span>
      ${starBtn(d.nombre)}
    </div>`).join('')||'<div class="empty">Sin datos</div>';
  // Top menos GC/partido — usando cálculo preciso por minutos en campo
  const minMinsGC=parseInt(document.getElementById('go-gc-mins')?.value||0)||0;
  // Calcular GC precisos: solo los goles recibidos mientras el jugador estaba en el campo
  const gcPrecisoMap={}; // nombre -> {gcEnCampo, PJ, mins, equipo}
  actasConFecha.forEach(a=>{
    if(isSala(a.categoria)) return;
    if(cat && a.categoria!==cat) return;
    if(temp && a.temporada!==temp) return;
    const L=a.equipo_local,V=a.equipo_visitante;
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    const goles=a.goleadores||[];
    const calcGCEnCampo=(jugs,tits,sust,golesContra,eqN)=>{
      if(filtProv && !eqPassProv(eqN)) return;
      (jugs||[]).forEach(n=>{
        if(eq && eqN!==eq) return;
        // Calcular tramo en campo: [minEntrada, minSalida]
        let minIn=0,minOut=90;
        if((tits||[]).includes(n)){
          // Titular: entra al 0, sale si hay sustitución
          const salida=(sust||[]).find(s=>s.sale===n);
          if(salida) minOut=salida.min;
        } else {
          // Suplente: entra cuando le sustituyen
          const entrada=(sust||[]).find(s=>s.entra===n);
          if(entrada) minIn=entrada.min;
        }
        // Contar goles en contra que cayeron mientras estaba en campo
        let gcEnPartido=0;
        golesContra.forEach(g=>{
          if(g.minuto>=minIn && g.minuto<=minOut) gcEnPartido++;
        });
        if(!gcPrecisoMap[n]) gcPrecisoMap[n]={gcEnCampo:0,PJ:0,mins:0,equipo:eqN,cat:a.categoria||'?'};
        gcPrecisoMap[n].gcEnCampo+=gcEnPartido;
        gcPrecisoMap[n].PJ++;
        gcPrecisoMap[n].mins+=(a.minutos_jugadores||{})[n]||0;
        // CORREGIDO: Siempre actualizar al equipo y categoría más actuales (actas ya ordenadas por fecha)
        gcPrecisoMap[n].equipo=eqN;
        gcPrecisoMap[n].cat=a.categoria||'?';
      });
    };
    // goles en contra del local = goles del visitante
    const golesVisitante=goles.filter(g=>g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador)));
    const golesLocal=goles.filter(g=>g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador)));
    calcGCEnCampo(a.jugadores_local,a.titulares_local,a.sustituciones_local,golesVisitante,L);
    calcGCEnCampo(a.jugadores_visitante,a.titulares_visitante,a.sustituciones_visitante,golesLocal,V);
  });
  let gcTop=Object.entries(gcPrecisoMap)
    .filter(([n,d])=>d.PJ>=3&&d.mins>=minMinsGC)
    .map(([n,d])=>({nombre:n,...d,gcMedia:d.PJ>0?d.gcEnCampo/d.PJ:0}))
    .sort((a,b)=>a.gcMedia-b.gcMedia).slice(0,20);
  const mxGC=Math.max(...gcTop.map(d=>d.gcMedia),1);
  document.getElementById('go-gc').innerHTML=gcTop.map((d,i)=>`
    <div class="gr" style="cursor:pointer" onclick="openGCDetail('${d.nombre.replace(/'/g,"\\'")}','${cat}','${temp}','${eq}')">
      <span class="grk">#${i+1}</span>
      <div style="flex:1">
        <div style="font-weight:600;display:flex;align-items:center;gap:4px">
          <span>${d.nombre}</span>${portTag(d.nombre)}
        </div>
        <div style="font-size:11px;color:var(--mu)">${d.equipo||'?'} · ${d.PJ}PJ · ${d.mins}min · <span style="color:var(--a4)">${d.gcEnCampo} GC en campo</span></div>
        <div class="bar"><div class="bf" style="width:${d.gcMedia/mxGC*100}%;background:var(--a4)"></div></div>
      </div>
      <span class="gv" style="color:var(--a4)">${d.gcMedia.toFixed(2)}</span>
    </div>`).join('')||'<div class="empty">Sin datos (mín 3PJ)</div>';

  rGoTable();
}

// ── DETALLE GC EN CAMPO ───────────────────────────────────────────────────────
function openGCDetail(nombre, cat, temp, eq){
  // Recalcular para este jugador con todos sus partidos (respetando filtros)
  const partidos=ACTAS.filter(a=>{
    if(isSala(a.categoria)) return false;
    if(cat && a.categoria!==cat) return false;
    if(temp && a.temporada!==temp) return false;
    const enLocal=(a.jugadores_local||[]).includes(nombre);
    const enVisit=(a.jugadores_visitante||[]).includes(nombre);
    if(!enLocal && !enVisit) return false;
    const eqN=enLocal?a.equipo_local:a.equipo_visitante;
    if(eq && eqN!==eq) return false;
    return true;
  }).sort((a,b)=>(b.jornada||0)-(a.jornada||0));

  const filas=partidos.map(a=>{
    const isL=(a.jugadores_local||[]).includes(nombre);
    const eqN=isL?a.equipo_local:a.equipo_visitante;
    const rival=isL?a.equipo_visitante:a.equipo_local;
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    const golesFavor=isL?gl:gv;
    const golesContra=isL?gv:gl;
    const tits=isL?a.titulares_local:a.titulares_visitante;
    const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
    const goles=a.goleadores||[];
    const mins=(a.minutos_jugadores||{})[nombre]||0;

    // Tramo en campo
    let minIn=0,minOut=90;
    if((tits||[]).includes(nombre)){
      const salida=(sust||[]).find(s=>s.sale===nombre);
      if(salida) minOut=salida.min;
    } else {
      const entrada=(sust||[]).find(s=>s.entra===nombre);
      if(entrada) minIn=entrada.min;
    }

    // Goles en contra mientras estaba en campo
    const golesContraEq=goles.filter(g=>{
      if(isL) return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
      return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
    });
    const gcEnCampo=golesContraEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut);
    const gcFuera=golesContraEq.filter(g=>g.minuto<minIn||g.minuto>minOut);
    const esTit=(tits||[]).includes(nombre);

    const gcBadge=gcEnCampo.length>0?`<span style="color:var(--a2);font-weight:700">${gcEnCampo.length} GC</span>`:`<span style="color:var(--hw)">0 GC</span>`;
    const golesDetalle=gcEnCampo.map(g=>`<span style="font-size:10px;color:var(--a2);margin-left:4px">⚽${g.minuto}'</span>`).join('');
    const gcFueraDetalle=gcFuera.length?`<span style="font-size:10px;color:var(--mu);margin-left:6px">(${gcFuera.length} GC fuera)</span>`:'';
    return `<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--b);font-size:13px">
      <span style="font-size:11px;color:var(--mu);min-width:28px">J${a.jornada||'?'}</span>
      <span style="flex:1">
        <span style="cursor:pointer;color:var(--acc)" onclick="openMatch('${a.acta_id}')">${rival}</span>
        <span style="font-size:11px;color:var(--mu);margin-left:6px">${a.fecha||''}</span>
      </span>
      <span style="font-size:11px;color:${esTit?'var(--acc)':'var(--mu)'};min-width:30px">${esTit?'TIT':'SUB'}</span>
      <span style="font-size:11px;color:var(--mu);min-width:48px">${minIn}'→${minOut}' <span style="color:var(--a3)">${mins}min</span></span>
      <span style="min-width:80px">${gcBadge}${golesDetalle}</span>
      ${gcFueraDetalle}
      <span style="font-size:11px;color:var(--mu);min-width:36px">${golesFavor}-${golesContra}</span>
    </div>`;
  });

  const totalGC=partidos.reduce((s,a)=>{
    const isL=(a.jugadores_local||[]).includes(nombre);
    const tits=isL?a.titulares_local:a.titulares_visitante;
    const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
    const goles=a.goleadores||[];
    let minIn=0,minOut=90;
    if((tits||[]).includes(nombre)){const sal=(sust||[]).find(sx=>sx.sale===nombre);if(sal)minOut=sal.min;}
    else{const ent=(sust||[]).find(sx=>sx.entra===nombre);if(ent)minIn=ent.min;}
    const golesContraEq=goles.filter(g=>{
      if(isL) return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
      return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
    });
    return s+golesContraEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
  },0);
  const totalMins=partidos.reduce((s,a)=>s+((a.minutos_jugadores||{})[nombre]||0),0);
  const gcMedia=partidos.length>0?(totalGC/partidos.length).toFixed(2):'-';

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <span class="mtit">🛡 GC en campo — ${nombre}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button>
    </div>
    <div class="sg" style="margin:12px 0">
      <div class="sc"><div class="sv">${partidos.length}</div><div class="sl">Partidos</div></div>
      <div class="sc"><div class="sv" style="color:var(--a4)">${totalMins}</div><div class="sl">Min en campo</div></div>
      <div class="sc r"><div class="sv" style="color:var(--a2)">${totalGC}</div><div class="sl">GC en campo</div></div>
      <div class="sc" style="border-top:2px solid var(--a4)"><div class="sv" style="color:var(--a4)">${gcMedia}</div><div class="sl">GC/P en campo</div></div>
    </div>
    <div style="font-size:11px;color:var(--mu);margin-bottom:10px;padding:8px;background:var(--s2);border-radius:6px">
      Solo se cuentan los goles recibidos <b style="color:var(--acc)">mientras el jugador estaba en el campo</b>. Si salió en el descanso, los goles de la segunda parte no le computan.
    </div>
    <div>${filas.join('')||'<div class="empty">Sin partidos</div>'}</div>`;
  document.getElementById('modal-bg').classList.add('open');
}


function sortGoTable(th,colIdx){
  const tbl=th.closest('table');if(!tbl)return;
  const tbody=tbl.querySelector('tbody');if(!tbody)return;
  const rows=[...tbody.querySelectorAll('tr')];
  if(_goTableSort.col===colIdx) _goTableSort.asc=!_goTableSort.asc;
  else{_goTableSort.col=colIdx;_goTableSort.asc=false;}
  const asc=_goTableSort.asc;
  rows.sort((a,b)=>{
    const va=a.cells[colIdx]?.innerText.trim()||'';
    const vb=b.cells[colIdx]?.innerText.trim()||'';
    const na=parseFloat(va),nb=parseFloat(vb);
    let v=isNaN(na)||isNaN(nb)?va.localeCompare(vb):nb-na;
    return asc?-v:v;
  });
  rows.forEach((r,i)=>{if(r.cells[0])r.cells[0].innerText=i+1;tbody.appendChild(r);});
}

function rGoTable(){
  const cat=document.getElementById('go-cat').value;
  const eq=document.getElementById('go-eq').value;
  const filtProv=document.getElementById('go-prov')?.value||'';
  const filtFed=document.getElementById('go-fed')?.value||'';
  const filtAnioGo=document.getElementById('go-anio')?.value||'';
  const ord=document.getElementById('go-st-ord')?.value||'gfMedia';
  const minMins=parseInt(document.getElementById('go-st-mins')?.value||0)||0;
  const {jug}=GS();
  function _anioPass(n){
    if(!filtAnioGo) return true;
    const r=getAnioNacCached(n);
    if(filtAnioGo==='le2006') return r && r.prefijo && r.anio<=2006;
    return r && !r.prefijo && String(r.anio)===filtAnioGo;
  }
  let data=Object.entries(jug).filter(([n,s])=>(!cat||s.cat===cat)&&(!eq||s.equipo===eq)&&(!filtProv||getProvincia(getClubCanon(s.equipo))===filtProv)&&(!filtFed||( s.fuentes&&s.fuentes.has(filtFed)))&&_anioPass(n)&&s.PJ>0&&(s.mins||0)>=minMins).map(([n,s])=>({nombre:n,...s}));
  data.sort((a,b)=>{
    if(ord==='gfMedia') return b.gfMedia-a.gfMedia;
    if(ord==='gcMedia') return a.gcMedia-b.gcMedia;
    if(ord==='goles')   return b.goles-a.goles;
    if(ord==='glspp')   return (b.PJ>0?b.goles/b.PJ:0)-(a.PJ>0?a.goles/a.PJ:0);
    return b.mins-a.mins;
  });
  document.getElementById('go-st-b').innerHTML=data.map((d,i)=>`
    <tr onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}')\" style="cursor:pointer">
      <td class="num" style="color:var(--mu)">${i+1}</td>
      <td style="font-weight:600;color:var(--acc)">${d.nombre}</td>
      <td style="font-size:12px;color:var(--mu)">${d.equipo||''}</td>
      <td class="num">${d.mins}</td>
      <td class="num">${d.goles||0}</td>
      <td class="num" style="color:var(--hw)">${d.PJ>0?(d.goles/d.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--hw)">${(d.gfMedia||0).toFixed(2)}</td>
      <td class="num" style="color:var(--a2)">${(d.gcMedia||0).toFixed(2)}</td>
      <td class="num">${d.PJ}</td>
    </tr>`).join('')||'<tr><td colspan="9" class="empty">Sin datos</td></tr>';
}


// ── JUGADORES ─────────────────────────────────────────────────────────────────
const JU_PAGE_SIZE = 500;
let _juPage = 0;          // página actual (0-indexed)
let _juData  = [];        // datos filtrados+ordenados completos
let _juDbt   = null;      // debounce timer para búsqueda

function _juRenderPage(){
  const total = _juData.length;
  const totalPages = Math.max(1, Math.ceil(total / JU_PAGE_SIZE));
  if(_juPage >= totalPages) _juPage = totalPages - 1;
  const start = _juPage * JU_PAGE_SIZE;
  const slice = _juData.slice(start, start + JU_PAGE_SIZE);

  document.getElementById('ju-b').innerHTML = slice.map((d,i) => {
    const gfVsEq=d.gfVsEq||0, gcVsEq=d.gcVsEq||0;
    const gfVsCol=gfVsEq>0.05?'var(--hw)':gfVsEq<-0.05?'var(--a2)':'var(--mu)';
    const gcVsCol=gcVsEq<-0.05?'var(--hw)':gcVsEq>0.05?'var(--a2)':'var(--mu)';
    const gfVsTxt=(gfVsEq>=0?'+':'')+gfVsEq.toFixed(2);
    const gcVsTxt=(gcVsEq>=0?'+':'')+gcVsEq.toFixed(2);
    return `
    <tr onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}');" style="cursor:pointer">
      <td class="num" style="color:var(--mu)">${start + i + 1}</td>
      <td style="font-weight:600;color:var(--acc)">${d.nombre}</td>
      <td style="font-size:12px;color:var(--mu)">${d.equipo||''}</td>
      <td class="num">${d.PJ}</td><td class="num">${d.tit}</td>
      <td class="num" style="color:${d.nojug>0?'var(--a2)':'var(--mu)'};${d.nojug>0?'cursor:pointer;text-decoration:underline dotted':''}" ${d.nojug>0?`onclick="event.stopPropagation();openPlayer('${d.nombre.replace(/'/g,"\\'")}')"`:''}>${d.nojug}</td>
      <td class="num">${d.mins}</td><td class="num">${d.goles||0}</td>
      <td class="num">${d.PJ>0?(d.mins/d.PJ).toFixed(0):0}</td>
      <td class="num" style="color:var(--hw)">${d.PJ>0?(d.goles/d.PJ).toFixed(2):0}</td>
      <td class="num">${d.pres}%</td>
      <td class="num" style="color:var(--hw)">${d.PJ>0?(d.gfMedia||0).toFixed(2):'—'}</td>
      <td class="num" style="color:var(--a2)">${d.PJ>0?(d.gcMedia||0).toFixed(2):'—'}</td>
      <td class="num" style="color:${gfVsCol};font-weight:${Math.abs(gfVsEq)>0.05?'600':'400'}" title="Eq. GF/P general: ${(d.teamGfPP||0).toFixed(2)}">${d.PJ>0?gfVsTxt:'—'}</td>
      <td class="num" style="color:${gcVsCol};font-weight:${Math.abs(gcVsEq)>0.05?'600':'400'}" title="Eq. GC/P general: ${(d.teamGcPP||0).toFixed(2)}">${d.PJ>0?gcVsTxt:'—'}</td>
    </tr>`;
  }).join('') || '<tr><td colspan="15" class="empty">Sin datos</td></tr>';

  // Info texto
  const infoEl = document.getElementById('ju-pag-info');
  if(infoEl) infoEl.textContent = total > 0
    ? `Mostrando ${start+1}–${Math.min(start+JU_PAGE_SIZE,total)} de ${total} jugadores`
    : '';

  // Botones de página
  const btnsEl = document.getElementById('ju-pag-btns');
  if(!btnsEl) return;
  if(totalPages <= 1){ btnsEl.innerHTML=''; return; }

  const btnStyle = (active) =>
    `style="padding:3px 10px;border-radius:5px;cursor:pointer;font-size:12px;font-family:'JetBrains Mono',monospace;border:1px solid ${active?'var(--acc)':'var(--b)'};background:${active?'var(--acc)':'var(--s2)'};color:${active?'var(--bg)':'var(--tx)'};"`;

  // Siempre mostrar: primera, última, ±2 alrededor de la actual
  const show = new Set([0, totalPages-1,
    _juPage-2,_juPage-1,_juPage,_juPage+1,_juPage+2
  ].filter(p=>p>=0&&p<totalPages));
  const sorted = [...show].sort((a,b)=>a-b);

  let html = '';
  let prev = -1;
  sorted.forEach(p => {
    if(prev !== -1 && p > prev+1)
      html += `<span style="color:var(--mu);padding:0 4px;font-size:12px">…</span>`;
    html += `<button ${btnStyle(p===_juPage)} onclick="_juGoPage(${p})">${p+1}</button>`;
    prev = p;
  });
  btnsEl.innerHTML = html;
}

function _juGoPage(p){
  _juPage = p;
  _juRenderPage();
  // Scroll suave al inicio de la tabla
  const el = document.getElementById('p-ju');
  if(el) el.scrollIntoView({block:'start', behavior:'smooth'});
}

function rJu(extKey, extAsc){
  const cat=document.getElementById('ju-cat').value;
  const temp=document.getElementById('ju-temp')?.value||'';
  const eq=document.getElementById('ju-eq').value;
  const filtProv=document.getElementById('ju-prov')?.value||'';
  const filtFed=document.getElementById('ju-fed')?.value||'';
  const srch=document.getElementById('ju-s').value.toLowerCase();
  const ord=extKey||document.getElementById('ju-ord').value||'mins';
  const asc= (extKey!==undefined)?extAsc:false;
  const minMins=parseInt(document.getElementById('ju-min-mins')?.value||0)||0;
  const soloPort=document.getElementById('ju-solo-port')?.value||'';
  const filtAnio=document.getElementById('ju-anio')?.value||'';
  // Si hay filtro de temporada, recalcular stats filtradas
  let jugData;
  if(temp){
    const jugT={};
    ACTAS.filter(a=>a.temporada===temp&&!isSala(a.categoria)).forEach(a=>{
      if(!a.equipo_local||!a.equipo_visitante)return;
      const L=a.equipo_local,V=a.equipo_visitante;
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const addJ=(jugs,tits,sust,eqN,golesAFavor,golesEnContra)=>{
        const fechaActa=a.fecha||'';
        (jugs||[]).forEach(nOrig=>{
          const nHom=_rn(a.acta_id,nOrig);
          const n=normPerson(nHom);
          if(!jugT[n])jugT[n]={equipo:eqN,cat:a.categoria,PJ:0,tit:0,mins:0,goles:0,gfCon:0,gcCon:0,nojug:0,pres:0,pjEq:0,equipos:new Set(),fuentes:new Set(),_uf:'',_ue:eqN};
          jugT[n].PJ++;if((tits||[]).includes(nOrig))jugT[n].tit++;
          jugT[n].mins+=(a.minutos_jugadores||{})[nOrig]||0;
          jugT[n].goles+=(a.goleadores||[]).filter(g=>g.jugador===nOrig&&!g.propia).length;
          // GF/GC en campo: solo los goles ocurridos mientras el jugador estaba en el campo
          let minIn=0,minOut=90;
          if((tits||[]).includes(nOrig)){
            const sal=(sust||[]).find(sx=>sx.sale===nOrig);
            if(sal) minOut=sal.min;
          } else {
            const ent=(sust||[]).find(sx=>sx.entra===nOrig);
            if(ent) minIn=ent.min;
          }
          jugT[n].gfCon=(jugT[n].gfCon||0)+(golesAFavor||[]).filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
          jugT[n].gcCon=(jugT[n].gcCon||0)+(golesEnContra||[]).filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
          jugT[n].equipos.add(eqN);
          if(a.fuente) jugT[n].fuentes.add(a.fuente);
          if(fechaActa>=jugT[n]._uf){jugT[n]._uf=fechaActa;jugT[n]._ue=eqN;}
        });
      };
      const addNoJugT=(lista,eqN)=>{
        (lista||[]).forEach(nOrig=>{
          const nHom=_rn(a.acta_id,nOrig);
          const n=normPerson(nHom);
          if(!jugT[n])jugT[n]={equipo:eqN,cat:a.categoria,PJ:0,tit:0,mins:0,goles:0,gfCon:0,gcCon:0,nojug:0,pres:0,pjEq:0,equipos:new Set(),fuentes:new Set(),_uf:'',_ue:eqN};
          jugT[n].nojug=(jugT[n].nojug||0)+1;
          jugT[n].equipos.add(eqN);
        });
      };
      const golesLoc=(a.goleadores||[]).filter(g=>g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador)));
      const golesVis=(a.goleadores||[]).filter(g=>g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador)));
      addJ(a.jugadores_local,a.titulares_local,a.sustituciones_local,L,golesLoc,golesVis);
      addJ(a.jugadores_visitante,a.titulares_visitante,a.sustituciones_visitante,V,golesVis,golesLoc);
      addNoJugT(a.convocados_sin_jugar_local,L);
      addNoJugT(a.convocados_sin_jugar_visitante,V);
    });
    Object.entries(jugT).forEach(([n,s])=>{
      if(s._ue) s.equipo=s._ue; delete s._ue; delete s._uf;
      s.nojug=s.nojug||0;
      s.pjEq=s.PJ+s.nojug;
      s.pres=s.pjEq>0?Math.min(100,Math.round(s.PJ/s.pjEq*100)):0;
      s.gfMedia=s.PJ>0?s.gfCon/s.PJ:0;s.gcMedia=s.PJ>0?s.gcCon/s.PJ:0;s.portPJ=0;
    });
    jugData=Object.entries(jugT);
  } else {
    const {jug}=GS();
    jugData=Object.entries(jug);
  }
  let data=jugData
    .filter(([n,s])=>{
      if(cat && s.cat!==cat) return false;
      if(eq && s.equipo!==eq) return false;
      if(filtProv && getProvincia(getClubCanon(s.equipo))!==filtProv) return false;
      if(filtFed && !(s.fuentes && s.fuentes.has(filtFed))) return false;
      if(srch && !n.toLowerCase().includes(srch)) return false;
      if((s.mins||0)<minMins) return false;
      if(soloPort && !isPort(n)) return false;
      if(filtAnio){
        // Usar cache precalculado — O(1) en lugar de recorrer todas las actas
        const r=getAnioNacCached(n);
        if(filtAnio==='le2006'){
          if(!r||!r.prefijo||r.anio>2006) return false;
        } else {
          if(!r||r.prefijo||String(r.anio)!==filtAnio) return false;
        }
      }
      return true;
    })
    .map(([n,s])=>({nombre:n,...s}));
  // ── Stats por equipo (GF/P y GC/P general del equipo) ────────────────────
  const _teamStats={};
  const _actasFiltEq=ACTAS.filter(a=>!isSala(a.categoria)&&(temp?a.temporada===temp:true)&&(cat?a.categoria===cat:true));
  _actasFiltEq.forEach(a=>{
    if(!a.equipo_local||!a.equipo_visitante)return;
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    if(!_teamStats[a.equipo_local])  _teamStats[a.equipo_local] ={PJ:0,GF:0,GC:0};
    if(!_teamStats[a.equipo_visitante]) _teamStats[a.equipo_visitante]={PJ:0,GF:0,GC:0};
    _teamStats[a.equipo_local].PJ++;  _teamStats[a.equipo_local].GF+=gl;  _teamStats[a.equipo_local].GC+=gv;
    _teamStats[a.equipo_visitante].PJ++; _teamStats[a.equipo_visitante].GF+=gv; _teamStats[a.equipo_visitante].GC+=gl;
  });
  data.forEach(d=>{
    const ts=_teamStats[d.equipo]||{PJ:0,GF:0,GC:0};
    d.teamGfPP=ts.PJ>0?ts.GF/ts.PJ:0;
    d.teamGcPP=ts.PJ>0?ts.GC/ts.PJ:0;
    d.gfVsEq=(d.gfMedia||0)-d.teamGfPP;
    d.gcVsEq=(d.gcMedia||0)-d.teamGcPP;
  });
  data.sort((a,b)=>{
    let v=0;
    if(ord==='mins')        v=b.mins-a.mins;
    else if(ord==='pj')     v=b.PJ-a.PJ;
    else if(ord==='goles')  v=b.goles-a.goles;
    else if(ord==='pres')   v=b.pres-a.pres;
    else if(ord==='nojug')  v=b.nojug-a.nojug;
    else if(ord==='tit')    v=b.tit-a.tit;
    else if(ord==='minpp')  v=(b.PJ>0?b.mins/b.PJ:0)-(a.PJ>0?a.mins/a.PJ:0);
    else if(ord==='glspp')  v=(b.PJ>0?b.goles/b.PJ:0)-(a.PJ>0?a.goles/a.PJ:0);
    else if(ord==='gfMedia')v=(b.gfMedia||0)-(a.gfMedia||0);
    else if(ord==='gcMedia')v=(a.gcMedia||0)-(b.gcMedia||0);
    else if(ord==='gfVsEq') v=(b.gfVsEq||0)-(a.gfVsEq||0);
    else if(ord==='gcVsEq') v=(a.gcVsEq||0)-(b.gcVsEq||0);
    else if(ord==='equipo') v=a.equipo.localeCompare(b.equipo);
    else v=a.nombre.localeCompare(b.nombre);
    return asc?-v:v;
  });
  // Al cambiar filtros u orden, volver siempre a página 1
  _juData = data;
  _juPage = 0;
  _juRenderPage();
}

// ── SORT JUGADORES (click en cabecera) ───────────────────────────────────────
let _juSort={key:'mins',asc:false};
function sortJu(key){
  if(key==='#')return;
  if(_juSort.key===key) _juSort.asc=!_juSort.asc;
  else {_juSort.key=key;_juSort.asc=false;}
  const el=document.getElementById('ju-ord');
  const map={mins:'mins',pj:'pj',goles:'goles',pres:'pres',nojug:'nojug',nombre:'name',tit:'tit',minpp:'minpp',glspp:'glspp',equipo:'equipo',gfMedia:'gfMedia',gcMedia:'gcMedia',gfVsEq:'gfVsEq',gcVsEq:'gcVsEq'};
  if(map[key]) el.value=map[key]||'mins';
  rJu(_juSort.key,_juSort.asc);
}


// ── FILTRO AÑO NACIMIENTO EN PLANTILLA ───────────────────────────────────────
function filtrarPlantilla(){
  var sel=document.getElementById('eq-pt-anio');
  if(!sel) return;
  var v=sel.value;
  var rows=[].slice.call(document.querySelectorAll('#eq-pt-tbl tbody tr'));
  rows.forEach(function(r){
    var da=r.getAttribute('data-anio')||'';
    var show=true;
    if(v==='le')      show=(da==='le');
    else if(v!=='')   show=(da===v);
    r.style.display=show?'':'none';
  });
}

// ── SORT TABLA EQUIPO (click cabecera) ───────────────────────────────────────
let _eqTableSort={col:-1,asc:false};
function sortEqTable(th,colIdx){
  const tbl=th.closest('table');
  if(!tbl)return;
  const tbody=tbl.querySelector('tbody');
  if(!tbody)return;
  const rows=[...tbody.querySelectorAll('tr')];
  if(_eqTableSort.col===colIdx) _eqTableSort.asc=!_eqTableSort.asc;
  else{_eqTableSort.col=colIdx;_eqTableSort.asc=false;}
  const asc=_eqTableSort.asc;
  rows.sort((a,b)=>{
    const va=a.cells[colIdx]?.innerText.trim().replace('%','').replace('+','')||'';
    const vb=b.cells[colIdx]?.innerText.trim().replace('%','').replace('+','')||'';
    const na=parseFloat(va),nb=parseFloat(vb);
    let v=isNaN(na)||isNaN(nb)?va.localeCompare(vb):nb-na;
    return asc?-v:v;
  });
  rows.forEach(r=>tbody.appendChild(r));
}

function rEqTemp(){
  // When season changes, re-filter teams available (those that played that season)
  const cat=document.getElementById('eq-cat').value;
  const temp=document.getElementById('eq-temp').value;
  const eqsFilt=[...new Set(
    ACTAS.filter(a=>!isSala(a.categoria)&&(!cat||a.categoria===cat)&&(!temp||a.temporada===temp))
      .flatMap(a=>[a.equipo_local,a.equipo_visitante].filter(Boolean))
  )].sort();
  fillRaw('eq-sel',eqsFilt,'Seleccionar equipo...');
  rEq();
}
function rEqCat(){
  const cat=document.getElementById('eq-cat').value;
  const temp=document.getElementById('eq-temp').value;
  const eqsFilt=[...new Set(
    ACTAS.filter(a=>!isSala(a.categoria)&&(!cat||a.categoria===cat)&&(!temp||a.temporada===temp))
      .flatMap(a=>[a.equipo_local,a.equipo_visitante].filter(Boolean))
  )].sort();
  fillRaw('eq-sel',eqsFilt,'Seleccionar equipo...');
  rEq();
}
function rEq(){
  const eq=document.getElementById('eq-sel').value;
  const tempFilt=document.getElementById('eq-temp')?.value||'';
  const catFilt=document.getElementById('eq-cat')?.value||'';
  const cont=document.getElementById('eq-c');
  if(!eq){cont.innerHTML='<div class="empty">Selecciona un equipo</div>';return;}
  const {cl,jug}=GS();

  // ── Helper: compute classification position for a given cat+temp (usa cache) ─
  function clForCatTemp(cat, temp){
    const clCache = _buildClCache();
    const key = cat+'|||'+temp;
    const tabla = clCache[key] || {};
    const rows = Object.entries(tabla)
      .sort((a,b)=>b[1].Pts-a[1].Pts||(b[1].GF-b[1].GC)-(a[1].GF-a[1].GC)||b[1].GF-a[1].GF);
    const pos = rows.findIndex(([e])=>e===eq);
    return {pos:pos>=0?pos+1:null, total:rows.length, stats:tabla[eq]||null};
  }

  // ── Gather seasons+cats this team played in ───────────────────────────────
  const actasEq=ACTAS.filter(a=>(a.equipo_local===eq||a.equipo_visitante===eq)&&!isSala(a.categoria)&&(!catFilt||a.categoria===catFilt));
  const seenCatTemp={};
  actasEq.forEach(a=>{
    const k=(a.temporada||'?')+'|||'+(a.categoria||'Sin cat');
    if(!seenCatTemp[k]) seenCatTemp[k]={temp:a.temporada||'?',cat:a.categoria||'Sin cat'};
  });
  const temporadas=Object.values(seenCatTemp)
    .sort((a,b)=>b.temp.localeCompare(a.temp)||a.cat.localeCompare(b.cat));

  // ── Filter by season if selected ──────────────────────────────────────────
  const actas=actasEq
    .filter(a=>(!tempFilt||a.temporada===tempFilt)&&(!catFilt||a.categoria===catFilt))
    .sort((a,b)=>(a.jornada||0)-(b.jornada||0));

  // ── Overall stats (filtered) ──────────────────────────────────────────────
  let stats=null;
  if(tempFilt){
    const t={PJ:0,G:0,E:0,P:0,GF:0,GC:0,Pts:0};
    actas.forEach(a=>{
      const isL=a.equipo_local===eq;
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const gf=isL?gl:gv,gc=isL?gv:gl;
      t.PJ++;t.GF+=gf;t.GC+=gc;
      if(gf>gc){t.G++;t.Pts+=3;}else if(gf<gc){t.P++;}else{t.E++;t.Pts++;}
    });
    if(t.PJ>0) stats=t;
  } else {
    Object.values(cl).forEach(c=>{if(c[eq])stats=c[eq];});
  }
  const sh=stats?`<div class="sg">
    <div class="sc"><div class="sv">${stats.Pts}</div><div class="sl">Puntos</div></div>
    <div class="sc"><div class="sv">${stats.PJ}</div><div class="sl">Partidos</div></div>
    <div class="sc"><div class="sv" style="color:var(--hw)">${stats.G}</div><div class="sl">Victorias</div></div>
    <div class="sc y"><div class="sv">${stats.E}</div><div class="sl">Empates</div></div>
    <div class="sc r"><div class="sv">${stats.P}</div><div class="sl">Derrotas</div></div>
    <div class="sc"><div class="sv">${stats.GF}</div><div class="sl">Goles F.</div></div>
    <div class="sc r"><div class="sv">${stats.GC}</div><div class="sl">Goles C.</div></div>
    <div class="sc b"><div class="sv">${stats.GF-stats.GC>0?'+':''}${stats.GF-stats.GC}</div><div class="sl">Diferencia</div></div>
  </div>`:'';

  // ── Entrenador y campo ────────────────────────────────────────────────────
  const entCount={};
  actas.forEach(a=>{
    const ent=normEnt(a.equipo_local===eq?a.entrenador_local:a.entrenador_visitante);
    if(ent) entCount[ent]=(entCount[ent]||0)+1;
  });
  const entsSorted=Object.entries(entCount).sort((a,b)=>b[1]-a[1]);
  const mainEnt=entsSorted[0];
  const otrosEnts=entsSorted.slice(1);
  const camposCount={};
  actas.filter(a=>a.equipo_local===eq).forEach(a=>{
    if(a.estadio){const c=a.estadio.trim();camposCount[c]=(camposCount[c]||0)+1;}
  });
  const camposUnicos=Object.keys(camposCount);
  let campoHtml='';
  if(camposUnicos.length===1){campoHtml=`<span>🏟 ${camposUnicos[0]}</span>`;}
  else if(camposUnicos.length>1){
    const listaC=Object.entries(camposCount).sort((a,b)=>b[1]-a[1]).map(([c,n])=>`${c} (${n}p)`).join(', ');
    campoHtml=`<span title="${listaC}">🏟 Varios campos: ${listaC}</span>`;
  }
  // ── Actas sin entrenador ──────────────────────────────────────────────────────
  const actasSinEnt = actas.filter(a=>!(a.equipo_local===eq ? a.entrenador_local : a.entrenador_visitante));
  // Candidatos para asignar: entrenadores que ya han dirigido a este equipo (en estas actas)
  const candidatosEnt = Object.keys(entCount).sort((a,b)=>entCount[b]-entCount[a]);
  const candidatosEntAttr = JSON.stringify(candidatosEnt).replace(/"/g,'&quot;');
  const sinEntHtml = actasSinEnt.length
    ? `<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--b);font-size:11px">
        <span style="color:var(--a2);font-weight:600">⚠ Sin entrenador en ${actasSinEnt.length} acta${actasSinEnt.length!==1?'s':''}:</span>
        <span style="margin-left:6px">${actasSinEnt.map(a=>{
          const esLocal = a.equipo_local===eq;
          return `<span style="display:inline-flex;align-items:center;gap:2px;margin-right:4px">
            <span style="cursor:pointer;color:var(--a3);text-decoration:underline dotted" onclick="openMatch('${a.acta_id}')" title="${a.equipo_local} vs ${a.equipo_visitante} · ${a.fecha||''}">J${a.jornada||'?'}</span>
            <span style="cursor:pointer;color:var(--acc);font-weight:700;border:1px solid var(--b2);border-radius:3px;padding:0 4px;font-size:10px" title="Asignar entrenador" onclick="event.stopPropagation();abrirAsignarEntrenador('${a.acta_id}',${esLocal},${candidatosEntAttr},this)">+</span>
          </span>`;
        }).join(' · ')}</span>
      </div>`
    : '';
  let entHtml='';
  if(mainEnt){
    entHtml=`<div style="background:var(--s2);border:1px solid var(--b);border-radius:8px;padding:12px 14px;margin-bottom:12px">
      <div style="font-size:10px;color:var(--mu);letter-spacing:.6px;text-transform:uppercase;margin-bottom:6px;font-family:'Bebas Neue',sans-serif">Información del Club</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:13px">
        <span>👨‍💼 <span style="cursor:pointer;color:var(--acc);font-weight:600" onclick="openCoach('${mainEnt[0].replace(/'/g,"\\'")}'">${mainEnt[0]}</span> <span style="color:var(--mu);font-size:11px">(${mainEnt[1]} partidos)</span></span>
        ${campoHtml}
      </div>
      ${otrosEnts.length?`<div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--b);font-size:11px;color:var(--mu)">
        <span style="color:var(--a3)">⚠ También entrenó${otrosEnts.length>1?'n':''}:</span>
        ${otrosEnts.map(([n,c])=>`<span style="cursor:pointer;color:var(--mu)" onclick="openCoach('${n.replace(/'/g,"\\'")}')"> ${n} <span style="color:var(--b2)">(${c} jornada${c!==1?'s':''})</span></span>`).join(' ·')}
      </div>`:''}
      ${sinEntHtml}
    </div>`;
  } else if(campoHtml || actasSinEnt.length){
    entHtml=`<div style="background:var(--s2);border:1px solid var(--b);border-radius:8px;padding:12px 14px;margin-bottom:12px">
      <div style="font-size:10px;color:var(--mu);letter-spacing:.6px;text-transform:uppercase;margin-bottom:6px;font-family:'Bebas Neue',sans-serif">Información del Club</div>
      <div style="font-size:13px">${campoHtml||'<span style="color:var(--mu)">Sin entrenador registrado</span>'}</div>
      ${sinEntHtml}
    </div>`;
  }

  // ── Historial por temporadas (solo sin filtro de temporada activo) ─────────
  let histHtml='';
  if(!tempFilt && temporadas.length>0){
    // Precalcular entrenadores por temp+cat en un solo recorrido
    const entsPorTempCat={};
    actasEq.forEach(a=>{
      if(isSala(a.categoria)) return;
      const k=(a.temporada||'?')+'|||'+(a.categoria||'Sin cat');
      if(!entsPorTempCat[k]) entsPorTempCat[k]={};
      const e=normEnt(a.equipo_local===eq?a.entrenador_local:a.entrenador_visitante);
      if(e) entsPorTempCat[k][e]=(entsPorTempCat[k][e]||0)+1;
    });
    histHtml=`<div class="st" style="margin-top:16px">📅 Historial por temporada</div>
    <div class="tw" style="margin-bottom:18px"><table><thead><tr>
      <th>Temporada</th><th>Categoría</th><th style="color:var(--a3)">Posición</th>
      <th>PJ</th><th style="color:var(--hw)">G</th><th>E</th><th style="color:var(--lw)">P</th>
      <th>GF</th><th>GC</th><th>DG</th><th style="color:var(--acc)">Pts</th><th>Entrenador(es)</th>
    </tr></thead><tbody>`;
    temporadas.forEach(({temp,cat})=>{
      const {pos,total,stats:s}=clForCatTemp(cat,temp);
      if(!s)return;
      const dg=s.GF-s.GC;
      const dgC=dg>0?'gdp':dg<0?'gdn':'';
      const posBadge=pos===1?`<span style="color:var(--a3);font-weight:700">🥇 1º</span>`
        :pos===2?`<span style="color:#c0c0c0;font-weight:700">🥈 2º</span>`
        :pos===3?`<span style="color:#cd7f32;font-weight:700">🥉 3º</span>`
        :pos?`<span style="font-weight:600">${pos}º / ${total}</span>`
        :`<span style="color:var(--mu)">—</span>`;
      const entsTemp = entsPorTempCat[(temp+'|||'+cat)] || {};
      const entsTempStr=Object.entries(entsTemp).sort((a,b)=>b[1]-a[1])
        .map(([n])=>`<span style="cursor:pointer;color:var(--acc);font-size:11px" onclick="openCoach('${n.replace(/'/g,"\\'")}') ">${n}</span>`).join(', ');
      histHtml+=`<tr style="cursor:pointer;background:rgba(0,0,0,.05);transition:background .2s" onmouseover="this.style.background='rgba(0,0,0,.1)'" onmouseout="this.style.background='rgba(0,0,0,.05)'" onclick="gotoTeamSeasonCalendar('${eq.replace(/'/g,"\\'")}','${temp}','${cat.replace(/'/g,"\\'")}')">
        <td style="font-family:'JetBrains Mono',monospace;color:var(--a3);font-weight:600">${temp}</td>
        <td style="font-size:12px;color:var(--mu)">${cat}</td>
        <td class="num">${posBadge}</td>
        <td class="num">${s.PJ}</td>
        <td class="num" style="color:var(--hw)">${s.G}</td>
        <td class="num">${s.E}</td>
        <td class="num" style="color:var(--lw)">${s.P}</td>
        <td class="num">${s.GF}</td>
        <td class="num">${s.GC}</td>
        <td class="num ${dgC}">${dg>0?'+':''}${dg}</td>
        <td class="num pts">${s.Pts}</td>
        <td style="font-size:11px">${entsTempStr||'<span style="color:var(--mu)">—</span>'}</td>
      </tr>`;
    });
    histHtml+='</tbody></table></div>';
  }

  // ── Nivel del equipo (A, B, C) dentro de su club ─────────────────────────────
  const nivelEq = detectarNivelEquipo(eq, catFilt||actas[0]?.categoria||'', tempFilt);
  const NIVEL_COL = {A:'var(--acc)',B:'var(--a4)',C:'var(--a5)',D:'var(--a2)'};
  const nivelBadge = (nivelEq.letra && nivelEq.grupo)
    ? `<span style="font-size:11px;font-weight:700;color:${NIVEL_COL[nivelEq.letra]||'var(--mu)'};background:rgba(255,255,255,.08);border:1px solid ${NIVEL_COL[nivelEq.letra]||'rgba(255,255,255,.2)'};border-radius:4px;padding:2px 9px;margin-left:8px">${nivelEq.grupo} ${nivelEq.letra}</span>`
    : '';

  // ── Bloque ALTAS/BAJAS/ACABAN ──────────────────────────────────────────────
  const movHtml = tempFilt ? renderMovimientos(eq, catFilt||actas[0]?.categoria||'', tempFilt, nivelEq.grupo) : '';


  const jugEq=Object.entries(jug).filter(([,s])=>s.equipo===eq&&(!catFilt||s.cat===catFilt)).map(([n,s])=>({nombre:n,...s})).sort((a,b)=>b.mins-a.mins);
  let jugEqFilt=jugEq;
  if(tempFilt||catFilt){
    const jugTemp={};
    const pjEqTemp=actas.length;
    actas.forEach(a=>{
      const isL=a.equipo_local===eq;
      const jugsOrig=isL?a.jugadores_local:a.jugadores_visitante;
      const tits=isL?a.titulares_local:a.titulares_visitante;
      const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
      const golesAFavorEqT=(a.goleadores||[]).filter(g=>isL?(g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador))):(g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador))));
      const golesEnContraEqT=(a.goleadores||[]).filter(g=>isL?(g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador))):(g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador))));
      (jugsOrig||[]).forEach(nOrig=>{
        const n=normPerson(_rn(a.acta_id,nOrig));
        if(!jugTemp[n])jugTemp[n]={nombre:n,equipo:eq,PJ:0,tit:0,mins:0,goles:0,gfCon:0,gcCon:0};
        jugTemp[n].PJ++;
        if((tits||[]).includes(nOrig))jugTemp[n].tit++;
        jugTemp[n].mins+=(a.minutos_jugadores||{})[nOrig]||0;
        jugTemp[n].goles+=(a.goleadores||[]).filter(g=>g.jugador===nOrig&&!g.propia).length;
        // GF/GC en campo: solo los goles ocurridos mientras el jugador estaba en el campo
        let minIn=0,minOut=90;
        if((tits||[]).includes(nOrig)){
          const sal=(sust||[]).find(sx=>sx.sale===nOrig);
          if(sal) minOut=sal.min;
        } else {
          const ent=(sust||[]).find(sx=>sx.entra===nOrig);
          if(ent) minIn=ent.min;
        }
        jugTemp[n].gfCon+=golesAFavorEqT.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
        jugTemp[n].gcCon+=golesEnContraEqT.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
      });
    });
    jugEqFilt=Object.values(jugTemp).map(d=>({
      ...d,
      pjEq:pjEqTemp,
      nojug:pjEqTemp-d.PJ,
      pres:pjEqTemp>0?Math.round(d.PJ/pjEqTemp*100):0,
      gfMedia:d.PJ>0?d.gfCon/d.PJ:0,
      gcMedia:d.PJ>0?d.gcCon/d.PJ:0
    })).sort((a,b)=>b.mins-a.mins);
  }

  const pt=`<div class="st" style="margin-top:18px">Plantilla${tempFilt?' — '+tempFilt:''}${catFilt?' · '+catFilt:''} (${jugEqFilt.length} jugadores)</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px;align-items:center">
      <select id="eq-pt-anio" onchange="filtrarPlantilla()" style="font-size:12px;padding:4px 8px;background:var(--s2);border:1px solid var(--b);color:var(--tx);border-radius:6px">
        <option value="">Todos los años nac.</option>
        ${[...new Set(jugEqFilt.map(d=>{const r=getAnioNacCached(d.nombre);return r&&!r.prefijo?String(r.anio):null;}).filter(Boolean))].sort().map(y=>`<option value="${y}">${y}</option>`).join('')}
        ${jugEqFilt.some(d=>{const r=getAnioNacCached(d.nombre);return r&&r.prefijo;})?`<option value="le">Con prefijo ≤ (senior sin historial)</option>`:''}
      </select>
      <button onclick="(function(){
        const n=autoAsignarPorteros();
        if(n>0){
          // Actualizar en tiempo real los <select> de posición visibles en la tabla
          document.querySelectorAll('select[data-pos-nombre]').forEach(sel=>{
            const nom=sel.getAttribute('data-pos-nombre');
            const pos=getPosicion(nom);
            if(pos){
              sel.value=pos;
              const colores={POR:'#f5c842',LTD:'#4d8bff',LTI:'#4d8bff',DFC:'#00f0a0',MC:'#b06fff',MP:'#b06fff',ED:'#ff9040',EI:'#ff9040',DEL:'#f24141'};
              sel.style.color=colores[pos]||'var(--tx)';
            }
          });
          rSc&&rSc();
          toast('🧤 '+n+' portero'+(n>1?'s asignados':' asignado')+' con POR','ok');
        }else{toast('Sin porteros nuevos que asignar','ok');}
      })()"
        style="font-size:11px;padding:3px 10px;background:rgba(245,200,66,.12);border:1px solid rgba(245,200,66,.4);color:#f5c842;border-radius:6px;cursor:pointer;white-space:nowrap"
        title="Asigna POR a todos los jugadores con ≥300 min como portero o ≥4 partidos de portero. REQUIERE haber regenerado el HTML con el nuevo script.">
        🧤 Auto-asignar porteros
      </button>
    </div>
    <div class="tw"><table id="eq-pt-tbl"><thead><tr>
      <th onclick="sortEqTable(this,0)" title="Jugador">Jugador ↕</th>
      <th onclick="sortEqTable(this,1)" title="Año de nacimiento inferido" style="color:var(--a4)">Año nac. ↕</th>
      <th onclick="sortEqTable(this,14)" title="Posición">Pos ↕</th>
      <th onclick="sortEqTable(this,15)" title="Pie dominante">Pie ↕</th>
      <th onclick="sortEqTable(this,2)" title="Partidos del equipo">PJ eq. ↕</th>
      <th onclick="sortEqTable(this,3)" title="Partidos jugados">Jugados ↕</th>
      <th onclick="sortEqTable(this,4)" style="color:var(--a2)" title="No jugados">No jug. ↕</th>
      <th onclick="sortEqTable(this,5)" title="Titular">Tit ↕</th>
      <th onclick="sortEqTable(this,6)">MIN ↕</th>
      <th onclick="sortEqTable(this,7)">⚽ ↕</th>
      <th onclick="sortEqTable(this,8)" title="Minutos por partido">Min/P ↕</th>
      <th onclick="sortEqTable(this,9)" title="Goles por partido" style="color:var(--hw)">Gls/P ↕</th>
      <th onclick="sortEqTable(this,10)" title="Goles a favor del equipo por partido estando en campo" style="color:var(--hw)">GF/P ↕</th>
      <th onclick="sortEqTable(this,11)" title="Goles en contra del equipo por partido estando en campo" style="color:var(--a2)">GC/P ↕</th>
      <th onclick="sortEqTable(this,12)">Pres.% ↕</th>
    </tr></thead><tbody>
    ${jugEqFilt.map(d=>{
      const rAnio=getAnioNacCached(d.nombre);
      const anioTxt=rAnio?(rAnio.prefijo?rAnio.prefijo+rAnio.anio:String(rAnio.anio)):'—';
      const anioStyle=rAnio?`color:${rAnio.fuente==='manual'?'var(--hw)':rAnio.prefijo?'var(--mu)':'var(--a4)'}`:''
      const posActual=getPosicion(d.nombre);
      const pieActual=getPie(d.nombre);
      const safeN=d.nombre.replace(/\\\\/g,'\\\\\\\\').replace(/'/g,"\\\\'");
      const optsPos=POSICIONES.map(p=>`<option value="${p.v}"${p.v===posActual?' selected':''}>${p.v||'—'}</option>`).join('');
      const optsPie=PIES.map(p=>`<option value="${p.v}"${p.v===pieActual?' selected':''}>${p.v?p.l:'—'}</option>`).join('');
      const colPos=(()=>{const c={POR:'#f5c842',LTD:'#4d8bff',LTI:'#4d8bff',DFC:'#00f0a0',MC:'#b06fff',MP:'#b06fff',ED:'#ff9040',EI:'#ff9040',DEL:'#f24141'};return posActual&&c[posActual]?c[posActual]:'var(--tx)';})();
      const colPie=pieActual==='Z'?'#b06fff':pieActual==='D'?'#4d8bff':'var(--tx)';
      return `<tr onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}') " style="cursor:pointer" data-anio="${rAnio&&!rAnio.prefijo?rAnio.anio:rAnio?'le':''}">
      <td style="font-weight:600;color:var(--acc)">${d.nombre}${portTag(d.nombre)}</td>
      <td class="num" style="${anioStyle};font-family:'JetBrains Mono',monospace;font-size:12px">${anioTxt}</td>
      <td onclick="event.stopPropagation()" style="padding:2px 4px">
        <select data-pos-nombre="${d.nombre.replace(/"/g,'&quot;')}" onchange="(function(sel,v){setPosicion('${safeN}',v);sel.style.color=({POR:'#f5c842',LTD:'#4d8bff',LTI:'#4d8bff',DFC:'#00f0a0',MC:'#b06fff',MP:'#b06fff',ED:'#ff9040',EI:'#ff9040',DEL:'#f24141'}[v]||'var(--tx)');toast(v?'Posición: '+v:'Posición eliminada','ok');})(this,this.value)"
          style="background:var(--s2);border:1px solid var(--b);color:${colPos};border-radius:5px;padding:2px 4px;font-size:11px;font-weight:700;font-family:'JetBrains Mono',monospace;outline:none;cursor:pointer;width:60px">
          ${optsPos}
        </select>
      </td>
      <td onclick="event.stopPropagation()" style="padding:2px 4px">
        <select onchange="(function(sel,v){setPie('${safeN}',v);sel.style.color=v==='Z'?'#b06fff':v==='D'?'#4d8bff':'var(--tx)';toast(v?'Pie: '+(v==='Z'?'Zurdo':'Diestro'):'Pie eliminado','ok');})(this,this.value)"
          style="background:var(--s2);border:1px solid var(--b);color:${colPie};border-radius:5px;padding:2px 4px;font-size:11px;font-weight:600;outline:none;cursor:pointer;width:68px">
          ${optsPie}
        </select>
      </td>
      <td class="num">${d.pjEq}</td><td class="num">${d.PJ}</td>
      <td class="num" style="color:${d.nojug>0?'var(--a2)':'var(--mu)'}">${d.nojug}</td>
      <td class="num">${d.tit}</td><td class="num">${d.mins}</td>
      <td class="num">${d.goles||0}</td>
      <td class="num">${d.PJ>0?(d.mins/d.PJ).toFixed(0):0}</td>
      <td class="num" style="color:var(--hw)">${d.PJ>0?((d.goles||0)/d.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--hw)">${(d.gfMedia||0).toFixed(2)}</td>
      <td class="num" style="color:var(--a2)">${(d.gcMedia||0).toFixed(2)}</td>
      <td class="num">${d.pres}%</td></tr>`;}).join('')}
    </tbody></table></div>`;
  const mh=`<div class="st" style="margin-top:18px">Partidos (${actas.length})${tempFilt?' — '+tempFilt:''}</div>`+
    actas.sort((a,b)=>(b.jornada||0)-(a.jornada||0)).map(a=>{
      const isL=a.equipo_local===eq;
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const eg=isL?gl:gv,rg=isL?gv:gl;
      return `<div class="mc" onclick="openMatch('${a.acta_id}')">
        <div class="mm">J${a.jornada||'?'}<br>${a.fecha||''}</div>
        <div class="mts">
          <div class="mt h">${eq}</div>
          <div class="ms ${c2(eg,rg)}">${eg} — ${rg}</div>
          <div class="mt">vs ${isL?a.equipo_visitante:a.equipo_local}</div>
        </div></div>`;
    }).join('');
  // ── Badge de nivel en la cabecera ─────────────────────────────────────────
  const logoEq = logoHtml(eq, 'team-logo-lg');
  const cabeceraNivel = nivelBadge
    ? `<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;padding:12px 16px;background:var(--s2);border:1px solid var(--b);border-radius:10px">
        ${logoEq}
        <div>
          <div style="font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:1px">${eq}${nivelBadge}</div>
          ${tempFilt?`<div style="font-size:11px;color:var(--mu);margin-top:3px">📅 ${tempFilt}</div>`:''}
        </div>
      </div>`
    : '';

  cont.innerHTML=cabeceraNivel+sh+entHtml+histHtml+movHtml+pt+mh;
}

// ── H2H ───────────────────────────────────────────────────────────────────────
function rH2(){
  const e1=document.getElementById('h2-a').value,e2=document.getElementById('h2-b').value;
  const cont=document.getElementById('h2-c');
  if(!e1||!e2||e1===e2){cont.innerHTML='<div class="empty">Selecciona dos equipos distintos</div>';return;}
  const {enf}=GS();
  const ee=enf.filter(e=>(e.L===e1&&e.V===e2)||(e.L===e2&&e.V===e1));
  if(!ee.length){cont.innerHTML='<div class="empty">Sin enfrentamientos</div>';return;}
  let w1=0,w2=0,dr=0,g1t=0,g2t=0;
  ee.forEach(e=>{const g1=e.L===e1?e.gl:e.gv,g2=e.L===e1?e.gv:e.gl;g1t+=g1;g2t+=g2;if(g1>g2)w1++;else if(g1<g2)w2++;else dr++;});
  cont.innerHTML=`
    <div class="h2hg">
      <div>
        <div class="h2ht">${e1}</div>
        <div style="display:flex;justify-content:center;gap:24px;margin-top:12px">
          <div style="text-align:center"><div style="font-family:'Bebas Neue',sans-serif;font-size:36px;color:var(--hw)">${w1}</div><div style="font-size:10px;color:var(--mu)">VICTORIAS</div></div>
          <div style="text-align:center"><div style="font-family:'Bebas Neue',sans-serif;font-size:36px">${g1t}</div><div style="font-size:10px;color:var(--mu)">GOLES</div></div>
        </div>
      </div>
      <div style="font-family:'Bebas Neue',sans-serif;font-size:28px;color:var(--mu)">VS</div>
      <div>
        <div class="h2ht">${e2}</div>
        <div style="display:flex;justify-content:center;gap:24px;margin-top:12px">
          <div style="text-align:center"><div style="font-family:'Bebas Neue',sans-serif;font-size:36px;color:var(--hw)">${w2}</div><div style="font-size:10px;color:var(--mu)">VICTORIAS</div></div>
          <div style="text-align:center"><div style="font-family:'Bebas Neue',sans-serif;font-size:36px">${g2t}</div><div style="font-size:10px;color:var(--mu)">GOLES</div></div>
        </div>
      </div>
    </div>
    <div style="text-align:center;color:var(--mu);font-size:12px;margin-bottom:12px">${dr} empate${dr!==1?'s':''} · ${ee.length} partido${ee.length!==1?'s':''}</div>
    ${ee.sort((a,b)=>(b.jornada||0)-(a.jornada||0)).map(e=>{
      const g1=e.L===e1?e.gl:e.gv,g2=e.L===e1?e.gv:e.gl;
      return `<div class="mc" onclick="openMatch('${e.id}')">
        <div class="mm">J${e.jornada||'?'}<br>${e.fecha||''}</div>
        <div class="mts">
          <div class="mt h">${e1}</div>
          <div class="ms ${c2(g1,g2)}">${g1} — ${g2}</div>
          <div class="mt">${e2}</div>
        </div></div>`;
    }).join('')}`;
}

// ── SCOUTING ──────────────────────────────────────────────────────────────────

// Calcula un score de interés scout normalizado 0-100
// Pondera: minutos (40%), presencia% (25%), goles/partido (20%), GF/P equipo (15%)
function scoutScore(d, maxMins, maxGlspp, maxGf){
  const wMin  = (d.mins/(maxMins||1))*40;
  const wPres = (d.pres/100)*25;
  const gpp   = d.PJ>0?(d.goles/d.PJ):0;
  const wGol  = (gpp/(maxGlspp||0.01))*20;
  const wGF   = ((d.gfMedia||0)/(maxGf||0.01))*15;
  return Math.min(100, Math.round(wMin+wPres+wGol+wGF));
}

function scScoreBadge(score){
  const col = score>=80?'var(--hw)':score>=55?'var(--a3)':score>=35?'var(--acc)':'var(--mu)';
  const bg  = score>=80?'rgba(0,240,160,.12)':score>=55?'rgba(245,200,66,.12)':score>=35?'rgba(77,139,255,.12)':'rgba(255,255,255,.06)';
  return `<span style="font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;color:${col};background:${bg};border:1px solid ${col};border-radius:4px;padding:1px 6px">${score}</span>`;
}

// Mini barra de progreso inline
function miniBar(val, max, color){
  const pct = Math.round((val/(max||1))*100);
  return `<div style="height:3px;background:rgba(255,255,255,.08);border-radius:2px;margin-top:3px;overflow:hidden"><div style="height:100%;width:${pct}%;background:${color||'var(--acc)'};border-radius:2px;transition:width .3s"></div></div>`;
}

function rSc(){
  const cat    = document.getElementById('sc-cat')?.value||'';
  const eq     = document.getElementById('sc-eq')?.value||'';
  const prov   = document.getElementById('sc-prov')?.value||'';
  const fed    = document.getElementById('sc-fed')?.value||'';
  const pos    = document.getElementById('sc-pos')?.value||'';
  const temp   = document.getElementById('sc-temp')?.value||'';
  const minMins= parseInt(document.getElementById('sc-min-mins')?.value||'0')||0;
  const minPJ  = parseInt(document.getElementById('sc-min-pj')?.value||'0')||0;
  const busq   = (document.getElementById('sc-s')?.value||'').trim().toLowerCase();
  const filtAnioSc = document.getElementById('sc-anio')?.value||'';
  const ord    = document.getElementById('sc-ord')?.value||'pres';

  const {jug}=GS();

  let data=Object.entries(jug)
    .filter(([n,s])=>{
      if(cat   && s.cat!==cat)   return false;
      if(eq    && s.equipo!==eq) return false;
      if(prov  && !jugadorPassProv(s,prov)) return false;
      if(fed   && !(s.fuentes instanceof Set ? s.fuentes.has(fed) : false)) return false;
      if(pos==='port' && !isPort(n))  return false;
      if(pos==='campo' && isPort(n))  return false;
      if(temp){
        // Filtrar por temporada: el jugador debe tener partidos en esa temporada
        const tieneTemp = ACTAS.some(a=>a.temporada===temp&&(
          (a.jugadores_local||[]).includes(n)||(a.jugadores_visitante||[]).includes(n)));
        if(!tieneTemp) return false;
      }
      if(s.mins   < minMins) return false;
      if(s.PJ     < minPJ)   return false;
      if(busq && !n.toLowerCase().includes(busq) && !(s.equipo||'').toLowerCase().includes(busq)) return false;
      if(filtAnioSc){
        const r=inferirAnio(n);
        if(filtAnioSc==='le2006'){
          if(!r||!r.prefijo||r.anio>2006) return false;
        } else {
          if(!r||r.prefijo||String(r.anio)!==filtAnioSc) return false;
        }
      }
      return true;
    })
    .map(([n,s])=>({nombre:n,...s}));

  // Pre-calcular maximos para scores
  const maxMins  = data.reduce((m,d)=>Math.max(m,d.mins),1);
  const maxGlspp = data.reduce((m,d)=>Math.max(m,d.PJ>0?d.goles/d.PJ:0),0.01);
  const maxGf    = data.reduce((m,d)=>Math.max(m,d.gfMedia||0),0.01);
  data = data.map(d=>({...d, score:scoutScore(d,maxMins,maxGlspp,maxGf)}));

  // ── TOP MINUTOS ──────────────────────────────────────────────
  const topMin=[...data].sort((a,b)=>b.mins-a.mins).slice(0,10);
  const mx=topMin[0]?.mins||1;
  document.getElementById('sc-m').innerHTML=topMin.map((d,i)=>`<div class="sr">
    <span class="srk">${i+1}</span>
    <div style="flex:1;min-width:0">
      <div style="display:flex;align-items:center;gap:6px">
        <span style="font-weight:600;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}'">${d.nombre}</span>
        ${portTag(d.nombre)}
      </div>
      <div style="font-size:11px;color:var(--mu)">${d.equipo} · ${d.PJ}PJ · ${d.tit}tit · ${d.pres}%</div>
      ${miniBar(d.mins,mx,'var(--acc)')}
    </div>
    <div style="text-align:right;flex-shrink:0">
      <div style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--acc)">${d.mins}'</div>
      ${scScoreBadge(d.score)}
    </div>
    ${starBtn(d.nombre)}
  </div>`).join('')||'<div class="empty">Sin datos</div>';

  // ── TOP GOLEADORES ────────────────────────────────────────────
  const topGol=[...data].filter(d=>d.goles>0).sort((a,b)=>b.goles!==a.goles?b.goles-a.goles:(b.PJ>0?b.goles/b.PJ:0)-(a.PJ>0?a.goles/a.PJ:0)).slice(0,10);
  const mxGol=topGol[0]?.goles||1;
  document.getElementById('sc-top-gol').innerHTML=topGol.map((d,i)=>{
    const gpp=d.PJ>0?(d.goles/d.PJ).toFixed(2):0;
    return `<div class="sr">
    <span class="srk">${i+1}</span>
    <div style="flex:1;min-width:0">
      <div style="display:flex;align-items:center;gap:6px">
        <span style="font-weight:600;cursor:pointer" onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}'">${d.nombre}</span>
        ${portTag(d.nombre)}
      </div>
      <div style="font-size:11px;color:var(--mu)">${d.equipo} · ${d.PJ}PJ · <span style="color:var(--hw)">${gpp} gls/P</span></div>
      ${miniBar(d.goles,mxGol,'var(--hw)')}
    </div>
    <span style="font-family:'JetBrains Mono',monospace;font-size:13px;color:var(--hw);flex-shrink:0">⚽${d.goles}</span>
    ${starBtn(d.nombre)}
  </div>`;}).join('')||'<div class="empty">Sin goles registrados</div>';

  // ── BAJO EL RADAR (muchos min, pres alta, pocos goles — jugadores de equipo) ──
  const radar=[...data]
    .filter(d=>d.mins>=200&&d.pres>=60&&!isPort(d.nombre))
    .sort((a,b)=>{
      // Score inverso: alta presencia + muchos minutos pero pocos goles conocidos
      const scA=(a.pres/100)*0.5+(a.mins/maxMins)*0.5-(a.PJ>0?(a.goles/a.PJ):0)*2;
      const scB=(b.pres/100)*0.5+(b.mins/maxMins)*0.5-(b.PJ>0?(b.goles/b.PJ):0)*2;
      return scB-scA;
    }).slice(0,10);
  document.getElementById('sc-radar').innerHTML=radar.map((d,i)=>`<div class="sr">
    <span class="srk">${i+1}</span>
    <div style="flex:1;min-width:0">
      <div style="display:flex;align-items:center;gap:6px">
        <span style="font-weight:600;cursor:pointer" onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}'">${d.nombre}</span>
      </div>
      <div style="font-size:11px;color:var(--mu)">${d.equipo} · ${d.mins}' · <span style="color:var(--a3)">${d.pres}% pres.</span></div>
    </div>
    <div style="text-align:right;flex-shrink:0;font-size:11px;color:var(--mu)">${d.PJ}PJ/${d.tit}tit</div>
    ${starBtn(d.nombre)}
  </div>`).join('')||'<div class="empty">Sin datos (ajusta filtros)</div>';

  // ── PLANTILLA ─────────────────────────────────────────────────
  if(eq){
    const jugEq=[...data].filter(d=>d.equipo===eq).sort((a,b)=>b.mins-a.mins);
    const mxEq=jugEq[0]?.mins||1;
    document.getElementById('sc-r').innerHTML=
      `<div style="font-weight:700;margin-bottom:8px;color:var(--acc);font-family:'Bebas Neue',sans-serif;letter-spacing:1px">${eq}</div>`+
      jugEq.map((d,i)=>`<div class="sr">
        <span class="srk" style="color:${isPort(d.nombre)?'var(--a3)':'var(--mu)'}">${isPort(d.nombre)?'🧤':i+1}</span>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:5px">
            <span style="cursor:pointer;font-weight:500;font-size:13px" onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}'">${d.nombre}</span>
          </div>
          <div style="font-size:10px;color:var(--mu);margin-top:1px">
            ${d.tit}tit · ${d.nojug}no · ${d.mins}' · ${d.pres}%${d.goles?' · ⚽'+d.goles:''}
            ${d.gfMedia>0?` · GF/P:<span style="color:var(--hw)">${d.gfMedia.toFixed(2)}</span>`:''}
          </div>
          ${miniBar(d.mins,mxEq,'rgba(77,139,255,.6)')}
        </div>
        <div style="flex-shrink:0;text-align:right">${scScoreBadge(d.score)}${starBtn(d.nombre)}</div>
      </div>`).join('')+(!jugEq.length?'<div class="empty">Sin jugadores</div>':'');
  } else {
    document.getElementById('sc-r').innerHTML='<div class="empty" style="padding:30px 20px">Selecciona un equipo para ver la plantilla</div>';
  }

  // ── TABLA COMPLETA ────────────────────────────────────────────
  const sorted=[...data].sort((a,b)=>{
    if(ord==='mins')   return b.mins-a.mins;
    if(ord==='goles')  return b.goles-a.goles;
    if(ord==='pj')     return b.PJ-a.PJ;
    if(ord==='tit')    return b.tit-a.tit;
    if(ord==='glspp')  return (b.PJ>0?b.goles/b.PJ:0)-(a.PJ>0?a.goles/a.PJ:0);
    if(ord==='minpp')  return (b.PJ>0?b.mins/b.PJ:0)-(a.PJ>0?a.mins/a.PJ:0);
    if(ord==='gfMedia')return (b.gfMedia||0)-(a.gfMedia||0);
    if(ord==='gcMedia')return (a.gcMedia||0)-(b.gcMedia||0);
    if(ord==='score')  return b.score-a.score;
    if(ord==='name')   return a.nombre.localeCompare(b.nombre);
    return b.pres-a.pres; // default: presencia
  });

  document.getElementById('sc-total-count').textContent=`${sorted.length} jugadores`;

  document.getElementById('sc-b').innerHTML=sorted.map((d,i)=>{
    const gpp=d.PJ>0?(d.goles/d.PJ).toFixed(2):'-';
    const mpp=d.PJ>0?Math.round(d.mins/d.PJ):'-';
    const nojugCol=d.nojug>0?'var(--a2)':'var(--mu)';
    const presCol=d.pres>=80?'var(--hw)':d.pres>=50?'var(--a3)':'var(--mu)';
    return `<tr onclick="openPlayer('${d.nombre.replace(/'/g,"\\'")}')\" style="cursor:pointer">
      <td class="num" style="color:var(--mu)">${i+1}</td>
      <td style="font-weight:600;color:var(--acc);white-space:nowrap">${d.nombre}${portTag(d.nombre)}</td>
      <td style="font-size:12px;color:var(--mu);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${d.equipo}</td>
      <td class="num" style="color:var(--mu)">${d.pjEq}</td>
      <td class="num">${d.PJ}</td>
      <td class="num" style="color:${nojugCol}">${d.nojug}</td>
      <td class="num">${d.tit}</td>
      <td class="num">${d.mins}</td>
      <td class="num" style="color:var(--mu)">${mpp}</td>
      <td class="num">${d.goles||0}</td>
      <td class="num" style="color:var(--hw)">${gpp}</td>
      <td class="num" style="color:var(--hw)">${(d.gfMedia||0).toFixed(2)}</td>
      <td class="num" style="color:var(--a2)">${(d.gcMedia||0).toFixed(2)}</td>
      <td class="num" style="color:${presCol};font-weight:600">${d.pres}%</td>
      <td class="num" onclick="event.stopPropagation()">${scScoreBadge(d.score)}</td>
      <td onclick="event.stopPropagation()">${starBtn(d.nombre)}</td>
    </tr>`;
  }).join('');

  renderFavSc();
}

// ── MODALES ───────────────────────────────────────────────────────────────────
function openMatch(id){
  const a=DB[id];if(!a)return;
  const gl=a.goles_local||0,gv=a.goles_visitante||0;
  const cs=c2(gl,gv);
  const scCol=cs==='hw'?'var(--hw)':cs==='aw'?'var(--lw)':'var(--dr)';
  const lineup=(tits,jugs,susts,goles,tarj,portero)=>{
    return (tits||[]).map(n=>{
      const g=(goles||[]).filter(x=>x.jugador===n).length;
      const t=(tarj||[]).filter(x=>x.jugador===n).length;
      const s=(susts||[]).find(x=>x.sale===n);
      const isPort=(portero&&portero===n);
      return `<div class="pl"><span style="color:var(--a3);font-size:9px">●</span>
        <span style="flex:1;font-weight:500">${n}${isPort?' 🧤':''}</span>
        ${g?'⚽'.repeat(Math.min(g,3)):''}${t?'🟨':''}
        ${s?`<span style="color:var(--a2);font-size:10px">↕${s.min}'</span>`:''}
      </div>`;
    }).join('')+(jugs||[]).filter(n=>!(tits||[]).includes(n)).map(n=>{
      const g=(goles||[]).filter(x=>x.jugador===n).length;
      const s=(susts||[]).find(x=>x.entra===n);
      const isPort=(portero&&portero===n);
      return `<div class="pl" style="opacity:.65"><span style="color:var(--mu);font-size:9px">○</span>
        <span style="flex:1">${n}${isPort?' 🧤':''}</span>
        ${g?'⚽'.repeat(Math.min(g,3)):''}
        ${s?`<span style="color:var(--acc);font-size:10px">↑${s.min}'</span>`:''}
      </div>`;
    }).join('');
  };
  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">Acta del Partido</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    <div style="text-align:center;font-size:11px;color:var(--mu);font-family:'JetBrains Mono',monospace">J${a.jornada||'?'} · ${a.fecha||''} ${a.hora||''}</div>
    <div style="text-align:center;font-size:11px;color:var(--mu);margin:2px 0 8px">${a.categoria||''}</div>
    <div style="text-align:center;font-size:16px;font-weight:700">${a.equipo_local} vs ${a.equipo_visitante}</div>
    <div class="mscore" style="color:${scCol}">${gl} — ${gv}</div>
    ${a.estadio?`<div style="text-align:center;font-size:12px;color:var(--mu)">🏟 ${a.estadio}${a.ciudad?', '+a.ciudad:''}</div>`:''}
    ${(a.arbitros&&a.arbitros.length)?`<div style="text-align:center;font-size:12px;color:var(--mu);margin-top:3px">⚖ ${a.arbitros.map(arb=>`<span style="cursor:pointer;text-decoration:underline dotted" onclick="openReferee('${arb.replace(/'/g,"\\'")}');event.stopPropagation()">${arb}</span>`).join(' · ')}</div>`:a.arbitro?`<div style="text-align:center;font-size:12px;color:var(--mu);margin-top:3px">⚖ <span style="cursor:pointer;text-decoration:underline dotted" onclick="openReferee('${(a.arbitro||'').replace(/'/g,"\\'")}');event.stopPropagation()">${a.arbitro}</span></div>`:''}
    ${(a.goleadores||[]).length?`<div style="margin:14px 0;padding:12px;background:var(--s2);border-radius:8px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:12px;letter-spacing:1px;color:var(--mu);margin-bottom:6px">GOLES</div>
      ${(a.goleadores||[]).map(g=>`<div style="font-size:13px;padding:2px 0">${g.propia?'<span title="Gol en propia puerta" style="font-size:11px;font-weight:700;color:var(--a2)">PP</span>':"⚽"} ${g.minuto}' — <b>${g.jugador}</b> <span style="color:var(--mu);font-size:11px">(${g.equipo==='local'?a.equipo_local:g.equipo==='visitante'?a.equipo_visitante:'?'}${g.propia?' · propia':''})</span></div>`).join('')}
    </div>`:''}
    ${(a.tarjetas||[]).length?`<div style="margin:0 0 14px;padding:12px;background:var(--s2);border-radius:8px">
      <div style="font-family:'Bebas Neue',sans-serif;font-size:12px;letter-spacing:1px;color:var(--mu);margin-bottom:6px">TARJETAS</div>
      ${(a.tarjetas||[]).map(t=>`<div style="font-size:13px;padding:2px 0">${t.tipo==='doble_amarilla'?'🟨🟥':t.tipo==='roja'?'🟥':'🟨'} ${t.minuto}' — ${t.jugador} <span style="color:var(--mu);font-size:11px">(${t.equipo==='local'?a.equipo_local:t.equipo==='visitante'?a.equipo_visitante:'?'})</span></div>`).join('')}
    </div>`:''}
    <div class="twocol">
      <div>
        <div class="coltit">${a.equipo_local}</div>
        <div style="font-size:10px;color:var(--mu);margin-bottom:6px;line-height:1.8">
          ${a.entrenador_local?`<span style="cursor:pointer" onclick="openCoach('${a.entrenador_local.replace(/'/g,"\\'")}')">👨‍💼 ${a.entrenador_local}</span>`:''}${a.segundo_entrenador_local?`<br>2º ${a.segundo_entrenador_local}`:''}${a.delegado_equipo_local?`<br>Del.Eq: ${a.delegado_equipo_local}`:''}${a.delegado_campo_local?`<br>Del.Campo: ${a.delegado_campo_local}`:''}
        </div>
        ${lineup(a.titulares_local,a.jugadores_local,a.sustituciones_local,a.goleadores,a.tarjetas,a.portero_local)}
        ${(a.convocados_sin_jugar_local||[]).length?`<div style="margin-top:8px;padding-top:6px;border-top:1px solid var(--b)"><div style="font-size:10px;color:var(--mu);margin-bottom:4px">NO JUGARON</div>${(a.convocados_sin_jugar_local||[]).map(n=>`<div class="pl" style="opacity:.4;font-size:11px">— ${n}</div>`).join('')}</div>`:''}
      </div>
      <div>
        <div class="coltit">${a.equipo_visitante}</div>
        <div style="font-size:10px;color:var(--mu);margin-bottom:6px;line-height:1.8">
          ${a.entrenador_visitante?`<span style="cursor:pointer" onclick="openCoach('${a.entrenador_visitante.replace(/'/g,"\\'")}')">👨‍💼 ${a.entrenador_visitante}</span>`:''}${a.segundo_entrenador_visitante?`<br>2º ${a.segundo_entrenador_visitante}`:''}${a.delegado_equipo_visitante?`<br>Del.Eq: ${a.delegado_equipo_visitante}`:''}${a.delegado_campo_visitante?`<br>Del.Campo: ${a.delegado_campo_visitante}`:''}
        </div>
        ${lineup(a.titulares_visitante,a.jugadores_visitante,a.sustituciones_visitante,a.goleadores,a.tarjetas,a.portero_visitante)}
        ${(a.convocados_sin_jugar_visitante||[]).length?`<div style="margin-top:8px;padding-top:6px;border-top:1px solid var(--b)"><div style="font-size:10px;color:var(--mu);margin-bottom:4px">NO JUGARON</div>${(a.convocados_sin_jugar_visitante||[]).map(n=>`<div class="pl" style="opacity:.4;font-size:11px">— ${n}</div>`).join('')}</div>`:''}
      </div>
    </div>`;
  document.getElementById('modal-bg').classList.add('open');
}

function openPlayer(nombre){
  const {jug}=GS();const s=jug[nombre];if(!s)return;
  // Buscar partidos por todos los nombres (canon + variantes fusionadas + resolución [1]/[2])
  const partidos=ACTAS.filter(a=>{
    if(isSala(a.categoria)) return false;
    return _jugNombreEnActa(a, nombre) !== null;
  }).sort((a,b)=>(b.jornada||0)-(a.jornada||0));

  // ── Calcular trayectoria por temporada con soporte multi-equipo/multi-liga ──
  // tempData[temp][eq_cat_key] = stats por equipo+categoría dentro de esa temporada
  const tempData={};  // { temp: { key: {equipo,cat,PJ,tit,mins,goles,V,E,D,GC} } }
  // tempSeq[temp] = secuencia cronológica de equipos (para detectar homónimos)
  const tempSeq={};
  const esPortero=isPort(nombre);
  const partidosAsc=partidos.slice().sort((a,b)=>(a.jornada||0)-(b.jornada||0)||(a.fecha||'').localeCompare(b.fecha||''));
  partidosAsc.forEach(a=>{
    const temp=a.temporada||'?';
    // Obtener el nombre original con el que aparece en esta acta
    const nEnActa = _jugNombreEnActa(a, nombre) || nombre;
    const isL=(a.jugadores_local||[]).includes(nEnActa);
    const eq=isL?a.equipo_local:a.equipo_visitante;
    const cat=a.categoria||'';
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    const eg=isL?gl:gv,rg=isL?gv:gl;
    const mins=(a.minutos_jugadores||{})[nEnActa]||0;
    const goles=(a.goleadores||[]).filter(g=>g.jugador===nEnActa&&!g.propia).length;
    const esTit=(isL?a.titulares_local:a.titulares_visitante||[]).includes(nEnActa);
    if(!tempData[temp]) tempData[temp]={};
    if(!tempSeq[temp]) tempSeq[temp]=[];
    // Clave combinada equipo+categoría para diferenciar tramos.
    // Se normaliza (espacios, mayúsculas, acentos) para que pequeñas variaciones
    // de formato del mismo equipo/categoría (p.ej. "Zarautz K.E." vs "ZARAUTZ K.E. ")
    // entre actas de distintas fuentes no se traten como tramos distintos.
    const eqKey=(eq||'').replace(/\s+/g,' ').trim();
    const key=_normCat(eqKey)+'|||'+_normCat(cat);
    if(!tempData[temp][key]) tempData[temp][key]={equipo:eq,cat,PJ:0,tit:0,mins:0,goles:0,V:0,E:0,D:0,GC:0,GF:0};
    const td=tempData[temp][key];
    td.PJ++;if(esTit)td.tit++;td.mins+=mins;td.goles+=goles;
    if(eg>rg)td.V++;else if(eg<rg)td.D++;else td.E++;
    // Calcular minutos en campo (entrada/salida) — se usa para GF y GC,
    // para TODOS los jugadores (no solo porteros): la tarjeta "GC/P campo"
    // del perfil se muestra para cualquier jugador, así que GC no puede
    // calcularse solo cuando esPortero es true (ese era el bug: GC/P
    // campo salía siempre 0.00 para jugadores de campo).
    {
      const tits=isL?a.titulares_local:a.titulares_visitante;
      const sust=isL?a.sustituciones_local:a.sustituciones_visitante;
      let minIn=0,minOut=90;
      if(Array.isArray(tits)&&tits.includes(nEnActa)){
        const sal=Array.isArray(sust)?sust.find(sx=>sx.sale===nEnActa):null;
        if(sal)minOut=sal.min;
      } else {
        const ent=Array.isArray(sust)?sust.find(sx=>sx.entra===nEnActa):null;
        if(ent)minIn=ent.min;
      }
      // Goles a favor del equipo del jugador, mientras estaba en el campo
      const golesAFavorEq=(a.goleadores||[]).filter(g=>{
        if(isL) return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
        return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
      });
      td.GF+=golesAFavorEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
      // Goles en contra del equipo del jugador, mientras estaba en el campo
      const golesContraEq=(a.goleadores||[]).filter(g=>{
        if(isL) return g.equipo==='visitante'||(!g.equipo&&(a.jugadores_visitante||[]).includes(g.jugador));
        return g.equipo==='local'||(!g.equipo&&(a.jugadores_local||[]).includes(g.jugador));
      });
      td.GC+=golesContraEq.filter(g=>g.minuto>=minIn&&g.minuto<=minOut).length;
    }
    // Añadir a secuencia si cambia de equipo respecto al último (comparación normalizada)
    const last=tempSeq[temp][tempSeq[temp].length-1];
    if(!last||_normCat(last)!==_normCat(eqKey)) tempSeq[temp].push(eq);
  });

  // ── Detección de homónimos: dos jugadores distintos con el mismo nombre ──
  // Criterio: dentro de una temporada la secuencia de equipos oscila A→B→A→B
  // entre clubes que NO son filiales entre sí (no comparten club matriz).
  // Si son filiales (mismo clubKey) el vaivén es ascenso/descenso legítimo.
  function _clubMatriz(eq){
    // Reutiliza la misma lógica de getClubKey del motor de clubes
    if(typeof getClubKey==='function') return getClubKey(eq);
    return (eq||'').replace(/[.,]/g,'').replace(/\s+/g,' ').trim().toUpperCase().replace(/\s+[ABCD]$/,'');
  }
  function _esOscilacionNoFilial(seq){
    // seq = ['EquipoA','EquipoB','EquipoA','EquipoB', ...]
    // Detectar si hay al menos 3 cambios y el par (A,B) se repite en no-filial
    if(seq.length<4) return false;
    // Contar alternancias: A→B→A cuenta como 2 vueltas al mismo par
    let alternancias=0;
    for(let i=2;i<seq.length;i++){
      if(seq[i]===seq[i-2]&&seq[i]!==seq[i-1]){
        // El equipo de hace 2 pasos vuelve → es una alternancia
        // Comprobar que los dos equipos involucrados NO son filiales
        const mA=_clubMatriz(seq[i]);
        const mB=_clubMatriz(seq[i-1]);
        if(mA!==mB) alternancias++;
      }
    }
    return alternancias>=2; // al menos dos vueltas al mismo par no-filial
  }

  // Construir filas de trayectoria: una fila por temporada (resumen sumado)
  // Si hay múltiples equipos/ligas en la misma temporada → mostrar equipo más jugado con *
  const temps=Object.keys(tempData).sort((a,b)=>b.localeCompare(a));

  // Totales globales
  let totPJ=0,totTit=0,totMins=0,totGoles=0,totV=0,totE=0,totD=0,totGC=0,totGF=0;
  temps.forEach(t=>{
    Object.values(tempData[t]).forEach(d=>{
      totPJ+=d.PJ;totTit+=d.tit;totMins+=d.mins;totGoles+=d.goles;
      totV+=d.V;totE+=d.E;totD+=d.D;totGC+=d.GC||0;totGF+=d.GF||0;
    });
  });

  // Generar filas de la tabla de trayectoria
  const _nEsc=n=>n.replace(/\\\\/g,'\\\\\\\\').replace(/'/g,"\\\\'").replace(/"/g,'&quot;');
  let tempRowsHtml='';
  // Si el jugador está marcado manualmente como "merge" → nunca tratar como homónimo
  const _cfgHomPlayer = loadHomCfg();
  const _nombreOrigPlayer = _nombreOrig ? _nombreOrig(nombre) : nombre;
  const _esMergeManual = _cfgHomPlayer[_nombreOrigPlayer] === 'merge'
    || _cfgHomPlayer[nombre] === 'merge';

  temps.forEach(t=>{
    const tramos=Object.values(tempData[t]);
    const seq=tempSeq[t]||[];
    // Detectar si es homónimo: si oscila A↔B entre clubes no-filiales → NO acumular
    // Pero si el usuario marcó explícitamente "mismo jugador", nunca mostrar ⚠
    const esHomonimo=!_esMergeManual&&tramos.length>1&&_esOscilacionNoFilial(seq);
    // Solo mostrar multi-equipo si NO es homónimo detectado
    const esMulti=tramos.length>1&&!esHomonimo;
    // Resumen sumado de la temporada
    const sumPJ=tramos.reduce((s,d)=>s+d.PJ,0);
    const sumTit=tramos.reduce((s,d)=>s+d.tit,0);
    const sumMins=tramos.reduce((s,d)=>s+d.mins,0);
    const sumGoles=tramos.reduce((s,d)=>s+d.goles,0);
    const sumV=tramos.reduce((s,d)=>s+d.V,0);
    const sumE=tramos.reduce((s,d)=>s+d.E,0);
    const sumD=tramos.reduce((s,d)=>s+d.D,0);
    // Equipo con más PJ en la temporada
    const mainTramo=tramos.slice().sort((a,b)=>b.PJ-a.PJ)[0];
    const mainEq=mainTramo.equipo+(esMulti?'*':'');
    // Categoría con más PJ
    const mainCat=mainTramo.cat+(esMulti?'*':'');
    // ID único para el desplegable
    const tid='td_'+nombre.replace(/[^a-zA-Z0-9]/g,'_')+'_'+t.replace(/[^a-zA-Z0-9]/g,'_');
    // Botón +/- si hay varios tramos (y no es homónimo)
    const toggleBtn=esMulti
      ?`<button id="btn_${tid}" onclick="(function(){var el=document.getElementById('${tid}');var btn=document.getElementById('btn_${tid}');if(el.style.display==='none'){el.style.display='';btn.textContent='−';}else{el.style.display='none';btn.textContent='+';}})();event.stopPropagation();" style="background:rgba(77,139,255,.18);border:1px solid rgba(77,139,255,.4);color:var(--a4);font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;border-radius:4px;padding:0 6px;cursor:pointer;margin-left:4px;line-height:1.6">+</button>`
      :(esHomonimo?`<span title="⚠ Posible homónimo: secuencia A→B→A entre clubes distintos detectada — puede ser otro jugador con el mismo nombre" style="font-size:10px;color:var(--a2);margin-left:5px;cursor:help">⚠</span>`:'');
    // FIX 1: color siempre var(--a3) (amarillo) tanto con * como sin él
    const sumGC=tramos.reduce((s,d)=>s+(d.GC||0),0);
    const gcColMain=esPortero
      ?`<td class="num" style="color:var(--a2)">${sumGC}</td><td class="num" style="color:var(--a2)">${sumPJ>0?(sumGC/sumPJ).toFixed(2):'-'}</td>`
      :'';
    tempRowsHtml+=`<tr style="cursor:pointer" onclick="openPlayerTempMatches('${_nEsc(nombre)}','${t}')">
      <td style="color:var(--acc);font-weight:600;white-space:nowrap">${t}${toggleBtn}</td>
      <td style="font-size:12px;color:var(--a3)">${mainEq}</td>
      <td style="font-size:11px;color:var(--a3)">${(mainCat||'').split('/')[0].trim()}</td>
      <td class="num">${sumPJ}</td><td class="num">${sumTit}</td>
      <td class="num" style="color:var(--hw)">${sumV}</td>
      <td class="num" style="color:var(--dr)">${sumE}</td>
      <td class="num" style="color:var(--lw)">${sumD}</td>
      <td class="num">${sumMins}</td>${gcColMain}<td class="num">${sumGoles}</td>
      <td class="num">${sumPJ>0?(sumMins/sumPJ).toFixed(0):0}</td>
      <td class="num" style="color:var(--hw)">${sumPJ>0?(sumGoles/sumPJ).toFixed(2):0}</td>
    </tr>`;
    // Filas desplegables (una por equipo/categoría) — ocultas por defecto
    // Solo si esMulti (no si es homónimo detectado)
    if(esMulti){
      const detRows=tramos.sort((a,b)=>b.PJ-a.PJ).map(d=>{
        const gcColDet=esPortero
          ?`<td class="num" style="font-size:11px;color:var(--a2)">${d.GC||0}</td><td class="num" style="font-size:11px;color:var(--a2)">${d.PJ>0?((d.GC||0)/d.PJ).toFixed(2):'-'}</td>`
          :'';
        return `<tr style="background:rgba(77,139,255,.05)">
        <td style="color:var(--mu);font-size:11px;padding-left:28px">↳</td>
        <td style="font-size:11px;color:var(--tx)">${d.equipo}</td>
        <td style="font-size:10px;color:var(--mu)">${(d.cat||'').split('/')[0].trim()}</td>
        <td class="num" style="font-size:11px">${d.PJ}</td>
        <td class="num" style="font-size:11px">${d.tit}</td>
        <td class="num" style="font-size:11px;color:var(--hw)">${d.V}</td>
        <td class="num" style="font-size:11px;color:var(--dr)">${d.E}</td>
        <td class="num" style="font-size:11px;color:var(--lw)">${d.D}</td>
        <td class="num" style="font-size:11px">${d.mins}</td>${gcColDet}
        <td class="num" style="font-size:11px">${d.goles}</td>
        <td class="num" style="font-size:11px">${d.PJ>0?(d.mins/d.PJ).toFixed(0):0}</td>
        <td class="num" style="font-size:11px;color:var(--hw)">${d.PJ>0?(d.goles/d.PJ).toFixed(2):0}</td>
      </tr>`;}).join('');
      const colspanDet=esPortero?14:12;
      tempRowsHtml+=`<tr id="${tid}" style="display:none"><td colspan="${colspanDet}" style="padding:0;border:none">
        <table style="width:100%;border-collapse:collapse">${detRows}</table>
      </td></tr>`;
    }
  });

  // Equipo más reciente: partido más reciente ya está en partidos[0] (orden desc)
  let equipoActual = '';
  if(partidos.length>0){
    const ult=partidos[0];
    const nEnActaUlt = _jugNombreEnActa(ult, nombre) || nombre;
    const isLU=(ult.jugadores_local||[]).includes(nEnActaUlt);
    equipoActual=isLU?(ult.equipo_local||''):(ult.equipo_visitante||'');
  }

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">Perfil del Jugador</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    <div class="phdr">
      <div class="av">${nombre.split(',')[0].trim().charAt(0)}</div>
      <div>
        <div class="pnm">${nombre}${nombre.match(/\[(\d+)\]/)?`<span style="font-size:13px;font-family:'JetBrains Mono',monospace;color:var(--a4);background:rgba(77,139,255,.18);border:1px solid rgba(77,139,255,.4);border-radius:5px;padding:1px 8px;margin-left:8px">${nombre.match(/\[(\d+)\]/)?.[1]?'Jugador '+nombre.match(/\[(\d+)\]/)[1]:''}</span>`:''}</div>
        ${equipoActual?`<div style="font-size:13px;font-weight:600;color:var(--acc);margin-top:2px;letter-spacing:.3px">🏟 ${equipoActual}</div>`:''}
        <div class="ptm">${(()=>{if(partidos.length>0){const ult=partidos[0];return ult.categoria||s.cat||'';}return s.cat||'';})()}</div>
        ${anioNacWidget(nombre)}
        ${posicionPieWidget(nombre)}
        ${nombre.match(/\[(\d+)\]/)?`<div style="font-size:10px;color:var(--mu);margin-top:3px">⚠ Nombre compartido — separado automáticamente por equipo</div>`:''}
      </div>
    </div>
    <div class="sg">
      <div class="sc"><div class="sv">${s.PJ}</div><div class="sl">Partidos</div></div>
      <div class="sc"><div class="sv">${s.tit}</div><div class="sl">Titular</div></div>
      <div class="sc r"><div class="sv">${s.nojug}</div><div class="sl">No jugados</div></div>
      <div class="sc"><div class="sv">${s.mins}</div><div class="sl">Minutos</div></div>
      <div class="sc y"><div class="sv">${s.goles||0}</div><div class="sl">Goles</div></div>
      <div class="sc b"><div class="sv">${s.pres}%</div><div class="sl">Presencia</div></div>
      <div class="sc"><div class="sv">${s.PJ>0?(s.mins/s.PJ).toFixed(0):0}</div><div class="sl">Min/P</div></div>
      <div class="sc p"><div class="sv">${s.pjEq}</div><div class="sl">PJ equipo</div></div>
      <div class="sc" style="border-top:2px solid var(--hw)"><div class="sv" style="color:var(--hw)">${totPJ>0?(totGF/totPJ).toFixed(2):'—'}</div><div class="sl" title="Goles a favor del equipo por partido, contando solo los minutos en que estaba en campo">GF/P campo</div></div>
      <div class="sc" style="border-top:2px solid var(--a2)"><div class="sv" style="color:var(--a2)">${totPJ>0?(totGC/totPJ).toFixed(2):'—'}</div><div class="sl" title="Goles en contra del equipo por partido, contando solo los minutos en que estaba en campo">GC/P campo</div></div>
    </div>
    ${temps.length>0?`<div class="st" style="margin-top:14px">Trayectoria por temporada
      <span style="font-size:10px;color:var(--mu);font-family:'Inter',sans-serif;font-weight:400;margin-left:8px">* = jugó en varios equipos/ligas esa temporada — pulsa + para ver detalle</span>
    </div>
    <div class="tw"><table><thead><tr>
      <th>Temporada</th><th>Equipo</th><th>Categoría</th><th>PJ</th><th>Tit</th>
      <th style="color:var(--hw)">V</th><th style="color:var(--dr)">E</th><th style="color:var(--lw)">D</th>
      <th>MIN</th>${esPortero?'<th style="color:var(--a2)" title="Goles recibidos en campo">GC</th><th style="color:var(--a2)" title="Goles recibidos por partido">GC/P</th>':''}
      <th>⚽</th><th>Min/P</th><th style="color:var(--hw)">Gls/P</th>
    </tr></thead><tbody>
    ${tempRowsHtml}
    <tr style="background:var(--s2);border-top:2px solid var(--b2);font-weight:700">
      <td style="color:var(--a3);font-family:'Bebas Neue',sans-serif;letter-spacing:1px">TOTAL</td>
      <td style="font-size:11px;color:var(--mu)">—</td>
      <td style="font-size:11px;color:var(--mu)">—</td>
      <td class="num" style="color:var(--acc)">${totPJ}</td>
      <td class="num" style="color:var(--acc)">${totTit}</td>
      <td class="num" style="color:var(--hw)">${totV}</td>
      <td class="num" style="color:var(--dr)">${totE}</td>
      <td class="num" style="color:var(--lw)">${totD}</td>
      <td class="num" style="color:var(--acc)">${totMins}</td>
      ${esPortero?`<td class="num" style="color:var(--a2);font-weight:700">${totGC}</td><td class="num" style="color:var(--a2);font-weight:700">${totPJ>0?(totGC/totPJ).toFixed(2):'-'}</td>`:''}
      <td class="num" style="color:var(--acc)">${totGoles}</td>
      <td class="num" style="color:var(--a3)">${totPJ>0?(totMins/totPJ).toFixed(0):0}</td>
      <td class="num" style="color:var(--hw)">${totPJ>0?(totGoles/totPJ).toFixed(2):0}</td>
    </tr>
    </tbody></table></div>`:''}
    <div class="st" style="margin-top:14px" id="player-matches-hdr">Historial (${partidos.length} partidos)</div>
    <div id="player-matches-list">${partidos.map(a=>{
      const nEnActa = _jugNombreEnActa(a, nombre) || nombre;
      const isL=(a.jugadores_local||[]).includes(nEnActa);
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const eg=isL?gl:gv,rg=isL?gv:gl;
      const mins=(a.minutos_jugadores||{})[nEnActa]||0;
      const goles=(a.goleadores||[]).filter(g=>g.jugador===nEnActa&&!g.propia).length;
      const esTit=(isL?a.titulares_local:a.titulares_visitante||[]).includes(nEnActa);
      return `<div class="mc" onclick="openMatch('${a.acta_id}')">
        <div class="mm">J${a.jornada||'?'}<br>${a.fecha||''}<br><span style="font-size:9px;color:var(--a3)">${a.temporada||''}</span></div>
        <div class="mts">
          <div class="mt h" style="font-size:11px;color:${esTit?'var(--acc)':'var(--mu)'}">${esTit?'TIT':'SUB'}</div>
          <div class="ms ${c2(eg,rg)}">${eg} — ${rg}</div>
          <div class="mt" style="font-size:12px">vs ${isL?a.equipo_visitante:a.equipo_local}</div>
        </div>
        <span class="mcat">${mins}min${goles?' ⚽'+goles:''}</span>
      </div>`;
    }).join('')}</div>`;
  document.getElementById('modal-bg').classList.add('open');
}

function openPlayerTempMatches(nombre, temp){
  const partidos=ACTAS.filter(a=>{
    if(a.temporada!==temp||isSala(a.categoria)) return false;
    return _jugNombreEnActa(a, nombre) !== null;
  }).sort((a,b)=>(b.jornada||0)-(a.jornada||0));
  const hdr=document.getElementById('player-matches-hdr');
  const lst=document.getElementById('player-matches-list');
  if(!hdr||!lst)return;
  hdr.innerHTML=`Historial ${temp} (${partidos.length} partidos) <button onclick="openPlayer('${nombre.replace(/'/g,"\\'")}');setTimeout(()=>{const h=document.getElementById('player-matches-hdr');if(h)h.scrollIntoView({block:'start',behavior:'smooth'})},50)" style="font-size:11px;background:var(--s2);border:1px solid var(--b);color:var(--mu);border-radius:5px;padding:2px 8px;cursor:pointer;margin-left:8px">Ver todos</button>`;
  lst.innerHTML=partidos.map(a=>{
    const nEnActa = _jugNombreEnActa(a, nombre) || nombre;
    const isL=(a.jugadores_local||[]).includes(nEnActa);
    const gl=a.goles_local||0,gv=a.goles_visitante||0;
    const eg=isL?gl:gv,rg=isL?gv:gl;
    const mins=(a.minutos_jugadores||{})[nEnActa]||0;
    const goles=(a.goleadores||[]).filter(g=>g.jugador===nEnActa&&!g.propia).length;
    const esTit=(isL?a.titulares_local:a.titulares_visitante||[]).includes(nEnActa);
    return `<div class="mc" onclick="openMatch('${a.acta_id}')">
      <div class="mm">J${a.jornada||'?'}<br>${a.fecha||''}<br><span style="font-size:9px;color:var(--a4);font-family:'JetBrains Mono',monospace">#${a.acta_id}</span></div>
      <div class="mts">
        <div class="mt h" style="font-size:11px;color:${esTit?'var(--acc)':'var(--mu)'}">${esTit?'TIT':'SUB'}</div>
        <div class="ms ${c2(eg,rg)}">${eg} — ${rg}</div>
        <div class="mt" style="font-size:12px">vs ${isL?a.equipo_visitante:a.equipo_local}</div>
      </div>
      <span class="mcat">${mins}min${goles?' ⚽'+goles:''}</span>
    </div>`;
  }).join('');
  lst.scrollIntoView({block:'start',behavior:'smooth'});
}

function goTeam(eq,cat,temp){
  // 1. Activar tab visualmente sin llamar SP (que dispararía rEq prematuramente con selects vacíos)
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('on'));
  document.getElementById('p-eq')?.classList.add('on');
  document.querySelectorAll('.nb').forEach(b=>{if(b.getAttribute('onclick')?.includes("'eq'"))b.classList.add('on');});

  // 2. En el siguiente tick: setear valores y renderizar una sola vez
  setTimeout(()=>{
    // Refrescar selectores (garantiza que eq-cat tiene todas las opciones)
    updSels();

    const catEl  = document.getElementById('eq-cat');
    const tempEl = document.getElementById('eq-temp');
    const selEl  = document.getElementById('eq-sel');

    // Setear cat y temp
    if(catEl  && cat)  catEl.value  = cat;
    if(tempEl && temp) tempEl.value = temp;

    // Repoblar eq-sel forzando el equipo seleccionado (sin depender de fillRaw que preserva cur)
    const eqsFilt = [...new Set(
      ACTAS.filter(a => !isSala(a.categoria) && (!cat||a.categoria===cat) && (!temp||a.temporada===temp))
           .flatMap(a => [a.equipo_local, a.equipo_visitante].filter(Boolean))
    )].sort();
    if(selEl){
      selEl.innerHTML = '<option value="">Seleccionar equipo...</option>' +
        eqsFilt.map(o=>`<option value="${o}">${o}</option>`).join('');
      selEl.value = eq;
    }

    rEq();
  }, 30);
}

// ── ENTRENADORES ──────────────────────────────────────────────────────────────
function rEnt(){
  const cat=document.getElementById('ent-cat').value;
  const temp=document.getElementById('ent-temp')?.value||'';
  const filtProv=document.getElementById('ent-prov')?.value||'';
  const srch=document.getElementById('ent-s').value.toLowerCase();
  const ord=document.getElementById('ent-ord').value||'pj';
  const minPJ=parseInt(document.getElementById('ent-min-pj')?.value??'20')||0;
  const {ents}=GS();
  let data=Object.values(ents).filter(e=>!isSala(e.cat));
  // Filtro categoría
  if(cat) data=data.filter(e=>e.cat===cat||Object.values(e.temporadas||{}).some(t=>t.cat===cat));
  // Filtro provincia: el equipo principal del entrenador debe ser de esa provincia
  if(filtProv) data=data.filter(e=>{
    const eqPrincipal=Object.entries(e.equipos||{}).sort((a,b)=>b[1]-a[1])[0]?.[0]||'';
    return getProvincia(getClubCanon(eqPrincipal))===filtProv;
  });
  // Filtro temporada: recalcular stats para esa temporada
  if(temp){
    data=data.map(e=>{
      const ts=e.temporadas?.[temp];
      if(!ts)return null;
      return {...e,...ts,PJ:ts.PJ,V:ts.V,E:ts.E,D:ts.D,Pts:ts.Pts,GF:ts.GF,GC:ts.GC,
        partidos:(e.partidos||[]).filter(p=>p.temp===temp||ACTAS.find(a=>a.acta_id===p.id&&a.temporada===temp))};
    }).filter(Boolean);
  }
  if(srch) data=data.filter(e=>e.nombre.toLowerCase().includes(srch));
  if(minPJ>0) data=data.filter(e=>e.PJ>=minPJ);
  data.sort((a,b)=>{
    if(ord==='pj')   return b.PJ-a.PJ;
    if(ord==='win')  return b.V-a.V;
    if(ord==='pts')  return b.Pts-a.Pts;
    if(ord==='pct')  return (b.PJ?b.V/b.PJ:0)-(a.PJ?a.V/a.PJ:0);
    if(ord==='ptsp') return (b.PJ?b.Pts/b.PJ:0)-(a.PJ?a.Pts/a.PJ:0);
    if(ord==='gfpp') return (b.PJ?b.GF/b.PJ:0)-(a.PJ?a.GF/a.PJ:0);
    if(ord==='gcpp') return (a.PJ?a.GC/a.PJ:0)-(b.PJ?b.GC/b.PJ:0);
    return a.nombre.localeCompare(b.nombre);
  });
  const mainEq=e=>e.equipoActual||e.equipo||Object.entries(e.equipos||{}).sort((a,b)=>b[1]-a[1])[0]?.[0]||'-';
  document.getElementById('ent-b').innerHTML=data.map((e,i)=>{
    const gfpp=e.PJ>0?(e.GF/e.PJ).toFixed(2):'-';
    const gcpp=e.PJ>0?(e.GC/e.PJ).toFixed(2):'-';
    const gfCol=e.PJ>0?(e.GF/e.PJ>=1.5?'var(--hw)':e.GF/e.PJ>=1?'var(--a3)':'var(--mu)'):'var(--mu)';
    const gcCol=e.PJ>0?(e.GC/e.PJ<1?'var(--hw)':e.GC/e.PJ<1.5?'var(--a3)':'var(--a2)'):'var(--mu)';
    return `
    <tr onclick="openCoach('${e.nombre.replace(/'/g,"\\\\'\'")}')" style="cursor:pointer">
      <td class="num" style="color:var(--mu)">${i+1}</td>
      <td style="font-weight:600;color:var(--acc)">${e.nombre}</td>
      <td style="font-size:12px;color:var(--mu)">${mainEq(e)}</td>
      <td style="font-size:11px;color:var(--mu)">${e.cat||''}</td>
      <td class="num">${e.PJ}</td>
      <td class="num" style="color:var(--hw)">${e.V}</td>
      <td class="num" style="color:var(--dr)">${e.E}</td>
      <td class="num" style="color:var(--lw)">${e.D}</td>
      <td class="num" style="color:var(--acc)">${e.Pts}</td>
      <td class="num">${e.PJ>0?Math.round(e.V/e.PJ*100):0}%</td>
      <td class="num" style="color:var(--acc)">${e.PJ>0?(e.Pts/e.PJ).toFixed(2):0}</td>
      <td class="num" style="color:${gfCol};font-weight:600">${gfpp}</td>
      <td class="num" style="color:${gcCol};font-weight:600">${gcpp}</td>
    </tr>`;
  }).join('')||'<tr><td colspan="13" class="empty">Sin datos</td></tr>';
}

let _prevCoach=null;
function goToEquipoTemp(eq, temp, cat, coachNombre){
  _prevCoach=coachNombre||null;
  document.getElementById('modal-bg').classList.remove('open');
  SP('eq');
  setTimeout(()=>{
    const tempEl=document.getElementById('eq-temp');
    const catEl=document.getElementById('eq-cat');
    const selEl=document.getElementById('eq-sel');
    if(tempEl&&temp) tempEl.value=temp;
    if(catEl&&cat) catEl.value=cat;
    if(typeof rEqTemp==='function') rEqTemp();
    const nombre_prev=_prevCoach;
    setTimeout(()=>{
      if(selEl&&eq) selEl.value=eq;
      if(typeof rEq==='function') rEq();
      if(nombre_prev){
        const old=document.getElementById('back-to-coach');if(old)old.remove();
        const eqC=document.getElementById('eq-c');
        if(eqC){
          const btn=document.createElement('button');
          btn.id='back-to-coach';
          btn.textContent='\u2190 Volver a '+nombre_prev;
          btn.style.cssText='margin-bottom:12px;font-size:12px;background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.3);color:var(--a4);border-radius:6px;padding:5px 14px;cursor:pointer;display:block';
          btn.onclick=()=>{_prevCoach=null;btn.remove();openCoach(nombre_prev);};
          eqC.insertAdjacentElement('beforebegin',btn);
        }
      }
    },80);
  },60);
}

// Calcula posición y zona final de un equipo en una cat+temp usando el cache.
// Devuelve {pos, total, zona, badge, badgeCls} o null si no hay datos.
function _posZonaEquipo(eq, cat, temp){
  if(!eq||!cat||!temp) return null;
  const clCache=_buildClCache();
  const key=cat+'|||'+temp;
  const tabla=clCache[key];
  if(!tabla||!tabla[eq]) return null;
  const rows=Object.entries(tabla)
    .sort((a,b)=>b[1].Pts-a[1].Pts||(b[1].GF-b[1].GC)-(a[1].GF-a[1].GC)||b[1].GF-a[1].GF);
  const pos=rows.findIndex(([e])=>e===eq);
  if(pos<0) return null;
  const {ents:_unused,...clAll}=GS();
  const zonas=_calcZonas(cat,rows,GS().cl);
  const zi=zonas[pos]||{zona:'',badge:'',badgeCls:''};
  return {pos:pos+1, total:rows.length, zona:zi.zona, badge:zi.badge, badgeCls:zi.badgeCls, title:zi.title||''};
}

// Devuelve HTML del badge de posición (número + zona si la hay)
function _posBadgeHtml(pz){
  if(!pz||!pz.pos) return '<span style="color:var(--mu)">—</span>';
  const numCol = pz.pos===1?'var(--a3)':'var(--tx)';
  const numHtml = `<span style="font-size:15px;font-weight:800;color:${numCol};font-family:'Bebas Neue',sans-serif;letter-spacing:.5px">${pz.pos}</span><span style="font-size:10px;color:var(--mu);font-weight:400">/${pz.total}</span>`;
  const zonaTxt = pz.badge ? `<span class="zona-badge ${pz.badgeCls}" title="${pz.title||''}" style="font-size:10px;margin-left:4px">${pz.badge}</span>` : '';
  return numHtml+zonaTxt;
}

function openCoach(nombre){
  const {ents}=GS();const e=ents[nombre];if(!e)return;
  const pct=e.PJ>0?Math.round(e.V/e.PJ*100):0;
  const ptsp=e.PJ>0?(e.Pts/e.PJ).toFixed(2):0;
  const temps=Object.entries(e.temporadas||{}).map(([t,v])=>[t,{...v}]).sort((a,b)=>b[0].localeCompare(a[0]));
  const mainEq=Object.entries(e.equipos||{}).sort((a,b)=>b[1]-a[1])[0]?.[0]||'-';
  // Totales trayectoria
  const totPJ=temps.reduce((s,[,t])=>s+t.PJ,0);
  const totV=temps.reduce((s,[,t])=>s+t.V,0);
  const totE=temps.reduce((s,[,t])=>s+t.E,0);
  const totD=temps.reduce((s,[,t])=>s+t.D,0);
  const totPts=temps.reduce((s,[,t])=>s+t.Pts,0);
  const totGF=temps.reduce((s,[,t])=>s+t.GF,0);
  const totGC=temps.reduce((s,[,t])=>s+t.GC,0);

  // ── Calcular posición/zona por temporada ───────────────────────────────────
  // Para cada temporada, obtener la categoría dominante y la posición final del equipo.
  // El descenso se asigna también si CUALQUIER entrenador llevó ese equipo ese año
  // (lógica: si el equipo bajó, todos los entrenadores de esa temporada comparten el descenso).
  const pzPorTemp={};  // temp → {pos,total,zona,badge,badgeCls,cat,eq}
  temps.forEach(([t,s])=>{
    const catCountTemp={};
    e.partidos.filter(p=>p.temp===t).forEach(p=>{if(p.cat)catCountTemp[p.cat]=(catCountTemp[p.cat]||0)+1;});
    const catTemp=Object.entries(catCountTemp).sort((a,b)=>b[1]-a[1])[0]?.[0]||'';
    const eq_t=s.equipo||'';
    const pz=_posZonaEquipo(eq_t, catTemp, t);
    pzPorTemp[t]={...(pz||{}), cat:catTemp, eq:eq_t};
  });

  // ── Resumen de logros (badges arriba) ──────────────────────────────────────
  const ligas=temps.filter(([t])=>pzPorTemp[t]?.zona==='camp');
  const descs=temps.filter(([t])=>{const z=pzPorTemp[t]?.zona;return z==='desc'||z==='desc2';});
  const ascs =temps.filter(([t])=>{const z=pzPorTemp[t]?.zona;return z==='asc';});
  const proms=temps.filter(([t])=>{const z=pzPorTemp[t]?.zona;return z==='prom';});

  let logrosHtml='';
  if(ligas.length||descs.length||ascs.length){
    const items=[];
    ligas.forEach(([t])=>{
      const pz=pzPorTemp[t];
      items.push(`<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(245,200,66,.15);border:1px solid rgba(245,200,66,.4);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;color:var(--a3)">🏆 Liga ${t} <span style="font-weight:400;font-size:11px;color:var(--mu)">${pz.eq||''}</span></span>`);
    });
    ascs.forEach(([t])=>{
      const pz=pzPorTemp[t];
      items.push(`<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(0,240,160,.1);border:1px solid rgba(0,240,160,.35);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;color:var(--hw)">↑ Ascenso ${t} <span style="font-weight:400;font-size:11px;color:var(--mu)">${pz.eq||''}</span></span>`);
    });
    proms.forEach(([t])=>{
      const pz=pzPorTemp[t];
      items.push(`<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(0,200,255,.08);border:1px solid rgba(0,200,255,.3);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:600;color:#00c8ff">⚑ Prom. ${t} <span style="font-weight:400;font-size:11px;color:var(--mu)">${pz.eq||''}</span></span>`);
    });
    descs.forEach(([t])=>{
      const pz=pzPorTemp[t];
      items.push(`<span style="display:inline-flex;align-items:center;gap:5px;background:rgba(255,79,55,.1);border:1px solid rgba(255,79,55,.35);border-radius:6px;padding:3px 10px;font-size:12px;font-weight:700;color:var(--a2)">↓ Descenso ${t} <span style="font-weight:400;font-size:11px;color:var(--mu)">${pz.eq||''}</span></span>`);
    });
    if(items.length){
      logrosHtml=`<div style="display:flex;flex-wrap:wrap;gap:6px;margin:10px 0 4px">${items.join('')}</div>`;
    }
  }

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">👨‍💼 Entrenador</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    <div class="phdr">
      <div class="av">${nombre.split(',')[0].trim().charAt(0)}</div>
      <div><div class="pnm">${nombre}</div><div class="ptm">${mainEq}</div></div>
    </div>
    ${logrosHtml}
    <div class="sg">
      <div class="sc"><div class="sv">${e.PJ}</div><div class="sl">Partidos</div></div>
      <div class="sc"><div class="sv" style="color:var(--hw)">${e.V}</div><div class="sl">Victorias</div></div>
      <div class="sc y"><div class="sv">${e.E}</div><div class="sl">Empates</div></div>
      <div class="sc r"><div class="sv">${e.D}</div><div class="sl">Derrotas</div></div>
      <div class="sc b"><div class="sv">${e.Pts}</div><div class="sl">Puntos</div></div>
      <div class="sc p"><div class="sv">${pct}%</div><div class="sl">%Victorias</div></div>
      <div class="sc"><div class="sv" style="cursor:pointer;text-decoration:underline dotted;color:var(--hw)" onclick="openCoachGoals('${nombre.replace(/'/g,"\\'")}','gf')" title="Ver desglose de goles a favor">${e.GF}</div><div class="sl">Goles F.</div></div>
      <div class="sc r"><div class="sv" style="cursor:pointer;text-decoration:underline dotted;color:var(--a2)" onclick="openCoachGoals('${nombre.replace(/'/g,"\\'")}','gc')" title="Ver desglose de goles en contra">${e.GC}</div><div class="sl">Goles C.</div></div>
      <div class="sc" style="border-top:2px solid var(--acc)"><div class="sv" style="color:var(--acc)">${ptsp}</div><div class="sl">Pts/Partido</div></div>
    </div>
    ${temps.length?`<div class="st" style="margin-top:14px">Trayectoria por temporada</div>
    <div class="tw"><table><thead><tr>
      <th>Temporada</th><th>Equipo</th><th style="color:#c084fc">Tipo</th><th style="color:var(--mu)">Categoría</th>
      <th title="Posición final en clasificación">Pos.</th>
      <th>PJ</th>
      <th style="color:var(--hw)">V</th><th style="color:var(--dr)">E</th><th style="color:var(--lw)">D</th>
      <th>Pts</th><th>GF</th><th>GC</th><th>DG</th><th style="color:var(--acc)">Pts/P</th><th></th>
    </tr></thead><tbody>
    ${temps.map(([t,s])=>{
      const dg=s.GF-s.GC;
      const catCountTemp={};
      const eqCountTemp={};
      e.partidos.filter(p=>p.temp===t).forEach(p=>{if(p.cat)catCountTemp[p.cat]=(catCountTemp[p.cat]||0)+1;if(p.eq)eqCountTemp[p.eq]=(eqCountTemp[p.eq]||0)+1;});
      const catTemp=Object.entries(catCountTemp).sort((a,b)=>b[1]-a[1])[0]?.[0]||'';
      const eqTemp=Object.entries(eqCountTemp).sort((a,b)=>b[1]-a[1])[0]?.[0]||s.equipo||'';
      const eqEsc=(eqTemp||'').replace(/\\\\/g,'\\\\\\\\').replace(/'/g,"\\\\'");
      const tEsc=t.replace(/'/g,"\\\\'");
      const catEsc=catTemp.replace(/'/g,"\\\\'");
      const nv=detectarNivelEquipo(eqTemp||'', catTemp, t);
      const pz=pzPorTemp[t];
      const posBadge=_posBadgeHtml(pz&&pz.pos?pz:null);
      // Color de fila si hubo descenso o liga
      const rowStyle=pz?.zona==='camp'?'background:rgba(245,200,66,.07)'
        :pz?.zona==='desc'||pz?.zona==='desc2'?'background:rgba(255,79,55,.07)'
        :pz?.zona==='asc'?'background:rgba(0,240,160,.05)':'';
      // ── Badge de tipo: grupo + letra (ej: JUVENIL A, CADETE B, SÉNIOR A) ──
      const _tipoBadge=(()=>{
        const gr=nv.grupo||getCatGrupo(catTemp)||'';
        const lt=nv.letra||'A';
        if(!gr) return '<span style="color:var(--mu);font-size:11px">—</span>';
        // Colores por grupo
        const grColors={
          'JUVENIL':  {bg:'rgba(139,92,246,.18)', border:'rgba(139,92,246,.45)', txt:'#c084fc'},
          'CADETE':   {bg:'rgba(59,130,246,.18)', border:'rgba(59,130,246,.45)', txt:'#60a5fa'},
          'INFANTIL': {bg:'rgba(16,185,129,.15)', border:'rgba(16,185,129,.4)',  txt:'#34d399'},
          'ALEVÍN':   {bg:'rgba(245,158,11,.15)', border:'rgba(245,158,11,.4)',  txt:'#fbbf24'},
          'SENIOR':   {bg:'rgba(239,68,68,.15)',  border:'rgba(239,68,68,.4)',   txt:'#f87171'},
          'SÉNIOR':   {bg:'rgba(239,68,68,.15)',  border:'rgba(239,68,68,.4)',   txt:'#f87171'},
        };
        const col=grColors[gr]||{bg:'rgba(100,100,100,.15)',border:'rgba(150,150,150,.3)',txt:'var(--mu)'};
        // Para la letra: A en dorado, B/C/D más apagado
        const ltCol=lt==='A'?'#fbbf24':lt==='B'?'#94a3b8':'#64748b';
        return `<span style="display:inline-flex;align-items:center;gap:3px;background:${col.bg};border:1px solid ${col.border};border-radius:5px;padding:2px 8px;white-space:nowrap">
          <span style="font-size:10px;font-weight:700;color:${col.txt};letter-spacing:.5px">${gr}</span>
          <span style="font-size:12px;font-weight:800;color:${ltCol};font-family:'Bebas Neue',sans-serif;line-height:1">${lt}</span>
        </span>`;
      })();
      return`<tr style="${rowStyle}">
      <td style="color:var(--acc);font-weight:600;cursor:pointer;text-decoration:underline dotted" title="Filtrar partidos de ${t}" onclick="filterCoachMatches('${nombre.replace(/'/g,"\\'")}','${t}')">${t}</td>
      <td style="font-size:12px">${eqTemp||'-'}</td>
      <td style="white-space:nowrap">${_tipoBadge}</td>
      <td style="font-size:11px;color:var(--mu);white-space:nowrap">${catAbrev(catTemp, nv.letra)}</td>
      <td class="num" style="white-space:nowrap">${posBadge}</td>
      <td class="num">${s.PJ}</td>
      <td class="num" style="color:var(--hw)">${s.V}</td>
      <td class="num" style="color:var(--dr)">${s.E}</td>
      <td class="num" style="color:var(--lw)">${s.D}</td>
      <td class="num" style="color:var(--acc)">${s.Pts}</td>
      <td class="num">${s.GF}</td><td class="num">${s.GC}</td>
      <td class="num ${dg>0?'gdp':dg<0?'gdn':''}">${dg>0?'+':''}${dg}</td>
      <td class="num" style="color:var(--acc)">${s.PJ>0?(s.Pts/s.PJ).toFixed(2):0}</td>
      <td><button onclick="event.stopPropagation();goToEquipoTemp('${eqEsc}','${tEsc}','${catEsc}','${nombre.replace(/'/g,"\\'")}')" style="font-size:15px;background:none;border:none;color:var(--a4);cursor:pointer;padding:2px 4px;opacity:.7;transition:opacity .15s" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.7" title="${eqTemp||''} · ${t}">🔗</button></td>
    </tr>`}).join('')}
    <tr style="background:var(--s2);border-top:2px solid var(--b2);font-weight:700">
      <td style="color:var(--a3);font-family:'Bebas Neue',sans-serif;letter-spacing:1px">TOTAL</td>
      <td style="font-size:11px;color:var(--mu)">—</td>
      <td></td>
      <td style="font-size:11px;color:var(--mu)">—</td>
      <td></td>
      <td class="num" style="color:var(--acc)">${totPJ}</td>
      <td class="num" style="color:var(--hw)">${totV}</td>
      <td class="num" style="color:var(--dr)">${totE}</td>
      <td class="num" style="color:var(--lw)">${totD}</td>
      <td class="num" style="color:var(--acc)">${totPts}</td>
      <td class="num">${totGF}</td><td class="num">${totGC}</td>
      <td class="num ${(totGF-totGC)>0?'gdp':(totGF-totGC)<0?'gdn':''}">${totGF-totGC>0?'+':''}${totGF-totGC}</td>
      <td class="num" style="color:var(--acc)">${totPJ>0?(totPts/totPJ).toFixed(2):0}</td>
      <td></td>
    </tr>
    </tbody></table></div>`:''}
    <div class="st" style="margin-top:14px" id="coach-matches-hdr">Partidos (${e.partidos.length})</div>
    <div id="coach-matches-list">${renderCoachMatches(e.partidos,e.partidos.length)}</div>`;
  document.getElementById('modal-bg').classList.add('open');
}

function renderCoachMatches(partidos, total){
  return partidos.sort((a,b)=>(b.jornada||0)-(a.jornada||0)).slice(0,50).map(p=>`
    <div class="mc" onclick="openMatch('${p.id}')">
      <div class="mm">J${p.jornada||'?'}<br>${p.fecha||''}<br><span style="font-size:9px;color:var(--a4);font-family:'JetBrains Mono',monospace">#${p.id}</span></div>
      <div class="mts">
        <div class="mt h">${p.eq}</div>
        <div class="ms ${c2(p.g1,p.g2)}">${p.g1} — ${p.g2}</div>
        <div class="mt">vs ${p.rival}</div>
      </div>
      <span class="mcat">${(p.cat||'').split('/')[0].trim()}</span>
    </div>`).join('');
}

function filterCoachMatches(nombre, temp){
  const {ents}=GS();const e=ents[nombre];if(!e)return;
  const filtrados=e.partidos.filter(p=>p.temp===temp);
  const hdr=document.getElementById('coach-matches-hdr');
  const lst=document.getElementById('coach-matches-list');
  if(!hdr||!lst)return;
  hdr.innerHTML=`Partidos ${temp} (${filtrados.length}) <button onclick="openCoach('${nombre.replace(/'/g,"\\'")}');setTimeout(()=>{const h=document.getElementById('coach-matches-hdr');if(h)h.scrollIntoView({block:'start',behavior:'smooth'})},50)" style="font-size:11px;background:var(--s2);border:1px solid var(--b);color:var(--mu);border-radius:5px;padding:2px 8px;cursor:pointer;margin-left:8px">Ver todos</button>`;
  lst.innerHTML=renderCoachMatches(filtrados,filtrados.length);
  lst.scrollIntoView({block:'start',behavior:'smooth'});
}

function openCoachGoals(nombre, tipo){
  // tipo = 'gf' / 'gc' — ahora unificado: muestra siempre todos los datos
  const {ents}=GS();const e=ents[nombre];if(!e)return;
  const esGF = tipo==='gf';
  const titulo = esGF?'⚽ Goles a Favor — Desglose':'🛡 Goles en Contra — Desglose';

  // ── Acumular datos ────────────────────────────────────────────────
  const goleadoresPropios = {};
  const goleadoresRivales = {};
  const clubsAFavor       = {};
  const clubsEnContra     = {};
  const victoriasPorEquipo = {};
  const derrotasPorEquipo  = {};
  const victoriasPorCoach  = {};
  const derrotasPorCoach   = {};

  // Registros especiales
  let mayorGoleada    = null; // { p, gP, gC }  — máxima diferencia favorable
  let mayorGoleadaRec = null; // { p, gP, gC }  — máxima diferencia desfavorable
  let mayorTotalGoles = null; // { p, gP, gC }  — más goles en total

  e.partidos.forEach(p=>{
    const acta = DB[p.id]; if(!acta) return;
    const esLocal   = acta.equipo_local === p.eq;
    const clubRival = getClubCanon(p.rival);
    const gP = esLocal ? (acta.goles_local||0) : (acta.goles_visitante||0);
    const gC = esLocal ? (acta.goles_visitante||0) : (acta.goles_local||0);
    const entRival = esLocal ? (acta.entrenador_visitante||'') : (acta.entrenador_local||'');

    if(gP > gC) victoriasPorEquipo[clubRival]=(victoriasPorEquipo[clubRival]||0)+1;
    else if(gP < gC) derrotasPorEquipo[clubRival]=(derrotasPorEquipo[clubRival]||0)+1;

    if(entRival){
      if(gP > gC) victoriasPorCoach[entRival]=(victoriasPorCoach[entRival]||0)+1;
      else if(gP < gC) derrotasPorCoach[entRival]=(derrotasPorCoach[entRival]||0)+1;
    }

    // ── Registros especiales ─────────────────────────────────────────
    const diff = gP - gC;
    const total = gP + gC;
    if(gP > gC){
      if(!mayorGoleada || diff > (mayorGoleada.gP - mayorGoleada.gC))
        mayorGoleada = {p, gP, gC};
    }
    if(gP < gC){
      if(!mayorGoleadaRec || (gC - gP) > (mayorGoleadaRec.gC - mayorGoleadaRec.gP))
        mayorGoleadaRec = {p, gP, gC};
    }
    if(!mayorTotalGoles || total > (mayorTotalGoles.gP + mayorTotalGoles.gC))
      mayorTotalGoles = {p, gP, gC};

    (acta.goleadores||[]).forEach(g=>{
      if(!g.jugador) return;
      const golesLocal = (acta.jugadores_local||[]).includes(g.jugador);
      const golesVisit = (acta.jugadores_visitante||[]).includes(g.jugador);
      let eqGol = g.equipo;
      if(!eqGol||eqGol==='?'){
        if(golesLocal) eqGol='local';
        else if(golesVisit) eqGol='visitante';
      }
      const esPropio = esLocal ? eqGol==='local' : eqGol==='visitante';
      if(esPropio){
        goleadoresPropios[g.jugador]=(goleadoresPropios[g.jugador]||0)+1;
        clubsAFavor[clubRival]=(clubsAFavor[clubRival]||0)+1;
      } else {
        goleadoresRivales[g.jugador]=(goleadoresRivales[g.jugador]||0)+1;
        clubsEnContra[clubRival]=(clubsEnContra[clubRival]||0)+1;
      }
    });
  });

  // ── Top-N ─────────────────────────────────────────────────────────
  const topN = (obj, n=12) => Object.entries(obj).sort((a,b)=>b[1]-a[1]).slice(0,n);
  const topPropios   = topN(goleadoresPropios);
  const topRivales   = topN(goleadoresRivales);
  const topClubsGF   = topN(clubsAFavor);
  const topClubsGC   = topN(clubsEnContra);
  const topVictorias = topN(victoriasPorEquipo);
  const topDerrotas  = topN(derrotasPorEquipo);
  const topCoachVic  = topN(victoriasPorCoach);
  const topCoachDer  = topN(derrotasPorCoach);

  const cne = nombre.replace(/'/g,"\\'");

  // ── Render helpers ────────────────────────────────────────────────
  const bar = (pct, col) =>
    `<div style="height:3px;background:rgba(255,255,255,.08);border-radius:2px;margin-top:4px"><div style="height:3px;background:${col};border-radius:2px;width:${pct}%;opacity:.85"></div></div>`;

  const rowRecord = (icon, label, col, rec) => {
    if(!rec) return '<div style="display:flex;align-items:center;gap:10px;padding:7px 4px;border-bottom:1px solid rgba(255,255,255,.05)"><span style="font-size:18px">'+icon+'</span><div style="flex:1"><div style="font-size:11px;font-weight:700;color:'+col+';letter-spacing:.6px;text-transform:uppercase;margin-bottom:2px">'+label+'</div><div style="font-size:12px;color:var(--mu)">Sin datos</div></div></div>';
    const rp=rec.p, gP=rec.gP, gC=rec.gC;
    const res=gP+'\u2013'+gC;
    const info='J'+(rp.jornada||'?')+' \xb7 '+(rp.fecha||'')+' \xb7 '+rp.eq+' vs '+rp.rival;
    const rcat=(rp.cat||'').split('/')[0].trim();
    return '<div style="display:flex;align-items:center;gap:10px;padding:7px 4px;border-bottom:1px solid rgba(255,255,255,.05);cursor:pointer" onclick="openMatch(\''+rp.id+'\')"><span style="font-size:18px">'+icon+'</span><div style="flex:1;min-width:0"><div style="font-size:11px;font-weight:700;color:'+col+';letter-spacing:.6px;text-transform:uppercase;margin-bottom:2px">'+label+'</div><div style="font-family:\'Bebas Neue\',sans-serif;font-size:22px;color:'+col+';line-height:1">'+res+'</div><div style="font-size:11px;color:var(--mu);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+info+(rcat?' \xb7 <span style="color:var(--a4)">'+rcat+'</span>':'')+'</div></div><span style="font-size:16px;color:var(--mu);flex-shrink:0">\u203a</span></div>';
  };

  const rowBase = (label, val, max, col, clickAttr) =>
    `<div style="display:flex;align-items:center;gap:8px;padding:5px 2px;border-bottom:1px solid rgba(255,255,255,.04)">
      <div style="flex:1;min-width:0">
        <div style="font-size:12.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--txt);cursor:${clickAttr?'pointer':'default'}" ${clickAttr||''}>${label}</div>
        ${bar(Math.round(val/max*100),col)}
      </div>
      <div style="font-family:'Bebas Neue',sans-serif;font-size:18px;color:${col};flex-shrink:0;min-width:24px;text-align:right">${val}</div>
    </div>`;

  const rowPlayer = (n, v, max, col) => rowBase(n, v, max, col,
    `onclick="document.getElementById('modal-bg').classList.remove('open');openPlayer('${n.replace(/'/g,"\\'")}')"`);
  const rowClub   = (n, v, max, col) => rowBase(n, v, max, col,
    `onclick="openCoachVsClubMatches('${cne}','${n.replace(/'/g,"\\'")}')" `);
  const rowCoach  = (n, v, max, col) => rowBase(n, v, max, col,
    `onclick="openCoachVsCoachMatches('${cne}','${n.replace(/'/g,"\\'")}')" `);

  const empty = msg => `<div class="empty" style="font-size:12px;padding:6px 0">${msg}</div>`;

  // Columna simple
  const col1 = (label, col, rows, renderFn) =>
    `<div>
      <div style="font-size:10.5px;font-weight:700;color:${col};letter-spacing:.8px;text-transform:uppercase;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid rgba(255,255,255,.06)">${label}</div>
      ${rows.length ? rows.map(([n,v])=>renderFn(n,v,rows[0][1],col)).join('') : empty('Sin datos')}
    </div>`;

  // Bloque con título de sección + 2 columnas
  const blk = (icon, title, leftLabel, leftCol, leftRows, leftFn, rightLabel, rightCol, rightRows, rightFn) =>
    `<div style="margin-top:20px">
      <div style="font-size:13px;font-weight:700;color:var(--acc);margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid var(--b2)">${icon} ${title}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        ${col1(leftLabel, leftCol, leftRows, leftFn)}
        ${col1(rightLabel, rightCol, rightRows, rightFn)}
      </div>
    </div>`;

  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <span class="mtit">${titulo}</span>
      <button class="mcl" onclick="openCoach('${nombre.replace(/'/g,"\\'")}')">← Volver</button>
    </div>
    ${blk('👨‍💼','Entrenadores rivales',
        '🏆 Le gané más veces','var(--hw)',topCoachVic,rowCoach,
        '💔 Me ganó más veces','var(--a2)',topCoachDer,rowCoach)}
    ${blk('🏟','Equipos rivales',
        '🏆 Victorias','var(--hw)',topVictorias,rowClub,
        '💔 Derrotas','var(--a2)',topDerrotas,rowClub)}
    ${blk('⚽','Goleadores',
        '⚽ Sus goleadores','var(--hw)',topPropios,rowPlayer,
        '🎯 Rivales que le marcaron','var(--a2)',topRivales,rowPlayer)}
    ${blk('📊','Goles por club rival',
        '⚽ Más goles metió a','var(--hw)',topClubsGF,rowClub,
        '🎯 Más goles recibió de','var(--a2)',topClubsGC,rowClub)}
    <div style="margin-top:20px">
      <div style="font-size:13px;font-weight:700;color:var(--acc);margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid var(--b2)">🏆 Récords de partido</div>
      ${rowRecord('🔥','Mayor goleada','var(--hw)',mayorGoleada)}
      ${rowRecord('💔','Mayor goleada recibida','var(--a2)',mayorGoleadaRec)}
      ${rowRecord('📈','Partido con más goles','var(--a3)',mayorTotalGoles)}
    </div>`;
  document.getElementById('modal-bg').classList.add('open');
}
function openCoachVsCoachMatches(coachNombre, entRival){
  const {ents}=GS();const e=ents[coachNombre];if(!e)return;
  const partidos=e.partidos.filter(p=>{
    const acta=DB[p.id];if(!acta)return false;
    const esLocal=acta.equipo_local===p.eq;
    const er=esLocal?(acta.entrenador_visitante||''):(acta.entrenador_local||'');
    return er===entRival;
  });
  if(!partidos.length){toast('Sin partidos contra '+entRival,'err');return;}
  const rows=partidos.sort((a,b)=>(b.jornada||0)-(a.jornada||0)).map(p=>`
    <div class="mc" onclick="openMatch('${p.id}')">
      <div class="mm">J${p.jornada||'?'}<br>${p.fecha||''}<br><span style="font-size:9px;color:var(--a3)">${p.temp||''}</span></div>
      <div class="mts">
        <div class="mt h">${p.eq}</div>
        <div class="ms ${c2(p.g1,p.g2)}">${p.g1} — ${p.g2}</div>
        <div class="mt">vs ${p.rival}</div>
      </div>
      <span class="mcat">${(p.cat||'').split('/')[0].trim()}</span>
    </div>`).join('');
  const cne=coachNombre.replace(/'/g,"\\'");
  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <button onclick="openCoachGoals('${cne}','gf')" style="background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.35);color:var(--a4);font-size:12px;border-radius:6px;padding:4px 10px;cursor:pointer;margin-right:8px">← Volver</button>
      <span class="mtit">👨‍💼 ${coachNombre} vs 👨‍💼 ${entRival}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button>
    </div>
    <div style="font-size:12px;color:var(--mu);margin-bottom:12px">${partidos.length} partido${partidos.length!==1?'s':''}</div>
    ${rows}`;
  document.getElementById('modal-bg').classList.add('open');
}

function openCoachVsClubMatches(coachNombre, clubRival){
  const {ents}=GS();const e=ents[coachNombre];if(!e)return;
  const partidos=e.partidos.filter(p=>getClubCanon(p.rival)===clubRival);
  if(!partidos.length){toast('Sin partidos contra '+clubRival,'err');return;}
  const rows=partidos.sort((a,b)=>(b.jornada||0)-(a.jornada||0)).map(p=>`
    <div class="mc" onclick="openMatch('${p.id}')">
      <div class="mm">J${p.jornada||'?'}<br>${p.fecha||''}<br><span style="font-size:9px;color:var(--a3)">${p.temp||''}</span></div>
      <div class="mts">
        <div class="mt h">${p.eq}</div>
        <div class="ms ${c2(p.g1,p.g2)}">${p.g1} — ${p.g2}</div>
        <div class="mt">vs ${p.rival}</div>
      </div>
      <span class="mcat">${(p.cat||'').split('/')[0].trim()}</span>
    </div>`).join('');
  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr">
      <button onclick="openCoach('${coachNombre.replace(/'/g,"\\'")}');" style="background:rgba(77,139,255,.12);border:1px solid rgba(77,139,255,.35);color:var(--a4);font-size:12px;border-radius:6px;padding:4px 10px;cursor:pointer;margin-right:8px">← Volver</button>
      <span class="mtit">👨‍💼 ${coachNombre} vs ${clubRival}</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button>
    </div>
    <div style="font-size:12px;color:var(--mu);margin-bottom:12px">${partidos.length} partido${partidos.length!==1?'s':''}</div>
    ${rows}`;
  document.getElementById('modal-bg').classList.add('open');
}

// ── NAVEGACION: Ir a calendario y clasificación de un equipo en una temporada/categoría ────
function gotoTeamSeasonCalendar(eq, temp, cat){
  document.getElementById('modal-bg').classList.remove('open');
  setTimeout(()=>{
    SP('pa');
    document.getElementById('pa-cat').value = cat;
    document.getElementById('pa-eq').value = eq;
    rPa();
    setTimeout(()=>{
      SP('cl');
      document.getElementById('cl-cat').value = cat;
      document.getElementById('cl-temp').value = temp;
      rCl();
    }, 100);
  }, 50);
}

// ── ARBITROS ──────────────────────────────────────────────────────────────────
function rArb(){
  const cat=document.getElementById('arb-cat').value;
  const temp=document.getElementById('arb-temp')?.value||'';
  const srch=document.getElementById('arb-s').value.toLowerCase();
  const ord=document.getElementById('arb-ord').value||'pj';
  const {arbs}=GS();
  let data=Object.values(arbs).filter(a=>!Object.keys(a.cats||{}).every(c=>isSala(c)));
  if(cat) data=data.filter(a=>a.cats[cat]);
  if(temp) data=data.filter(a=>a.temporadas&&a.temporadas[temp]);
  if(srch) data=data.filter(a=>a.nombre.toLowerCase().includes(srch));
  // Si hay filtro temporada, usar stats de esa temporada
  if(temp) data=data.map(a=>{const ts=a.temporadas[temp];return ts?{...a,...ts,PJ:ts.PJ,goles:ts.goles,amarillas:ts.amarillas,rojas:ts.rojas,rojas_directas:ts.rojas_directas,am_jug:ts.am_jug,am_banq:ts.am_banq,ro_jug:ts.ro_jug,ro_banq:ts.ro_banq,_base:a}:null;}).filter(Boolean);
  data.sort((a,b)=>{
    if(ord==='goles') return (b.PJ?b.goles/b.PJ:0)-(a.PJ?a.goles/a.PJ:0);
    if(ord==='tarj')  return (b.PJ?(b.amarillas+b.rojas)/b.PJ:0)-(a.PJ?(a.amarillas+a.rojas)/a.PJ:0);
    if(ord==='name')  return a.nombre.localeCompare(b.nombre);
    return b.PJ-a.PJ;
  });
  document.getElementById('arb-b').innerHTML=data.map((a,i)=>`
    <tr onclick="openReferee('${a.nombre.replace(/'/g,"\\'")}')" style="cursor:pointer">
      <td class="num" style="color:var(--mu)">${i+1}</td>
      <td style="font-weight:600;color:var(--acc)">${a.nombre}</td>
      <td style="font-size:11px;color:var(--mu)">${Object.keys((a._base||a).cats||{}).join(', ').split('/')[0]||''}</td>
      <td class="num">${a.PJ}</td>
      <td class="num">${a.PJ?(a.goles/a.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a3)">${a.PJ?(a.amarillas/a.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a2)">${a.PJ?(a.rojas/a.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a2);font-size:11px">${a.rojas_directas||0}</td>
      <td class="num">${a.amarillas+a.rojas}</td>
    </tr>`).join('')||'<tr><td colspan="9" class="empty">Sin datos</td></tr>';
}

function openReferee(nombre){
  const {arbs}=GS();const a=arbs[nombre];if(!a)return;
  const temps=Object.entries(a.temporadas||{}).sort((a,b)=>b[0].localeCompare(a[0]));
  const p2=v=>a.PJ?(v/a.PJ).toFixed(2):0;
  // Totales
  const totPJ=temps.reduce((s,[,t])=>s+t.PJ,0);
  const totAm=temps.reduce((s,[,t])=>s+t.amarillas,0);
  const totRo=temps.reduce((s,[,t])=>s+t.rojas,0);
  document.getElementById('modal-c').innerHTML=`
    <div class="mhdr"><span class="mtit">⚖ Árbitro</span>
      <button class="mcl" onclick="document.getElementById('modal-bg').classList.remove('open')">✕</button></div>
    <div class="phdr">
      <div class="av" style="background:linear-gradient(135deg,var(--a4),#1a3a80)">${nombre.split(',')[0].trim().charAt(0)}</div>
      <div><div class="pnm">${nombre}</div><div class="ptm">${Object.keys(a.cats||{}).join(' · ')}</div></div>
    </div>
    <div class="sg">
      <div class="sc b"><div class="sv">${a.PJ}</div><div class="sl">Partidos</div></div>
      <div class="sc"><div class="sv">${a.goles}</div><div class="sl">Goles total</div></div>
      <div class="sc"><div class="sv">${p2(a.goles)}</div><div class="sl">Goles/P</div></div>
      <div class="sc y"><div class="sv">${a.amarillas}</div><div class="sl">🟨 Total</div></div>
      <div class="sc y"><div class="sv">${p2(a.amarillas)}</div><div class="sl">🟨/P</div></div>
      <div class="sc r"><div class="sv">${a.rojas}</div><div class="sl">🟥 Total</div></div>
      <div class="sc r"><div class="sv">${p2(a.rojas)}</div><div class="sl">🟥/P</div></div>
      <div class="sc r"><div class="sv">${a.rojas_directas||0}</div><div class="sl">🟥 Directas</div></div>
    </div>
    <div class="st" style="margin-top:14px">Desglose por destinatario</div>
    <div class="tw"><table><thead><tr>
      <th>Destinatario</th>
      <th style="color:var(--a3)">🟨</th><th style="color:var(--a3)">🟨/P</th>
      <th style="color:var(--a2)">🟥</th><th style="color:var(--a2)">🟥/P</th>
    </tr></thead><tbody>
      <tr>
        <td>⚽ Jugadores</td>
        <td class="num" style="color:var(--a3)">${a.am_jug||0}</td>
        <td class="num" style="color:var(--a3)">${a.PJ?((a.am_jug||0)/a.PJ).toFixed(2):0}</td>
        <td class="num" style="color:var(--a2)">${a.ro_jug||0}</td>
        <td class="num" style="color:var(--a2)">${a.PJ?((a.ro_jug||0)/a.PJ).toFixed(2):0}</td>
      </tr>
      <tr>
        <td>🪑 Banquillo</td>
        <td class="num" style="color:var(--a3)">${a.am_banq||0}</td>
        <td class="num" style="color:var(--a3)">${a.PJ?((a.am_banq||0)/a.PJ).toFixed(2):0}</td>
        <td class="num" style="color:var(--a2)">${a.ro_banq||0}</td>
        <td class="num" style="color:var(--a2)">${a.PJ?((a.ro_banq||0)/a.PJ).toFixed(2):0}</td>
      </tr>
    </tbody></table></div>
    ${temps.length?`<div class="st" style="margin-top:14px">Trayectoria por temporada</div>
    <div class="tw"><table><thead><tr>
      <th>Temporada</th><th>PJ</th><th>G/P</th>
      <th style="color:var(--a3)">🟨</th><th style="color:var(--a3)">🟨/P</th>
      <th style="color:var(--a3)">🟨 Jug</th><th style="color:var(--a3)">🟨 Banq</th>
      <th style="color:var(--a2)">🟥</th><th style="color:var(--a2)">🟥/P</th>
      <th style="color:var(--a2)">🟥 Dir</th>
      <th style="color:var(--a2)">🟥 Jug</th><th style="color:var(--a2)">🟥 Banq</th>
    </tr></thead><tbody>
    ${temps.map(([t,s])=>`<tr>
      <td style="color:var(--acc);font-weight:600;cursor:pointer;text-decoration:underline dotted" title="Filtrar partidos de ${t}" onclick="filterRefereeMatches('${nombre.replace(/'/g,"\\'")}','${t}')">${t}</td>
      <td class="num">${s.PJ}</td>
      <td class="num">${s.PJ?(s.goles/s.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a3)">${s.amarillas}</td>
      <td class="num" style="color:var(--a3)">${s.PJ?(s.amarillas/s.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a3)">${s.am_jug||0}</td>
      <td class="num" style="color:var(--a3)">${s.am_banq||0}</td>
      <td class="num" style="color:var(--a2)">${s.rojas}</td>
      <td class="num" style="color:var(--a2)">${s.PJ?(s.rojas/s.PJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a2)">${s.rojas_directas||0}</td>
      <td class="num" style="color:var(--a2)">${s.ro_jug||0}</td>
      <td class="num" style="color:var(--a2)">${s.ro_banq||0}</td>
    </tr>`).join('')}
    <tr style="background:var(--s2);border-top:2px solid var(--b2);font-weight:700">
      <td style="color:var(--a3);font-family:'Bebas Neue',sans-serif;letter-spacing:1px">TOTAL</td>
      <td class="num" style="color:var(--acc)">${totPJ}</td>
      <td class="num">—</td>
      <td class="num" style="color:var(--a3)">${totAm}</td>
      <td class="num" style="color:var(--a3)">${totPJ>0?(totAm/totPJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a3)">—</td><td class="num" style="color:var(--a3)">—</td>
      <td class="num" style="color:var(--a2)">${totRo}</td>
      <td class="num" style="color:var(--a2)">${totPJ>0?(totRo/totPJ).toFixed(2):0}</td>
      <td class="num" style="color:var(--a2)">—</td>
      <td class="num" style="color:var(--a2)">—</td><td class="num" style="color:var(--a2)">—</td>
    </tr>
    </tbody></table></div>`:''}
    <div class="st" style="margin-top:14px" id="ref-matches-hdr">Partidos (${a.partidos.length})</div>
    <div id="ref-matches-list">${renderRefMatches(a.partidos)}</div>`;
  document.getElementById('modal-bg').classList.add('open');
}

function renderRefMatches(partidos){
  return partidos.sort((x,y)=>(y.jornada||0)-(x.jornada||0)).slice(0,50).map(p=>`
    <div class="mc" onclick="openMatch('${p.id}')">
      <div class="mm">J${p.jornada||'?'}<br>${p.fecha||''}</div>
      <div class="mts">
        <div class="mt h">${p.L}</div>
        <div class="ms ${c2(p.gl,p.gv)}">${p.gl} — ${p.gv}</div>
        <div class="mt">${p.V}</div>
      </div>
      <span class="mcat">${(p.cat||'').split('/')[0].trim()}</span>
    </div>`).join('');
}

function filterRefereeMatches(nombre, temp){
  const {arbs}=GS();const a=arbs[nombre];if(!a)return;
  const filtrados=a.partidos.filter(p=>{
    const acta=ACTAS.find(ac=>ac.acta_id===p.id);
    return acta&&acta.temporada===temp;
  });
  const hdr=document.getElementById('ref-matches-hdr');
  const lst=document.getElementById('ref-matches-list');
  if(!hdr||!lst)return;
  hdr.innerHTML=`Partidos ${temp} (${filtrados.length}) <button onclick="openReferee('${nombre.replace(/'/g,"\\'")}');setTimeout(()=>{const h=document.getElementById('ref-matches-hdr');if(h)h.scrollIntoView({block:'start',behavior:'smooth'})},50)" style="font-size:11px;background:var(--s2);border:1px solid var(--b);color:var(--mu);border-radius:5px;padding:2px 8px;cursor:pointer;margin-left:8px">Ver todos</button>`;
  lst.innerHTML=renderRefMatches(filtrados);
  lst.scrollIntoView({block:'start',behavior:'smooth'});
}

// ── ACTAS ─────────────────────────────────────────────────────────────────────
function rAc(){
  const cat=document.getElementById('ac-cat').value;
  const srch=document.getElementById('ac-s')?.value.toLowerCase()||'';
  const list=ACTAS.filter(a=>(!cat||a.categoria===cat)&&
    (!srch||[a.equipo_local,a.equipo_visitante,a.acta_id].join(' ').toLowerCase().includes(srch))
  ).sort((a,b)=>(b.jornada||0)-(a.jornada||0));
  const byJ={};
  list.forEach(a=>{const j=a.jornada||'?';if(!byJ[j])byJ[j]=[];byJ[j].push(a);});
  let h='';
  Object.keys(byJ).sort((a,b)=>b-a).forEach(j=>{
    h+=`<div class="jh"><span>Jornada ${j}</span></div>`;
    h+=byJ[j].map(a=>{
      const gl=a.goles_local||0,gv=a.goles_visitante||0;
      const fbadge=a.fuente==='euskadi'?'<span class="fbadge eus">EUS</span>':a.fuente==='gipuzkoa'?'<span class="fbadge gip">GIP</span>':a.fuente==='bizkaia'?'<span class="fbadge biz">BIZ</span>':a.fuente==='rfef'?'<span class="fbadge rfef">RFEF</span>':'';
      const revisada = _actaRevisada(a.acta_id);
      const tickBadge = revisada
        ? '<span title="Sin discrepancias — acta revisada" style="position:absolute;top:5px;right:5px;font-size:11px;color:var(--hw);background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.35);border-radius:10px;padding:1px 5px;line-height:1.4">✓</span>'
        : '';
      return `<div class="mc" onclick="openMatch('${a.acta_id}')" style="position:relative">
        ${tickBadge}
        <div class="mm" style="font-size:10px">${a.acta_id}<br>${a.fecha||''}</div>
        <div class="mts">
          <div class="mt h">${a.equipo_local||'?'}</div>
          <div class="ms ${c2(gl,gv)}">${gl} — ${gv}</div>
          <div class="mt">${a.equipo_visitante||'?'}</div>
        </div>
        ${fbadge}<span class="mcat">${(a.categoria||'').split('/')[0].trim()}</span>
      </div>`;
    }).join('');
  });
  document.getElementById('ac-l').innerHTML=h||'<div class="empty">Sin actas</div>';
}

// ── NAV ───────────────────────────────────────────────────────────────────────
function SP(name){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('on'));
  document.getElementById('p-'+name)?.classList.add('on');
  document.querySelectorAll('.nb').forEach(b=>{if(b.getAttribute('onclick')?.includes("'"+name+"'"))b.classList.add('on');});
  if(name==='cfg'){ cfgTab('cat'); return; }
  if(name==='dl'){  dlTab('clubes'); return; }
  ({cl:rCl,pa:rPa,go:rGo,ju:rJu,eq:rEq,cb:rCb,h2:rH2,sc:rSc,ent:rEnt,arb:rArb})[name]?.();
}

// ── CALENDARIO ─────────────────────────────────────────────────────────────────
function abrirCalendario(categoria, temporada) {
  try {
    const actasFilt = ACTAS.filter(a => 
      !isSala(a.categoria) && 
      a.categoria === categoria && 
      (!temporada || a.temporada === temporada)
    );
    
    if (!actasFilt.length) {
      alert(`No hay actas para la categoría: ${catNombre(categoria) || categoria}`);
      return;
    }
    
    // Agrupar por jornada
    const porJornada = {};
    const equiposPorJornada = {};
    actasFilt.forEach(a => {
      const j = a.jornada || '?';
      if (!porJornada[j]) porJornada[j] = [];
      if (!equiposPorJornada[j]) equiposPorJornada[j] = new Set();
      porJornada[j].push(a);
      if (a.equipo_local) equiposPorJornada[j].add(a.equipo_local);
      if (a.equipo_visitante) equiposPorJornada[j].add(a.equipo_visitante);
    });
    
    // Calcular clasificación
    const cl = {};
    actasFilt.forEach(a => {
      if (!a.equipo_local || !a.equipo_visitante) return;
      const L = a.equipo_local, V = a.equipo_visitante;
      const gl = a.goles_local || 0, gv = a.goles_visitante || 0;
      [L, V].forEach(e => { if (!cl[e]) cl[e] = { PJ: 0, G: 0, E: 0, P: 0, GF: 0, GC: 0, Pts: 0 }; });
      cl[L].PJ++; cl[V].PJ++;
      cl[L].GF += gl; cl[L].GC += gv;
      cl[V].GF += gv; cl[V].GC += gl;
      if (gl > gv) { cl[L].G++; cl[L].Pts += 3; cl[V].P++; }
      else if (gl < gv) { cl[V].G++; cl[V].Pts += 3; cl[L].P++; }
      else { [L, V].forEach(e => { cl[e].E++; cl[e].Pts++; }); }
    });
    
    const clasificacion = Object.entries(cl)
      .map(([eq, stats]) => ({
        nombre: eq,
        PJ: stats.PJ, G: stats.G, E: stats.E, P: stats.P,
        GF: stats.GF, GC: stats.GC, DG: stats.GF - stats.GC, Pts: stats.Pts
      }))
      .sort((a, b) => b.Pts - a.Pts || (b.DG - a.DG) || b.GF - a.GF);
    
    clasificacion.forEach((eq, idx) => eq.posicion = idx + 1);

    // Calcular Pichichis (máximos goleadores)
    const pichichis = {};
    actasFilt.forEach(a => {
      (a.goleadores || []).forEach(g => {
        if (g.propia) return; // no contar goles en propia puerta
        const gn = normPerson(_rn(a.acta_id, g.jugador));
        let eqGol = '?';
        if ((a.jugadores_local || []).includes(g.jugador)) eqGol = a.equipo_local;
        else if ((a.jugadores_visitante || []).includes(g.jugador)) eqGol = a.equipo_visitante;
        if (eqGol === '?') return;
        if (!pichichis[gn]) pichichis[gn] = { goles: 0, equipo: eqGol };
        pichichis[gn].goles++;
        pichichis[gn].equipo = eqGol;
      });
    });
    const listaPichichis = Object.entries(pichichis)
      .map(([nombre, d]) => {
        const anioInfo = getAnioNacCached(nombre);
        return { nombre, goles: d.goles, equipo: d.equipo, anio: anioInfo ? anioInfo.anio : null };
      })
      .sort((a, b) => b.goles - a.goles || a.nombre.localeCompare(b.nombre));

    // Calcular Zamoras (porteros menos goleados, con mínimo 35% de minutos posibles)
    const porteros = {};
    actasFilt.forEach(a => {
      const gl = a.goles_local || 0, gv = a.goles_visitante || 0;
      const L = a.equipo_local, V = a.equipo_visitante;
      const pLOrig = a.portero_local || (a.titulares_local || [])[0];
      const pVOrig = a.portero_visitante || (a.titulares_visitante || [])[0];
      const pL = pLOrig ? normPerson(_rn(a.acta_id, pLOrig)) : null;
      const pV = pVOrig ? normPerson(_rn(a.acta_id, pVOrig)) : null;
      const sustL = a.sustituciones_local || [];
      const sustV = a.sustituciones_visitante || [];
      if (pL) {
        if (!porteros[pL]) porteros[pL] = { nombre: pL, equipo: L, GC: 0, PJ: 0, mins: 0 };
        porteros[pL].GC += gv;
        porteros[pL].PJ++;
        porteros[pL].equipo = L;
        const salL = sustL.find(sx => sx.sale === pLOrig);
        const entL = sustL.find(sx => sx.entra === pLOrig);
        porteros[pL].mins += (salL ? salL.min : 90) - (entL ? entL.min : 0);
      }
      if (pV) {
        if (!porteros[pV]) porteros[pV] = { nombre: pV, equipo: V, GC: 0, PJ: 0, mins: 0 };
        porteros[pV].GC += gl;
        porteros[pV].PJ++;
        porteros[pV].equipo = V;
        const salV = sustV.find(sx => sx.sale === pVOrig);
        const entV = sustV.find(sx => sx.entra === pVOrig);
        porteros[pV].mins += (salV ? salV.min : 90) - (entV ? entV.min : 0);
      }
    });
    // Jornadas ordenadas
    const jornadasOrdenadas = Object.keys(porJornada)
      .filter(j => j !== '?')
      .map(Number)
      .sort((a, b) => a - b);
    
    const minMinutosZamora = jornadasOrdenadas.length * 90 * 0.35;
    const listaZamoras = Object.entries(porteros)
      .map(([nombre, d]) => {
        const anioInfo = getAnioNacCached(nombre);
        return {
          nombre, equipo: d.equipo, GC: d.GC, PJ: d.PJ, mins: d.mins,
          media: d.PJ > 0 ? d.GC / d.PJ : 0,
          anio: anioInfo ? anioInfo.anio : null
        };
      })
      .filter(p => p.mins >= minMinutosZamora)
      .sort((a, b) => a.media - b.media || a.GC - b.GC);
    
    if (!jornadasOrdenadas.length) {
      alert('No hay jornadas con datos válidos');
      return;
    }
    
    // Crear overlay del modal
    const overlay = document.createElement('div');
    overlay.className = 'cal-modal-overlay';
    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    
    // Crear modal principal
    const modal = document.createElement('div');
    modal.className = 'cal-modal';
    modal.onclick = (e) => e.stopPropagation();
    
    // Header
    const header = document.createElement('div');
    header.className = 'cal-modal-header';
    header.innerHTML = `
      <h2 class="cal-modal-title">${getCatLogoNac(categoria)}${catNombre(categoria) || categoria}${temporada ? ` — ${temporada}` : ''}</h2>
      <button class="cal-modal-close" onclick="this.closest('.cal-modal-overlay').remove()">✕</button>
    `;
    modal.appendChild(header);
    
    // Contenedor principal
    const container = document.createElement('div');
    container.className = 'cal-container';
    
    // SECCIÓN CLASIFICACIÓN
    const clsDiv = document.createElement('div');
    clsDiv.innerHTML = '<div class="cal-section-title">📊 Clasificación</div>';
    
    const clsWrapper = document.createElement('div');
    clsWrapper.className = 'cal-clasificacion';
    
    const table = document.createElement('table');
    table.innerHTML = `
      <thead>
        <tr>
          <th style="width:30%;text-align:left;padding-left:8px">Equipo</th>
          <th style="width:12%;font-size:9px">Pts</th>
          <th style="width:12%;font-size:9px">PJ</th>
          <th style="width:12%;font-size:9px">G</th>
          <th style="width:12%;font-size:9px">E</th>
          <th style="width:12%;font-size:9px">P</th>
          <th style="width:12%;font-size:9px">DG</th>
        </tr>
      </thead>
      <tbody>
        ${clasificacion.map((eq, i) => `
          <tr>
            <td style="text-align:left;padding-left:8px;font-weight:600">${eq.posicion}. ${eq.nombre}</td>
            <td class="pts">${eq.Pts}</td>
            <td>${eq.PJ}</td>
            <td style="color:var(--hw)">${eq.G}</td>
            <td style="color:var(--a3)">${eq.E}</td>
            <td style="color:var(--a2)">${eq.P}</td>
            <td>${eq.DG > 0 ? '+' : ''}${eq.DG}</td>
          </tr>
        `).join('')}
      </tbody>
    `;
    clsWrapper.appendChild(table);
    clsDiv.appendChild(clsWrapper);
    container.appendChild(clsDiv);

    // SECCIÓN PICHICHIS
    const pichDiv = document.createElement('div');
    pichDiv.innerHTML = '<div class="cal-section-title">⚽ Pichichis</div>';

    // Filtro año nacimiento Pichichi
    const aniosPich = [...new Set(listaPichichis.map(p => p.anio).filter(Boolean))].sort();
    const pichFiltroDiv = document.createElement('div');
    pichFiltroDiv.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 8px;flex-wrap:wrap;';
    pichFiltroDiv.innerHTML = `
      <span style="font-size:11px;color:var(--mu)">Año nac.:</span>
      <select id="pich-anio-desde" style="font-size:11px;padding:2px 4px;background:var(--bg2);color:var(--tx);border:1px solid var(--brd);border-radius:4px">
        <option value="">Desde</option>
        ${aniosPich.map(a => `<option value="${a}">${a}</option>`).join('')}
      </select>
      <span style="font-size:11px;color:var(--mu)">—</span>
      <select id="pich-anio-hasta" style="font-size:11px;padding:2px 4px;background:var(--bg2);color:var(--tx);border:1px solid var(--brd);border-radius:4px">
        <option value="">Hasta</option>
        ${aniosPich.map(a => `<option value="${a}">${a}</option>`).join('')}
      </select>
      <button id="pich-anio-reset" style="font-size:11px;padding:2px 8px;background:var(--bg2);color:var(--mu);border:1px solid var(--brd);border-radius:4px;cursor:pointer">✕</button>
    `;
    pichDiv.appendChild(pichFiltroDiv);

    const pichWrapper = document.createElement('div');
    pichWrapper.className = 'cal-clasificacion';

    const pichTable = document.createElement('table');
    pichTable.id = 'pich-tabla';

    const renderPichichi = () => {
      const desde = parseInt(pichFiltroDiv.querySelector('[id="pich-anio-desde"]').value) || 0;
      const hasta = parseInt(pichFiltroDiv.querySelector('[id="pich-anio-hasta"]').value) || 9999;
      const filtrados = listaPichichis.filter(p => {
        if (!p.anio) return (!desde && !hasta) ? true : false;
        return p.anio >= desde && p.anio <= hasta;
      });
      let pos = 0;
      pichTable.innerHTML = `
        <thead>
          <tr>
            <th style="width:8%;font-size:9px">#</th>
            <th style="width:36%;text-align:left;padding-left:8px">Jugador</th>
            <th style="width:26%;text-align:left">Equipo</th>
            <th style="width:10%;font-size:9px">Año</th>
            <th style="width:10%;font-size:9px">Edad</th>
            <th style="width:10%;font-size:9px">Goles</th>
          </tr>
        </thead>
        <tbody>
          ${filtrados.length ? filtrados.map((p, i) => {
            const edad = p.anio ? (new Date().getFullYear() - p.anio) : null;
            return `
            <tr style="cursor:pointer" onclick="openPlayer('${p.nombre.replace(/'/g,"\\'")}')">
              <td>${i + 1}</td>
              <td style="text-align:left;padding-left:8px;font-weight:600;color:var(--acc)">${p.nombre}</td>
              <td style="text-align:left;font-size:11px">${p.equipo}</td>
              <td style="font-size:11px;color:var(--mu)">${p.anio || '-'}</td>
              <td style="font-size:11px;color:var(--mu)">${edad !== null ? edad : '-'}</td>
              <td class="pts">${p.goles}</td>
            </tr>`;
          }).join('') : `<tr><td colspan="6" style="padding:10px;color:var(--mu)">Sin goleadores en ese rango</td></tr>`}
        </tbody>
      `;
    };
    renderPichichi();
    pichWrapper.appendChild(pichTable);
    pichDiv.appendChild(pichWrapper);
    container.appendChild(pichDiv);

    // SECCIÓN ZAMORAS
    const zamDiv = document.createElement('div');
    zamDiv.innerHTML = `<div class="cal-section-title">🧤 Zamora (mín. 35% minutos — ${Math.round(minMinutosZamora)}')</div>`;

    // Filtro año nacimiento Zamora
    const aniosZam = [...new Set(listaZamoras.map(p => p.anio).filter(Boolean))].sort();
    const zamFiltroDiv = document.createElement('div');
    zamFiltroDiv.style.cssText = 'display:flex;align-items:center;gap:6px;padding:6px 8px;flex-wrap:wrap;';
    zamFiltroDiv.innerHTML = `
      <span style="font-size:11px;color:var(--mu)">Año nac.:</span>
      <select id="zam-anio-desde" style="font-size:11px;padding:2px 4px;background:var(--bg2);color:var(--tx);border:1px solid var(--brd);border-radius:4px">
        <option value="">Desde</option>
        ${aniosZam.map(a => `<option value="${a}">${a}</option>`).join('')}
      </select>
      <span style="font-size:11px;color:var(--mu)">—</span>
      <select id="zam-anio-hasta" style="font-size:11px;padding:2px 4px;background:var(--bg2);color:var(--tx);border:1px solid var(--brd);border-radius:4px">
        <option value="">Hasta</option>
        ${aniosZam.map(a => `<option value="${a}">${a}</option>`).join('')}
      </select>
      <button id="zam-anio-reset" style="font-size:11px;padding:2px 8px;background:var(--bg2);color:var(--mu);border:1px solid var(--brd);border-radius:4px;cursor:pointer">✕</button>
    `;
    zamDiv.appendChild(zamFiltroDiv);

    const zamWrapper = document.createElement('div');
    zamWrapper.className = 'cal-clasificacion';

    const zamTable = document.createElement('table');
    zamTable.id = 'zam-tabla';

    const renderZamora = () => {
      const desde = parseInt(zamFiltroDiv.querySelector('[id="zam-anio-desde"]').value) || 0;
      const hasta = parseInt(zamFiltroDiv.querySelector('[id="zam-anio-hasta"]').value) || 9999;
      const filtrados = listaZamoras.filter(p => {
        if (!p.anio) return (!desde && !hasta) ? true : false;
        return p.anio >= desde && p.anio <= hasta;
      });
      zamTable.innerHTML = `
        <thead>
          <tr>
            <th style="width:8%;font-size:9px">#</th>
            <th style="width:28%;text-align:left;padding-left:8px">Portero</th>
            <th style="width:22%;text-align:left">Equipo</th>
            <th style="width:10%;font-size:9px">Año</th>
            <th style="width:10%;font-size:9px">Edad</th>
            <th style="width:10%;font-size:9px">PJ</th>
            <th style="width:6%;font-size:9px">GC</th>
            <th style="width:6%;font-size:9px">Media</th>
          </tr>
        </thead>
        <tbody>
          ${filtrados.length ? filtrados.map((p, i) => {
            const edad = p.anio ? (new Date().getFullYear() - p.anio) : null;
            return `
            <tr style="cursor:pointer" onclick="openPlayer('${p.nombre.replace(/'/g,"\\'")}')">
              <td>${i + 1}</td>
              <td style="text-align:left;padding-left:8px;font-weight:600;color:var(--acc)">${p.nombre}</td>
              <td style="text-align:left;font-size:11px">${p.equipo}</td>
              <td style="font-size:11px;color:var(--mu)">${p.anio || '-'}</td>
              <td style="font-size:11px;color:var(--mu)">${edad !== null ? edad : '-'}</td>
              <td>${p.PJ}</td>
              <td style="color:var(--a2)">${p.GC}</td>
              <td class="pts">${p.media.toFixed(2)}</td>
            </tr>`;
          }).join('') : `<tr><td colspan="8" style="padding:10px;color:var(--mu)">Ningún portero en ese rango</td></tr>`}
        </tbody>
      `;
    };
    renderZamora();
    zamWrapper.appendChild(zamTable);
    zamDiv.appendChild(zamWrapper);
    container.appendChild(zamDiv);
    
    // SECCIÓN CALENDARIO
    const calDiv = document.createElement('div');
    calDiv.innerHTML = '<div class="cal-section-title">📅 Calendario</div>';
    
    // Botones de jornadas + botón partidos faltantes
    const btnsJornadas = document.createElement('div');
    btnsJornadas.className = 'cal-jornadas-btns';
    
    // Botón partidos faltantes
    const btnFaltantes = document.createElement('button');
    btnFaltantes.className = 'cal-jornada-btn cal-btn-faltantes';
    btnFaltantes.textContent = '⚠️ Faltantes';
    btnFaltantes.onclick = () => {
      document.querySelectorAll(`[data-jornada]`).forEach(e => e.style.display = 'none');
      document.getElementById('cal-faltantes').style.display = 'block';
      document.querySelectorAll('.cal-jornada-btn').forEach(b => b.classList.remove('active'));
      btnFaltantes.classList.add('active');
    };
    btnsJornadas.appendChild(btnFaltantes);
    
    jornadasOrdenadas.forEach(j => {
      const btn = document.createElement('button');
      btn.className = 'cal-jornada-btn';
      if (j === jornadasOrdenadas[0]) btn.classList.add('active');
      btn.textContent = `J${j}`;
      btn.onclick = () => {
        document.querySelectorAll(`[data-jornada]`).forEach(e => e.style.display = 'none');
        document.querySelector(`[data-jornada="${j}"]`).style.display = 'block';
        document.querySelectorAll('.cal-jornada-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      };
      btnsJornadas.appendChild(btn);
    });
    calDiv.appendChild(btnsJornadas);
    
    // PARTIDOS POR JORNADA
    jornadasOrdenadas.forEach(j => {
      const jornadaDiv = document.createElement('div');
      jornadaDiv.setAttribute('data-jornada', j);
      jornadaDiv.style.display = j === jornadasOrdenadas[0] ? 'block' : 'none';
      
      const jornadaTitle = document.createElement('div');
      jornadaTitle.style.cssText = 'font-size:12px;font-weight:700;color:var(--a3);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.5px';
      jornadaTitle.textContent = `Jornada ${j} (${porJornada[j].length} partidos)`;
      jornadaDiv.appendChild(jornadaTitle);
      
      if (!porJornada[j] || porJornada[j].length === 0) {
        const sinPartidos = document.createElement('div');
        sinPartidos.className = 'cal-sin-partidos';
        sinPartidos.textContent = 'Sin partidos en esta jornada';
        jornadaDiv.appendChild(sinPartidos);
      } else {
        porJornada[j].forEach(p => {
          const gl = p.goles_local || 0, gv = p.goles_visitante || 0;
          // Un partido tiene resultado si: tiene goles O tiene resultado field O tiene titulares (acta completada)
          const tienResultado = (gl + gv > 0) || p.resultado || (p.titulares_local && p.titulares_local.length > 0);
          
          const partidoDiv = document.createElement('div');
          partidoDiv.className = `cal-partido ${tienResultado ? '' : 'pendiente'}`;
          partidoDiv.style.position = 'relative';

          // Tick de revisión: solo si tiene acta y no hay discrepancia pendiente
          const calRevisado = tienResultado && p.acta_id && _actaRevisada(p.acta_id);
          const calTick = calRevisado
            ? `<span title="Sin discrepancias — partido revisado" style="position:absolute;top:6px;right:8px;font-size:11px;color:var(--hw);background:rgba(0,240,160,.15);border:1px solid rgba(0,240,160,.35);border-radius:10px;padding:1px 6px;line-height:1.4;pointer-events:none">✓</span>`
            : '';
          
          let resultadoHtml = '';
          if (tienResultado) {
            if (gl > gv) {
              resultadoHtml = `<span style="color:var(--hw)">${gl}</span> - <span>${gv}</span>`;
            } else if (gl < gv) {
              resultadoHtml = `<span>${gl}</span> - <span style="color:var(--hw)">${gv}</span>`;
            } else {
              resultadoHtml = `<span style="color:var(--a3)">${gl}</span> - <span style="color:var(--a3)">${gv}</span>`;
            }
          } else {
            resultadoHtml = `<span style="color:var(--a2)">- - -</span>`;
          }
          
          partidoDiv.innerHTML = `
            ${calTick}
            <div class="cal-partido-header">
              <div class="cal-partido-equipos">
                <div class="cal-partido-local">${p.equipo_local}</div>
                <div class="cal-partido-visitante">${p.equipo_visitante}</div>
              </div>
              <div class="cal-partido-resultado">${resultadoHtml}</div>
            </div>
            <div class="cal-fecha">🎫 Acta: ${p.acta_id || 'N/A'} | ${p.fecha || 'Sin fecha'}</div>
            ${!tienResultado ? '<div style="font-size:9px;color:var(--a2);margin-top:4px">⚠️ Resultado pendiente</div>' : ''}
          `;
          
          partidoDiv.style.cursor = 'pointer';
          partidoDiv.onclick = () => {
            if (tienResultado || p.acta_id) {
              mostrarDetallePartido(p);
            }
          };
          
          jornadaDiv.appendChild(partidoDiv);
        });
      }
      
      calDiv.appendChild(jornadaDiv);
    });
    
    // SECCIÓN PARTIDOS FALTANTES
    const faltantesDiv = document.createElement('div');
    faltantesDiv.id = 'cal-faltantes';
    faltantesDiv.setAttribute('data-jornada', 'faltantes');
    faltantesDiv.style.display = 'none';
    
    const faltantesTitle = document.createElement('div');
    faltantesTitle.style.cssText = 'font-size:12px;font-weight:700;color:var(--a3);margin-bottom:10px;text-transform:uppercase;letter-spacing:0.5px';
    faltantesTitle.textContent = '⚠️ Partidos Faltantes';
    faltantesDiv.appendChild(faltantesTitle);
    
    let hayFaltantes = false;
    jornadasOrdenadas.forEach(j => {
      const equiposConPartidos = new Set(porJornada[j]
        .filter(p => p.equipo_local && p.equipo_visitante)
        .flatMap(p => [p.equipo_local, p.equipo_visitante]));
      
      const equiposFaltantes = Array.from(equiposPorJornada[j] || [])
        .filter(eq => !equiposConPartidos.has(eq));
      
      if (equiposFaltantes.length > 0) {
        hayFaltantes = true;
        const jSection = document.createElement('div');
        jSection.style.marginBottom = '12px';
        
        const jTitle = document.createElement('div');
        jTitle.style.cssText = 'font-size:11px;font-weight:700;color:var(--a3);margin-bottom:6px';
        jTitle.textContent = `Jornada ${j} (${equiposFaltantes.length} equipo${equiposFaltantes.length > 1 ? 's' : ''})`;
        jSection.appendChild(jTitle);
        
        equiposFaltantes.forEach(eq => {
          const eqDiv = document.createElement('div');
          eqDiv.style.cssText = 'background:rgba(255,79,55,.12);border-left:3px solid var(--a2);padding:8px;margin-bottom:6px;border-radius:4px;font-size:11px';
          eqDiv.textContent = `${eq}`;
          jSection.appendChild(eqDiv);
        });
        
        faltantesDiv.appendChild(jSection);
      }
    });
    
    if (!hayFaltantes) {
      const sinFaltantes = document.createElement('div');
      sinFaltantes.className = 'cal-sin-partidos';
      sinFaltantes.textContent = '✅ Todos los partidos completados';
      faltantesDiv.appendChild(sinFaltantes);
    }
    
    calDiv.appendChild(faltantesDiv);
    container.appendChild(calDiv);
    modal.appendChild(container);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Asignar eventos (elementos ya en DOM y también referenciables por closure)
    pichFiltroDiv.querySelector('[id="pich-anio-desde"]').onchange = renderPichichi;
    pichFiltroDiv.querySelector('[id="pich-anio-hasta"]').onchange = renderPichichi;
    pichFiltroDiv.querySelector('[id="pich-anio-reset"]').onclick = () => {
      pichFiltroDiv.querySelector('[id="pich-anio-desde"]').value = '';
      pichFiltroDiv.querySelector('[id="pich-anio-hasta"]').value = '';
      renderPichichi();
    };
    zamFiltroDiv.querySelector('[id="zam-anio-desde"]').onchange = renderZamora;
    zamFiltroDiv.querySelector('[id="zam-anio-hasta"]').onchange = renderZamora;
    zamFiltroDiv.querySelector('[id="zam-anio-reset"]').onclick = () => {
      zamFiltroDiv.querySelector('[id="zam-anio-desde"]').value = '';
      zamFiltroDiv.querySelector('[id="zam-anio-hasta"]').value = '';
      renderZamora();
    };

  } catch (error) {
    console.error('Error en abrirCalendario:', error);
    alert('Error al abrir el calendario: ' + error.message);
  }
}

function mostrarDetallePartido(partido) {
  if (!partido || !partido.acta_id) return;
  
  // Crear modal overlay
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 10000; padding: 20px;
  `;
  
  // Crear contenedor del modal
  const modal = document.createElement('div');
  modal.style.cssText = `
    background: var(--s1); border: 1px solid var(--b);
    border-radius: 12px; max-width: 900px; width: 100%;
    max-height: 90vh; overflow-y: auto; padding: 30px;
    color: var(--tx); font-family: 'Inter', sans-serif;
  `;
  
  // Botón cerrar
  const btnCerrar = document.createElement('button');
  btnCerrar.innerHTML = '✕';
  btnCerrar.style.cssText = `
    position: absolute; top: 15px; right: 15px;
    background: none; border: none; color: var(--tx);
    font-size: 28px; cursor: pointer; width: 40px; height: 40px;
    display: flex; align-items: center; justify-content: center;
  `;
  btnCerrar.onclick = () => overlay.remove();
  modal.appendChild(btnCerrar);
  
  // Encabezado
  const header = document.createElement('div');
  header.style.cssText = `
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--b);
  `;
  
  const titleDiv = document.createElement('div');
  titleDiv.innerHTML = `
    <div style="font-size: 13px; color: var(--mu); margin-bottom: 8px;">
      J${partido.jornada || '?'} · ${partido.fecha || ''} · ${partido.hora || ''}
    </div>
    <div style="font-size: 24px; font-weight: 700; font-family: 'Bebas Neue', sans-serif; letter-spacing: 1px;">
      ${partido.equipo_local} ${partido.goles_local || 0} - ${partido.goles_visitante || 0} ${partido.equipo_visitante}
    </div>
    <div style="font-size: 12px; color: var(--mu); margin-top: 6px;">
      ${partido.categoria || ''} · Acta: ${partido.acta_id}
    </div>
  `;
  header.appendChild(titleDiv);
  modal.appendChild(header);
  
  // Contenido dividido en columnas
  const mainContent = document.createElement('div');
  mainContent.style.cssText = 'display: grid; grid-template-columns: 1fr 1fr; gap: 30px;';
  
  // COLUMNA IZQUIERDA: LOCAL
  const colLocal = document.createElement('div');
  colLocal.innerHTML = renderTeamDetails(partido, 'local');
  mainContent.appendChild(colLocal);
  
  // COLUMNA DERECHA: VISITANTE
  const colVisitante = document.createElement('div');
  colVisitante.innerHTML = renderTeamDetails(partido, 'visitante');
  mainContent.appendChild(colVisitante);
  
  modal.appendChild(mainContent);
  
  // SECCIÓN BAJA: INCIDENCIAS (si es responsive, ir a una sola columna)
  const incidents = document.createElement('div');
  incidents.style.cssText = 'margin-top: 30px; padding-top: 20px; border-top: 1px solid var(--b);';
  incidents.innerHTML = renderIncidencias(partido);
  modal.appendChild(incidents);
  
  // Responsive
  if (window.innerWidth < 900) {
    mainContent.style.gridTemplateColumns = '1fr';
  }
  
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  
  btnCerrar.focus();
}

function renderTeamDetails(partido, tipo) {
  const esLocal = tipo === 'local';
  const equipo = esLocal ? partido.equipo_local : partido.equipo_visitante;
  const titulares = esLocal ? partido.titulares_local : partido.titulares_visitante;
  const suplentes = esLocal ? partido.suplentes_local : partido.suplentes_visitante;
  const sustituciones = esLocal ? partido.sustituciones_local : partido.sustituciones_visitante;
  const entrenador = esLocal ? partido.entrenador_local : partido.entrenador_visitante;
  const dorsales = esLocal ? partido.dorsales_local : partido.dorsales_visitante;
  const minutos = partido.minutos_jugadores || {};
  
  return `
    <div>
      <h3 style="font-size: 16px; font-weight: 700; margin-bottom: 12px; color: var(--hw);">
        ${equipo}
      </h3>
      
      ${entrenador ? `<div style="font-size: 12px; color: var(--mu); margin-bottom: 15px;">
        <strong>Entrenador:</strong> ${entrenador}
      </div>` : ''}
      
      <div style="font-size: 11px; font-weight: 600; color: var(--a3); margin-bottom: 8px; text-transform: uppercase;">
        Titulares (${titulares?.length || 0})
      </div>
      <div style="margin-bottom: 16px;">
        ${(titulares || []).map(j => `
          <div style="font-size: 12px; padding: 6px 0; border-bottom: 1px solid var(--b2); display: flex; justify-content: space-between; cursor: pointer;" onclick="abrirJugador('${j.replace(/'/g, "\\'")}')">
            <span style="color: var(--hw);">${j}</span>
            <span style="color: var(--mu); font-family: 'JetBrains Mono';">${minutos[j] ? minutos[j] + "'" : '90\''}</span>
          </div>
        `).join('')}
      </div>
      
      ${(sustituciones || []).length > 0 ? `
        <div style="font-size: 11px; font-weight: 600; color: var(--a3); margin-bottom: 8px; text-transform: uppercase;">
          Cambios (${sustituciones.length})
        </div>
        <div style="margin-bottom: 16px;">
          ${sustituciones.map(s => `
            <div style="font-size: 11px; padding: 6px; background: var(--b2); border-radius: 4px; margin-bottom: 4px;">
              <div>${s.min}'</div>
              <div style="color: var(--a2); cursor: pointer;" onclick="abrirJugador('${s.sale.replace(/'/g, "\\'")}')">↓ ${s.sale}</div>
              <div style="color: var(--hw); cursor: pointer;" onclick="abrirJugador('${s.entra.replace(/'/g, "\\'")}')">↑ ${s.entra}</div>
            </div>
          `).join('')}
        </div>
      ` : ''}
      
      ${(suplentes || []).length > 0 ? `
        <div style="font-size: 11px; font-weight: 600; color: var(--mu); margin-bottom: 8px; text-transform: uppercase;">
          Suplentes (${suplentes.length})
        </div>
        <div>
          ${suplentes.map(j => `
            <div style="font-size: 12px; padding: 4px 0; color: var(--mu); cursor: pointer;" onclick="abrirJugador('${j.replace(/'/g, "\\'")}')">• ${j}</div>
          `).join('')}
        </div>
      ` : ''}
    </div>
  `;
}

function renderIncidencias(partido) {
  const goles = (partido.goleadores || []).filter(g => g.equipo !== '?');
  const tarjetas = partido.tarjetas || [];
  const arbitros = partido.arbitros || [];
  
  return `
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
      <div>
        <h4 style="font-size: 12px; font-weight: 700; color: var(--a3); margin-bottom: 12px; text-transform: uppercase;">
          Goles (${goles.length})
        </h4>
        <div>
          ${goles.length > 0 ? goles.map(g => `
            <div style="font-size: 12px; padding: 8px; background: var(--b2); border-radius: 4px; margin-bottom: 6px; border-left: 3px solid ${g.equipo === 'local' ? 'var(--hw)' : 'var(--lw)'}; cursor: pointer;" onclick="abrirJugador('${g.jugador.replace(/'/g, "\\'")}')">
              <strong>${g.minuto}'</strong> - ${g.jugador}
            </div>
          `).join('') : '<div style="font-size: 12px; color: var(--mu);">Sin goles</div>'}
        </div>
      </div>
      
      <div>
        <h4 style="font-size: 12px; font-weight: 700; color: var(--a3); margin-bottom: 12px; text-transform: uppercase;">
          Tarjetas (${tarjetas.length})
        </h4>
        <div>
          ${tarjetas.length > 0 ? tarjetas.map(t => {
            const color = t.tipo === 'roja' ? 'var(--lw)' : t.tipo === 'doble_amarilla' ? 'var(--a3)' : 'var(--dr)';
            const icono = t.tipo === 'roja' ? '🟥' : t.tipo === 'doble_amarilla' ? '📕' : '🟨';
            return `
              <div style="font-size: 12px; padding: 8px; background: var(--b2); border-radius: 4px; margin-bottom: 6px; cursor: pointer;" onclick="abrirJugador('${t.jugador.replace(/'/g, "\\'")}')">
                <span style="color: ${color}; margin-right: 6px;">${icono}</span>
                <strong>${t.minuto}'</strong> - ${t.jugador}
              </div>
            `;
          }).join('') : '<div style="font-size: 12px; color: var(--mu);">Sin tarjetas</div>'}
        </div>
      </div>
    </div>
    
    ${arbitros.length > 0 ? `
      <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid var(--b);">
        <h4 style="font-size: 12px; font-weight: 700; color: var(--a3); margin-bottom: 8px; text-transform: uppercase;">
          Árbitros
        </h4>
        <div style="font-size: 12px;">
          ${arbitros.map(a => `<div style="padding: 4px 0;">🏁 ${a}</div>`).join('')}
        </div>
      </div>
    ` : ''}
    
    ${partido.estadio ? `
      <div style="margin-top: 12px; font-size: 12px; color: var(--mu);">
        📍 ${partido.estadio}${partido.ciudad ? ' · ' + partido.ciudad : ''}
      </div>
    ` : ''}
  `;
}

function abrirJugador(nombreJugador) {
  // Buscar todas las actas donde aparezca este jugador
  const actasJugador = ACTAS.filter(a => {
    const todos = (a.jugadores_local || []).concat(a.jugadores_visitante || []);
    return todos.includes(nombreJugador);
  });
  
  if (actasJugador.length === 0) {
    alert(`No se encontraron actas para ${nombreJugador}`);
    return;
  }
  
  // Crear modal del jugador
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7); backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 10001; padding: 20px;
  `;
  
  const modal = document.createElement('div');
  modal.style.cssText = `
    background: var(--s1); border: 1px solid var(--b);
    border-radius: 12px; max-width: 1000px; width: 100%;
    max-height: 90vh; overflow-y: auto; padding: 30px;
    color: var(--tx); font-family: 'Inter', sans-serif;
  `;
  
  // Botón cerrar
  const btnCerrar = document.createElement('button');
  btnCerrar.innerHTML = '✕';
  btnCerrar.style.cssText = `
    position: absolute; top: 15px; right: 15px;
    background: none; border: none; color: var(--tx);
    font-size: 28px; cursor: pointer; width: 40px; height: 40px;
    display: flex; align-items: center; justify-content: center;
  `;
  btnCerrar.onclick = () => overlay.remove();
  modal.appendChild(btnCerrar);
  
  // Encabezado
  const header = document.createElement('div');
  header.style.cssText = `
    margin-bottom: 25px; padding-bottom: 15px; border-bottom: 1px solid var(--b);
  `;
  
  // Estadísticas del jugador
  let pj = 0, goles = 0, amarillas = 0, rojas = 0, equipos = new Set();
  let minutosTotales = 0;
  
  actasJugador.forEach(a => {
    const esLocal = a.jugadores_local?.includes(nombreJugador);
    const esVisitante = a.jugadores_visitante?.includes(nombreJugador);
    
    if (esLocal || esVisitante) {
      pj++;
      equipos.add(esLocal ? a.equipo_local : a.equipo_visitante);
      minutosTotales += a.minutos_jugadores?.[nombreJugador] || 0;
      goles += (a.goleadores || []).filter(g => g.jugador === nombreJugador && !g.propia).length;
      amarillas += (a.tarjetas || []).filter(t => t.jugador === nombreJugador && t.tipo === 'amarilla').length;
      rojas += (a.tarjetas || []).filter(t => t.jugador === nombreJugador && (t.tipo === 'roja' || t.tipo === 'doble_amarilla')).length;
    }
  });
  
  header.innerHTML = `
    <div style="font-size: 28px; font-weight: 700; font-family: 'Bebas Neue', sans-serif; letter-spacing: 1px; margin-bottom: 12px;">
      ${nombreJugador}
    </div>
    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin-bottom: 15px;">
      <div style="background: var(--b2); padding: 12px; border-radius: 8px; text-align: center;">
        <div style="font-size: 20px; font-weight: 700; color: var(--hw);">${pj}</div>
        <div style="font-size: 11px; color: var(--mu); text-transform: uppercase;">Partidos</div>
      </div>
      <div style="background: var(--b2); padding: 12px; border-radius: 8px; text-align: center;">
        <div style="font-size: 20px; font-weight: 700; color: var(--a3);">${goles}</div>
        <div style="font-size: 11px; color: var(--mu); text-transform: uppercase;">Goles</div>
      </div>
      <div style="background: var(--b2); padding: 12px; border-radius: 8px; text-align: center;">
        <div style="font-size: 20px; font-weight: 700; color: var(--dr);">${amarillas}</div>
        <div style="font-size: 11px; color: var(--mu); text-transform: uppercase;">Amarillas</div>
      </div>
      <div style="background: var(--b2); padding: 12px; border-radius: 8px; text-align: center;">
        <div style="font-size: 20px; font-weight: 700; color: var(--lw);">${rojas}</div>
        <div style="font-size: 11px; color: var(--mu); text-transform: uppercase;">Rojas</div>
      </div>
      <div style="background: var(--b2); padding: 12px; border-radius: 8px; text-align: center;">
        <div style="font-size: 20px; font-weight: 700; color: var(--a4);">${minutosTotales}'</div>
        <div style="font-size: 11px; color: var(--mu); text-transform: uppercase;">Minutos</div>
      </div>
    </div>
    <div style="font-size: 12px; color: var(--mu);">
      Equipos: ${[...equipos].join(', ')}
    </div>
  `;
  modal.appendChild(header);
  
  // Tabla de trayectoria
  const trayectoria = document.createElement('div');
  trayectoria.style.cssText = 'margin-top: 20px;';
  
  const title = document.createElement('h4');
  title.style.cssText = 'font-size: 12px; font-weight: 700; color: var(--a3); margin-bottom: 12px; text-transform: uppercase;';
  title.textContent = `Trayectoria (${actasJugador.length} partidos)`;
  trayectoria.appendChild(title);
  
  const tabla = document.createElement('div');
  tabla.style.cssText = 'display: flex; flex-direction: column; gap: 8px;';
  
  actasJugador.forEach(a => {
    const esLocal = a.jugadores_local?.includes(nombreJugador);
    const esVisitante = a.jugadores_visitante?.includes(nombreJugador);
    
    if (!esLocal && !esVisitante) return;
    
    const equipo = esLocal ? a.equipo_local : a.equipo_visitante;
    const rival = esLocal ? a.equipo_visitante : a.equipo_local;
    const resultado = esLocal ? `${a.goles_local}-${a.goles_visitante}` : `${a.goles_visitante}-${a.goles_local}`;
    const minutos = a.minutos_jugadores?.[nombreJugador] || 0;
    
    const goleadorEnPartido = (a.goleadores || []).filter(g => g.jugador === nombreJugador && !g.propia).length > 0;
    const tarjetasEnPartido = (a.tarjetas || []).filter(t => t.jugador === nombreJugador);
    
    let badges = '';
    if (goleadorEnPartido) badges += '<span style="background: var(--a3); color: #000; padding: 2px 6px; border-radius: 3px; font-size: 10px; font-weight: 700; margin-right: 4px;">⚽</span>';
    tarjetasEnPartido.forEach(t => {
      if (t.tipo === 'amarilla') badges += '<span style="background: var(--dr); color: #000; padding: 2px 6px; border-radius: 3px; font-size: 10px; font-weight: 700; margin-right: 4px;">🟨</span>';
      if (t.tipo === 'doble_amarilla' || t.tipo === 'roja') badges += '<span style="background: var(--lw); color: #000; padding: 2px 6px; border-radius: 3px; font-size: 10px; font-weight: 700; margin-right: 4px;">🟥</span>';
    });
    
    const row = document.createElement('div');
    row.style.cssText = `
      background: var(--b2); padding: 12px; border-radius: 6px; display: flex;
      justify-content: space-between; align-items: center; font-size: 12px;
    `;
    row.innerHTML = `
      <div style="flex: 1;">
        <div style="font-weight: 600; margin-bottom: 4px;">J${a.jornada} · ${a.fecha}</div>
        <div style="color: var(--mu); font-size: 11px;">${equipo} vs ${rival}</div>
      </div>
      <div style="text-align: right; margin-right: 15px;">
        ${badges}
        <div style="font-size: 13px; font-weight: 700; color: var(--hw); margin-top: 4px;">${resultado}</div>
        <div style="color: var(--mu); font-size: 11px;">${minutos}'</div>
      </div>
    `;
    tabla.appendChild(row);
  });
  
  trayectoria.appendChild(tabla);
  modal.appendChild(trayectoria);
  
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  
  btnCerrar.focus();
}


// ── DESCARGAS ─────────────────────────────────────────────────────────────────
// Sub-tab switching
function dlTab(tab){
  ['clubes','cats'].forEach(t=>{
    document.getElementById('dl-panel-'+t).style.display = t===tab?'':'none';
    const btn = document.getElementById('dl-tab-'+t);
    if(btn) btn.classList.toggle('on', t===tab);
  });
  if(tab==='clubes') rDlClubes();
  else               rDlCats();
}

// ── Estado de ordenación ────────────────────────────────────────────────────
let _dlClubSort = {col:1, asc:true};
let _dlCatSort  = {col:1, asc:true};

// ── CLUBES ──────────────────────────────────────────────────────────────────
function _buildClubesData(){
  // Recoger todos los clubs canónicos únicos
  const clubSet = new Set();
  ACTAS.filter(a=>!isSala(a.categoria)).forEach(a=>{
    [a.equipo_local,a.equipo_visitante].filter(Boolean).forEach(eq=>{
      clubSet.add(getClubCanon(eq));
    });
  });
  return [...clubSet].sort().map(club=>({
    club,
    prov: getProvincia(club) || ''
  }));
}

let _clubesData = null;
function getClubesData(){ if(!_clubesData) _clubesData=_buildClubesData(); return _clubesData; }

function dlSortClubes(col){
  if(_dlClubSort.col===col) _dlClubSort.asc=!_dlClubSort.asc;
  else { _dlClubSort.col=col; _dlClubSort.asc=true; }
  rDlClubes();
}

function rDlClubes(){
  const srch = (document.getElementById('dl-club-s')?.value||'').toLowerCase();
  const provFilt = document.getElementById('dl-club-prov')?.value||'';
  let data = getClubesData().filter(r=>{
    if(srch && !r.club.toLowerCase().includes(srch)) return false;
    if(provFilt==='_sin') return !r.prov;
    if(provFilt) return r.prov===provFilt;
    return true;
  });
  // Ordenar
  const {col,asc} = _dlClubSort;
  data = [...data].sort((a,b)=>{
    let va,vb;
    if(col===0) { va=a._idx||0; vb=b._idx||0; }
    else if(col===1){ va=a.club; vb=b.club; }
    else { va=a.prov||'zzz'; vb=b.prov||'zzz'; }
    const c = typeof va==='number'? va-vb : (va).localeCompare(vb);
    return asc?c:-c;
  });
  document.getElementById('dl-club-count').textContent = data.length + ' clubes';
  const PCOL = {'Álava':'#f5c842','Bizkaia':'#4d8bff','Gipuzkoa':'#00f0a0','Vasca':'#f5c842','Nacional':'#ff4040'};
  const tbody = document.getElementById('dl-club-body');
  tbody.innerHTML = data.map((r,i)=>{
    const pc = PCOL[r.prov]||'';
    const provHtml = r.prov
      ? `<span style="font-size:11px;font-weight:700;color:${pc};background:${pc}22;border:1px solid ${pc}55;border-radius:4px;padding:1px 7px">${r.prov}</span>`
      : `<span style="font-size:11px;color:var(--mu);font-style:italic">Sin asignar</span>`;
    return `<tr><td class="num">${i+1}</td><td style="font-weight:500">${r.club}</td><td>${provHtml}</td></tr>`;
  }).join('');
  // Guardar datos filtrados para CSV
  _dlClubsFiltered = data;
}
let _dlClubsFiltered = [];

function _csvClubes(data){
  const rows = [['Club','Provincia'],...data.map(r=>[r.club, r.prov||'Sin asignar'])];
  return rows.map(r=>r.map(v=>JSON.stringify(String(v||''))).join(',')).join('\\n');
}
function dlCsvClubes(){
  const csv = _csvClubes(_dlClubsFiltered.length?_dlClubsFiltered:getClubesData());
  const a=document.createElement('a');
  a.href='data:text/csv;charset=utf-8,\uFEFF'+encodeURIComponent(csv);
  a.download='clubes.csv'; a.click();
}
function copyCsvClubes(){
  navigator.clipboard?.writeText(_csvClubes(_dlClubsFiltered.length?_dlClubsFiltered:getClubesData()))
    .then(()=>toast('Copiado al portapapeles','ok'));
}

// ── CATEGORÍAS ──────────────────────────────────────────────────────────────
function _buildCatsData(){
  // Por cada combinación categoría+temporada, calcular stats
  const map = {}; // key: cat+'|||'+temp
  ACTAS.filter(a=>a.categoria && !isSala(a.categoria)).forEach(a=>{
    const cat  = a.categoria;
    const temp = a.temporada || '';
    const key  = cat+'|||'+temp;
    if(!map[key]) map[key] = {cat, temp, jornadas:new Set(), actas:[], eqJornadas:{}};
    const m = map[key];
    if(a.acta_id != null) m.actas.push(Number(a.acta_id));
    if(a.jornada != null){
      m.jornadas.add(a.jornada);
      // Contar jornadas por equipo para sacar el máximo
      [a.equipo_local,a.equipo_visitante].filter(Boolean).forEach(eq=>{
        if(!m.eqJornadas[eq]) m.eqJornadas[eq]=new Set();
        m.eqJornadas[eq].add(a.jornada);
      });
    }
  });
  return Object.values(map).map(m=>{
    const maxJorEq = Object.values(m.eqJornadas).reduce((mx,s)=>s.size>mx?s.size:mx, 0);
    const actasSorted = m.actas.sort((a,b)=>a-b);
    return {
      cat:      m.cat,
      grupo:    getCatGrupo(m.cat) || '—',
      prov:     getCatProvincia(m.cat) || '—',
      temp:     m.temp || '—',
      jornadas: maxJorEq || m.jornadas.size || 0,
      actaMin:  actasSorted.length ? actasSorted[0]             : '—',
      actaMax:  actasSorted.length ? actasSorted[actasSorted.length-1] : '—',
      // Nuevos campos para ascensos/descensos (por defecto vacíos)
      ascenso:  false,
      ascienden: 0,
      asiendeA: '',
      descenso: false,
      descienden: 0,
      descendeA: '',
    };
  });
}

let _catsData = null;
function getCatsData(){ if(!_catsData) _catsData=_buildCatsData(); return _catsData; }

function dlSortCats(col){
  if(_dlCatSort.col===col) _dlCatSort.asc=!_dlCatSort.asc;
  else { _dlCatSort.col=col; _dlCatSort.asc=true; }
  rDlCats();
}

function rDlCats(){
  const srch   = (document.getElementById('dl-cat-s')?.value||'').toLowerCase();
  const grpFilt= document.getElementById('dl-cat-grupo')?.value||'';
  let data = getCatsData().filter(r=>{
    if(srch && !r.cat.toLowerCase().includes(srch) && !r.temp.toLowerCase().includes(srch)) return false;
    if(grpFilt && r.grupo!==grpFilt) return false;
    return true;
  });
  // Ordenar
  const {col,asc} = _dlCatSort;
  data = [...data].sort((a,b)=>{
    const vals = [0, a.cat,a.grupo,a.prov,a.temp,a.jornadas,a.actaMin,a.actaMax,
                   a.ascenso?1:0, a.ascienden||0, a.asiendeA||'', a.descenso?1:0, a.descienden||0, a.descendeA||''];
    const valsB= [0, b.cat,b.grupo,b.prov,b.temp,b.jornadas,b.actaMin,b.actaMax,
                   b.ascenso?1:0, b.ascienden||0, b.asiendeA||'', b.descenso?1:0, b.descienden||0, b.descendeA||''];
    const va=vals[col], vb=valsB[col];
    const c = typeof va==='number'? va-vb : String(va).localeCompare(String(vb));
    return asc?c:-c;
  });
  document.getElementById('dl-cat-count').textContent = data.length + ' filas';
  const GCOL = {SENIOR:'var(--hw)',JUVENIL:'var(--a4)',CADETE:'var(--a5)'};
  const PCOL = {'Álava':'#f5c842','Bizkaia':'#4d8bff','Gipuzkoa':'#00f0a0','Vasca':'#f5c842','Nacional':'#ff4040'};
  const tbody = document.getElementById('dl-cat-body');
  tbody.innerHTML = data.map((r,i)=>{
    const gc = GCOL[r.grupo]||'var(--mu)';
    const pc = PCOL[r.prov]||'var(--mu)';
    const gBadge = r.grupo!=='—'
      ? `<span style="font-size:10px;font-weight:700;color:${gc};background:${gc}22;border:1px solid ${gc}55;border-radius:4px;padding:1px 6px">${r.grupo}</span>`
      : `<span style="font-size:11px;color:var(--mu);font-style:italic">—</span>`;
    const pBadge = r.prov!=='—'
      ? `<span style="font-size:10px;font-weight:700;color:${pc};background:${pc}22;border:1px solid ${pc}55;border-radius:4px;padding:1px 6px">${r.prov}</span>`
      : `<span style="font-size:11px;color:var(--mu);font-style:italic">—</span>`;
    const ascBadge = r.ascenso ? '✓ Sí' : '✗ No';
    const ascColor = r.ascenso ? 'color:#00f0a0' : 'color:var(--mu)';
    const descBadge = r.descenso ? '✓ Sí' : '✗ No';
    const descColor = r.descenso ? 'color:#ff4f37' : 'color:var(--mu)';
    return `<tr>
      <td class="num">${i+1}</td>
      <td style="font-weight:500">${getCatLogoNac(r.cat)}${r.cat}</td>
      <td>${gBadge}</td>
      <td>${pBadge}</td>
      <td style="font-family:'JetBrains Mono',monospace;font-size:12px">${r.temp}</td>
      <td class="num">${r.jornadas||'—'}</td>
      <td class="num" style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--mu)">${r.actaMin}</td>
      <td class="num" style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--mu)">${r.actaMax}</td>
      <td style="${ascColor};font-weight:600">${ascBadge}</td>
      <td class="num" style="color:${r.ascenso?'#00f0a0':'var(--mu)'}">${r.ascienden||'—'}</td>
      <td style="font-size:12px;color:${r.ascenso?'var(--tx)':'var(--mu)'}">${r.asiendeA||'—'}</td>
      <td style="${descColor};font-weight:600">${descBadge}</td>
      <td class="num" style="color:${r.descenso?'#ff4f37':'var(--mu)'}">${r.descienden||'—'}</td>
      <td style="font-size:12px;color:${r.descenso?'var(--tx)':'var(--mu)'}">${r.descendeA||'—'}</td>
    </tr>`;
  }).join('');
  _dlCatsFiltered = data;
}
let _dlCatsFiltered = [];

function _csvCats(data){
  const rows = [['Categoría','Grupo','Provincia','Temporada','Jornadas (máx equipo)','Acta mín','Acta máx','Ascenso','Ascienden','Sube a Liga','Descenso','Descienden','Baja a Liga'],
    ...data.map(r=>[r.cat,r.grupo,r.prov,r.temp,r.jornadas,r.actaMin,r.actaMax,
                     r.ascenso?'Sí':'No', r.ascienden||'', r.asiendeA||'',
                     r.descenso?'Sí':'No', r.descienden||'', r.descendeA||''])];
  return rows.map(r=>r.map(v=>JSON.stringify(String(v||''))).join(',')).join('\n');
}

function dlExcelCats(){
  // Usar SheetJS si está disponible (ya viene en algunas versiones)
  const data = _dlCatsFiltered.length?_dlCatsFiltered:getCatsData();
  const ws_data = [['Categoría','Grupo','Provincia','Temporada','Jornadas','Acta mín','Acta máx','Ascenso','Ascienden','Sube a Liga','Descenso','Descienden','Baja a Liga'],
    ...data.map(r=>[r.cat,r.grupo,r.prov,r.temp,r.jornadas||'',r.actaMin,r.actaMax,
                     r.ascenso?'Sí':'No', r.ascienden||'', r.asiendeA||'',
                     r.descenso?'Sí':'No', r.descienden||'', r.descendeA||''])];
  
  // Crear tabla HTML y descargar como Excel (compatibilidad máxima)
  let html = '<table><tr>';
  ws_data[0].forEach(h => html += '<th>' + h + '</th>');
  html += '</tr>';
  ws_data.slice(1).forEach(row => {
    html += '<tr>';
    row.forEach(cell => html += '<td>' + (cell||'') + '</td>');
    html += '</tr>';
  });
  html += '</table>';
  
  // Descargar como .xls (formato antiguo pero universal)
  const bom = '\uFEFF';
  const a = document.createElement('a');
  a.href = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(bom + html);
  a.download = 'categorias_ascensos_descensos.xls';
  a.click();
  toast('Excel descargado','ok');
}

function uploadExcelCats(event){
  const file = event.target.files[0];
  if(!file) return;
  
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = new Uint8Array(e.target.result);
      // Usar función para leer Excel si existe
      if(typeof XLSX !== 'undefined') {
        const workbook = XLSX.read(data, {type: 'array'});
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet);
        
        // Actualizar datos con los valores del Excel
        updateCatsFromExcel(rows);
      } else {
        toast('Se requiere SheetJS para procesar Excel','error');
      }
    } catch(err) {
      toast('Error al procesar Excel: ' + err.message,'error');
      console.error(err);
    }
  };
  reader.readAsArrayBuffer(file);
}

function updateCatsFromExcel(rows){
  // Buscar categorías en los datos actuales y actualizarlas
  let updated = 0;
  rows.forEach(row => {
    const cat = row['Categoría'] || row['categoria'];
    if(!cat) return;
    
    // Buscar en getCatsData()
    const catsData = getCatsData();
    const idx = catsData.findIndex(c => c.cat === cat);
    if(idx >= 0) {
      catsData[idx].ascenso = row['Ascenso']?.toLowerCase() === 'sí';
      catsData[idx].ascienden = parseInt(row['Ascienden']) || 0;
      catsData[idx].asiendeA = row['Sube a Liga'] || '';
      catsData[idx].descenso = row['Descenso']?.toLowerCase() === 'sí';
      catsData[idx].descienden = parseInt(row['Descienden']) || 0;
      catsData[idx].descendeA = row['Baja a Liga'] || '';
      updated++;
    }
  });
  
  // Guardar en localStorage
  localStorage.setItem('faf_cats_ascensos', JSON.stringify(getCatsData()));
  
  // Refrescar tabla
  rDlCats();
  
  toast(`${updated} categorías actualizadas`,'ok');
  console.log(`✓ Cargadas ${updated} categorías desde Excel`);
}

// Al iniciar, restaurar ascensos/descensos desde localStorage si existen
(function() {
  try {
    const cached = localStorage.getItem('faf_cats_ascensos');
    if(cached) {
      const data = JSON.parse(cached);
      // Aplicar datos guardados a _catsData
      data.forEach(newData => {
        // Buscar en getCatsData() y actualizar
        const catsData = getCatsData();
        const idx = catsData.findIndex(c => c.cat === newData.cat && c.temp === newData.temp);
        if(idx >= 0) {
          catsData[idx].ascenso = newData.ascenso;
          catsData[idx].ascienden = newData.ascienden;
          catsData[idx].asiendeA = newData.asiendeA;
          catsData[idx].descenso = newData.descenso;
          catsData[idx].descienden = newData.descienden;
          catsData[idx].descendeA = newData.descendeA;
        }
      });
      console.log('✓ Ascensos/descensos restaurados desde localStorage');
    }
  } catch(e) {
    console.log('Info: No hay datos de ascensos/descensos guardados');
  }
})();


// ── HERO ──────────────────────────────────────────────────────────────────────
function buildHero(){
  const {cl,gols,jug,enf}=GS();
  const totP=enf.length;
  const totJ=Object.keys(jug).length;
  const totG=Object.values(gols).reduce((s,c)=>s+Object.values(c).reduce((a,b)=>a+b.goles,0),0);
  const totCat=Object.keys(cl).length;
  const totEq=[...new Set(enf.flatMap(e=>[e.L,e.V]))].length;
  const hero=`<div class="hgrid">
    <div class="hc g"><div class="hv">${totP}</div><div class="hl">Partidos</div></div>
    <div class="hc b"><div class="hv">${totEq}</div><div class="hl">Equipos</div></div>
    <div class="hc p"><div class="hv">${totJ}</div><div class="hl">Jugadores</div></div>
    <div class="hc y"><div class="hv">${totG}</div><div class="hl">Goles</div></div>
    <div class="hc r"><div class="hv">${totCat}</div><div class="hl">Categorías</div></div>
  </div>`;
  document.getElementById('p-cl').insertAdjacentHTML('afterbegin',hero);
}

updSels();buildHero();
// ── Valores por defecto: temporada actual, Álava, Juvenil ──────────────────
(function(){
  const tempEl=document.getElementById('cl-temp');
  if(tempEl){
    // Buscar la temporada 2025-2026 si existe, si no la más reciente
    const opts=[...tempEl.options].map(o=>o.value).filter(Boolean);
    const def=opts.find(t=>t==='2025-2026')||opts.sort((a,b)=>b.localeCompare(a))[0]||'';
    if(def) tempEl.value=def;
  }
  const provEl=document.getElementById('cl-prov');
  if(provEl) provEl.value='Álava';
  const grupoEl=document.getElementById('cl-grupo');
  if(grupoEl) grupoEl.value='JUVENIL';
  // _updateClFilters respetará grupo+prov+temp ya seteados para poblar cat y temp
  _updateClFilters();
})();
rCl();rCfgCat();

// Guardar cambios en objetos globales
const handler = {
  set: function(target, property, value) {
    target[property] = value;
    return true;
  }
};

if (typeof ACTAS === 'object') {
  const ACtasProxy = new Proxy(ACTAS, handler);
}

// Guardar antes de cerrar la pestaña
window.addEventListener('beforeunload', autoSaveToLocalStorage);

// ═══════════════════════════════════════════════════════════════
// OPTIMIZACIÓN: localStorage AUTO-PERSISTENTE
// Guarda TODO (actas, datos, cambios) en localStorage
// Funciona en CUALQUIER dispositivo: envía el HTML por mail, se abre en otro PC y ¡todo está ahí!
// ═══════════════════════════════════════════════════════════════

// Al cargar: restaurar desde localStorage si existe
window.addEventListener('load', function() {
  try {
    const cached = localStorage.getItem('faf_actas_full_cache');
    const timestamp = localStorage.getItem('faf_cache_timestamp');
    if(cached) {
      console.log('[localStorage] ✓ Datos restaurados desde localStorage (timestamp:', new Date(parseInt(timestamp)).toLocaleString(), ')');
    }
  } catch(e) {
    console.warn('[localStorage] Advertencia:', e.message);
  }
});

// Guardar TODA la información en localStorage después de procesar
function autoSaveToLocalStorage() {
  try {
    // Guardar el estado completo de ACTAS
    localStorage.setItem('faf_actas_full_cache', JSON.stringify(ACTAS));
    
    // Guardar ascensos/descensos de categorías
    if(_catsData) {
      localStorage.setItem('faf_cats_ascensos', JSON.stringify(_catsData));
    }
    
    // Guardar configuración de categorías
    try {
      localStorage.setItem('faf_cat_overrides', JSON.stringify(loadCatOverrides()));
    } catch(e) {}
    
    // Timestamp de cuándo fue guardado (para debugging)
    localStorage.setItem('faf_cache_timestamp', Date.now().toString());
    
    console.log('[localStorage] ✓ Auto-guardado completado (incluyendo ascensos/descensos)');
  } catch(e) {
    if(e.name === 'QuotaExceededError') {
      console.warn('[localStorage] ⚠ Cuota excedida');
    } else {
      console.log('[localStorage] Info:', e.message);
    }
  }
}

// Guardar cada 10 segundos (más frecuente que saveDataToJSON)
setInterval(autoSaveToLocalStorage, 10000);

console.log('✓ Sistema de localStorage persistente activado');
console.log('  Los datos se guardan automáticamente cada 10 segundos');
console.log('  Si llevas este HTML a otro dispositivo, ¡todo estará aquí!');
</script>

<!-- ── Modal visor/editor de discrepancias ─────────────────────────────── -->
<div id="disc-modal-overlay" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(7,9,14,.88);backdrop-filter:blur(6px);align-items:center;justify-content:center;padding:16px" onclick="if(event.target===this)discCerrarVisor()">
  <div style="background:var(--s1);border:1px solid var(--b2);border-radius:12px;width:100%;max-width:720px;max-height:90vh;overflow-y:auto;padding:20px;position:relative;box-shadow:0 24px 64px rgba(0,0,0,.6)">
    <div id="disc-modal-body"></div>
  </div>
</div>
</body>
</html>"""

    # Sustituir metadatos y datos
    tpl = tpl.replace("TMETA_TOTAL", str(total))
    tpl = tpl.replace("TMETA_JUG",   str(n_jug))
    tpl = tpl.replace("TMETA_GEN",   gen)
    tpl = tpl.replace(TOKEN,          db_js)
    tpl = tpl.replace(TOKEN_LOGOS,    logos_js)
    tpl = tpl.replace(TOKEN_CLUBS,    club_map_js)
    tpl = tpl.replace(TOKEN_ENTRENADORES, entrenadores_map_js)
    tpl = tpl.replace(TOKEN_PROVINCIA,    provincia_map_js)
    tpl = tpl.replace(TOKEN_CAT_CFG,      cat_cfg_js)
    tpl = tpl.replace(TOKEN_DISCREPANCIAS, disc_js)
    tpl = tpl.replace(TOKEN_LIGAS_TC,      ligas_con_tabla_js)

    out = os.path.join(HTML_DIR, "FAF_Stats.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(tpl)
    
    kb_size = os.path.getsize(out)//1024
    print(f"[+] HTML: {out} ({kb_size} KB, {total} actas)")
    print(f"    ✓ localStorage ACTIVADO — Todos los datos se guardan automáticamente")
    print(f"    ✓ Excel/CSV en Descargas — Incluye ascensos/descensos")
    print(f"    ✓ Subir Excel — Actualiza ascensos/descensos y persiste")
    print(f"    ✓ Puedes enviar este HTML por mail a otro dispositivo y ¡todo estará aquí!")
    return out

# ═══════════════════════════════════════════════════════════════
#  PASO 4 — REVISIÓN DE TARJETAS (detección de rojas directas)
# ═══════════════════════════════════════════════════════════════
TARJETAS_REVISADAS_FILE = FUENTES["alava"]["revisadas_file"]  # se sobreescribe en main()
LOTE_REVISION = 20   # actas por pasada

def load_revisadas(fpath=None):
    try:
        with open(fpath or TARJETAS_REVISADAS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    except:
        return set()

def save_revisadas(revisadas, fpath=None):
    with open(fpath or TARJETAS_REVISADAS_FILE, "w", encoding="utf-8") as f:
        json.dump(sorted(revisadas), f)

def _color_icono_tarjeta(driver, minuto, nombre_jugador):
    """
    Usa Selenium para leer el color REAL del icono de tarjeta en el DOM renderizado.
    El FAF usa un cuadradito (<span> o <img>) cuyo color CSS distingue
    amarilla (#f5c800 / amarillo) de roja (#cc0000 / rojo).
    Devuelve: 'roja' | 'amarilla' | None (si no se encuentra el elemento)
    """
    nombre_upper = nombre_jugador.upper()
    min_str      = f"({minuto}')"

    try:
        # Buscar todos los elementos que contengan el minuto como texto
        # y tengan cerca el nombre del jugador (dentro de la misma fila/bloque)
        xpath_expr = f"//*[contains(text(), '({minuto}\')') or contains(text(), '({minuto}\'+')]"
        elementos = driver.find_elements("xpath", xpath_expr)
        for el in elementos:
            try:
                # Subir hasta el contenedor de la fila de tarjeta (~3 niveles)
                fila = el
                for _ in range(4):
                    texto_fila = fila.text.upper() if fila.text else ""
                    # Comprobar que el nombre del jugador está en esta fila
                    if nombre_upper[:14] in texto_fila or nombre_upper.split(",")[0].strip() in texto_fila:
                        # Buscar el icono de tarjeta dentro de esta fila
                        iconos = fila.find_elements("css selector",
                            "span[class*='tarjeta'], span[class*='card'], "
                            "img[src*='tarjeta'], img[src*='card'], "
                            "span[style*='background'], div[class*='tarjeta']"
                        )
                        for icono in iconos:
                            # Leer color de fondo computado
                            try:
                                bg = driver.execute_script(
                                    "return window.getComputedStyle(arguments[0]).backgroundColor;",
                                    icono
                                ) or ""
                                src = icono.get_attribute("src") or ""
                                cls = icono.get_attribute("class") or ""
                                style = icono.get_attribute("style") or ""
                                combinado = (bg + src + cls + style).lower()
                                # Rojo: rgb(r>150, g<80, b<80) o palabras clave
                                if _bg_es_roja(bg) or any(k in combinado for k in [
                                    "roja", "red", "#c00", "#d00", "#e00", "#cc0000",
                                    "rgb(204", "rgb(200", "rgb(220", "rgb(180,0", "rgb(255,0,0"
                                ]):
                                    return "roja"
                                if _bg_es_amarilla(bg) or any(k in combinado for k in [
                                    "amarilla", "yellow", "#f5c", "#fc0", "#ff0",
                                    "rgb(245,200", "rgb(255,200", "rgb(240,180"
                                ]):
                                    return "amarilla"
                            except Exception:
                                continue
                    if fila.tag_name.lower() in ("body", "html"):
                        break
                    try:
                        fila = fila.find_element("xpath", "..")
                    except Exception:
                        break
            except Exception:
                continue
    except Exception:
        pass
    return None   # no se pudo determinar → dejar como amarilla (valor por defecto)


def _bg_es_roja(bg_css):
    """True si el color CSS de fondo es rojo (tarjeta roja)."""
    # bg_css formato: "rgb(r, g, b)" o "rgba(r, g, b, a)"
    m = re.search(r"rgb\w*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)", bg_css)
    if not m:
        return False
    r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
    return r > 140 and g < 80 and b < 80


def _bg_es_amarilla(bg_css):
    """True si el color CSS de fondo es amarillo/naranja (tarjeta amarilla)."""
    m = re.search(r"rgb\w*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)", bg_css)
    if not m:
        return False
    r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
    return r > 180 and g > 140 and b < 80


def revisar_tarjetas_html(fuente_cfg=None):
    """
    Paso 4: Re-descarga el HTML de actas con tarjetas y corrige rojas directas.
    Procesa LOTE_REVISION actas por pasada, guardando progreso para reanudar.
    """
    if fuente_cfg is None:
        fuente_cfg = FUENTES["alava"]
    json_dir = fuente_cfg["json_dir"]
    revisadas_file = fuente_cfg["revisadas_file"]

    print("\n[*] PASO 4 — Revisión de tarjetas (detección de rojas directas)")
    revisadas = load_revisadas(revisadas_file)

    # Acta prioritaria para prueba/validacion — siempre va primera si no esta revisada
    ACTA_PRUEBA = "9989523"

    # Recopilar actas con tarjetas que aun no se han revisado
    pendientes = []
    for fn in sorted(f for f in os.listdir(json_dir) if f.endswith(".json")):
        aid = fn.replace(".json", "")
        if aid in revisadas:
            continue
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as jf:
                datos = json.load(jf)
            # Solo revisar actas que tengan tarjetas marcadas como "amarilla"
            if any(t.get("tipo") == "amarilla" for t in datos.get("tarjetas", [])):
                pendientes.append(aid)
        except:
            continue

    # Poner la acta de prueba la primera si esta pendiente
    if ACTA_PRUEBA in pendientes:
        pendientes.remove(ACTA_PRUEBA)
        pendientes.insert(0, ACTA_PRUEBA)
        print(f"  [!] Acta de prueba {ACTA_PRUEBA} colocada en primera posicion")

    total_pendientes = len(pendientes)
    lote = pendientes[:LOTE_REVISION]

    print(f"  Actas con amarillas pendientes de revisión : {total_pendientes}")
    print(f"  Esta pasada revisará                       : {len(lote)} actas")
    if not lote:
        print("  [✓] Todas las actas con tarjetas ya han sido revisadas.")
        return

    print("[*] Iniciando Chrome para revisión...")
    driver = crear_nav(0)
    calentar(driver, fuente_cfg)

    corregidas_total = 0
    errores = 0

    for idx, aid in enumerate(lote, 1):
        # Para las de Euskadi el aid ya incluye el prefijo E_ (ej: "E_9969188")
        # Para RFEF el aid incluye N_ (ej: "N_70674828")
        # Hay que extraer solo el número para construir la URL
        raw_id = aid
        for pfx in ("E_", "G_", "B_", "N_"):
            if aid.startswith(pfx):
                raw_id = aid[len(pfx):]
                break
        url = f"{fuente_cfg['base_url']}?cod_primaria={fuente_cfg['cod_primaria']}&CodActa={raw_id}"
        print(f"  ({idx:>2}/{len(lote)}) Acta {aid}...", end=" ", flush=True)
        try:
            driver.get(url)
            WebDriverWait(driver, PAGE_TIMEOUT).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
                          and len(d.page_source) > 300)
            time.sleep(random.uniform(0.4, 0.9))
            jp = os.path.join(json_dir, f"{aid}.json")
            with open(jp, encoding="utf-8") as jf:
                datos = json.load(jf)

            cambios = 0
            for tarjeta in datos["tarjetas"]:
                if tarjeta.get("tipo") != "amarilla":
                    continue
                minuto  = tarjeta.get("minuto", 0)
                jugador = tarjeta.get("jugador", "")
                resultado = _color_icono_tarjeta(driver, minuto, jugador)
                if resultado == "roja":
                    tarjeta["tipo"] = "roja"
                    cambios += 1

            # Recalcular suspendidos
            datos["suspendidos"] = [
                t["jugador"] for t in datos["tarjetas"]
                if t.get("tipo") in ("doble_amarilla", "roja")
            ]

            with open(jp, "w", encoding="utf-8") as jf:
                json.dump(datos, jf, indent=2, ensure_ascii=False)

            revisadas.add(aid)
            if cambios:
                print(f"✓ {cambios} roja(s) directa(s) corregida(s)")
                corregidas_total += cambios
            else:
                print("✓ sin cambios")

        except Exception as e:
            print(f"✗ Error: {str(e).split(chr(10))[0][:80]}")
            errores += 1

        time.sleep(random.uniform(0.8, 1.4))

    cerrar(driver)
    save_revisadas(revisadas, revisadas_file)

    restantes = total_pendientes - len(lote)
    print(f"\n[+] Revisadas: {len(lote)} | Rojas directas corregidas: {corregidas_total} | Errores: {errores}")
    if restantes > 0:
        print(f"[~] Quedan {restantes} actas — vuelve a ejecutar el Paso 4 para continuar.")
    else:
        print("[✓] Revisión completa de todas las actas con tarjetas.")

    print("[*] Regenerando HTML...")
    generar_html()
    print("[✓] HTML actualizado.\n")


# ═══════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════
def limpiar_vacias(fuente_cfg=None):
    if fuente_cfg is None:
        fuente_cfg = FUENTES["alava"]
    out_dir  = fuente_cfg["output_dir"]
    prefix   = fuente_cfg["prefix"]
    empty_fp = fuente_cfg["empty_file"]

    print(f"\n[*] MODO 5 — Limpieza de actas vacías ({fuente_cfg['label']})")
    print(f"    Umbral: menos de {MIN_LINEAS_REAL} líneas = vacía\n")

    pat = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    txts = [f for f in os.listdir(out_dir) if pat.match(f)]

    empty_ids = load_empty_ids(empty_fp)
    eliminadas = 0
    ya_marcadas_antes = 0
    revisadas_total   = 0

    for fn in sorted(txts):
        fp = os.path.join(out_dir, fn)
        revisadas_total += 1
        if es_acta_vacia(fp):
            cod = pat.search(fn).group(1)
            # Marcar con timestamp (para reintento futuro)
            ya_estaba = str(cod) in empty_ids
            mark_empty(cod, empty_ids, empty_fp)
            try:
                os.remove(fp)
                print(f"  [x] Eliminada: {fn} {'(ya marcada antes)' if ya_estaba else '(nueva)'}")
                eliminadas += 1
                if ya_estaba:
                    ya_marcadas_antes += 1
            except Exception as e:
                print(f"  [!] No se pudo borrar {fn}: {e}")

    print(f"\n[+] Revisadas: {revisadas_total} TXTs")
    print(f"[+] Eliminadas (vacías): {eliminadas}  "
          f"({ya_marcadas_antes} ya estaban en empty_ids, "
          f"{eliminadas - ya_marcadas_antes} nuevas)")
    print(f"[~] Todas marcadas con timestamp → se reintentarán en {7} días")
    print(f"[~] Para forzar re-descarga inmediata de una acta: Modo 2 con ese ID\n")


# ═══════════════════════════════════════════════════════════════
#  MODO 6 — ANÁLISIS DE HUECOS ENTRE IDs DESCARGADOS
#  Detecta IDs intermedios que faltan (gaps de 1-2 entre IDs
#  consecutivos en disco), los agrupa por competición según
#  los vecinos y estima qué jornada/partido podrían ser.
#
#  DESCARGA: las 7 fuentes (ALAVA, BIZKAIA, GIPUZKOA, NAVARRA,
#  RIOJA, RFEF, EUSKADI) se descargan EN PARALELO, cada una en su
#  propio hilo y con su propia sesión de Chrome (son webs/dominios
#  distintos, así que no se bloquean entre sí). Cada línea de log
#  indica SIEMPRE de qué fuente viene (tag [ALAVA], [BIZKAIA]...).
#
#  Si en algún momento se simula un movimiento "humano" en la
#  página (scroll, mouse, etc.) para parecer menos un bot, también
#  queda registrado en el log con su propio tag, igual que el resto.
#
#  Backoff ante bloqueos: cada racha de bloqueos dobla la pausa
#  (hasta el tope PAUSA_TOPE_BLOQUEO). Si TRAS una pausa de
#  seguridad la fuente vuelve a recibir 3 bloqueos seguidos, esa
#  fuente entra en PAUSA DURA de 30 min (nueva sesión Chrome tras
#  la espera) y vuelve a intentarlo automáticamente. Si el bloqueo
#  persiste tras 2 pausas duras, la fuente se detiene definitivamente.
# ═══════════════════════════════════════════════════════════════
import threading as _threading_m6

M6_BLOQUEOS_TRAS_PAUSA_MAX   = 3     # 3 bloqueos seguidos TRAS una pausa corta → pausa dura
M6_PAUSA_BLOQUEO_DURO        = 1800  # 30 min de pausa cuando el bloqueo es persistente
M6_INTENTOS_BLOQUEO_DURO_MAX = 2     # tras 2 pausas duras seguidas sin éxito → para definitivamente


def _detectar_huecos_fuente(fuente_cfg):
    """Devuelve (huecos, diagnostico) para una fuente concreta. Gap máximo 5.
    huecos: lista de {id, id_ant, id_sig, gap, cat_est, jor_est}
    diagnostico: dict con info de por qué hay o no huecos, para poder ver en
    pantalla SIEMPRE qué ha pasado con cada fuente (incluso si da 0 huecos),
    en vez de que desaparezca del resumen sin explicación."""
    out_dir  = fuente_cfg["output_dir"]
    json_dir = fuente_cfg["json_dir"]
    prefix   = fuente_cfg["prefix"]
    empty_fp = fuente_cfg["empty_file"]

    diag = {"txts_disco": 0, "motivo": ""}

    pat = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    try:
        archivos = os.listdir(out_dir)
    except FileNotFoundError:
        diag["motivo"] = f"carpeta inexistente: {out_dir}"
        return [], diag

    ids_disco = sorted(int(pat.search(fn).group(1)) for fn in archivos if pat.match(fn))
    diag["txts_disco"] = len(ids_disco)

    if not ids_disco:
        diag["motivo"] = "0 TXTs en disco (aún no se ha descargado nada de esta fuente)"
        return [], diag
    if len(ids_disco) == 1:
        diag["motivo"] = "solo hay 1 TXT en disco, no hay pares consecutivos para comparar"
        return [], diag

    empty_ids  = load_empty_ids(empty_fp)
    ids_vacios = {int(k) for k in empty_ids}
    conocidos  = set(ids_disco) | ids_vacios

    # Cargar JSONs para contexto
    json_info = {}
    pat_j = re.compile(rf"{re.escape(prefix)}(\d+)\.json")
    try:
        for fn in os.listdir(json_dir):
            m = pat_j.match(fn)
            if not m:
                continue
            try:
                with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                    d = json.load(f)
                json_info[int(m.group(1))] = {
                    "categoria": d.get("categoria", "?"),
                    "jornada":   d.get("jornada"),
                    "fecha":     d.get("fecha", ""),
                }
            except:
                pass
    except FileNotFoundError:
        pass

    huecos = []
    gaps_grandes = 0   # gaps > 5 que NO se descargan (para que se vea en diagnóstico)
    for i in range(len(ids_disco) - 1):
        a, b = ids_disco[i], ids_disco[i + 1]
        gap = b - a - 1
        if gap > 5:
            gaps_grandes += 1
            continue
        if gap <= 0:
            continue
        for mid in range(a + 1, b):
            if mid not in conocidos:
                ant = json_info.get(a, {})
                sig = json_info.get(b, {})
                cat_ant = ant.get("categoria", "?")
                cat_sig = sig.get("categoria", "?")
                jor_ant = ant.get("jornada")
                jor_sig = sig.get("jornada")
                cat_est = cat_ant if cat_ant == cat_sig else f"{cat_ant} / {cat_sig}"
                if jor_ant is not None and jor_sig is not None:
                    if jor_sig == jor_ant:
                        jor_est = f"J{jor_ant} (mismo día)"
                    elif jor_sig == jor_ant + 1:
                        jor_est = f"J{jor_ant}→J{jor_sig}"
                    else:
                        jor_est = f"J{jor_ant}..J{jor_sig}"
                elif jor_ant is not None:
                    jor_est = f"~J{jor_ant + 1}"
                elif jor_sig is not None:
                    jor_est = f"~J{jor_sig}"
                else:
                    jor_est = "desconocida"
                huecos.append({
                    "id":      mid,
                    "id_ant":  a,
                    "id_sig":  b,
                    "gap":     gap,
                    "cat_est": cat_est,
                    "jor_est": jor_est,
                })

    if not huecos:
        if gaps_grandes:
            diag["motivo"] = (f"{len(ids_disco)} TXTs en disco, pero todos los huecos entre IDs "
                               f"consecutivos son > 5 ({gaps_grandes} gaps grandes ignorados a propósito)")
        else:
            diag["motivo"] = f"{len(ids_disco)} TXTs en disco, sin huecos (todo consecutivo o ya marcado vacío)"
    return huecos, diag


def _m6_scroll_humano(driver, tag):
    """Alias de compatibilidad → delega en _m6_comportamiento_humano."""
    return _m6_comportamiento_humano(driver, tag)


def _m6_comportamiento_humano(driver, tag):
    """Simula comportamiento humano variado tras cargar una página:
    scroll (varios patrones), hover sobre enlaces, micro-movimientos de ratón
    y pausas de lectura aleatorias.  REGISTRA EN LOG cada acción individual
    para que sea fácil correlacionarlo con un posible bloqueo posterior."""
    acciones = []
    try:
        # ── 1. Scroll (patrón aleatorio) ───────────────────────────────────
        tipo = random.choice(["simple", "lectura", "rapido"])
        if tipo == "simple":
            bajada = random.randint(150, 600)
            driver.execute_script(f"window.scrollTo(0, {bajada});")
            time.sleep(random.uniform(0.4, 1.1))
            driver.execute_script("window.scrollTo(0, 0);")
            acciones.append(f"scroll-simple 0→{bajada}px→0")
        elif tipo == "lectura":
            # Varios pasos hacia abajo simulando leer párrafo a párrafo
            pos = 0
            pasos = random.randint(2, 4)
            for _ in range(pasos):
                paso = random.randint(70, 220)
                pos += paso
                driver.execute_script(f"window.scrollTo(0, {pos});")
                time.sleep(random.uniform(0.5, 1.6))
            driver.execute_script("window.scrollTo(0, 0);")
            acciones.append(f"scroll-lectura {pasos} pasos hasta {pos}px")
        else:  # rapido — vistazo rápido
            bajada = random.randint(50, 200)
            driver.execute_script(f"window.scrollTo(0, {bajada});")
            time.sleep(random.uniform(0.12, 0.35))
            driver.execute_script("window.scrollTo(0, 0);")
            acciones.append(f"scroll-rapido 0→{bajada}px→0")

        # ── 2. Hover sobre un enlace aleatorio de la página ────────────────
        if random.random() < 0.45:
            try:
                from selenium.webdriver.common.action_chains import ActionChains
                links = driver.find_elements("tag name", "a")
                candidatos = [l for l in links[:15] if l.is_displayed()]
                if candidatos:
                    tgt = random.choice(candidatos)
                    ActionChains(driver).move_to_element(tgt).perform()
                    time.sleep(random.uniform(0.2, 0.7))
                    acciones.append("hover-enlace")
            except Exception:
                pass  # sin impacto si no hay ActionChains o el elemento desapareció

        # ── 3. Micro-movimiento de ratón por coordenadas relativas ─────────
        if random.random() < 0.35:
            try:
                from selenium.webdriver.common.action_chains import ActionChains
                dx = random.randint(-120, 120)
                dy = random.randint(-80, 80)
                ActionChains(driver).move_by_offset(dx, dy).perform()
                time.sleep(random.uniform(0.08, 0.25))
                acciones.append(f"mouse-move ({dx:+d},{dy:+d})")
            except Exception:
                pass

        # ── 4. Pausa adicional de "lectura" (simula que el usuario lee) ────
        if random.random() < 0.30:
            p = round(random.uniform(1.2, 4.5), 1)
            time.sleep(p)
            acciones.append(f"pausa-lectura {p}s")

        resumen = " | ".join(acciones) if acciones else "ninguna"
        log6(f"{tag} [anti-bot] Comportamiento humano: {resumen}")
        return True
    except Exception as e:
        log6(f"{tag} [anti-bot] Comportamiento humano fallido (sin impacto): {str(e).split(chr(10))[0]}")
        return False


def _modo6_descargar_fuente(fkey, huecos, lock, resultados, stop_event):
    """Hilo dedicado a UNA fuente: descarga todos sus huecos con su propia
    sesión de Chrome, en paralelo con el resto de fuentes. 'resultados' es un
    dict compartido (protegido por 'lock') donde se acumulan ok/vacias/fail/
    pausas/parado_por_bloqueo para el resumen global al final."""
    fcfg  = FUENTES[fkey]
    tag   = f"[{fcfg['label'].split(' ')[0].upper():<9}]"
    out_dir  = fcfg["output_dir"]
    json_dir = fcfg["json_dir"]
    empty_fp = fcfg["empty_file"]
    empty_ids_f = load_empty_ids(empty_fp)

    ids_pendientes = [h["id"] for h in huecos]
    ok = vacias = fail = pausas = 0
    fallos_consec = 0
    bloqueos_tras_pausa = 0   # bloqueos seguidos DESPUÉS de la última pausa de seguridad
    bloqueos_duros = 0        # pausas duras de 30 min ya realizadas en esta fuente
    parado_por_bloqueo = False
    driver = None
    ua_idx = 0
    actas_ses = 0

    log6(f"{tag} Inicio: {len(ids_pendientes)} huecos a descargar.")

    try:
        driver = crear_nav(ua_idx)
        calentar(driver, fcfg)
        log6(f"{tag} Sesión calentada (visita a home + calendario antes de pedir actas).")

        for idx, cod in enumerate(ids_pendientes, 1):
            if stop_event.is_set():
                log6(f"{tag} Detenido por orden global (Ctrl+C).")
                break

            # Reinicio periódico de sesión (fingerprint nuevo)
            if actas_ses > 0 and actas_ses % M6_REINICIAR_CADA == 0:
                log6(f"{tag} Reinicio programado de Chrome (cada {M6_REINICIAR_CADA} actas) "
                     f"— nuevo user-agent y nueva sesión.")
                cerrar(driver); ua_idx += 1
                p = round(random.uniform(2, 4), 1)
                time.sleep(p)
                driver = crear_nav(ua_idx); calentar(driver, fcfg); actas_ses = 0
                pausas += 1

            # Pausa larga periódica "de descanso" (rompe el patrón de ritmo
            # constante incluso si todo va bien, sin esperar a que haya fallos)
            if actas_ses > 0 and actas_ses % M6_PAUSA_LARGA_CADA == 0:
                p = random.randint(*M6_PAUSA_LARGA_RANGO)
                log6(f"{tag} Pausa larga programada cada {M6_PAUSA_LARGA_CADA} actas: {p}s de descanso.")
                time.sleep(p)
                pausas += 1

            # Pausa humana ANTES de cada descarga individual
            d = round(random.uniform(*M6_DELAY_ENTRE_ACTAS), 1)
            time.sleep(d)

            t_antes = _ts()
            ruta, estado = descargar(driver, cod, idx, len(ids_pendientes), fcfg)

            # Comportamiento humano variado tras una descarga OK (scroll,
            # hover, movimiento de ratón…). Probabilidad 55% → sube desde 35%
            # para que el patrón sea menos predecible.
            if estado == "ok" and random.random() < 0.55:
                _m6_comportamiento_humano(driver, tag)
            elif estado == "vacia" and random.random() < 0.18:
                _m6_comportamiento_humano(driver, tag)

            if estado == "vacia":
                mark_empty(cod, empty_ids_f, empty_fp)
                try: os.remove(ruta)
                except: pass
                vacias += 1; fallos_consec = 0; bloqueos_tras_pausa = 0
                log6(f"{tag} [{t_antes}] ID {cod} → vacía (espera previa {d}s)")

            elif estado == "ok":
                ok += 1; fallos_consec = 0; bloqueos_tras_pausa = 0
                log6(f"{tag} [{t_antes}] ID {cod} → OK (espera previa {d}s)")

            else:
                fallos_consec += 1; fail += 1
                log6(f"{tag} [{t_antes}] ID {cod} → FALLO/bloqueo nº{fallos_consec} consecutivo "
                     f"(estado='{estado}', espera previa {d}s)", rojo=True)

                if fallos_consec >= FALLOS_PAUSA:
                    racha = fallos_consec // FALLOS_PAUSA
                    p = _pausa_escalada(racha)
                    log6(f"{tag} {fallos_consec} fallos seguidos → PAUSA DE SEGURIDAD de {p}s "
                         f"(backoff escalado, racha {racha}) + nueva sesión Chrome", rojo=True)
                    cerrar(driver); ua_idx += 1
                    for _ in range(p):
                        if stop_event.is_set():
                            break
                        time.sleep(1)
                    pausas += 1
                    driver = crear_nav(ua_idx); calentar(driver, fcfg)
                    actas_ses = 0; fallos_consec = 0

                    # Reintento tras la pausa de seguridad
                    t_reintento = _ts()
                    ruta, estado = descargar(driver, cod, idx, len(ids_pendientes), fcfg)
                    log6(f"{tag} [{t_reintento}] Reintento ID {cod} tras pausa → {estado}")

                    if estado == "ok":
                        ok += 1; fail -= 1; bloqueos_tras_pausa = 0
                    elif estado == "vacia":
                        mark_empty(cod, empty_ids_f, empty_fp)
                        try: os.remove(ruta)
                        except: pass
                        vacias += 1; fail -= 1; bloqueos_tras_pausa = 0
                    else:
                        # Sigue fallando justo DESPUÉS de haber pausado: esto es
                        # lo que cuenta para el límite de "3 bloqueos seguidos
                        # tras la pausa" → si se alcanza, pausa DURA de 30 min.
                        bloqueos_tras_pausa += 1
                        log6(f"{tag} [!] Bloqueo nº{bloqueos_tras_pausa} TRAS la pausa de seguridad "
                             f"(límite: {M6_BLOQUEOS_TRAS_PAUSA_MAX})", rojo=True)
                        if bloqueos_tras_pausa >= M6_BLOQUEOS_TRAS_PAUSA_MAX:
                            bloqueos_duros += 1
                            if bloqueos_duros >= M6_INTENTOS_BLOQUEO_DURO_MAX:
                                log6(f"{tag} [✗] {M6_INTENTOS_BLOQUEO_DURO_MAX} pausas duras sin resultado "
                                     f"→ FUENTE DETENIDA definitivamente. "
                                     f"Quedan {len(ids_pendientes) - idx} IDs sin intentar.", rojo=True)
                                parado_por_bloqueo = True
                                break
                            else:
                                mins = M6_PAUSA_BLOQUEO_DURO // 60
                                log6(f"{tag} [⏸] Bloqueo persistente — PAUSA DURA de {mins} min "
                                     f"(pausa dura {bloqueos_duros}/{M6_INTENTOS_BLOQUEO_DURO_MAX}). "
                                     f"Se reanudará automáticamente.", rojo=True)
                                cerrar(driver); ua_idx += 1
                                for seg in range(M6_PAUSA_BLOQUEO_DURO):
                                    if stop_event.is_set():
                                        break
                                    if seg % 300 == 0 and seg > 0:
                                        restantes = (M6_PAUSA_BLOQUEO_DURO - seg) // 60
                                        log6(f"{tag} [⏸] Pausa dura: {restantes} min restantes...")
                                    time.sleep(1)
                                pausas += 1
                                driver = crear_nav(ua_idx); calentar(driver, fcfg)
                                actas_ses = 0; fallos_consec = 0; bloqueos_tras_pausa = 0

            actas_ses += 1

        log6(f"{tag} Fuente terminada: {ok} OK | {vacias} vacías | {fail} fallidas"
             f"{' | DETENIDA POR BLOQUEO' if parado_por_bloqueo else ''}",
             rojo=parado_por_bloqueo)

        # ── Parsear los TXTs nuevos de esta fuente ────────────────────────
        prefix  = fcfg["prefix"]
        pat_p   = re.compile(rf"Acta_{re.escape(prefix)}\d+\.txt")
        parseadas = 0
        for fn in sorted(f for f in os.listdir(out_dir) if pat_p.match(f)):
            aid = re.search(r"Acta_(.+)\.txt", fn).group(1)
            jp  = os.path.join(json_dir, f"{aid}.json")
            if not os.path.exists(jp):
                try:
                    Parser(os.path.join(out_dir, fn), json_dir=json_dir, fuente=fkey).process()
                    parseadas += 1
                except Exception as e:
                    log6(f"{tag} Error parseando {fn}: {e}")
        if parseadas:
            log6(f"{tag} Parseados {parseadas} nuevos TXTs.")

    except Exception:
        log6(f"{tag} ERROR CRITICO en hilo de fuente:")
        traceback.print_exc()
    finally:
        if driver:
            log6(f"{tag} Cerrando sesión de Chrome.")
            cerrar(driver)

    with lock:
        resultados[fkey] = {
            "ok": ok, "vacias": vacias, "fail": fail, "pausas": pausas,
            "parado_por_bloqueo": parado_por_bloqueo,
        }


def _encontrar_zonas_sin_explorar(fuente_cfg, paso=None):
    """Detecta grandes gaps (> M6_UMBRAL_GAP_EXP) entre IDs conocidos de una fuente
    y genera los puntos de sondeo dentro de cada zona.

    Para cada zona inexplorada (inicio, fin), el extremo superior conocido es
    fin+1 (el bloque de actas ya descargado que viene justo después del hueco).
    En vez de sondear con puntos aleatorios repartidos por toda la zona, primero
    se prueba PEGADO a ese extremo y bajando, con pasos fijos crecientes:
        extremo-1, extremo-50, extremo-200, extremo-500
    (filtrando los que caigan fuera de la zona o ya sean conocidos). La idea es
    que, si las actas de esa fuente son más o menos correlativas, lo más
    probable es encontrar la siguiente nueva muy cerca del límite ya conocido,
    así que merece la pena mirar ahí antes de tirar dados por toda la zona.

    Si ninguno de esos 4 puntos fijos basta (zona tan grande que hace falta
    más cobertura, o no hay un extremo real del que partir -p.ej. cuando no
    hay NADA en disco y el "tope" es solo un límite artificial-), se completa
    con el sondeo aleatorio de siempre, espaciado ~paso IDs, sobre el resto
    de la zona (descontando ya los 4 puntos fijos).

    Devuelve (puntos_sondeo, zonas, puntos_fijos):
      puntos_sondeo → lista[int] de IDs a probar. Los puntos fijos de cada
                       zona van PRIMERO y en orden (extremo-1, -50, -200,
                       -500); el resto (aleatorio) va detrás, mezclado.
      zonas         → lista[(inicio, fin)] de rangos inexplorados detectados
      puntos_fijos  → set[int] con los IDs que son sondeo "fijo" (pegado al
                       extremo conocido), para poder distinguirlos en el log
    """
    if paso is None:
        paso = M6_PASO_SONDEO
    out_dir  = fuente_cfg["output_dir"]
    prefix   = fuente_cfg["prefix"]
    empty_fp = fuente_cfg["empty_file"]

    pat = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    try:
        archivos = os.listdir(out_dir)
    except FileNotFoundError:
        return [], []

    ids_disco = sorted(int(pat.search(fn).group(1)) for fn in archivos if pat.match(fn))
    empty_raw = load_empty_ids(empty_fp)
    ids_vacios = {int(k) for k in empty_raw}
    conocidos  = set(ids_disco) | ids_vacios

    # zonas: lista de (inicio, fin, extremo) — extremo es el ID conocido justo
    # encima de la zona (fin+1) desde el que se sondea hacia abajo, o None si
    # no hay un extremo real (caso "nada en disco", tope artificial).
    zonas_info = []
    if not ids_disco:
        # Sin nada en disco: explorar desde 1 hasta un límite razonable.
        # No hay extremo conocido real del que partir -> sin puntos fijos.
        tope = min(fuente_cfg.get("acta_tope", ACTA_TOPE), 10000)
        zonas_info.append((1, tope, None))
    else:
        # Zona antes del primer ID descargado: el extremo es ese primer ID.
        min_id = ids_disco[0]
        if min_id > M6_UMBRAL_GAP_EXP + 1:
            zonas_info.append((1, min_id - 1, min_id))
        # Zonas entre IDs consecutivos con gap grande: el extremo es el ID
        # de arriba del hueco (b), que es el bloque conocido más cercano.
        for i in range(len(ids_disco) - 1):
            a, b = ids_disco[i], ids_disco[i + 1]
            gap = b - a - 1
            if gap > M6_UMBRAL_GAP_EXP:
                zonas_info.append((a + 1, b - 1, b))

    PASOS_FIJOS = (1, 50, 200, 500)

    puntos_fijos_todas = []     # en orden, por zona
    puntos_random_todas = []    # se mezclan al final
    for (inicio, fin, extremo) in zonas_info:
        rango_libre = set(x for x in range(inicio, fin + 1) if x not in conocidos)
        if not rango_libre:
            continue

        fijos_zona = []
        if extremo is not None:
            for d in PASOS_FIJOS:
                cand = extremo - d
                if cand in rango_libre:
                    fijos_zona.append(cand)
                    rango_libre.discard(cand)
            puntos_fijos_todas.extend(fijos_zona)

        # Sondeo aleatorio de siempre sobre lo que quede de la zona
        rango_libre = list(rango_libre)
        if rango_libre:
            n_puntos = max(1, len(rango_libre) // paso)
            n_puntos = min(n_puntos, len(rango_libre))
            puntos_random_todas.extend(random.sample(rango_libre, n_puntos))

    random.shuffle(puntos_random_todas)
    # Los fijos van primero (ya en orden extremo-1/-50/-200/-500 por zona),
    # luego el aleatorio mezclado.
    puntos = puntos_fijos_todas + puntos_random_todas
    zonas = [(i, f) for (i, f, _e) in zonas_info]
    return puntos, zonas, set(puntos_fijos_todas)


def _explorar_zonas_fuente(fkey, puntos_sondeo, lock, resultados, stop_event, puntos_fijos=None):
    """Hilo dedicado a UNA fuente en el sub-modo de exploración (Modo 6 opción 2).
    Recorre los puntos de sondeo EN EL ORDEN EN QUE LLEGAN: primero los puntos
    fijos pegados al extremo conocido de cada zona (extremo-1, -50, -200, -500),
    y solo si esos fallan, los puntos aleatorios de refuerzo. Cuando encuentra
    una acta válida descarga hacia abajo hasta topar con M6_VACIAS_STOP_EXP
    vacías consecutivas, luego vuelve al siguiente punto de sondeo.

    puntos_fijos: set[int] (opcional) con los IDs que son sondeo "fijo", solo
    para poder distinguirlo en el log (no cambia el comportamiento)."""
    puntos_fijos = puntos_fijos or set()
    fcfg     = FUENTES[fkey]
    tag      = f"[{fcfg['label'].split(' ')[0].upper():<9}]"
    out_dir  = fcfg["output_dir"]
    json_dir = fcfg["json_dir"]
    prefix   = fcfg["prefix"]
    empty_fp = fcfg["empty_file"]
    empty_ids_f = load_empty_ids(empty_fp)

    ok = vacias = fail = pausas = 0
    fallos_consec = 0
    bloqueos_tras_pausa = 0
    bloqueos_duros = 0        # pausas duras de 30 min ya realizadas en esta fuente
    parado_por_bloqueo = False
    driver   = None
    ua_idx   = 0
    actas_ses = 0

    pat_disco = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")

    def ids_en_disco():
        try:
            return {int(pat_disco.search(fn).group(1)) for fn in os.listdir(out_dir) if pat_disco.match(fn)}
        except Exception:
            return set()

    def vacios_en_disco():
        return {int(k) for k in load_empty_ids(empty_fp)}

    def _anti_bloqueo_periodico():
        """Aplica reinicio periódico y pausa larga si toca. Modifica nonlocals."""
        nonlocal driver, actas_ses, ua_idx, pausas
        if actas_ses > 0 and actas_ses % M6_REINICIAR_CADA == 0:
            log6(f"{tag} Reinicio programado de Chrome (cada {M6_REINICIAR_CADA} actas).")
            cerrar(driver); ua_idx += 1
            time.sleep(random.uniform(2, 4))
            driver = crear_nav(ua_idx); calentar(driver, fcfg); actas_ses = 0
            pausas += 1
        if actas_ses > 0 and actas_ses % M6_PAUSA_LARGA_CADA == 0:
            p = random.randint(*M6_PAUSA_LARGA_RANGO)
            log6(f"{tag} Pausa larga programada: {p}s.")
            time.sleep(p)
            pausas += 1

    def _descargar_con_retry(cod, idx_g):
        """Descarga un ID con anti-bloqueo y reintento. Devuelve (ruta, estado).
        Gestiona fallos_consec, bloqueos_tras_pausa, bloqueos_duros y parado_por_bloqueo."""
        nonlocal driver, ua_idx, actas_ses, pausas
        nonlocal ok, vacias, fail, fallos_consec, bloqueos_tras_pausa, bloqueos_duros, parado_por_bloqueo

        d = round(random.uniform(*M6_DELAY_ENTRE_ACTAS), 1)
        time.sleep(d)
        ruta, estado = descargar(driver, cod, idx_g, len(puntos_sondeo), fcfg)

        # Comportamiento humano variado: más variantes que solo scroll,
        # y también en vacías ocasionalmente para no parecer que solo
        # "se detiene" ante páginas con contenido.
        if estado == "ok" and random.random() < 0.55:
            _m6_comportamiento_humano(driver, tag)
        elif estado == "vacia" and random.random() < 0.18:
            _m6_comportamiento_humano(driver, tag)

        if estado in ("ok", "vacia"):
            fallos_consec = 0; bloqueos_tras_pausa = 0
        else:
            fallos_consec += 1
            # Pausa extra aleatoria tras fallo de sondeo — los fallos consecutivos
            # (IDs que no existen) son el patrón más fácil de detectar como bot.
            extra = round(random.uniform(2.0, 6.5), 1)
            log6(f"{tag} [anti-bot] Sondeo fallido → pausa extra {extra}s antes de continuar.")
            time.sleep(extra)

            if fallos_consec >= FALLOS_PAUSA:
                racha = fallos_consec // FALLOS_PAUSA
                p = _pausa_escalada(racha)
                log6(f"{tag} {fallos_consec} fallos seguidos → pausa {p}s + nueva sesión Chrome.", rojo=True)
                cerrar(driver); ua_idx += 1
                for _ in range(p):
                    if stop_event.is_set(): break
                    time.sleep(1)
                pausas += 1
                driver = crear_nav(ua_idx); calentar(driver, fcfg)
                actas_ses = 0; fallos_consec = 0
                # Reintento
                ruta, estado = descargar(driver, cod, idx_g, len(puntos_sondeo), fcfg)
                log6(f"{tag} Reintento ID {cod} tras pausa → {estado}")
                if estado not in ("ok", "vacia"):
                    bloqueos_tras_pausa += 1
                    log6(f"{tag} [!] Bloqueo nº{bloqueos_tras_pausa} tras pausa "
                         f"(límite {M6_BLOQUEOS_TRAS_PAUSA_MAX})", rojo=True)
                    if bloqueos_tras_pausa >= M6_BLOQUEOS_TRAS_PAUSA_MAX:
                        bloqueos_duros += 1
                        if bloqueos_duros >= M6_INTENTOS_BLOQUEO_DURO_MAX:
                            log6(f"{tag} [✗] {M6_INTENTOS_BLOQUEO_DURO_MAX} pausas duras sin resultado "
                                 f"→ FUENTE DETENIDA definitivamente.", rojo=True)
                            parado_por_bloqueo = True
                        else:
                            mins = M6_PAUSA_BLOQUEO_DURO // 60
                            log6(f"{tag} [⏸] Bloqueo persistente — PAUSA DURA de {mins} min "
                                 f"(pausa dura {bloqueos_duros}/{M6_INTENTOS_BLOQUEO_DURO_MAX}). "
                                 f"Se reanudará automáticamente.", rojo=True)
                            cerrar(driver); ua_idx += 1
                            for seg in range(M6_PAUSA_BLOQUEO_DURO):
                                if stop_event.is_set(): break
                                if seg % 300 == 0 and seg > 0:
                                    restantes = (M6_PAUSA_BLOQUEO_DURO - seg) // 60
                                    log6(f"{tag} [⏸] Pausa dura: {restantes} min restantes...")
                                time.sleep(1)
                            pausas += 1
                            driver = crear_nav(ua_idx); calentar(driver, fcfg)
                            actas_ses = 0; fallos_consec = 0; bloqueos_tras_pausa = 0
                else:
                    bloqueos_tras_pausa = 0
        return ruta, estado

    log6(f"{tag} Exploración: {len(puntos_sondeo)} puntos de sondeo generados.")
    try:
        driver = crear_nav(ua_idx)
        calentar(driver, fcfg)
        log6(f"{tag} Sesión calentada.")

        idx_g = 0
        for punto in puntos_sondeo:
            if stop_event.is_set() or parado_por_bloqueo:
                break

            # Saltar si ya fue descargado/marcado vacío en esta misma ejecución
            if punto in ids_en_disco() or punto in vacios_en_disco():
                continue

            _anti_bloqueo_periodico()
            idx_g += 1
            etiqueta = "fijo·extremo" if punto in puntos_fijos else "aleatorio"
            log6(f"{tag} Sondeo #{idx_g} ({etiqueta}): ID {punto}")
            ruta, estado = _descargar_con_retry(punto, idx_g)

            if parado_por_bloqueo:
                break

            if estado == "ok":
                ok += 1
                log6(f"{tag} ✓ Sondeo ID {punto} → ACTA ENCONTRADA — bajando secuencialmente...")

                # ── Descarga hacia abajo desde punto−1 ──────────────────────
                vacias_consec_abajo = 0
                id_abajo = punto - 1
                while id_abajo > 0 and vacias_consec_abajo < M6_VACIAS_STOP_EXP:
                    if stop_event.is_set() or parado_por_bloqueo:
                        break

                    disco_ahora  = ids_en_disco()
                    vacios_ahora = vacios_en_disco()

                    if id_abajo in disco_ahora:
                        # Ya tenemos esta acta: hemos llegado a una zona conocida → parar
                        log6(f"{tag} ↓ ID {id_abajo} ya en disco → borde alcanzado, fin bajada.")
                        break
                    if id_abajo in vacios_ahora:
                        # Ya marcado vacío previamente
                        vacias_consec_abajo += 1
                        log6(f"{tag} ↓ ID {id_abajo} ya vacío ({vacias_consec_abajo}/{M6_VACIAS_STOP_EXP})")
                        id_abajo -= 1
                        continue

                    _anti_bloqueo_periodico()
                    idx_g += 1
                    ruta2, estado2 = _descargar_con_retry(id_abajo, idx_g)

                    if parado_por_bloqueo:
                        break

                    if estado2 == "ok":
                        ok += 1; vacias_consec_abajo = 0
                        log6(f"{tag} ↓ ID {id_abajo} → OK")
                    elif estado2 == "vacia":
                        mark_empty(id_abajo, empty_ids_f, empty_fp)
                        try: os.remove(ruta2)
                        except: pass
                        vacias += 1; vacias_consec_abajo += 1
                        log6(f"{tag} ↓ ID {id_abajo} → vacía ({vacias_consec_abajo}/{M6_VACIAS_STOP_EXP})")
                    else:
                        fail += 1
                        log6(f"{tag} ↓ ID {id_abajo} → fallo")

                    actas_ses += 1
                    id_abajo -= 1

                if vacias_consec_abajo >= M6_VACIAS_STOP_EXP:
                    log6(f"{tag} {M6_VACIAS_STOP_EXP} vacías seguidas → volviendo al sondeo aleatorio.")

            elif estado == "vacia":
                mark_empty(punto, empty_ids_f, empty_fp)
                try: os.remove(ruta)
                except: pass
                vacias += 1
                log6(f"{tag} Sondeo ID {punto} → vacía")
            else:
                fail += 1
                log6(f"{tag} Sondeo ID {punto} → fallo")

            actas_ses += 1

        log6(f"{tag} Exploración terminada: {ok} OK | {vacias} vacías | {fail} fallidas"
             f"{' | DETENIDA POR BLOQUEO' if parado_por_bloqueo else ''}",
             rojo=parado_por_bloqueo)

        # ── Parsear TXTs nuevos de esta fuente ───────────────────────────────
        pat_p   = re.compile(rf"Acta_{re.escape(prefix)}\d+\.txt")
        parseadas = 0
        for fn in sorted(f for f in os.listdir(out_dir) if pat_p.match(f)):
            aid = re.search(r"Acta_(.+)\.txt", fn).group(1)
            jp  = os.path.join(json_dir, f"{aid}.json")
            if not os.path.exists(jp):
                try:
                    Parser(os.path.join(out_dir, fn), json_dir=json_dir, fuente=fkey).process()
                    parseadas += 1
                except Exception as e:
                    log6(f"{tag} Error parseando {fn}: {e}")
        if parseadas:
            log6(f"{tag} Parseados {parseadas} nuevos TXTs.")

    except Exception:
        log6(f"{tag} ERROR CRITICO en hilo de exploración:")
        traceback.print_exc()
    finally:
        if driver:
            log6(f"{tag} Cerrando sesión de Chrome.")
            cerrar(driver)

    with lock:
        resultados[fkey] = {
            "ok": ok, "vacias": vacias, "fail": fail, "pausas": pausas,
            "parado_por_bloqueo": parado_por_bloqueo,
        }


def analizar_huecos_exploracion():
    """Sub-modo 2 del Modo 6: rastreo de zonas sin explorar (grandes gaps).
    Lanza un hilo por fuente, igual que el sub-modo de huecos clásicos."""
    print(f"\n[*] MODO 6 — Sub-modo 2: Rastreo de zonas inexploradas\n")

    # ── Paso previo: corregir discrepancias actas-vs-tablas cruzadas ─────────
    # Misma corrección que hace el Modo 3.1, aplicada aquí ANTES de buscar
    # zonas/números nuevos, para arrancar el rastreo con los datos ya al día.
    # Solo usa actas y tablas cruzadas YA EN DISCO, así que no genera ninguna
    # petición nueva a ninguna fuente: no hace falta ritmo "humano" para esto,
    # pero se deja con el mismo formato de log (con hora) que el resto del
    # Modo 6 para que se vea como una fase más del mismo proceso, no como un
    # bloque aparte.
    log6("Corrigiendo discrepancias (actas vs. tablas cruzadas) antes de buscar números nuevos...")
    resumen_31 = _reanalizar_tablas_cruzadas_conocidas(usar_log6=True)
    if resumen_31:
        log6(f"Discrepancias: {resumen_31['discrepancias']} | "
             f"sin acta: {resumen_31['sin_acta']} | "
             f"resueltas: {resumen_31['resueltas']} | "
             f"pendientes: {resumen_31['pendientes']}")
    print()

    # ── Fuentes a procesar (excluye las temporalmente desactivadas) ──────────
    fuentes_m6 = {k: v for k, v in FUENTES.items() if k not in M6_FUENTES_EXCLUIDAS}
    if M6_FUENTES_EXCLUIDAS:
        excl_str = ", ".join(FUENTES[k]["label"] for k in M6_FUENTES_EXCLUIDAS if k in FUENTES)
        print(f"  [~] Excluidas del Modo 6 (error pendiente): {excl_str}\n")

    # ── Detectar zonas y generar puntos de sondeo por fuente ─────────────────
    sondeos_por_fuente = {}
    fijos_por_fuente    = {}
    zonas_por_fuente   = {}
    for fkey, fcfg in fuentes_m6.items():
        puntos, zonas, puntos_fijos = _encontrar_zonas_sin_explorar(fcfg)
        zonas_por_fuente[fkey]   = zonas
        if puntos:
            sondeos_por_fuente[fkey] = puntos
            fijos_por_fuente[fkey]   = puntos_fijos

    # ── Resumen de zonas detectadas ───────────────────────────────────────────
    print(f"  Fuentes analizadas: {len(fuentes_m6)} "
          f"({', '.join(fuentes_m6[k]['label'].split(' ')[0] for k in fuentes_m6)})")
    print("  " + "-" * 70)
    total_sondeos = 0
    for fkey, fcfg in fuentes_m6.items():
        zonas  = zonas_por_fuente.get(fkey, [])
        puntos = sondeos_por_fuente.get(fkey, [])
        n_fijos = len(fijos_por_fuente.get(fkey, ()))
        if zonas:
            zonas_str = ", ".join(f"{a}-{b}" for a, b in zonas[:4])
            if len(zonas) > 4: zonas_str += f" (+{len(zonas)-4} más)"
            print(f"  • {fcfg['label']:<28} → {len(zonas)} zona(s) inexplorada(s) "
                  f"| {len(puntos)} sondeos ({n_fijos} junto al extremo + "
                  f"{len(puntos)-n_fijos} aleatorios)   [{zonas_str}]")
            total_sondeos += len(puntos)
        else:
            print(f"  • {fcfg['label']:<28} → sin zonas inexploradas detectadas")
    print("  " + "-" * 70)
    print(f"  Total sondeos a lanzar (en paralelo): {total_sondeos}")
    tiempo_est = round(max((len(p) for p in sondeos_por_fuente.values()), default=0)
                       * sum(M6_DELAY_ENTRE_ACTAS) / 2 / 60, 1)
    if tiempo_est:
        print(f"  Tiempo estimado mínimo (fuente más cargada, sin descargas hacia abajo): ~{tiempo_est} min")
    print(f"  Sondeo: extremo-1/-50/-200/-500 primero, luego aleatorio cada ~{M6_PASO_SONDEO} IDs | "
          f"Para bajar: para tras {M6_VACIAS_STOP_EXP} vacías seguidas\n")

    if not sondeos_por_fuente:
        print("  [✓] No hay zonas inexploradas en ninguna fuente.\n")
        return

    resp = input("  ¿Lanzar rastreo en TODAS las fuentes ahora (en paralelo)? [S/N]: ").strip().upper()
    if resp != "S":
        print("\n  [!] Rastreo cancelado.\n")
        return

    # ── Lanzar un hilo por fuente con sondeos, todas EN PARALELO ─────────────
    fuentes_keys  = list(sondeos_por_fuente.keys())
    nombres_sel   = ", ".join(FUENTES[k]["label"].split(" ")[0] for k in fuentes_keys)
    lock          = _threading_m6.Lock()
    stop_event    = _threading_m6.Event()
    resultados    = {}

    log6(f"Inicio rastreo de zonas en paralelo. {total_sondeos} sondeos en "
         f"{len(fuentes_keys)} fuentes: {nombres_sel}.")

    t_inicio = time.time()
    hilos = [
        _threading_m6.Thread(
            target=_explorar_zonas_fuente,
            args=(fkey, sondeos_por_fuente[fkey], lock, resultados, stop_event,
                  fijos_por_fuente.get(fkey, set())),
            daemon=True,
        )
        for fkey in fuentes_keys
    ]
    for i, hilo in enumerate(hilos):
        hilo.start()
        if i < len(hilos) - 1:
            time.sleep(random.uniform(1.5, 3.5))

    print(f"[*] {len(hilos)} hilos arrancados ({nombres_sel}). Pulsa Ctrl+C para detener.\n")
    try:
        while any(h.is_alive() for h in hilos):
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Interrupción — deteniendo hilos...")
        stop_event.set()
        for h in hilos:
            h.join(timeout=60)

    t_total   = time.time() - t_inicio
    ok_t      = sum(r.get("ok", 0)     for r in resultados.values())
    vacias_t  = sum(r.get("vacias", 0) for r in resultados.values())
    fail_t    = sum(r.get("fail", 0)   for r in resultados.values())
    pausas_t  = sum(r.get("pausas", 0) for r in resultados.values())
    det_bloq  = [fk for fk, r in resultados.items() if r.get("parado_por_bloqueo")]

    print(f"\n  {'='*70}")
    print(f"  RESUMEN GLOBAL MODO 6 sub-modo 2 (rastreo en paralelo)")
    print(f"  {'='*70}")
    for fkey in fuentes_keys:
        r = resultados.get(fkey, {})
        bloqueada = r.get("parado_por_bloqueo")
        extra = "  [✗ DETENIDA POR BLOQUEO]" if bloqueada else ""
        linea = (f"  • {FUENTES[fkey]['label']:<28} → {r.get('ok',0)} OK | "
                 f"{r.get('vacias',0)} vacías | {r.get('fail',0)} fallidas | "
                 f"{r.get('pausas',0)} pausas{extra}")
        print(_rojo(linea) if bloqueada else linea)
    print(f"  {'-'*70}")
    print(f"  Total:          {ok_t} OK | {vacias_t} vacías | {fail_t} fallidas")
    print(f"  Duración total: {t_total:.0f}s ({t_total/60:.1f} min)")
    if det_bloq:
        nombres_det = ", ".join(FUENTES[fk]["label"] for fk in det_bloq)
        print(_rojo(f"  [✗] Detenidas por bloqueo: {nombres_det}"))
        print(_rojo(f"      Reintenta más tarde con Modo 6 opción 2 (solo quedarán sus zonas pendientes)."))
    print()

    # ── HTML ─────────────────────────────────────────────────────────────────
    # Una sola regeneración al final, ya con descargas nuevas + discrepancias
    # corregidas al principio de esta función incluidas.
    print(f"\n[*] Regenerando HTML...")
    generar_html()
    print(f"  HTML actualizado en {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    print(f"  {'='*70}")
    print()


def analizar_huecos(fuente_cfg=None):
    print(f"\n[*] MODO 6 — Huecos e IDs inexplorados (todas las fuentes EN PARALELO)\n")

    # ── Preguntar qué tipo de búsqueda ────────────────────────────────────────
    print("  ¿Qué tipo de búsqueda quieres hacer?")
    print("  [1] Huecos clásicos    (gaps de 1-5 IDs entre actas consecutivas en disco)")
    print("  [2] Zonas inexploradas (sondeo aleatorio en grandes gaps — busca actas nuevas)")
    print()
    while True:
        sub = input("  Elige [1/2]: ").strip()
        if sub in ("1", "2"):
            break
        print("  Introduce 1 o 2.")

    if sub == "2":
        analizar_huecos_exploracion()
        return

    # ── Sub-modo 1: huecos clásicos (lógica original) ─────────────────────────
    print(f"\n[*] MODO 6 — Sub-modo 1: Huecos clásicos (gaps 1-5)\n")

    # ── Fuentes a procesar (excluye las temporalmente desactivadas) ──────────
    fuentes_m6 = {k: v for k, v in FUENTES.items() if k not in M6_FUENTES_EXCLUIDAS}
    if M6_FUENTES_EXCLUIDAS:
        excl_str = ", ".join(FUENTES[k]["label"] for k in M6_FUENTES_EXCLUIDAS if k in FUENTES)
        print(f"  [~] Excluidas del Modo 6 (error pendiente): {excl_str}\n")

    # ── Detectar huecos en las fuentes activas del Modo 6 ─────────────────────
    # Importante: se recorren SIEMPRE todas las fuentes activas (fuentes_m6),
    # sin excepción. Si alguna no muestra huecos no es porque se "salte", es
    # porque no los tiene (se explica abajo con diagnostico).
    huecos_por_fuente = {}   # fuente_key → lista de huecos
    diag_por_fuente = {}     # fuente_key → diagnóstico (para mostrar SIEMPRE, aunque sea 0 huecos)
    total_global = 0
    for fkey, fcfg in fuentes_m6.items():
        h, diag = _detectar_huecos_fuente(fcfg)
        diag_por_fuente[fkey] = diag
        if h:
            huecos_por_fuente[fkey] = h
            total_global += len(h)

    # ── Diagnóstico SIEMPRE visible de las fuentes activas, tengan huecos o no ──
    print(f"  Fuentes analizadas: {len(fuentes_m6)} "
          f"({', '.join(fuentes_m6[k]['label'].split(' ')[0] for k in fuentes_m6)})")
    print("  " + "-" * 70)
    for fkey, fcfg in fuentes_m6.items():
        diag = diag_por_fuente[fkey]
        n_huecos = len(huecos_por_fuente.get(fkey, []))
        if n_huecos:
            print(f"  • {fcfg['label']:<28} → {n_huecos} huecos detectados ({diag['txts_disco']} TXTs en disco)")
        else:
            print(f"  • {fcfg['label']:<28} → 0 huecos  [{diag['motivo']}]")
    print("  " + "-" * 70 + "\n")

    if not total_global:
        print("  [✓] Sin huecos de 1-5 IDs detectados en ninguna fuente (ver motivos arriba).\n")
        print("  Tip: usa la opción [2] Zonas inexploradas para buscar actas en grandes gaps.\n")
        return

    # ── Mostrar resumen detallado por fuente con huecos ───────────────────────
    for fkey, huecos in huecos_por_fuente.items():
        fcfg  = fuentes_m6[fkey]
        label = fcfg["label"]
        gap1  = [h for h in huecos if h["gap"] == 1]
        print(f"  ── {label} ({'%d huecos' % len(huecos)}) ──────────────────────────────")
        print(f"  {'ID Faltante':>12}  {'Gap':>4}  {'Cat vecinos':>30}  {'Jornada est.':>16}")
        print("  " + "-" * 70)
        for h in huecos:
            print(f"  {str(h['id']):>12}  {h['gap']:>4}  {h['cat_est'][:30]:>30}  {h['jor_est']:>16}")
        print(f"\n  Gap=1 (más probables): {[h['id'] for h in gap1]}\n")

    print(f"  {'='*70}")
    print(f"  TOTAL HUECOS en fuentes activas ({len(huecos_por_fuente)} de {len(fuentes_m6)} con huecos): {total_global}")
    tiempo_est_min = round(max(len(h) for h in huecos_por_fuente.values()) * sum(M6_DELAY_ENTRE_ACTAS) / 2 / 60, 1)
    print(f"  Tiempo estimado en PARALELO (lo que tarde la fuente con más huecos, "
          f"ritmo conservador, sin contar bloqueos): ~{tiempo_est_min} min")
    print(f"  {'='*70}\n")

    # ── Preguntar si descargar ────────────────────────────────────────────────
    resp = input("  ¿Descargar TODOS los huecos de TODAS las fuentes ahora (en paralelo)? [S/N]: ").strip().upper()
    if resp != "S":
        print("\n  [!] Descarga cancelada. Puedes usar el Modo 2 para descargar IDs concretos.\n")
        return

    # ── Lanzar un hilo por fuente con huecos, todas EN PARALELO ───────────────
    fuentes_keys = list(huecos_por_fuente.keys())
    nombres_sel = ", ".join(FUENTES[k]["label"].split(" ")[0] for k in fuentes_keys)
    log6(f"Inicio de la descarga de huecos en paralelo. {total_global} IDs en "
         f"{len(fuentes_keys)} fuentes: {nombres_sel}.")
    log6(f"Ritmo por fuente: pausa {M6_DELAY_ENTRE_ACTAS[0]}-{M6_DELAY_ENTRE_ACTAS[1]}s entre actas | "
         f"reinicio sesión cada {M6_REINICIAR_CADA} actas | "
         f"pausa larga {M6_PAUSA_LARGA_RANGO[0]}-{M6_PAUSA_LARGA_RANGO[1]}s cada {M6_PAUSA_LARGA_CADA} actas | "
         f"si hay {M6_BLOQUEOS_TRAS_PAUSA_MAX} bloqueos seguidos TRAS una pausa → PAUSA DURA {M6_PAUSA_BLOQUEO_DURO//60} min "
         f"(máx. {M6_INTENTOS_BLOQUEO_DURO_MAX} pausas duras antes de detener la fuente).")

    lock = _threading_m6.Lock()
    stop_event = _threading_m6.Event()
    resultados = {}

    t_inicio_global = time.time()
    hilos = [
        _threading_m6.Thread(
            target=_modo6_descargar_fuente,
            args=(fkey, huecos_por_fuente[fkey], lock, resultados, stop_event),
            daemon=True,
        )
        for fkey in fuentes_keys
    ]

    for i, hilo in enumerate(hilos):
        hilo.start()
        if i < len(hilos) - 1:
            # Pequeño desfase al arrancar para que no abran Chrome todas
            # las fuentes exactamente en el mismo instante.
            time.sleep(random.uniform(1.5, 3.5))

    print(f"[*] {len(hilos)} hilos arrancados en paralelo ({nombres_sel}). "
          f"Pulsa Ctrl+C para detener limpiamente.\n")
    try:
        while any(h.is_alive() for h in hilos):
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Interrupción — deteniendo hilos de todas las fuentes (puede tardar unos segundos)...")
        stop_event.set()
        for h in hilos:
            h.join(timeout=60)

    # ── Regenerar HTML global ────────────────────────────────────────────────
    print(f"\n[*] Regenerando HTML...")
    generar_html()

    t_total = time.time() - t_inicio_global
    ok_total = sum(r["ok"] for r in resultados.values())
    vacias_total = sum(r["vacias"] for r in resultados.values())
    fail_total = sum(r["fail"] for r in resultados.values())
    pausas_totales = sum(r["pausas"] for r in resultados.values())
    detenidas_por_bloqueo = [fk for fk, r in resultados.items() if r.get("parado_por_bloqueo")]

    print(f"\n  {'='*70}")
    print(f"  RESUMEN GLOBAL MODO 6 (descarga en paralelo)")
    print(f"  {'='*70}")
    for fkey in fuentes_keys:
        r = resultados.get(fkey, {})
        label = FUENTES[fkey]["label"]
        bloqueada = r.get("parado_por_bloqueo")
        estado_extra = "  [✗ DETENIDA POR BLOQUEO]" if bloqueada else ""
        linea = (f"  • {label:<28} → {r.get('ok',0)} OK | {r.get('vacias',0)} vacías | "
                 f"{r.get('fail',0)} fallidas | {r.get('pausas',0)} pausas{estado_extra}")
        print(_rojo(linea) if bloqueada else linea)
    print(f"  {'-'*70}")
    print(f"  Total:            {ok_total} OK | {vacias_total} vacías | {fail_total} fallidas")
    print(f"  Duración total:   {t_total:.0f}s ({t_total/60:.1f} min) — todas las fuentes en paralelo")
    print(f"  Pausas activadas: {pausas_totales} (cambios de sesión + backoffs por bloqueo, suma de todas las fuentes)")
    print(f"  HTML actualizado en {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    print(f"  {'='*70}")
    if detenidas_por_bloqueo:
        nombres_det = ", ".join(FUENTES[fk]["label"] for fk in detenidas_por_bloqueo)
        print(_rojo(f"  [✗] Fuentes detenidas por bloqueo persistente ({M6_BLOQUEOS_TRAS_PAUSA_MAX} bloqueos "
              f"seguidos tras pausa): {nombres_det}"))
        print(_rojo(f"      Puedes reintentarlas más tarde con el Modo 6 otra vez (solo quedarán sus huecos pendientes)."))
    if fail_total > 0:
        print(f"  [!] Hubo {fail_total} fallidas. Si crees que te han bloqueado, copia TODO el log")
        print(f"      de esta consola (con las horas [{_ts()}] y el tag [FUENTE] de cada línea) y pásamelo")
        print(f"      para que ajuste los tiempos de pausa antes de volver a intentarlo.")
    print()




# ═══════════════════════════════════════════════════════════════
#  MODO 7 — DESCARGA AUTOMÁTICA DE JORNADAS ANTIGUAS POR CATEGORÍA
#
#  Lógica inteligente:
#  1. Lee todos los JSONs en disco y agrupa por (fuente, categoría).
#  2. Para cada categoría detecta el ID mínimo que ya tiene.
#  3. Baja desde ese mínimo hacia abajo buscando las jornadas que faltan.
#  4. Procesa 30 IDs por tanda, pausa 20 min entre tandas.
#  5. Álava y Euskadi funcionan en hilos paralelos (webs distintas).
#  6. Si detecta bloqueo: pausa 20 min automática + reinicio Chrome.
#  7. Al acabar todas las categorías de una fuente, para ese hilo.
# ═══════════════════════════════════════════════════════════════
import threading

LOTE_M7  = 30        # actas por tanda
PAUSA_M7 = 15 * 60   # 15 min entre tandas (segundos)
# Máximo de IDs "vacíos" consecutivos antes de considerar que
# ya no hay más actas de esa categoría en esa dirección
MAX_VACIOS_CONSEC = 60


def _m7_inventario(fuente_cfg):
    """Devuelve (en_disco:set, vacios:set, excluir:set, json_info:dict).
    json_info = {id_int: {categoria, jornada}}"""
    prefix   = fuente_cfg["prefix"]
    out_dir  = fuente_cfg["output_dir"]
    json_dir = fuente_cfg["json_dir"]

    pat = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    en_disco = {int(pat.search(f).group(1)) for f in os.listdir(out_dir) if pat.match(f)}

    empty_ids_raw = load_empty_ids(fuente_cfg["empty_file"])
    vacios = {int(k) for k in empty_ids_raw if not should_retry_empty(int(k), empty_ids_raw)}
    excluir = en_disco | vacios

    # Leer JSONs para saber categoría de cada ID
    pat_j = re.compile(rf"^{re.escape(prefix)}(\d+)\.json$")
    json_info = {}
    for fn in os.listdir(json_dir):
        m = pat_j.match(fn)
        if not m: continue
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                d = json.load(f)
            json_info[int(m.group(1))] = {
                "categoria": d.get("categoria", "?"),
                "jornada":   d.get("jornada"),
            }
        except: pass

    return en_disco, vacios, excluir, json_info


def _m7_categorias_pendientes(fuente_cfg):
    """
    Devuelve lista de dicts, uno por categoría que todavía tiene jornadas
    previas sin descargar:
      { 'cat': str, 'min_id': int, 'min_jor': int, 'cursor': int }
    cursor = próximo ID a intentar (empieza en min_id - 1).
    NOTA: Se ignoran completamente las categorías de fútbol sala.
    """
    en_disco, vacios, excluir, json_info = _m7_inventario(fuente_cfg)

    # Palabras clave que identifican categorías a ignorar (sala + femeninas)
    _EXCL_KEYS = ['sala', 'futsal', 'futsala', 'femenina', 'femenino', 'femeninas', 'femeninos']
    def _es_excluida(cat):
        c = (cat or '').lower()
        return any(k in c for k in _EXCL_KEYS)

    # Agrupar por categoría: min_id y min_jornada
    cats = {}   # cat_str -> {'min_id':int, 'min_jor':int}
    for iid, info in json_info.items():
        cat = info.get("categoria", "?")
        # Saltar categorías de fútbol sala y femeninas
        if _es_excluida(cat):
            continue
        jor = info.get("jornada") or 0
        if cat not in cats:
            cats[cat] = {"min_id": iid, "min_jor": jor}
        else:
            if iid < cats[cat]["min_id"]:
                cats[cat]["min_id"] = iid
            if jor and (jor < cats[cat]["min_jor"] or cats[cat]["min_jor"] == 0):
                cats[cat]["min_jor"] = jor

    resultado = []
    for cat, info in cats.items():
        min_jor = info["min_jor"]
        # Si ya tenemos la J1 de esa categoría, no hay nada que buscar
        if min_jor <= 1:
            continue
        resultado.append({
            "cat":     cat,
            "min_id":  info["min_id"],
            "min_jor": min_jor,
            "cursor":  info["min_id"] - 1,  # empezamos justo debajo del mínimo
        })

    # Ordenar: primero las categorías con IDs más altos (temporadas más modernas)
    resultado.sort(key=lambda x: x["min_id"], reverse=True)
    return resultado


def _m7_descargar_lote(driver, fuente_cfg, pendientes, tag, empty_ids, stop_event):
    """
    Descarga la lista de IDs en 'pendientes'.
    Devuelve (driver, ok, vacias_n, fail, bloqueo_fuerte:bool).
    Gestiona reintentos, bloqueos y pausa de 20 min si hay bloqueo fuerte.
    """
    prefix   = fuente_cfg["prefix"]
    ua_idx   = [0]   # mutable para la closure

    def _reiniciar(motivo):
        nonlocal driver
        print(f"{tag} [~] Reiniciando Chrome ({motivo})...")
        cerrar(driver)
        ua_idx[0] += 1
        time.sleep(random.uniform(2, 5))
        driver = crear_nav(ua_idx[0])
        calentar(driver, fuente_cfg)
        return driver

    ok = fail = vacias_n = 0
    actas_ses = fallos_consec = bloqueos_consec = 0
    bloqueo_fuerte = False

    for idx, cod in enumerate(pendientes, 1):
        if stop_event.is_set():
            break
        if actas_ses > 0 and actas_ses % REINICIAR_CADA == 0:
            driver = _reiniciar(f"cada {REINICIAR_CADA}")

        ruta, estado = descargar(driver, cod, idx, len(pendientes), fuente_cfg)

        if estado == "vacia":
            mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
            try: os.remove(ruta)
            except: pass
            vacias_n += 1; fallos_consec = 0; bloqueos_consec = 0

        elif estado == "ok":
            ok += 1; fallos_consec = 0; bloqueos_consec = 0

        elif estado == "bloqueo":
            bloqueos_consec += 1; fallos_consec += 1; fail += 1
            print(f"{tag} [!] Bloqueo #{bloqueos_consec}")
            if bloqueos_consec >= 2:
                print(f"{tag} [!] Bloqueo fuerte → pausa {PAUSA_M7//60} min...")
                cerrar(driver); driver = None
                for _ in range(PAUSA_M7):
                    if stop_event.is_set(): break
                    time.sleep(1)
                if stop_event.is_set(): break
                driver = crear_nav(ua_idx[0]); calentar(driver, fuente_cfg)
                bloqueos_consec = 0; fallos_consec = 0; bloqueo_fuerte = True
                ruta2, estado2 = descargar(driver, cod, idx, len(pendientes), fuente_cfg)
                if estado2 == "ok":    ok += 1; fail -= 1
                elif estado2 == "vacia":
                    mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                    try: os.remove(ruta2)
                    except: pass
                    vacias_n += 1
            else:
                driver = _reiniciar("anti-bloqueo leve")

        else:   # error genérico
            fallos_consec += 1; fail += 1
            if fallos_consec >= FALLOS_PAUSA:
                p = random.randint(PAUSA_MIN, PAUSA_MAX)
                print(f"{tag} [!] {fallos_consec} fallos → pausa {p}s")
                driver = _reiniciar("anti-bloqueo")
                time.sleep(p); fallos_consec = 0
                ruta3, estado3 = descargar(driver, cod, idx, len(pendientes), fuente_cfg)
                if estado3 == "ok":    ok += 1; fail -= 1
                elif estado3 == "vacia":
                    mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                    try: os.remove(ruta3)
                    except: pass
                    vacias_n += 1
        actas_ses += 1

    return driver, ok, vacias_n, fail, bloqueo_fuerte


def _m7_parsear_nuevos(fuente_cfg, fuente_key, tag):
    """Parsea los TXTs que no tienen JSON válido."""
    out_dir  = fuente_cfg["output_dir"]
    json_dir = fuente_cfg["json_dir"]
    prefix   = fuente_cfg["prefix"]
    pat_p = re.compile(rf"Acta_{re.escape(prefix)}\d+\.txt")
    parseadas = 0
    for fn in sorted(f for f in os.listdir(out_dir) if pat_p.match(f)):
        aid = re.search(r"Acta_(.+)\.txt", fn).group(1)
        jp  = os.path.join(json_dir, f"{aid}.json")
        if os.path.exists(jp):
            try:
                with open(jp, encoding="utf-8") as jf: jd = json.load(jf)
                if all(k in jd for k in ("jornada","titulares_local","sustituciones_local")):
                    continue
            except: pass
        try:
            Parser(os.path.join(out_dir, fn), json_dir=json_dir, fuente=fuente_key).process()
            parseadas += 1
        except Exception as e:
            print(f"{tag} [!] Error parseando {fn}: {e}")
    if parseadas:
        print(f"{tag} [+] Parseadas: {parseadas} actas nuevas")


def _modo7_fuente(fuente_key, stop_event, tag=""):
    """
    Hilo principal del Modo 7 para una fuente.
    Estrategia: para CADA categoría que tiene jornadas previas sin descargar,
    baja desde su ID mínimo hacia abajo de 30 en 30 hasta encontrar J1
    o hasta que MAX_VACIOS_CONSEC IDs consecutivos estén vacíos (no hay más).
    Rota entre categorías para ir completando todas en paralelo.
    """
    fuente_cfg = FUENTES[fuente_key]
    if not tag:
        tag = f"[{fuente_key.upper()[:6]}]"

    driver = None
    try:
        # ── Cargar estado inicial de cursores por categoría ──────────
        categorias = _m7_categorias_pendientes(fuente_cfg)

        if not categorias:
            print(f"{tag} Todas las categorías tienen J1 o no hay datos. Nada que hacer.")
            return

        print(f"{tag} Categorías con jornadas previas pendientes:")
        for c in categorias:
            print(f"{tag}   · {c['cat'][:55]} → desde J{c['min_jor']-1} hacia atrás (cursor ID {c['cursor']})")
        print()

        # Persistir cursores para reanudar si se interrumpe
        cursor_file = os.path.join(fuente_cfg["output_dir"], "m7_cursors.json")
        try:
            saved = json.load(open(cursor_file, encoding="utf-8"))
            # Actualizar cursores con los guardados (más bajos = más avanzados)
            for c in categorias:
                k = c["cat"]
                if k in saved and saved[k] < c["cursor"]:
                    c["cursor"] = saved[k]
                    print(f"{tag} [~] Cursor restaurado para '{k[:40]}': {c['cursor']}")
        except: pass

        # vacios_consec por categoría: si acumula MAX_VACIOS_CONSEC → la damos por terminada
        vacios_cat = {c["cat"]: 0 for c in categorias}
        terminadas = set()

        empty_ids = load_empty_ids(fuente_cfg["empty_file"])

        # ── Arrancar Chrome ──────────────────────────────────────────
        ua_idx = 0
        driver = crear_nav(ua_idx)
        calentar(driver, fuente_cfg)

        tanda_global = 0

        while not stop_event.is_set():
            # Categorías activas (tienen cursor > 0 y no están terminadas)
            activas = [c for c in categorias
                       if c["cat"] not in terminadas and c["cursor"] > 0]
            if not activas:
                print(f"{tag} Todas las categorías completadas.")
                break

            # Rotar: una tanda por categoría activa antes de pausar
            hubo_descarga = False
            for cat_info in list(activas):
                if stop_event.is_set(): break
                cat   = cat_info["cat"]
                cursor = cat_info["cursor"]

                # Inventario fresco para saber qué ya está en disco
                _, _, excluir, _ = _m7_inventario(fuente_cfg)

                # Construir lote de 30 IDs desde cursor hacia abajo
                candidatos = [cursor - i for i in range(LOTE_M7) if (cursor - i) > 0]
                pendientes = [c for c in candidatos if c not in excluir]

                if not pendientes:
                    # Todos ya estaban → avanzar cursor y seguir
                    cat_info["cursor"] = max(cursor - LOTE_M7, 0)
                    continue

                tanda_global += 1
                print(f"\n{tag} ═══ Tanda #{tanda_global} | {cat[:45]} | IDs {pendientes[0]}→{pendientes[-1]} ═══")
                hubo_descarga = True

                driver, ok, vacias_n, fail, bloqueo_fuerte = _m7_descargar_lote(
                    driver, fuente_cfg, pendientes, tag, empty_ids, stop_event)

                print(f"{tag} [+] {ok} OK | {vacias_n} vacías | {fail} fallidas")

                # Actualizar cursor: siguiente ID a intentar
                cat_info["cursor"] = min(pendientes) - 1

                # Contar vacíos consecutivos para esta categoría
                if ok > 0:
                    vacios_cat[cat] = 0   # encontramos algo real → reset
                else:
                    vacios_cat[cat] += vacias_n + fail
                    if vacios_cat[cat] >= MAX_VACIOS_CONSEC:
                        print(f"{tag} [~] '{cat[:45]}': {MAX_VACIOS_CONSEC} IDs sin actas → categoría completada")
                        terminadas.add(cat)

                # Guardar cursores
                cursores_dict = {c["cat"]: c["cursor"] for c in categorias}
                try:
                    with open(cursor_file, "w", encoding="utf-8") as f:
                        json.dump(cursores_dict, f, ensure_ascii=False)
                except: pass

                # Parsear lo nuevo
                _m7_parsear_nuevos(fuente_cfg, fuente_key, tag)

                # Si hubo bloqueo fuerte, la pausa ya se hizo dentro → no pausar otra vez
                if not bloqueo_fuerte and not stop_event.is_set() and activas.index(cat_info) < len(activas) - 1:
                    # Mini-pausa entre categorías para no saturar
                    time.sleep(random.uniform(8, 15))

            # ── Pausa 20 min entre rondas completas ──────────────────
            if hubo_descarga and not stop_event.is_set():
                activas_ahora = [c for c in categorias if c["cat"] not in terminadas and c["cursor"] > 0]
                if activas_ahora:
                    print(f"\n{tag} [~] Ronda completa. Pausa {PAUSA_M7//60} min...")
                    for _ in range(PAUSA_M7):
                        if stop_event.is_set(): break
                        time.sleep(1)
            elif not hubo_descarga:
                break   # nada que hacer

    except Exception:
        print(f"{tag} ERROR CRITICO en hilo Modo 7:")
        traceback.print_exc()
    finally:
        if driver:
            try: cerrar(driver)
            except: pass
        print(f"{tag} Hilo Modo 7 finalizado.")


def _m7_borrar_actas_excluidas():
    """
    Marca en empty_ids las actas cuya categoría sea fútbol sala o femenina,
    para que no se vuelvan a descargar. NO elimina los archivos de disco,
    así se evita re-descargarlas en cada ejecución.
    Los datos de sala/femeninas se ocultan en el HTML mediante isSala() en JS.
    """
    _EXCL_KEYS = ['sala', 'futsal', 'futsala', 'femenina', 'femenino', 'femeninas', 'femeninos']
    def _es_excluida(cat):
        return any(k in (cat or '').lower() for k in _EXCL_KEYS)

    total_marcadas = 0
    for fuente_key, fuente_cfg in FUENTES.items():
        json_dir = fuente_cfg["json_dir"]
        prefix   = fuente_cfg["prefix"]
        empty_fp = fuente_cfg["empty_file"]
        pat_j = re.compile(rf"^{re.escape(prefix)}(\d+)\.json$")

        empty_ids = load_empty_ids(empty_fp)
        marcadas_fuente = 0

        for fn in os.listdir(json_dir):
            m = pat_j.match(fn)
            if not m: continue
            try:
                with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                    d = json.load(f)
                if _es_excluida(d.get("categoria", "")):
                    aid = m.group(1)
                    if str(aid) not in empty_ids:
                        mark_empty(aid, empty_ids, empty_fp)
                        marcadas_fuente += 1
            except: pass

        if marcadas_fuente:
            total_marcadas += marcadas_fuente

    if total_marcadas:
        print(f"[+] Actas de sala/femeninas marcadas (no se re-descargarán): {total_marcadas}")
    else:
        print("[~] No hay actas de sala/femeninas nuevas que marcar.")


def modo7_retrograde():
    """Modo 7: descarga automática de jornadas antiguas por categoría, todas las fuentes en paralelo."""
    print("\n" + "=" * 72)
    print("  MODO 7 — Descarga automática de jornadas antiguas por categoría")
    print(f"  • {LOTE_M7} actas por tanda  •  Pausa {PAUSA_M7//60} min entre rondas")
    print("  • Detecta qué jornadas faltan en CADA categoría y las busca")
    print("  • Bloqueo detectado → pausa automática 20 min + reinicio Chrome")
    print("  • Reanuda desde donde lo dejó si se interrumpe (cursores guardados)")
    print("  • Pulsa Ctrl+C para detener y generar HTML final")
    print("  • Fútbol Sala y Femeninas: no se buscan ni descargan (archivos en disco conservados, ocultos en HTML)")
    print("=" * 72 + "\n")

    # ── Selección de fuentes ───────────────────────────────────────────────
    OPCIONES_FUENTES = {
        "A": [("alava",    "[ÁLAVA   ]")],
        "E": [("euskadi",  "[EUSKADI ]")],
        "G": [("gipuzkoa", "[GIPUZKOA]")],
        "B": [("bizkaia",  "[BIZKAIA ]")],
        "NA":[("navarra",  "[NAVARRA ]")],
        "N": [("rfef",     "[RFEF    ]")],
        "R": [("rioja",    "[RIOJA   ]")],
        "CA": [("cantabria", "[CANTABRIA]")],
        "SA":[("euskadi",  "[EUSKADI ]"), ("gipuzkoa", "[GIPUZKOA]"),
              ("bizkaia",  "[BIZKAIA ]"), ("navarra",  "[NAVARRA ]"),
              ("rfef",     "[RFEF    ]"), ("rioja",    "[RIOJA   ]"),
              ("cantabria", "[CANTABRIA]")],
        "T": [("alava",    "[ÁLAVA   ]"), ("euskadi",  "[EUSKADI ]"),
              ("gipuzkoa", "[GIPUZKOA]"), ("bizkaia",  "[BIZKAIA ]"),
              ("navarra",  "[NAVARRA ]"), ("rfef",     "[RFEF    ]"),
              ("rioja",    "[RIOJA   ]"), ("cantabria", "[CANTABRIA]")],
    }
    print("  ¿Qué fuentes quieres descargar?")
    print("  [T]  Todas  (Álava + Euskadi + Gipuzkoa + Bizkaia + Navarra + RFEF + La Rioja + Cantabria)")
    print("  [SA] Sin Álava  (Euskadi + Gipuzkoa + Bizkaia + Navarra + RFEF + La Rioja + Cantabria)")
    print("  [A]  Solo Álava")
    print("  [E]  Solo Euskadi")
    print("  [G]  Solo Gipuzkoa")
    print("  [B]  Solo Bizkaia")
    print("  [NA] Solo Navarra")
    print("  [N]  Solo RFEF (Nacional)")
    print("  [R]  Solo La Rioja")
    print()
    while True:
        sel7 = input("  Elige [T/SA/A/E/G/B/NA/N/R]: ").strip().upper()
        if sel7 in OPCIONES_FUENTES:
            break
        print("  Opción no válida. Introduce T, SA, A, E, G, B, NA, N o R.")

    fuentes_seleccionadas = OPCIONES_FUENTES[sel7]
    nombres_sel = ", ".join(tag.strip("[] ") for _, tag in fuentes_seleccionadas)
    print(f"\n  → Fuentes seleccionadas: {nombres_sel}")
    print(f"  → {'Paralelo' if len(fuentes_seleccionadas) > 1 else 'Un solo hilo'} "
          f"(webs distintas → no se bloquean entre sí)" if len(fuentes_seleccionadas) > 1
          else "")
    print()

    # Eliminar actas de fútbol sala y femeninas que pudieran haberse descargado previamente
    print("[*] Verificando actas de sala/femeninas (marcando para no re-descargar)...")
    _m7_borrar_actas_excluidas()
    print()

    stop_event = threading.Event()
    hilos = [
        threading.Thread(target=_modo7_fuente, args=(fk, stop_event, tag), daemon=True)
        for fk, tag in fuentes_seleccionadas
    ]

    for i, hilo in enumerate(hilos):
        hilo.start()
        if i < len(hilos) - 1:
            time.sleep(random.uniform(5, 10))  # desfase: arrancan Chrome en momentos distintos

    print(f"[*] Hilos arrancados ({nombres_sel}). Pulsa Ctrl+C para parar limpiamente.\n")
    try:
        while any(h.is_alive() for h in hilos):
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Interrupción — deteniendo hilos (puede tardar hasta 30s)...")
        stop_event.set()
        for h in hilos:
            h.join(timeout=60)

    print("\n[*] Generando HTML final con todos los datos...")
    generar_html()
    print(f"[+] HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    print("[+] Modo 7 finalizado.\n")




# ═══════════════════════════════════════════════════════════════
#  MODO 9 — DESCARGA JORNADA SIGUIENTE (TEMPORADA ACTUAL, TODAS LAS LIGAS)
#
#  Lógica:
#  1. Temporada actual = "2025-2026" (calculada automáticamente según la fecha).
#  2. Para cada fuente (Álava, Euskadi, Gipuzkoa, Bizkaia, RFEF) EN PARALELO:
#     a. Lee JSONs filtrando SOLO los de la temporada actual.
#     b. Agrupa por categoría y detecta la última jornada descargada.
#     c. Calcula cuántos partidos tiene esa jornada (moda últimas 3 jornadas).
#     d. Busca IDs ascendentes desde max_id+1 buscando la jornada siguiente.
#     e. Parsea inmediatamente cada acta descargada para confirmar jornada/cat.
#     f. Para al completar los partidos esperados o tras MAX_VACIOS_SEQ vacíos.
#  3. Al terminar todos los hilos, parsea TXTs sin JSON y regenera HTML.
# ═══════════════════════════════════════════════════════════════

# Ventana de búsqueda por categoría (IDs hacia arriba desde max_id)
_M9_VENTANA     = 300
# Vacíos consecutivos antes de asumir que la jornada aún no se ha jugado
_M9_VACIOS_SEQ  = 60
# Pausa entre categorías dentro de un mismo hilo (segundos)
_M9_PAUSA_CAT   = (5, 12)


def _m9_temporada_actual():
    """
    Devuelve la temporada actual como string "YYYY-YYYY".
    La temporada de fútbol arranca en julio: si estamos en julio o más tarde
    es la temporada que comienza ese año; si no, la que comenzó el año anterior.
    """
    import datetime
    hoy = datetime.date.today()
    if hoy.month >= 7:
        return f"{hoy.year}-{hoy.year + 1}"
    else:
        return f"{hoy.year - 1}-{hoy.year}"


def _m9_estado_por_categoria(fuente_cfg, temporada):
    """
    Lee los JSONs de una fuente filtrando SOLO los de 'temporada'.
    Devuelve por categoría (excluidas sala/femeninas):
      { cat: { 'max_jor': int, 'max_id': int, 'partidos_por_jornada': int,
               'terminada': bool } }

    'terminada' = True cuando la última jornada registrada alcanza o supera
    el número total de jornadas de la liga (calculado a partir del nº de equipos:
    liga de N equipos → N*2-2 jornadas).  Si hay pocas jornadas en disco no se
    puede estimar el nº de equipos con fiabilidad → se deja terminada=False.
    """
    _EXCL = ['sala', 'futsal', 'futsala', 'femenina', 'femenino', 'femeninas', 'femeninos']
    def _excl(c): return any(k in (c or '').lower() for k in _EXCL)

    prefix   = fuente_cfg["prefix"]
    json_dir = fuente_cfg["json_dir"]
    pat_j    = re.compile(rf"^{re.escape(prefix)}(\d+)\.json$")

    # cat -> { jornada -> set(equipos) }  — solo temporada actual
    # Guardamos equipos para poder estimar el tamaño real de la liga
    cats_jor    = defaultdict(lambda: defaultdict(list))    # jornada -> [ids]
    cats_equipos= defaultdict(set)                          # todos los equipos vistos

    for fn in os.listdir(json_dir):
        m = pat_j.match(fn)
        if not m: continue
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                d = json.load(f)
            temp = (d.get("temporada") or "").strip()
            if temp != temporada:
                continue
            cat = d.get("categoria", "?")
            jor = d.get("jornada")
            if _excl(cat) or not jor:
                continue
            jor = int(jor)
            cats_jor[cat][jor].append(int(m.group(1)))
            # Acumular equipos para estimar tamaño de liga
            for eq in (d.get("equipo_local"), d.get("equipo_visitante")):
                if eq: cats_equipos[cat].add(eq)
        except:
            pass

    from collections import Counter as _Counter
    resultado = {}
    for cat, jornadas in cats_jor.items():
        if not jornadas:
            continue
        max_jor = max(jornadas.keys())
        max_id  = max(max(ids) for ids in jornadas.values())

        # Tamaño de jornada: moda de las últimas 3 jornadas de la temporada actual
        ultimas = sorted(jornadas.keys(), reverse=True)[:3]
        moda    = _Counter([len(jornadas[j]) for j in ultimas]).most_common(1)[0][0]

        # ── Detección de liga terminada ──────────────────────────────
        # Con N equipos una liga de todos contra todos (ida+vuelta) tiene N*2-2 jornadas.
        # Estimamos N a partir de los equipos distintos vistos en disco.
        # Para que la estimación sea fiable necesitamos al menos 3 jornadas completas
        # y que el nº de equipos sea par y >= 4.
        terminada = False
        n_equipos = len(cats_equipos[cat])
        n_jornadas_disco = len(jornadas)
        if (n_equipos >= 4 and n_equipos % 2 == 0
                and n_jornadas_disco >= 3):
            jornadas_totales = n_equipos * 2 - 2
            terminada = (max_jor >= jornadas_totales)
        elif n_jornadas_disco >= 3:
            # N de equipos impar o desconocido: usamos la moda de partidos/jornada
            # para deducir N (moda = N/2 → N = moda*2) y de ahí las jornadas totales
            n_eq_estimado = moda * 2
            if n_eq_estimado >= 4:
                jornadas_totales = n_eq_estimado * 2 - 2
                terminada = (max_jor >= jornadas_totales)

        resultado[cat] = {
            "max_jor":              max_jor,
            "max_id":               max_id,
            "partidos_por_jornada": moda,
            "terminada":            terminada,
        }
    return resultado


def _m9_buscar_jornada_siguiente(driver, fuente_cfg, fuente_key, cat_info,
                                  cat_nombre, temporada, tag):
    """
    Recorre IDs ascendentes desde max_id+1 buscando partidos de la
    jornada (max_jor+1) EN LA TEMPORADA 'temporada' y en la categoría
    'cat_nombre'. Parsea cada acta descargada inmediatamente para confirmar.
    Devuelve (ok_total, vacias_total, encontrados_jornada_objetivo).
    """
    max_id     = cat_info["max_id"]
    jor_target = cat_info["max_jor"] + 1
    esperados  = cat_info["partidos_por_jornada"]

    prefix   = fuente_cfg["prefix"]
    out_dir  = fuente_cfg["output_dir"]
    json_dir = fuente_cfg["json_dir"]

    # Inventario fresco: no re-descargar lo ya descargado y válido
    pat_disco  = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    en_disco   = {int(pat_disco.search(f).group(1))
                  for f in os.listdir(out_dir) if pat_disco.match(f)}
    vacios_raw = load_empty_ids(fuente_cfg["empty_file"])
    vacios_set = {int(k) for k in vacios_raw
                  if not should_retry_empty(int(k), vacios_raw)}
    excluir    = en_disco | vacios_set

    encontrados   = 0
    ok = vacias_n = 0
    vacios_consec = 0

    candidatos = [max_id + i for i in range(1, _M9_VENTANA + 1)]
    pendientes  = [c for c in candidatos if c not in excluir]

    print(f"{tag}   Temporada {temporada} | Buscando J{jor_target} "
          f"(~{esperados} partidos) desde ID {max_id + 1}")

    for idx, cod in enumerate(pendientes, 1):
        if encontrados >= esperados:
            print(f"{tag}   ✓ J{jor_target} completa ({encontrados}/{esperados})")
            break
        if vacios_consec >= _M9_VACIOS_SEQ:
            print(f"{tag}   ✗ {_M9_VACIOS_SEQ} vacíos seguidos "
                  f"— J{jor_target} no disputada aún o fuera de rango")
            break

        ruta, estado = descargar(driver, cod, idx, len(pendientes), fuente_cfg)

        if estado == "ok":
            vacios_consec = 0
            ok += 1
            try:
                aid = re.search(r"Acta_(.+)\.txt", os.path.basename(ruta)).group(1)
                jp  = os.path.join(json_dir, f"{aid}.json")
                Parser(ruta, json_dir=json_dir, fuente=fuente_key).process()
                with open(jp, encoding="utf-8") as jf:
                    d = json.load(jf)
                jor_real  = d.get("jornada")
                cat_real  = d.get("categoria", "")
                temp_real = (d.get("temporada") or "").strip()
                if (jor_real == jor_target
                        and cat_real == cat_nombre
                        and temp_real == temporada):
                    encontrados += 1
                    print(f"{tag}     → [{encontrados}/{esperados}] "
                          f"{d.get('equipo_local','?')} vs "
                          f"{d.get('equipo_visitante','?')} "
                          f"({d.get('fecha','')})")
            except Exception as e:
                print(f"{tag}   [!] Error parseo ID {cod}: {e}")

        elif estado == "vacia":
            eid = load_empty_ids(fuente_cfg["empty_file"])
            mark_empty(cod, eid, fuente_cfg["empty_file"])
            try: os.remove(ruta)
            except: pass
            vacias_n += 1
            vacios_consec += 1

        else:   # bloqueo / error
            vacios_consec += 1
            time.sleep(random.uniform(4, 9))

    return ok, vacias_n, encontrados


def _m9_hilo_fuente(fuente_key, temporada, resumen_dict, lock, stop_event, ua_offset=0):
    """
    Hilo del Modo 9 para una fuente completa.
    Descarga la jornada siguiente de todas las categorías de la temporada actual.
    """
    fuente_cfg = FUENTES[fuente_key]
    tag = f"[{fuente_key.upper()[:6]:6s}]"

    resumen_fuente = {}
    driver = None

    try:
        if not os.path.isdir(fuente_cfg["json_dir"]):
            print(f"{tag} Directorio JSON no existe. Saltando.")
            return

        estado_cats = _m9_estado_por_categoria(fuente_cfg, temporada)
        cats_trabajo = {
            cat: info for cat, info in estado_cats.items()
            if info["max_jor"] >= 1 and info["partidos_por_jornada"] >= 1
               and not info["terminada"]
        }
        cats_terminadas = {
            cat: info for cat, info in estado_cats.items()
            if info.get("terminada")
        }

        if not cats_trabajo and not cats_terminadas:
            print(f"{tag} Sin categorías de la temporada {temporada}. Saltando.")
            return

        # Mostrar las ya terminadas (no se descargan)
        if cats_terminadas:
            print(f"\n{tag} {len(cats_terminadas)} categorías FINALIZADAS (se omiten):")
            for cat, info in sorted(cats_terminadas.items()):
                n_eq = len({eq for eq in []})   # placeholder visual
                print(f"{tag}   ✗ {cat[:52]:<52} | J{info['max_jor']:>3} (liga terminada)")

        if not cats_trabajo:
            print(f"{tag} Todas las categorías de {temporada} han finalizado. Nada que descargar.")
            return

        print(f"\n{tag} {len(cats_trabajo)} categorías en temporada {temporada}:")
        for cat, info in sorted(cats_trabajo.items()):
            print(f"{tag}   · {cat[:52]:<52} | J{info['max_jor']:>3}→J{info['max_jor']+1:>3}"
                  f" | ~{info['partidos_por_jornada']} partidos | max_id={info['max_id']}")

        print(f"\n{tag} Iniciando Chrome...")
        driver = crear_nav(ua_offset)
        calentar(driver, fuente_cfg)

        for cat_nombre, cat_info in sorted(cats_trabajo.items()):
            if stop_event.is_set():
                break
            print(f"\n{tag} ── {cat_nombre[:65]}")
            ok, vacias, encontrados = _m9_buscar_jornada_siguiente(
                driver, fuente_cfg, fuente_key,
                cat_info, cat_nombre, temporada, tag)
            resumen_fuente[cat_nombre] = {
                "jor_target":  cat_info["max_jor"] + 1,
                "esperados":   cat_info["partidos_por_jornada"],
                "encontrados": encontrados,
            }
            if len(cats_trabajo) > 1 and not stop_event.is_set():
                time.sleep(random.uniform(*_M9_PAUSA_CAT))

        # Parsear nuevos TXTs sin JSON válido
        print(f"\n{tag} Parseando nuevas actas...")
        prefix   = fuente_cfg["prefix"]
        out_dir  = fuente_cfg["output_dir"]
        json_dir = fuente_cfg["json_dir"]
        pat_p    = re.compile(rf"Acta_{re.escape(prefix)}\d+\.txt")
        parseadas = 0
        for fn in sorted(f for f in os.listdir(out_dir) if pat_p.match(f)):
            aid = re.search(r"Acta_(.+)\.txt", fn).group(1)
            jp  = os.path.join(json_dir, f"{aid}.json")
            reparsear = True
            if os.path.exists(jp):
                try:
                    with open(jp, encoding="utf-8") as jf: jd = json.load(jf)
                    if all(k in jd for k in ("jornada", "titulares_local",
                                             "sustituciones_local")):
                        reparsear = False
                except: pass
            if reparsear:
                try:
                    Parser(os.path.join(out_dir, fn),
                           json_dir=json_dir, fuente=fuente_key).process()
                    parseadas += 1
                except Exception as e:
                    print(f"{tag} [!] Error {fn}: {e}")
        if parseadas:
            print(f"{tag} [+] Parseadas: {parseadas} nuevas actas")

    except Exception:
        print(f"{tag} ERROR CRITICO:")
        traceback.print_exc()
    finally:
        if driver:
            try: cerrar(driver)
            except: pass
        with lock:
            resumen_dict[fuente_key] = resumen_fuente
        print(f"{tag} Hilo finalizado.")


def modo9_jornada_siguiente():
    """
    Modo 9: descarga la jornada siguiente de la temporada actual en TODAS
    las ligas y categorías, lanzando un hilo Chrome por fuente en PARALELO
    (igual que el Modo 7, pero hacia ARRIBA buscando la jornada próxima).
    """
    temporada = _m9_temporada_actual()

    print("\n" + "=" * 72)
    print("  MODO 9 — Jornada siguiente (temporada actual: todas las ligas)")
    print(f"  Temporada: {temporada}")
    print("  Fuentes en PARALELO: Álava · Euskadi · Gipuzkoa · Bizkaia · RFEF · La Rioja")
    print("  Ignora Fútbol Sala y categorías Femeninas")
    print("  Pulsa Ctrl+C para detener y generar HTML con lo descargado")
    print("=" * 72 + "\n")

    resumen_global = {}
    lock       = threading.Lock()
    stop_event = threading.Event()

    # Un hilo por fuente, desfasados para no abrir todos los Chrome a la vez
    hilos = []
    for i, (fkey, _) in enumerate(FUENTES.items()):
        h = threading.Thread(
            target=_m9_hilo_fuente,
            args=(fkey, temporada, resumen_global, lock, stop_event, i),
            daemon=True,
            name=f"m9_{fkey}",
        )
        hilos.append(h)

    for i, h in enumerate(hilos):
        h.start()
        if i < len(hilos) - 1:
            time.sleep(random.uniform(6, 12))   # desfase entre arranques

    print("[*] Hilos arrancados (Álava, Euskadi, Gipuzkoa, Bizkaia, RFEF, La Rioja). "
          "Pulsa Ctrl+C para parar.\n")
    try:
        while any(h.is_alive() for h in hilos):
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Interrupción — deteniendo hilos...")
        stop_event.set()
        for h in hilos:
            h.join(timeout=60)

    # ── Resumen final ──────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print(f"  RESUMEN MODO 9 — Temporada {temporada}")
    print("=" * 72)
    total_enc = total_esp = 0
    for fkey, fcfg in FUENTES.items():
        # Recalcular estado para mostrar también las terminadas en el resumen
        estado_res = {}
        try:
            estado_res = _m9_estado_por_categoria(FUENTES[fkey], temporada)
        except: pass

        cats_proc = resumen_global.get(fkey, {})
        cats_term = {cat: info for cat, info in estado_res.items()
                     if info.get("terminada")}

        if not cats_proc and not cats_term:
            continue
        print(f"\n  {fcfg['label']}:")
        for cat, info in sorted(cats_proc.items()):
            enc = info["encontrados"]; esp = info["esperados"]
            total_enc += enc; total_esp += esp
            icono = "✓" if enc >= esp else ("~" if enc > 0 else "✗")
            print(f"    {icono} {cat[:55]:<55} J{info['jor_target']:>3}: "
                  f"{enc}/{esp} partidos")
        for cat, info in sorted(cats_term.items()):
            if cat not in cats_proc:   # no mostrar duplicados
                print(f"    — {cat[:55]:<55} J{info['max_jor']:>3}  "
                      f"(liga finalizada, omitida)")
    print(f"\n  TOTAL procesadas: {total_enc}/{total_esp} partidos "
          f"en temporada {temporada}")

    # ── HTML final ─────────────────────────────────────────────────────────
    print("\n[*] Generando HTML...")
    generar_html()
    print(f"[+] HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}\n")


# ═══════════════════════════════════════════════════════════════
#  SERVIDOR WEB PARA AUTO-GUARDADO DE CAMBIOS
# ═══════════════════════════════════════════════════════════════
def iniciar_servidor_autosave():
    """Inicia un servidor web simple para recibir cambios del HTML y guardarlos en JSON."""
    try:
        from http.server import HTTPServer, BaseHTTPRequestHandler
        import threading
        
        class AutoSaveHandler(BaseHTTPRequestHandler):
            def do_POST(self):
                if self.path == '/api/save-data':
                    content_length = int(self.headers.get('Content-Length', 0))
                    body = self.rfile.read(content_length)
                    
                    try:
                        data = json.loads(body.decode('utf-8'))
                        json_path = os.path.join(HTML_DIR, "FAF_Stats_Data.json")
                        
                        with open(json_path, "w", encoding="utf-8") as f:
                            json.dump(data, f, ensure_ascii=False, indent=2)
                        
                        self.send_response(200)
                        self.send_header('Content-type', 'application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({"ok": True}).encode())
                    except Exception as e:
                        self.send_response(500)
                        self.end_headers()
                        self.wfile.write(json.dumps({"error": str(e)}).encode())
                else:
                    self.send_response(404)
                    self.end_headers()
            
            def do_GET(self):
                self.send_response(404)
                self.end_headers()
            
            def log_message(self, format, *args):
                pass  # Silenciar logs
        
        # Iniciar servidor en background
        server = HTTPServer(('127.0.0.1', 5555), AutoSaveHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        print("[+] Servidor auto-save iniciado en 127.0.0.1:5555")
        return server
    except Exception as e:
        print(f"[~] No se pudo iniciar servidor auto-save: {e}")
        return None


# ═══════════════════════════════════════════════════════════════
#  MODO 11: EXPORTAR DATOS DEL HTML A JSON
# ═══════════════════════════════════════════════════════════════
def modo11_exportar_datos():
    """
    Extrae TODOS los datos que el HTML tiene en memoria (localStorage, sessionStorage)
    incluyendo: favoritos, merges, equipos, jugadores modificados manualmente, etc.
    y los exporta a JSON en la carpeta de salida para análisis offline.
    """
    import re as re_module
    from bs4 import BeautifulSoup
    
    html_path = os.path.join(HTML_DIR, "FAF_Stats.html")
    
    if not os.path.exists(html_path):
        print(f"\n[!] No existe el archivo HTML: {html_path}")
        print("[!] Genera primero el HTML ejecutando el Modo 1, 2 o 3.")
        return
    
    print(f"\n[*] Leyendo HTML: {html_path}")
    try:
        with open(html_path, "r", encoding="utf-8") as f:
            html_content = f.read()
    except Exception as e:
        print(f"[!] Error leyendo HTML: {e}")
        return
    
    datos_exportados = {}
    
    # ── Extraer TODAS las variables JavaScript con datos ──────────────────────
    # Patrones para encontrar: const VAR_NAME = {...}; o const VAR_NAME = [...];
    
    # Buscar todas las asignaciones de variables JavaScript
    pattern = r"const\s+(\w+)\s*=\s*(\{(?:[^{}]|(?:\{[^{}]*\}))*\}|\[(?:[^\[\]]|(?:\[[^\]]*\]))*\]);?"
    
    matches = re_module.findall(pattern, html_content)
    
    for var_name, json_str in matches:
        try:
            # Intentar parsear como JSON
            data = json.loads(json_str)
            datos_exportados[var_name] = data
            
            # Dar info según el tipo de variable
            if isinstance(data, dict):
                print(f"[+] {var_name}: {len(data)} items (dict)")
            elif isinstance(data, list):
                print(f"[+] {var_name}: {len(data)} items (list)")
            else:
                print(f"[+] {var_name}: extraído")
        except json.JSONDecodeError:
            # Si no es JSON válido, intentar extraer como string si es relevante
            if any(keyword in var_name.lower() for keyword in 
                   ['favorit', 'merge', 'equipo', 'jugador', 'config', 'prefer', 'custom', 'storage']):
                datos_exportados[var_name] = json_str[:500]  # primeros 500 chars
                print(f"[~] {var_name}: capturado como texto (parcial)")
    
    # ── Buscar variables globales sin "const" ────────────────────────────────
    # Algunas variables pueden estar asignadas sin const
    pattern2 = r"(?:window\.)?(\w+)\s*=\s*(\{[^;]*\}|\[[^\]]*\]);?"
    matches2 = re_module.findall(pattern2, html_content)
    
    for var_name, json_str in matches2:
        if var_name not in datos_exportados:  # No duplicar
            try:
                if json_str.strip().startswith('{') or json_str.strip().startswith('['):
                    data = json.loads(json_str)
                    datos_exportados[var_name] = data
                    if isinstance(data, dict):
                        print(f"[+] {var_name}: {len(data)} items (dict, global)")
                    elif isinstance(data, list):
                        print(f"[+] {var_name}: {len(data)} items (list, global)")
            except:
                pass
    
    # ── Extraer inline scripts con datos almacenados ────────────────────────
    # Buscar patrones como: localStorage.setItem(...) o sessionStorage.setItem(...)
    localStorage_pattern = r"localStorage\.setItem\(['\"](\w+)['\"]\s*,\s*(['\"])(.+?)\2"
    sessionStorage_pattern = r"sessionStorage\.setItem\(['\"](\w+)['\"]\s*,\s*(['\"])(.+?)\2"
    
    local_matches = re_module.findall(localStorage_pattern, html_content)
    session_matches = re_module.findall(sessionStorage_pattern, html_content)
    
    if local_matches:
        local_storage = {}
        for key, _, value in local_matches:
            try:
                local_storage[key] = json.loads(value)
            except:
                local_storage[key] = value
        if local_storage:
            datos_exportados["_localStorage"] = local_storage
            print(f"[+] localStorage: {len(local_storage)} items")
    
    if session_matches:
        session_storage = {}
        for key, _, value in session_matches:
            try:
                session_storage[key] = json.loads(value)
            except:
                session_storage[key] = value
        if session_storage:
            datos_exportados["_sessionStorage"] = session_storage
            print(f"[+] sessionStorage: {len(session_storage)} items")
    
    # ── Extraer comentarios HTML que puedan contener datos ────────────────────
    # Buscar comentarios como: <!-- DATA: {...} -->
    comment_pattern = r"<!--\s*DATA:\s*(.+?)\s*-->"
    comment_matches = re_module.findall(comment_pattern, html_content, re_module.DOTALL)
    
    if comment_matches:
        for i, comment_data in enumerate(comment_matches):
            try:
                data = json.loads(comment_data)
                datos_exportados[f"_comment_data_{i}"] = data
                print(f"[+] Dato embebido en comentario {i}: extraído")
            except:
                pass
    
    if not datos_exportados:
        print("[!] No se encontraron datos en el HTML para exportar.")
        return
    
    # ── Guardar a JSON ──────────────────────────────────────────────
    export_filename = "FAF_Stats_Data.json"  # Nombre fijo, sin timestamp
    export_path = os.path.join(HTML_DIR, export_filename)
    
    try:
        with open(export_path, "w", encoding="utf-8") as f:
            json.dump(datos_exportados, f, ensure_ascii=False, indent=2)
        
        tamaño_kb = os.path.getsize(export_path) / 1024
        print(f"\n[+] Datos exportados correctamente:")
        print(f"    Archivo: {export_path}")
        print(f"    Tamaño:  {tamaño_kb:.1f} KB")
        print(f"    Secciones: {len(datos_exportados)} variables/objetos")
        print(f"    Variables: {', '.join(list(datos_exportados.keys())[:10])}")
        if len(datos_exportados) > 10:
            print(f"              ... y {len(datos_exportados) - 10} más")
    except Exception as e:
        print(f"[!] Error exportando JSON: {e}")


# ═══════════════════════════════════════════════════════════════
#  MODO 12 — TABLAS CRUZADAS (comparar resultados con actas)
#
#  1. Pide al usuario un CodGrupo (ej: 2191)
#  2. Descarga esa tabla cruzada y las 50 anteriores (2191, 2190, …, 2142)
#  3. Parsea los resultados local-visitante de cada celda
#  4. Compara contra los JSON en disco de todas las fuentes
#  5. Guarda discrepancias en F/2/tablas_cruzadas_discrepancias.json
#  6. Regenera el HTML para que aparezcan en la pestaña Config > Discrepancias
# ═══════════════════════════════════════════════════════════════

TABLAS_CRUZADAS_FILE   = os.path.join(BASE_DIR, "2", "tablas_cruzadas.json")
DISCREPANCIAS_FILE     = os.path.join(BASE_DIR, "2", "tablas_cruzadas_discrepancias.json")
TC_BASE_URL            = "https://www.faf-aff.eus/pnfg/NPcd/NFG_VisTablaCruzada"
TC_COD_PRIMARIA        = "1000120"


def _tc_descargar(driver, cod_grupo):
    """Descarga una tabla cruzada y devuelve el HTML crudo, o None si falla."""
    url = f"{TC_BASE_URL}?cod_primaria={TC_COD_PRIMARIA}&CodGrupo={cod_grupo}"
    for intento in range(1, 4):
        try:
            driver.get(url)
            WebDriverWait(driver, PAGE_TIMEOUT).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
                          and len(d.page_source) > 500)
            time.sleep(random.uniform(0.4, 0.8))
            html = driver.page_source
            if len(html) < 2000:
                return None
            return html
        except Exception as e:
            print(f"  [!] CodGrupo {cod_grupo} intento {intento}: {str(e).split(chr(10))[0][:80]}")
            time.sleep(2 * intento)
    return None


def _tc_parsear_tabla(html, cod_grupo):
    """
    Parsea una tabla cruzada y devuelve un dict con los resultados, o None si no hay datos.
    La tabla FAF tiene:
      - Fila de cabecera: columna 0 = etiqueta (vacía/"FUERA"), columnas 1..N = equipos visitante
      - Filas de datos:   columna 0 = equipo local ("CASA"), columnas 1..N = resultado o vacío (diagonal)
    """
    try:
        soup = BeautifulSoup(html, "html.parser")

        # ── Título real de la competición ────────────────────────────────────
        # La página FAF tiene un <h2> genérico ("Tabla cruzada de Partidos") y luego
        # el título real de la liga/temporada en otro elemento más abajo.
        # Estrategia: buscar el texto que contenga la temporada (XXXX-XXXX) primero;
        # si no, buscar el texto más largo entre todos los encabezados que NO sea el genérico.

        TITULO_GENERICO = re.compile(r"tabla\s+cruzada\s+de\s+partidos", re.I)

        titulo = ""
        temporada = ""

        # 1) Buscar cualquier tag de texto que contenga un patrón de temporada (\d{4}[-/]\d{4})
        for tag in soup.find_all(["h1", "h2", "h3", "h4", "h5", "p", "div", "span", "td", "th"]):
            txt = tag.get_text(" ", strip=True)
            if re.search(r"\d{4}[-/]\d{4}", txt) and not TITULO_GENERICO.search(txt):
                # Puede ser largo (con "Temporada XXXX-XXXX" al final); lo tomamos entero
                titulo = re.sub(r"\s+", " ", txt).strip()
                break

        # 2) Si no encontramos temporada en el texto, buscar el encabezado más largo
        #    que no sea el título genérico
        if not titulo:
            candidatos = []
            for tag in ("h1", "h2", "h3", "h4"):
                for h in soup.find_all(tag):
                    txt = h.get_text(" ", strip=True)
                    if txt and not TITULO_GENERICO.search(txt):
                        candidatos.append(txt)
            if candidatos:
                titulo = max(candidatos, key=len)

        # 3) Fallback: cualquier div/span con clase relacionada con título/competición
        if not titulo:
            for t_div in soup.find_all(class_=re.compile(r"titulo|title|competicion|liga|header", re.I)):
                txt = t_div.get_text(" ", strip=True)
                if txt and not TITULO_GENERICO.search(txt):
                    titulo = txt
                    break

        # Extraer temporada del título
        m_temp = re.search(r"(\d{4}[-/]\d{4})", titulo)
        if m_temp:
            temporada = m_temp.group(1).replace("/", "-")

        # Extraer categoría: todo lo que está ANTES de "Temporada ..." o de la fecha
        categoria = re.sub(r"\s*[\|,]?\s*(temporada|season|\d{4}[-/]\d{4}).*", "", titulo, flags=re.I).strip()
        # Limpiar posibles separadores finales
        categoria = re.sub(r"[\-–|,;]+\s*$", "", categoria).strip()
        if not categoria:
            categoria = f"Grupo {cod_grupo}"

        tablas = soup.find_all("table")
        if not tablas:
            return None
        tabla = max(tablas, key=lambda t: len(t.find_all("td")))
        rows = tabla.find_all("tr")
        if len(rows) < 3:
            return None

        # Cabecera (equipos visitante)
        head_cells = rows[0].find_all(["th", "td"])
        eq_columna = []
        for c in head_cells[1:]:
            txt = c.get_text(" ", strip=True)
            if txt and txt.upper() not in ("FUERA", "CASA", "", "LOCAL", "VISITANTE"):
                eq_columna.append(txt)

        resultados = {}
        for row in rows[1:]:
            celdas = row.find_all(["th", "td"])
            if not celdas:
                continue
            eq_local_txt = celdas[0].get_text(" ", strip=True)
            if not eq_local_txt or eq_local_txt.upper() in ("CASA", "FUERA", "LOCAL"):
                continue

            for j, celda in enumerate(celdas[1:]):
                if j >= len(eq_columna):
                    break
                eq_visit_txt = eq_columna[j]
                if _tc_normalizar(eq_local_txt) == _tc_normalizar(eq_visit_txt):
                    continue  # diagonal
                celda_txt = celda.get_text(" ", strip=True)
                m = re.search(r"(\d+)\s*[-–]\s*(\d+)", celda_txt)
                if m:
                    resultado = f"{m.group(1)}-{m.group(2)}"
                    clave = f"{eq_local_txt}|||{eq_visit_txt}"
                    resultados[clave] = resultado

        if not resultados:
            return None

        return {
            "cod_grupo":  cod_grupo,
            "titulo":     titulo,
            "temporada":  temporada,
            "categoria":  categoria,
            "resultados": resultados,
        }
    except Exception as e:
        print(f"  [!] Error parseando tabla {cod_grupo}: {e}")
        return None


def _tc_normalizar(nombre):
    """Normaliza nombre de equipo para comparación flexible."""
    n = (nombre or "").upper().strip()
    n = re.sub(r"\s+", " ", n)
    n = re.sub(r"[.,;:'\"\(\)]", "", n)
    return n


def _tc_cargar_actas_todos():
    """Carga todos los JSONs de todas las fuentes y los devuelve como lista."""
    actas = []
    for fcfg in FUENTES.values():
        jdir = fcfg["json_dir"]
        if not os.path.isdir(jdir):
            continue
        for fn in os.listdir(jdir):
            if not fn.endswith(".json"):
                continue
            try:
                with open(os.path.join(jdir, fn), encoding="utf-8") as jf:
                    d = json.load(jf)
                if d.get("equipo_local") and d.get("equipo_visitante"):
                    actas.append(d)
            except:
                pass
    return actas


def _tc_buscar_acta(actas, eq_local, eq_visit, temporada, categoria=None):
    """
    Busca el partido (eq_local vs eq_visit) en la temporada dada.
    Usa comparación normalizada con tolerancia parcial.
    Si se proporciona categoria, filtra también por ella para evitar confundir
    partidos de equipos con el mismo nombre en distintas ligas.
    Devuelve el acta más coincidente, o None.
    """
    nl = _tc_normalizar(eq_local)
    nv = _tc_normalizar(eq_visit)
    nt = (temporada or "").strip()
    nc = _tc_normalizar(categoria or "")

    candidatos = []
    for a in actas:
        al = _tc_normalizar(a.get("equipo_local", ""))
        av = _tc_normalizar(a.get("equipo_visitante", ""))
        at = (a.get("temporada") or "").strip()
        ac = _tc_normalizar(a.get("categoria") or "")

        if nt and at and nt != at:
            continue

        # Filtrar por categoría si se proporcionó: debe coincidir parcialmente
        if nc and ac:
            # Coincidencia parcial: al menos los primeros 15 chars del nombre de categoría
            cat_match = (nc in ac or ac in nc or nc[:15] == ac[:15])
            if not cat_match:
                continue

        # Coincidencia exacta de equipos
        if al == nl and av == nv:
            return a

        # Coincidencia parcial robusta (nombre de tabla puede abreviar)
        match_l = (nl in al or al in nl or nl[:12] == al[:12])
        match_v = (nv in av or av in nv or nv[:12] == av[:12])
        if match_l and match_v:
            candidatos.append(a)

    return candidatos[0] if candidatos else None


def _tc_comparar(tablas, actas):
    """Compara resultados de tablas cruzadas vs actas. Devuelve lista de discrepancias."""
    discrepancias = []
    for tabla in tablas:
        if not tabla:
            continue
        temporada = tabla.get("temporada", "")
        categoria = tabla.get("categoria", "")
        cod_grupo = tabla.get("cod_grupo")

        for clave, resultado_tabla in tabla.get("resultados", {}).items():
            partes = clave.split("|||")
            if len(partes) != 2:
                continue
            eq_local, eq_visit = partes

            acta = _tc_buscar_acta(actas, eq_local, eq_visit, temporada, categoria)

            if acta is None:
                discrepancias.append({
                    "cod_grupo":        cod_grupo,
                    "categoria":        categoria,
                    "temporada":        temporada,
                    "equipo_local":     eq_local,
                    "equipo_visitante": eq_visit,
                    "resultado_tabla":  resultado_tabla,
                    "resultado_acta":   None,
                    "acta_id":          None,
                    "estado":           "sin_acta",
                    "resolucion":       None,
                })
            else:
                resultado_acta = f"{acta.get('goles_local', 0)}-{acta.get('goles_visitante', 0)}"
                # Auto-resolver: si la tabla dice 0-0 y el acta da otro resultado
                # pero no hay ningún goleador registrado → dar razón a la tabla (0-0 real)
                if resultado_tabla != resultado_acta and resultado_tabla == "0-0":
                    goles_acta = [g for g in (acta.get("goleadores") or [])
                                  if g.get("equipo") in ("local", "visitante")]
                    if not goles_acta:
                        # Sin goleadores → el acta no puede justificar su marcador; tabla gana
                        continue   # no añadir discrepancia
                if resultado_tabla != resultado_acta:
                    # Recopilar jugadores de ambos equipos (titulares + suplentes)
                    # Algunos campos pueden ser strings en lugar de dicts; proteger contra eso
                    def _nombres(lista):
                        out = set()
                        for j in (lista or []):
                            if isinstance(j, dict):
                                n = j.get("nombre","")
                            elif isinstance(j, str):
                                n = j
                            else:
                                n = ""
                            if n:
                                out.add(n)
                        return sorted(out)
                    jugadores_local = _nombres(
                        acta.get("titulares_local",[]) + acta.get("suplentes_local",[])
                    )
                    jugadores_visit = _nombres(
                        acta.get("titulares_visitante",[]) + acta.get("suplentes_visitante",[])
                    )
                    discrepancias.append({
                        "cod_grupo":           cod_grupo,
                        "categoria":           categoria,
                        "temporada":           temporada,
                        "equipo_local":        eq_local,
                        "equipo_visitante":    eq_visit,
                        "resultado_tabla":     resultado_tabla,
                        "resultado_acta":      resultado_acta,
                        "acta_id":             acta.get("acta_id", ""),
                        "estado":              "discrepancia",
                        "resolucion":          None,
                        "goleadores_acta":     acta.get("goleadores", []),
                        "jugadores_local":     sorted(jugadores_local),
                        "jugadores_visitante": sorted(jugadores_visit),
                        "jornada":             acta.get("jornada"),
                        "fecha":               acta.get("fecha", ""),
                    })

    return discrepancias


def _tc_guardar_tablas(tablas):
    """Guarda las tablas cruzadas en disco haciendo MERGE con las ya existentes.
    Las tablas recien descargadas (por cod_grupo) reemplazan a las antiguas del
    mismo grupo; el resto de grupos anteriores se conserva intacto."""
    os.makedirs(os.path.dirname(TABLAS_CRUZADAS_FILE), exist_ok=True)
    existentes = []
    try:
        with open(TABLAS_CRUZADAS_FILE, encoding="utf-8") as f:
            existentes = json.load(f)
    except:
        pass
    grupos_nuevos = {t["cod_grupo"] for t in tablas if t.get("cod_grupo")}
    merged = [t for t in existentes if t.get("cod_grupo") not in grupos_nuevos]
    merged.extend(tablas)
    with open(TABLAS_CRUZADAS_FILE, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)


def _tc_guardar_discrepancias(tablas, disc_previas):
    """
    Compara las tablas contra las actas en disco, preserva resoluciones previas
    y guarda el JSON de discrepancias haciendo MERGE con las ya existentes.
    Las discrepancias de las ligas recien analizadas se recalculan; las del resto
    de ligas se conservan intactas (incluyendo sus resoluciones).
    Devuelve la lista COMPLETA de discrepancias tras el merge.
    """
    actas = _tc_cargar_actas_todos()
    print(f"[*] Comparando {sum(len(t.get('resultados',{})) for t in tablas)} resultados "
          f"contra {len(actas)} actas...")

    nuevas = _tc_comparar(tablas, actas)
    # Aplicar resoluciones previas a las discrepancias recien calculadas
    for d in nuevas:
        key = f"{d['cod_grupo']}|||{d['equipo_local']}|||{d['equipo_visitante']}"
        if key in disc_previas:
            d["resolucion"] = disc_previas[key]

    # ── MERGE: conservar discrepancias de ligas NO analizadas ahora ──────────
    # Las ligas analizadas en esta ejecucion se identifican por cod_grupo
    grupos_analizados = {t["cod_grupo"] for t in tablas if t.get("cod_grupo")}
    disc_antiguas = []
    try:
        with open(DISCREPANCIAS_FILE, encoding="utf-8") as f:
            disc_antiguas = json.load(f)
    except:
        pass
    # Conservar las que son de grupos distintos a los que acabamos de analizar
    conservadas = [d for d in disc_antiguas if d.get("cod_grupo") not in grupos_analizados]
    merged = conservadas + nuevas

    os.makedirs(os.path.dirname(DISCREPANCIAS_FILE), exist_ok=True)
    with open(DISCREPANCIAS_FILE, "w", encoding="utf-8") as f:
        json.dump(merged, f, ensure_ascii=False, indent=2)

    if conservadas:
        print(f"[~] Conservadas {len(conservadas)} discrepancias de ligas anteriores")

    return merged


def _reanalizar_tablas_cruzadas_conocidas(usar_log6=False):
    """Re-analiza TODAS las tablas cruzadas ya descargadas (sin pedir nada nuevo
    a la web) y recalcula discrepancias actas-vs-tablas, preservando resoluciones
    previas. Es exactamente la lógica del Modo 3.1, extraída aquí para que
    también pueda invocarla el Modo 6 sub-modo 2 al terminar su rastreo.

    Como solo lee TABLAS_CRUZADAS_FILE / DISCREPANCIAS_FILE y las actas que ya
    están en disco, no hace ninguna petición de red: no necesita ni respeta
    pausas anti-bloqueo, da igual qué modo la llame.

    usar_log6=True hace que los mensajes salgan con el formato de log con hora
    (log6) que usa el resto del Modo 6, para que se vea como una fase más del
    mismo proceso en vez de un bloque aparte.

    Devuelve un dict con el resumen (o None si no había tablas que re-analizar).
    """
    out = log6 if usar_log6 else print

    grupos_conocidos = set()
    try:
        with open(TABLAS_CRUZADAS_FILE, encoding="utf-8") as f:
            tc_existentes = json.load(f)
        grupos_conocidos = {t["cod_grupo"] for t in tc_existentes if t.get("cod_grupo")}
    except Exception:
        pass

    if not grupos_conocidos:
        out("[~] No hay tablas cruzadas previas que re-analizar. Ejecuta Modo 12 primero.")
        return None

    out(f"[*] Re-analizando {len(grupos_conocidos)} tablas cruzadas conocidas "
        f"({sorted(grupos_conocidos)})...")

    # Cargar resoluciones previas de TODOS los grupos conocidos
    disc_previas = {}
    try:
        with open(DISCREPANCIAS_FILE, encoding="utf-8") as f:
            prev = json.load(f)
        for d in prev:
            if d.get("resolucion"):
                key = f"{d['cod_grupo']}|||{d['equipo_local']}|||{d['equipo_visitante']}"
                disc_previas[key] = d["resolucion"]
        if disc_previas:
            out(f"[~] {len(disc_previas)} resoluciones previas preservadas")
    except Exception:
        pass

    # Usar las tablas ya descargadas (sin re-descargar de la web)
    try:
        with open(TABLAS_CRUZADAS_FILE, encoding="utf-8") as f:
            tablas = json.load(f)
        nuevas  = _tc_guardar_discrepancias(tablas, disc_previas)
        n_disc  = len([d for d in nuevas if d["estado"] == "discrepancia"])
        n_sin   = len([d for d in nuevas if d["estado"] == "sin_acta"])
        n_res   = len([d for d in nuevas if d.get("resolucion")])
        out(f"[+] Discrepancias actualizadas : {n_disc}")
        out(f"[+] Sin acta en disco          : {n_sin}")
        out(f"[+] Ya resueltas               : {n_res}")
        out(f"[+] Pendientes                 : {n_disc - n_res}")
        return {"discrepancias": n_disc, "sin_acta": n_sin, "resueltas": n_res,
                "pendientes": n_disc - n_res}
    except Exception as e:
        out(f"[!] Error re-analizando tablas: {e}")
        return None


# ═══════════════════════════════════════════════════════════════
#  DETECCIÓN DE PROPIAS PUERTA DESDE HTML (no desde TXT)
#
#  El TXT no captura los iconos de imagen (balón rojo) que marcan
#  "G. Propia Puerta" en la web. Esta función analiza el HTML
#  directamente para detectar qué goles son en propia puerta,
#  buscando los atributos title/alt/src en los iconos de gol.
# ═══════════════════════════════════════════════════════════════
_PROPIA_TITULOS = {
    "g. propia puerta", "bere atean", "propia puerta", "own goal",
    "gol en propia", "g.propia puerta",
}

def _buscar_minuto_cercano(nodo):
    """
    Dado un nodo BeautifulSoup, busca un patrón de minuto (NN') en:
      - el texto completo del nodo y sus ancestros (subiendo hasta 8 niveles)
      - los nodos hermanos (prev/next siblings) del nodo y sus ancestros
    Retorna int o None.
    """
    pat = re.compile(r"\((\d{1,3})['+\d]*\)")

    def _extraer(texto):
        m = pat.search(texto or "")
        return int(m.group(1)) if m else None

    # 1. Subir por el árbol de padres
    cur = nodo
    for _ in range(8):
        if cur is None:
            break
        min_val = _extraer(cur.get_text(" ", strip=True))
        if min_val is not None:
            return min_val
        # También mirar hermanos del nodo actual antes de subir
        for sib in list(cur.previous_siblings) + list(cur.next_siblings):
            if hasattr(sib, "get_text"):
                min_val = _extraer(sib.get_text(" ", strip=True))
                if min_val is not None:
                    return min_val
        cur = cur.parent

    return None


def _extraer_propias_desde_html(page_source):
    """
    Analiza el HTML del acta y devuelve una lista de dicts {"minuto": int|None}
    con cada gol en propia puerta detectado.

    Estrategia multi-capa (funciona aunque no haya texto "G. Propia Puerta"):
      1. <img> con title/alt/src que indique propia (balón rojo, balonRojo, propia…)
      2. Cualquier tag con atributo title/data-tipo/class que contenga "propia"
      3. Texto literal "G. Propia Puerta" / "Bere Atean" en nodos del DOM
      4. Estructura de fila de goles: busca filas que contengan el patrón de gol
         y donde el icono sea de tipo propia comparando colores CSS o clases "rojo/red"
    """
    try:
        soup = BeautifulSoup(page_source, "html.parser")
    except Exception:
        return []

    propias_detectadas = []
    vistos = set()   # evitar duplicados por minuto

    def _add(minuto):
        key = minuto if minuto is not None else f"_none_{len(propias_detectadas)}"
        if key not in vistos:
            vistos.add(key)
            propias_detectadas.append({"minuto": minuto})

    # ── Capa 1: <img> con title/alt/src que sugiera propia ───────────────────
    for img in soup.find_all("img"):
        title = (img.get("title") or img.get("alt") or "").strip().lower()
        src   = (img.get("src") or "").lower()
        es_propia = (
            any(p in title for p in _PROPIA_TITULOS)
            or "propia" in src
            or "bere_atean" in src.replace("-","_")
            or "balonrojo" in src.replace("-","_").replace(" ","")
            or "red_ball"  in src
            or "own"       in src
            or ("rojo" in src and "gol" in src)
            or ("red"  in src and "goal" in src)
        )
        if es_propia:
            _add(_buscar_minuto_cercano(img))

    if propias_detectadas:
        return propias_detectadas

    # ── Capa 2: cualquier tag con title/data-tipo/class que contenga "propia" ─
    for tag in soup.find_all(True):
        title = (tag.get("title") or tag.get("data-tipo") or "").strip().lower()
        cls   = " ".join(tag.get("class") or []).lower()
        style = (tag.get("style") or "").lower()
        es_propia = (
            any(p in title for p in _PROPIA_TITULOS)
            or "propia" in cls
            or "bere_atean" in cls.replace("-","_")
        )
        if es_propia:
            _add(_buscar_minuto_cercano(tag))

    if propias_detectadas:
        return propias_detectadas

    # ── Capa 3: texto literal en nodos ───────────────────────────────────────
    _PROPIA_TEXTOS = {"G. Propia Puerta", "Bere Atean", "G.Propia Puerta",
                      "G. Propia puerta", "g. propia puerta"}
    for txt_nodo in soup.find_all(string=True):
        if txt_nodo.strip() in _PROPIA_TEXTOS:
            _add(_buscar_minuto_cercano(txt_nodo.parent if txt_nodo.parent else txt_nodo))

    return propias_detectadas


def _aplicar_propias_html(jd, propias_html, gl_t, gv_t):
    """
    Dado el JSON del acta (jd) y la lista de propias detectadas desde HTML,
    marca los goles correctos como propia=True y actualiza goles_local/visitante/resultado.

    Lógica:
      - Empareja por minuto cuando es posible.
      - Si no hay minutos (None), y el nº de propias detectadas == nº de goles sin marcar
        como propia cuyo jugador está en el equipo contrario → marcarlos.
      - Si tampoco hay candidatos cruzados y hay exactamente 1 propia detectada y
        1 gol sin marcar → marcar ese (último recurso).
      - Tras marcar, recalcula goles_local/visitante sumando los marcadores parciales
        (campo "equipo" de cada goleador) y verifica que cuadran con gl_t/gv_t.
      - Si no cuadran, intenta corregir el campo "equipo" del gol PP:
        un gol en propia se anota al equipo BENEFICIADO (el contrario al jugador),
        así que si equipo=="local" pero el jugador es local → debería ser "visitante".

    Retorna True si se pudo aplicar y el marcador final cuadra con la tabla.
    """
    goleadores = jd.get("goleadores", [])
    if not goleadores or not propias_html:
        return False

    jug_local = set(jd.get("jugadores_local", []))
    jug_visit = set(jd.get("jugadores_visitante", []))

    # ── Paso 1: emparejar por minuto ─────────────────────────────────────────
    minutos_propia = {p["minuto"] for p in propias_html if p["minuto"] is not None}
    cambios = 0
    if minutos_propia:
        for g in goleadores:
            if g.get("propia"):
                continue
            if g.get("minuto") in minutos_propia:
                g["propia"] = True
                cambios += 1

    # ── Paso 2: sin minutos → emparejar por equipo cruzado ───────────────────
    if cambios == 0:
        n_pp = len(propias_html)
        sin_propia = [g for g in goleadores if not g.get("propia")]
        # Candidatos: jugador del equipo contrario al marcador
        cruzados = [g for g in sin_propia
                    if (g.get("equipo") == "local"      and g.get("jugador","") in jug_visit)
                    or (g.get("equipo") == "visitante"  and g.get("jugador","") in jug_local)]
        if len(cruzados) == n_pp:
            for g in cruzados:
                g["propia"] = True
                cambios += 1
        elif n_pp == 1 and len(sin_propia) >= 1:
            # Último recurso: si hay exactamente 1 propia detectada y candidatos cruzados
            # exactos no coinciden en número, marcar el primero cruzado o el primero sin propia
            target = cruzados[0] if cruzados else sin_propia[0]
            target["propia"] = True
            cambios += 1

    if cambios == 0:
        return False

    # ── Paso 3: corregir campo "equipo" de los goles PP si está invertido ────
    # Un gol en propia beneficia al equipo CONTRARIO al jugador.
    # El campo "equipo" debe ser el equipo BENEFICIADO.
    for g in goleadores:
        if not g.get("propia"):
            continue
        jug = g.get("jugador", "")
        eq  = g.get("equipo", "")
        # Si el jugador es local pero el gol figura como "local" → el beneficiado es visitante
        if jug in jug_local and eq == "local":
            g["equipo"] = "visitante"
        # Si el jugador es visitante pero el gol figura como "visitante" → beneficiado es local
        elif jug in jug_visit and eq == "visitante":
            g["equipo"] = "local"

    # ── Paso 4: recontar y verificar ─────────────────────────────────────────
    gl_sim = sum(1 for g in goleadores if g.get("equipo") == "local")
    gv_sim = sum(1 for g in goleadores if g.get("equipo") == "visitante")

    if gl_sim != gl_t or gv_sim != gv_t:
        return False

    # ── Paso 5: actualizar JSON ───────────────────────────────────────────────
    jd["goles_local"]     = gl_t
    jd["goles_visitante"] = gv_t
    jd["resultado"] = "W" if gl_t > gv_t else ("L" if gl_t < gv_t else "D")
    return True


# ═══════════════════════════════════════════════════════════════
#  RESOLVER DISCREPANCIAS POR GOLES EN PROPIA PUERTA (Modo 3)
#
#  Condición para auto-resolver:
#    • Discrepancia sin resolución previa
#    • Total goles tabla == total goles acta  (misma cantidad de goles)
#    • Nº goleadores en acta == total goles tabla  (un goleador por gol)
#    • Exactamente UN jugador que figure en el equipo contrario al que
#      se le anotó el gol → ese gol es propia puerta
#  Si la lógica por TXT no resuelve:
#    • Re-cargar el acta con Selenium y analizar el HTML directamente
#      buscando iconos/imágenes de "G. Propia Puerta" (balón rojo)
#  Acción:
#    • Marcar ese gol como propia:true en el JSON del acta
#    • Recalcular goles_local / goles_visitante
#    • Guardar JSON
#    • Marcar discrepancia como resuelta con "tabla" (ambos resultados coinciden)
# ═══════════════════════════════════════════════════════════════
def resolver_discrepancias_pp(solo_txt=False):
    """
    Revisa discrepancias pendientes y auto-resuelve las que cuadran con un gol en PP.

    Dos pasadas:
      1ª — Lógica por TXT: si el jugador pertenece al equipo contrario al que figura el gol.
      2ª — Fallback HTML: para los casos donde el TXT no detectó el balón rojo (icono de
           propia puerta), re-carga la página con Selenium y analiza el HTML directamente
           buscando imágenes/iconos con title/alt "G. Propia Puerta" o equivalente.

    Si solo_txt=True, se omite la 2ª pasada HTML (sin Chrome). Usar en Modo 3;
    para la pasada completa con Chrome usar Modo 3.1.
    """
    if not os.path.exists(DISCREPANCIAS_FILE):
        print("[~] Sin archivo de discrepancias, nada que revisar.")
        return

    try:
        with open(DISCREPANCIAS_FILE, encoding="utf-8") as f:
            disc_list = json.load(f)
    except Exception as e:
        print(f"[!] No se pudo leer discrepancias: {e}")
        return

    pendientes = [d for d in disc_list
                  if d.get("estado") == "discrepancia" and not d.get("resolucion")]
    if not pendientes:
        print("[~] No hay discrepancias pendientes de resolver.")
        return

    print(f"[*] Revisando {len(pendientes)} discrepancias pendientes para auto-resolver PP...")
    resueltas = errores = 0

    # Candidatas para 2ª pasada HTML (mismos goles totales, no resueltas por TXT)
    pendientes_html = []

    # ── 1ª PASADA: lógica por TXT / mapa de equipos ──────────────────────────
    for d in pendientes:
        res_tabla = d.get("resultado_tabla", "")
        res_acta  = d.get("resultado_acta", "")
        acta_id   = d.get("acta_id", "")

        if not acta_id or not res_tabla or not res_acta:
            continue

        # Parsear resultados
        try:
            gl_t, gv_t = map(int, res_tabla.split("-"))
            gl_a, gv_a = map(int, res_acta.split("-"))
        except Exception:
            continue

        total_tabla = gl_t + gv_t
        total_acta  = gl_a + gv_a

        # Condición 1: misma cantidad total de goles
        if total_tabla != total_acta:
            continue

        # Localizar el JSON del acta y la fuente
        json_path = None
        fuente_cfg_d = None
        fuente_key_d = None
        for fk, fcfg in FUENTES.items():
            jp = os.path.join(fcfg["json_dir"], f"{acta_id}.json")
            if os.path.exists(jp):
                json_path = jp
                fuente_cfg_d = fcfg
                fuente_key_d = fk
                break
        if not json_path:
            continue

        try:
            with open(json_path, encoding="utf-8") as jf:
                jd = json.load(jf)
        except Exception:
            continue

        goleadores = jd.get("goleadores", [])

        # Condición 2: nº goleadores == total goles de tabla (un goleador por gol)
        # NOTA: si no coinciden, puede ser que el parser contó mal por no detectar la propia.
        # En ese caso encolar para 2ª pasada HTML en lugar de descartar.
        if len(goleadores) != total_tabla:
            pendientes_html.append({
                "d": d, "jd": jd, "json_path": json_path,
                "gl_t": gl_t, "gv_t": gv_t,
                "res_tabla": res_tabla, "res_acta": res_acta,
                "acta_id": acta_id,
                "fuente_cfg": fuente_cfg_d, "fuente_key": fuente_key_d,
            })
            continue

        jugadores_locales    = set(jd.get("jugadores_local", []))
        jugadores_visitantes = set(jd.get("jugadores_visitante", []))

        # Buscar exactamente 1 gol donde el jugador está en el equipo contrario
        candidatos_pp = []
        for g in goleadores:
            jug    = g.get("jugador", "")
            eq_gol = g.get("equipo", "")
            if eq_gol == "local"      and jug in jugadores_visitantes:
                candidatos_pp.append(g)
            elif eq_gol == "visitante" and jug in jugadores_locales:
                candidatos_pp.append(g)
            elif g.get("propia") and not (
                (eq_gol == "local"      and jug in jugadores_locales) or
                (eq_gol == "visitante"  and jug in jugadores_visitantes)
            ):
                candidatos_pp.append(g)

        if len(candidatos_pp) != 1:
            # No resuelto por TXT → encolar para 2ª pasada HTML
            pendientes_html.append({
                "d": d, "jd": jd, "json_path": json_path,
                "gl_t": gl_t, "gv_t": gv_t,
                "res_tabla": res_tabla, "res_acta": res_acta,
                "acta_id": acta_id,
                "fuente_cfg": fuente_cfg_d, "fuente_key": fuente_key_d,
            })
            continue

        # Comprobar que el marcador cuadra con la tabla
        gl_sim = sum(1 for g in goleadores if g.get("equipo") == "local")
        gv_sim = sum(1 for g in goleadores if g.get("equipo") == "visitante")
        if gl_sim != gl_t or gv_sim != gv_t:
            pendientes_html.append({
                "d": d, "jd": jd, "json_path": json_path,
                "gl_t": gl_t, "gv_t": gv_t,
                "res_tabla": res_tabla, "res_acta": res_acta,
                "acta_id": acta_id,
                "fuente_cfg": fuente_cfg_d, "fuente_key": fuente_key_d,
            })
            continue

        # ── Todo cuadra por TXT: marcar propia y guardar ─────────────────────
        gol_pp = candidatos_pp[0]
        gol_pp["propia"] = True
        jd["goles_local"]     = gl_t
        jd["goles_visitante"] = gv_t
        jd["resultado"] = "W" if gl_t > gv_t else ("L" if gl_t < gv_t else "D")

        try:
            with open(json_path, "w", encoding="utf-8") as jf:
                json.dump(jd, jf, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"  [!] No se pudo guardar {json_path}: {e}")
            errores += 1
            continue

        d["resolucion"] = f"tabla:{res_tabla} (PP auto)"
        eq_l = d.get("equipo_local", "")
        eq_v = d.get("equipo_visitante", "")
        print(f"  [✓] PP auto-resuelta (TXT): {eq_l} vs {eq_v}  "
              f"(acta:{res_acta}→{res_tabla})  "
              f"PP={gol_pp.get('jugador','')} ({gol_pp.get('equipo','')})")
        resueltas += 1

    # ── 2ª PASADA: fallback HTML para los que el TXT no resolvió ─────────────
    if solo_txt and pendientes_html:
        print(f"[~] {len(pendientes_html)} discrepancias no resueltas por TXT — "
              f"omitiendo pasada HTML (usa Modo 3.1 para la detección completa con Chrome).")
        pendientes_html = []

    if pendientes_html:
        print(f"\n[*] 2ª pasada HTML: {len(pendientes_html)} discrepancias sin resolver "
              f"por TXT — re-cargando actas para detectar balón rojo (G. Propia Puerta)...")
        pp_driver = None
        try:
            pp_driver = crear_nav(0)
            calentar(pp_driver, FUENTES["alava"])

            for item in pendientes_html:
                d          = item["d"]
                jd         = item["jd"]
                json_path  = item["json_path"]
                gl_t       = item["gl_t"]
                gv_t       = item["gv_t"]
                res_tabla  = item["res_tabla"]
                res_acta   = item["res_acta"]
                acta_id    = item["acta_id"]
                fcfg       = item["fuente_cfg"]
                fk         = item["fuente_key"]

                if fcfg is None:
                    continue

                prefix = fcfg["prefix"]
                try:
                    cod = int(str(acta_id).replace(prefix, ""))
                except ValueError:
                    continue

                eq_l = d.get("equipo_local", "")
                eq_v = d.get("equipo_visitante", "")
                print(f"  [↓] HTML Acta {acta_id}  {eq_l} vs {eq_v}  "
                      f"(tabla:{res_tabla} | acta:{res_acta})...", end=" ", flush=True)

                # Cargar la página con Selenium
                url = (f"{fcfg['base_url']}?cod_primaria={fcfg['cod_primaria']}"
                       f"&CodActa={cod}")
                try:
                    pp_driver.get(url)
                    WebDriverWait(pp_driver, PAGE_TIMEOUT).until(
                        lambda drv: drv.execute_script("return document.readyState") == "complete"
                                    and len(drv.page_source) > 300)
                    time.sleep(random.uniform(0.5, 1.0))
                    page_src = pp_driver.page_source
                except Exception as e_nav:
                    print(f"error navegación: {e_nav}")
                    errores += 1
                    continue

                # Analizar HTML para detectar propias
                propias_html = _extraer_propias_desde_html(page_src)
                if not propias_html:
                    print(f"sin propias detectadas en HTML")
                    continue

                print(f"{len(propias_html)} PP detectadas en HTML...", end=" ", flush=True)

                # Aplicar propias al JSON y verificar que el marcador cuadra
                # Re-leer el JSON por si fue modificado en la 1ª pasada
                try:
                    with open(json_path, encoding="utf-8") as jf:
                        jd_fresco = json.load(jf)
                except Exception:
                    jd_fresco = jd

                if _aplicar_propias_html(jd_fresco, propias_html, gl_t, gv_t):
                    try:
                        with open(json_path, "w", encoding="utf-8") as jf:
                            json.dump(jd_fresco, jf, indent=2, ensure_ascii=False)
                        d["resolucion"] = f"tabla:{res_tabla} (PP auto HTML)"
                        print(f"✓ CORREGIDO")
                        resueltas += 1
                    except Exception as e_save:
                        print(f"error guardado: {e_save}")
                        errores += 1
                else:
                    print(f"no cuadra marcador tras aplicar PP")

        except Exception as e_pp:
            print(f"\n[!] Error en 2ª pasada HTML: {e_pp}")
        finally:
            if pp_driver:
                try:
                    cerrar(pp_driver)
                except Exception:
                    pass

    print(f"\n[+] PP auto-resueltas: {resueltas} | Errores: {errores} "
          f"| Siguen pendientes: {len(pendientes) - resueltas}\n")

    if resueltas:
        # Guardar discrepancias actualizadas
        try:
            with open(DISCREPANCIAS_FILE, "w", encoding="utf-8") as f:
                json.dump(disc_list, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"[!] No se pudo guardar discrepancias: {e}")
        # Regenerar HTML para reflejar los cambios en los JSONs
        print("[*] Regenerando HTML tras correcciones PP...")
        try:
            generar_html()
        except Exception as e_html:
            print(f"[!] Error regenerando HTML: {e_html}")


def modo12_tablas_cruzadas():
    """Modo 12: descarga tablas cruzadas, compara con actas, guarda discrepancias y regenera HTML."""
    print()
    while True:
        val = input("  CodGrupo más reciente (ej: 2191): ").strip()
        if val.isdigit() and int(val) > 0:
            cod_max = int(val)
            break
        print("  Valor inválido. Introduce un entero positivo.")

    # ── Solo el CodGrupo indicado ─────────────────────────────────────────
    grupos = [cod_max]

    # Rutas de salida
    print()
    print("=" * 72)
    print(f"  Modo 12 — Tablas cruzadas")
    print(f"  Grupo a descargar  : {cod_max} (1 grupo)")
    print(f"  Tablas JSON        : {TABLAS_CRUZADAS_FILE}")
    print(f"  Discrepancias JSON : {DISCREPANCIAS_FILE}")
    print(f"  HTML               : {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    print("=" * 72 + "\n")

    # Cargar resoluciones previas del grupo que vamos a re-analizar
    # (las de otros grupos se conservan automaticamente por el merge en _tc_guardar_discrepancias)
    disc_previas = {}
    try:
        with open(DISCREPANCIAS_FILE, encoding="utf-8") as f:
            prev = json.load(f)
        for d in prev:
            if d.get("resolucion") and d.get("cod_grupo") == cod_max:
                key = f"{d['cod_grupo']}|||{d['equipo_local']}|||{d['equipo_visitante']}"
                disc_previas[key] = d["resolucion"]
        if disc_previas:
            print(f"[~] {len(disc_previas)} resoluciones previas del grupo {cod_max} preservadas\n")
    except:
        pass

    fuente_cfg = FUENTES["alava"]
    ua_idx = 0
    driver = crear_nav(ua_idx)
    calentar(driver, fuente_cfg)

    tablas = []
    ok = skip = 0
    GUARDAR_CADA = 5   # guardar cada N descargas OK
    fallos_consec = racha_bloqueo = 0
    abortado_bloqueo = False

    try:
        for idx, cg in enumerate(grupos, 1):
            if idx > 1 and (idx - 1) % REINICIAR_CADA_SUAVE == 0:
                print(f"\n  [~] Reiniciando Chrome (cada {REINICIAR_CADA_SUAVE})...")
                cerrar(driver); ua_idx += 1
                time.sleep(random.uniform(3, 6))
                driver = crear_nav(ua_idx); calentar(driver, fuente_cfg)

            _delay_humano()
            print(f"  [{idx:>2}/{len(grupos)}] CodGrupo {cg}...", end=" ", flush=True)
            html = _tc_descargar(driver, cg)
            if html is None:
                print("sin datos")
                skip += 1
                fallos_consec += 1
                if fallos_consec >= FALLOS_PAUSA:
                    racha_bloqueo += 1
                    p = _pausa_escalada(racha_bloqueo)
                    print(f"  [!] {fallos_consec} fallos seguidos — racha de bloqueo nº{racha_bloqueo} "
                          f"— pausa {p}s + nueva sesion")
                    if racha_bloqueo > RACHAS_MAX_BLOQUEO:
                        print(f"\n  [X] {racha_bloqueo} rachas de bloqueo seguidas: la IP parece "
                              f"marcada por el servidor. Se detiene la descarga para no agravarlo.")
                        print(f"      Prueba de nuevo más tarde (30-60 min) o, si persiste, "
                              f"cambia de red (otro WiFi/4G/VPN).\n")
                        abortado_bloqueo = True
                        break
                    cerrar(driver); ua_idx += 1; time.sleep(p)
                    driver = crear_nav(ua_idx); calentar(driver, fuente_cfg)
                    fallos_consec = 0
                continue
            tabla = _tc_parsear_tabla(html, cg)
            if tabla is None or not tabla.get("resultados"):
                print("sin resultados válidos")
                skip += 1
                fallos_consec = 0
                continue
            tablas.append(tabla)
            ok += 1
            fallos_consec = 0
            racha_bloqueo = 0
            n_res = len(tabla['resultados'])
            print(f"OK — {tabla['categoria'][:48]} ({n_res} resultados)")

            # ── Guardado intermedio cada GUARDAR_CADA tablas OK ─────────────
            if ok % GUARDAR_CADA == 0:
                _tc_guardar_tablas(tablas)
                nuevas = _tc_guardar_discrepancias(tablas, disc_previas)
                nd = len([d for d in nuevas if d["estado"] == "discrepancia"])
                ns = len([d for d in nuevas if d["estado"] == "sin_acta"])
                print(f"  [~] Guardado intermedio: {ok} tablas OK | "
                      f"{nd} discrepancias | {ns} sin acta\n")

    finally:
        cerrar(driver)

    etiqueta12 = "interrumpida por bloqueo" if abortado_bloqueo else "Descarga finalizada"
    print(f"\n[+] {etiqueta12}: {ok} OK | {skip} sin datos\n")

    if not tablas:
        print("[!] No se descargó ninguna tabla válida. Abortando.")
        return

    # ── Guardado final ─────────────────────────────────────────────────────
    print("[*] Guardado final de tablas...")
    _tc_guardar_tablas(tablas)
    print(f"[+] {len(tablas)} tablas → {TABLAS_CRUZADAS_FILE}")

    print("[*] Comprobación final completa...")
    nuevas = _tc_guardar_discrepancias(tablas, disc_previas)

    n_disc = len([d for d in nuevas if d["estado"] == "discrepancia"])
    n_sin  = len([d for d in nuevas if d["estado"] == "sin_acta"])
    n_res  = len([d for d in nuevas if d.get("resolucion")])
    print(f"[+] Total discrepancias : {n_disc}")
    print(f"[+] Sin acta en disco   : {n_sin}")
    print(f"[+] Ya resueltas        : {n_res}")
    print(f"[+] Pendientes de revisar: {n_disc - n_res}")
    print(f"[+] Guardado en         → {DISCREPANCIAS_FILE}\n")

    # ── RE-DESCARGA DE ACTAS CON DISCREPANCIA ──────────────────────────────
    # Solo se re-descargan las discrepancias de la(s) categoría(s) + temporada(s)
    # que se acaban de analizar en ESTE run (p.ej. "CADETE DE HONOR" 2025-2026).
    # Las discrepancias conservadas de OTRAS ligas/temporadas (arrastradas de
    # ejecuciones anteriores del Modo 12) se quedan guardadas en el JSON para
    # la pestaña Config > Discrepancias, pero NO se tocan aquí: así no se gastan
    # peticiones de más ni se arriesga un bloqueo re-descargando actas de ligas
    # que no has pedido analizar en este run.
    _cats_analizadas_ahora = {
        (_tc_normalizar(t.get("categoria", "")), (t.get("temporada") or "").strip())
        for t in tablas if t
    }

    def _es_de_liga_analizada(d):
        return (_tc_normalizar(d.get("categoria", "")),
                (d.get("temporada") or "").strip()) in _cats_analizadas_ahora

    disc_list_todas       = [d for d in nuevas if d["estado"] == "discrepancia"]
    disc_list             = [d for d in disc_list_todas if _es_de_liga_analizada(d)]
    n_omitidas_otras_ligas = len(disc_list_todas) - len(disc_list)

    LOTE = 5
    if disc_list:
        print()
        print("=" * 72)
        print(f"  Re-descargando {len(disc_list)} actas con discrepancia de esta liga "
              f"(de {LOTE} en {LOTE}, con pausas anti-bloqueo)...")
        if n_omitidas_otras_ligas:
            print(f"  ({n_omitidas_otras_ligas} discrepancias de otras ligas/temporadas se "
                  f"conservan en el JSON pero no se re-descargan en este run)")
        print("=" * 72 + "\n")

        # Detectar fuente de cada acta por su acta_id (prefijo)
        def _fuente_de_id(aid):
            if not aid:
                return None
            for fk, fcfg in FUENTES.items():
                px = fcfg["prefix"]
                if px == "" and not any(aid.startswith(f["prefix"]) for f in FUENTES.values() if f["prefix"]):
                    return fk, fcfg
                if px and str(aid).startswith(px):
                    return fk, fcfg
            return "alava", FUENTES["alava"]   # fallback

        disc_driver = crear_nav(0)
        calentar(disc_driver, FUENTES["alava"])
        corregidas = sin_cambio = fallidas = 0
        actas_ses = fallos_consec = racha_bloqueo = disc_ua_idx = 0
        abortado_bloqueo_tc = False

        def _reiniciar_disc(motivo):
            nonlocal disc_driver, actas_ses, disc_ua_idx
            print(f"\n  [~] Reiniciando Chrome ({motivo})...")
            cerrar(disc_driver)
            time.sleep(random.uniform(3, 6))
            disc_ua_idx += 1
            disc_driver = crear_nav(disc_ua_idx)
            calentar(disc_driver, FUENTES["alava"])
            actas_ses = 0

        try:
            for lote_ini in range(0, len(disc_list), LOTE):
                if abortado_bloqueo_tc:
                    break
                lote = disc_list[lote_ini:lote_ini + LOTE]
                print(f"  ── Lote {lote_ini//LOTE + 1} "
                      f"({lote_ini+1}–{lote_ini+len(lote)} de {len(disc_list)}) ──")

                for d in lote:
                    aid    = d.get("acta_id", "")
                    eq_l   = d["equipo_local"]
                    eq_v   = d["equipo_visitante"]
                    res_t  = d["resultado_tabla"]
                    res_a  = d["resultado_acta"]

                    if not aid:
                        print(f"  [!] Sin acta_id: {eq_l} vs {eq_v} — omitido")
                        fallidas += 1
                        continue

                    # Determinar fuente y número de acta
                    fk, fcfg = _fuente_de_id(str(aid))
                    prefix   = fcfg["prefix"]
                    json_dir = fcfg["json_dir"]
                    out_dir  = fcfg["output_dir"]
                    try:
                        cod = int(str(aid).replace(prefix, ""))
                    except ValueError:
                        print(f"  [!] ID no numérico '{aid}' — omitido")
                        fallidas += 1
                        continue

                    # Sesión de Chrome más corta -> fingerprint nuevo más a menudo
                    if actas_ses > 0 and actas_ses % REINICIAR_CADA_SUAVE == 0:
                        _reiniciar_disc(f"cada {REINICIAR_CADA_SUAVE}")

                    # Pausa "humana" ANTES de cada petición (igual que en el resto
                    # de modos anti-bloqueo) para no disparar el detector de scraping
                    _delay_humano()

                    print(f"  [↓] Acta {aid}  {eq_l} vs {eq_v}  "
                          f"(tabla:{res_t} | acta:{res_a})...", end=" ", flush=True)

                    ruta, estado = descargar(disc_driver, cod, aid, len(disc_list), fcfg)
                    actas_ses += 1

                    if estado != "ok":
                        print(f"fallo ({estado})")
                        fallidas += 1
                        fallos_consec += 1
                        reintentado_ok = False

                        if fallos_consec >= FALLOS_PAUSA:
                            racha_bloqueo += 1
                            p = _pausa_escalada(racha_bloqueo)
                            print(f"\n  [!] {fallos_consec} fallos seguidos — racha de bloqueo nº{racha_bloqueo} "
                                  f"— pausa {p}s + nueva sesion")
                            if racha_bloqueo > RACHAS_MAX_BLOQUEO:
                                print(f"\n  [X] {racha_bloqueo} rachas de bloqueo seguidas: la IP parece "
                                      f"marcada por el servidor. Se detiene la re-descarga para no agravarlo.")
                                print(f"      Las discrepancias restantes quedan pendientes; vuelve a "
                                      f"lanzar el Modo 12 más tarde (30-60 min) o cambia de red.\n")
                                abortado_bloqueo_tc = True
                                break
                            _reiniciar_disc("anti-bloqueo")
                            time.sleep(p)
                            fallos_consec = 0
                            _delay_humano()
                            print(f"  [↓] Acta {aid} (reintento)...", end=" ", flush=True)
                            ruta, estado = descargar(disc_driver, cod, aid, len(disc_list), fcfg)
                            actas_ses += 1
                            if estado == "ok":
                                print("OK")
                                fallidas -= 1
                                reintentado_ok = True
                            else:
                                print(f"fallo de nuevo ({estado}), se deja pendiente")

                        if not reintentado_ok:
                            continue
                    else:
                        fallos_consec = 0
                        racha_bloqueo = 0

                    # Re-parsear
                    try:
                        Parser(ruta, json_dir=json_dir, fuente=fk).process()
                    except Exception as pe:
                        print(f"error parseo: {pe}")
                        fallidas += 1
                        continue

                    # Leer nuevo resultado del JSON recién escrito
                    jp = os.path.join(json_dir, f"{aid}.json")
                    try:
                        with open(jp, encoding="utf-8") as jf:
                            jd = json.load(jf)
                        nuevo_res = f"{jd.get('goles_local',0)}-{jd.get('goles_visitante',0)}"

                        # ── Verificar que el acta redescargada corresponde exactamente
                        #    al partido de la discrepancia (categoría + temporada + equipos) ──
                        cat_acta  = _tc_normalizar(jd.get("categoria") or "")
                        cat_tabla = _tc_normalizar(d.get("categoria") or "")
                        temp_acta = (jd.get("temporada") or "").strip()
                        temp_tabla= (d.get("temporada") or "").strip()
                        al_acta   = _tc_normalizar(jd.get("equipo_local") or "")
                        av_acta   = _tc_normalizar(jd.get("equipo_visitante") or "")
                        al_tabla  = _tc_normalizar(d.get("equipo_local") or "")
                        av_tabla  = _tc_normalizar(d.get("equipo_visitante") or "")

                        # Categoría debe coincidir
                        cat_ok = (not cat_tabla or not cat_acta or
                                  cat_tabla in cat_acta or cat_acta in cat_tabla or
                                  cat_tabla[:15] == cat_acta[:15])
                        # Temporada debe coincidir (si ambas están presentes)
                        temp_ok = (not temp_tabla or not temp_acta or temp_tabla == temp_acta)
                        # Equipos deben coincidir (tolerancia parcial igual que _tc_buscar_acta)
                        eq_l_ok = (al_tabla == al_acta or
                                   al_tabla in al_acta or al_acta in al_tabla or
                                   al_tabla[:12] == al_acta[:12])
                        eq_v_ok = (av_tabla == av_acta or
                                   av_tabla in av_acta or av_acta in av_tabla or
                                   av_tabla[:12] == av_acta[:12])

                        if not cat_ok:
                            print(f"⚠ CATEGORÍA INCORRECTA (acta:'{jd.get('categoria','')}' | "
                                  f"esperada:'{d.get('categoria','')}')")
                            fallidas += 1
                            continue
                        if not temp_ok:
                            print(f"⚠ TEMPORADA INCORRECTA (acta:'{temp_acta}' | "
                                  f"esperada:'{temp_tabla}')")
                            fallidas += 1
                            continue
                        if not (eq_l_ok and eq_v_ok):
                            print(f"⚠ EQUIPOS INCORRECTOS (acta:'{jd.get('equipo_local','')} vs "
                                  f"{jd.get('equipo_visitante','')}' | "
                                  f"esperado:'{d.get('equipo_local','')} vs "
                                  f"{d.get('equipo_visitante','')}')")
                            fallidas += 1
                            continue
                    except Exception:
                        nuevo_res = "?"

                    if nuevo_res == res_t:
                        print(f"✓ CORREGIDO  ({res_a} → {nuevo_res})")
                        corregidas += 1
                    else:
                        # ── Fallback HTML: el TXT no corrigió la discrepancia.
                        #    Analizar el HTML de la página ya cargada en disc_driver
                        #    para detectar el balón rojo (G. Propia Puerta).
                        #    Se intenta aunque los totales no coincidan, porque el
                        #    parser pudo contar mal al no detectar la propia.
                        _resuelto_html = False
                        try:
                            gl_t_d, gv_t_d = map(int, res_t.split("-"))
                            # La página sigue cargada en disc_driver desde descargar()
                            _page_src = disc_driver.page_source
                            _propias = _extraer_propias_desde_html(_page_src)
                            if _propias:
                                # Siempre re-leer el JSON fresco desde disco
                                with open(jp, encoding="utf-8") as _jf:
                                    _jd_fresh = json.load(_jf)
                                if _aplicar_propias_html(_jd_fresh, _propias,
                                                         gl_t_d, gv_t_d):
                                    with open(jp, "w", encoding="utf-8") as _jf:
                                        json.dump(_jd_fresh, _jf,
                                                  indent=2, ensure_ascii=False)
                                    print(f"✓ CORREGIDO via HTML  "
                                          f"({res_a} → {res_t})")
                                    corregidas += 1
                                    _resuelto_html = True
                                else:
                                    print(f"~ HTML detectó PP pero marcador no cuadra "
                                          f"(tabla:{res_t})")
                                    sin_cambio += 1
                                    _resuelto_html = True  # evitar doble mensaje
                        except Exception as _e_html:
                            pass  # no crítico

                        if not _resuelto_html:
                            if nuevo_res == res_a:
                                print(f"= sin cambio (sigue {nuevo_res})")
                            else:
                                print(f"~ nuevo resultado: {nuevo_res}  (tabla:{res_t})")
                            sin_cambio += 1

                print()   # línea en blanco entre lotes

                # Pausa real ENTRE LOTES (no solo entre peticiones individuales):
                # esto es lo que más ayuda a no parecer un patrón robótico, ya que
                # rompe la ráfaga de 5 peticiones seguidas con un hueco más largo.
                if not abortado_bloqueo_tc and lote_ini + LOTE < len(disc_list):
                    pausa_lote = random.uniform(*PAUSA_ENTRE_LOTES_TC)
                    print(f"  [⏸] Pausa entre lotes ({pausa_lote:.0f}s)...\n")
                    time.sleep(pausa_lote)

        finally:
            cerrar(disc_driver)

        print(f"[+] Re-descarga: {corregidas} corregidas | "
              f"{sin_cambio} sin cambio | {fallidas} fallidas\n")

        # Recomparar y guardar discrepancias actualizadas
        print("[*] Recomparando tras re-descarga...")
        nuevas = _tc_guardar_discrepancias(tablas, disc_previas)
        n_disc = len([d for d in nuevas if d["estado"] == "discrepancia"])
        n_sin  = len([d for d in nuevas if d["estado"] == "sin_acta"])
        n_res  = len([d for d in nuevas if d.get("resolucion")])
        print(f"[+] Discrepancias tras re-descarga : {n_disc}")
        print(f"[+] Sin acta                       : {n_sin}")
        print(f"[+] Ya resueltas                   : {n_res}\n")

    # ── Regenerar HTML ─────────────────────────────────────────────────────
    print("[*] Regenerando HTML...")
    html_path = generar_html()
    if not html_path:
        html_path = os.path.join(HTML_DIR, "FAF_Stats.html")

    # ── Abrir HTML en el navegador ─────────────────────────────────────────
    print(f"[*] Abriendo HTML en el navegador...")
    try:
        import webbrowser
        webbrowser.open(f"file:///{html_path.replace(os.sep, '/')}")
        print(f"[+] Abierto: {html_path}")
    except Exception as e:
        print(f"[!] No se pudo abrir automáticamente: {e}")
        print(f"    Abre manualmente: {html_path}")

    print()
    print("=" * 72)
    if n_disc - n_res > 0:
        print(f"  ⚠  HAY {n_disc - n_res} DISCREPANCIAS PENDIENTES DE RESOLVER")
        print(f"     Ve a Config > ⚠ Discrepancias en el HTML y elige cuál es el correcto")
    else:
        print(f"  ✓  Sin discrepancias pendientes")
    print("=" * 72)


# ═══════════════════════════════════════════════════════════════
#  MODO 13 — CAMBIAR RUTA DE LA CARPETA F
# ═══════════════════════════════════════════════════════════════
def modo13_cambiar_ruta():
    """
    Pregunta al usuario si la ruta actual de BASE_DIR es correcta.
    Si no, pide la nueva ruta y reescribe este mismo .py cambiando
    únicamente la línea BASE_DIR = r"..." con la nueva ruta.
    """
    print("=" * 72)
    print("  Modo 13 — Cambiar ruta de la carpeta F")
    print("=" * 72)
    print()
    print(f"  Ruta actual de la carpeta F:")
    print(f"  → {BASE_DIR}")
    print()

    while True:
        resp = input("  ¿Es correcta esta ruta? [s/n]: ").strip().lower()
        if resp in ("s", "n"):
            break
        print("  Introduce s (sí) o n (no).")

    if resp == "s":
        print()
        print("  [+] Ruta confirmada. No se ha cambiado nada.")
        print()
        return

    # ── Pedir nueva ruta ──────────────────────────────────────────
    print()
    print("  Introduce la nueva ruta completa de la carpeta F.")
    print("  Ejemplo: C:\\Users\\Nuevo\\Documents\\F")
    print("           D:\\Datos\\FAF\\F")
    print()
    while True:
        nueva = input("  Nueva ruta: ").strip().strip('"').strip("'")
        if not nueva:
            print("  La ruta no puede estar vacía.")
            continue
        # Normalizar separadores para Windows
        nueva = nueva.replace("/", "\\")
        print()
        print(f"  Ruta introducida: {nueva}")
        confirma = input("  ¿Confirmas este cambio? [s/n]: ").strip().lower()
        if confirma == "s":
            break
        print()
        print("  Vuelve a introducir la ruta.")
        print()

    # ── Reescribir este mismo .py ────────────────────────────────
    script_path = os.path.abspath(__file__)
    try:
        with open(script_path, "r", encoding="utf-8") as f:
            contenido = f.read()

        # Sustituir solo la línea BASE_DIR = r"..."
        nuevo_contenido = re.sub(
            r'^BASE_DIR\s*=\s*r?"[^"]*"',
            f'BASE_DIR = r"{nueva}"',
            contenido,
            count=1,
            flags=re.MULTILINE
        )

        if nuevo_contenido == contenido:
            print()
            print("  [!] No se encontró la línea BASE_DIR en el script.")
            print("      Modifica manualmente la línea 42:")
            print(f'      BASE_DIR = r"{nueva}"')
            return

        with open(script_path, "w", encoding="utf-8") as f:
            f.write(nuevo_contenido)

        print()
        print("  [+] ¡Ruta actualizada correctamente!")
        print(f"      Antes : {BASE_DIR}")
        print(f"      Ahora : {nueva}")
        print()
        print("  IMPORTANTE: Vuelve a ejecutar el script para que los")
        print("  cambios surtan efecto. La nueva ruta ya está guardada.")
        print()

    except Exception as e:
        print()
        print(f"  [!] Error al modificar el script: {e}")
        print(f"      Modifica manualmente la línea 42:")
        print(f'      BASE_DIR = r"{nueva}"')
        print()


# ═══════════════════════════════════════════════════════════════
#  MODO 14 — RASTREO SILENCIOSO (1→9999, ≤6 actas/min, paralelo)
#
#  Estrategia anti-bloqueo:
#  • Va del ID 1 al 9999 en orden ascendente.
#  • Máximo 6 actas por minuto por fuente (1 cada ~10s).
#  • Cada fuente corre en su propio hilo (webs distintas → sin bloqueos cruzados).
#  • Los IDs ya en disco o marcados como vacíos se saltan al instante.
#  • Cursor persistido en disco: si se interrumpe, retoma donde lo dejó.
#  • Parseo y HTML se regeneran cada 20 actas OK acumuladas.
#  • Pulsa Ctrl+C para parar limpiamente y generar HTML final.
# ═══════════════════════════════════════════════════════════════

M14_MAX_ID      = 9999     # ID tope del rastreo
M14_ACTAS_MIN   = 6        # máx. actas por minuto (por fuente)
M14_INTERVALO   = 60.0 / M14_ACTAS_MIN   # segundos entre descargas (~10s)
M14_REGEN_CADA  = 20       # regenerar HTML cada N actas OK totales (entre fuentes)
_m14_lock_html  = threading.Lock()
_m14_ok_total   = [0]      # contador compartido entre hilos para regenerar HTML


def _m14_cursor_file(fuente_cfg):
    return os.path.join(fuente_cfg["output_dir"], "m14_cursor.json")


def _m14_load_cursor(fuente_cfg):
    """Devuelve el último ID rastreado (0 = no empezado)."""
    fp = _m14_cursor_file(fuente_cfg)
    try:
        with open(fp, encoding="utf-8") as f:
            d = json.load(f)
        return int(d.get("cursor", 0))
    except:
        return 0


def _m14_save_cursor(fuente_cfg, cursor):
    fp = _m14_cursor_file(fuente_cfg)
    try:
        with open(fp, "w", encoding="utf-8") as f:
            json.dump({"cursor": cursor}, f)
    except:
        pass


def _modo14_fuente(fuente_key, stop_event, tag, fuentes_stop_events):
    """
    Hilo del Modo 14 para una fuente.
    Recorre IDs 1..M14_MAX_ID a velocidad controlada (M14_ACTAS_MIN/min).
    Salta los que ya están en disco o en empty_ids.
    """
    fuente_cfg = FUENTES[fuente_key]
    prefix     = fuente_cfg["prefix"]
    out_dir    = fuente_cfg["output_dir"]
    json_dir   = fuente_cfg["json_dir"]

    # ── Cargar cursor (reanuda si se interrumpió) ───────────────
    cursor_inicio = _m14_load_cursor(fuente_cfg)
    if cursor_inicio >= M14_MAX_ID:
        print(f"{tag} Rastreo ya completado (cursor={cursor_inicio}). Nada que hacer.")
        return

    if cursor_inicio > 0:
        print(f"{tag} Reanudando desde ID {cursor_inicio + 1} (cursor guardado)")
    else:
        print(f"{tag} Iniciando rastreo desde ID 1 hasta {M14_MAX_ID}")

    # ── Inventario inicial ──────────────────────────────────────
    pat        = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
    empty_ids  = load_empty_ids(fuente_cfg["empty_file"])

    driver = None
    ok = vacias_n = fail = ok_sesion = 0
    ua_idx = 0
    ultimo_tiempo = 0.0   # timestamp de la última descarga real

    try:
        driver = crear_nav(ua_idx)
        calentar(driver, fuente_cfg)

        for cod in range(cursor_inicio + 1, M14_MAX_ID + 1):
            if stop_event.is_set():
                break

            # ── ¿Ya lo tenemos? ────────────────────────────────
            ya_en_disco = os.path.exists(os.path.join(out_dir, f"Acta_{prefix}{cod}.txt"))
            ya_vacio    = str(cod) in empty_ids and not should_retry_empty(cod, empty_ids)

            if ya_en_disco or ya_vacio:
                # Guardar cursor cada 500 IDs saltados para no perder posición
                if cod % 500 == 0:
                    _m14_save_cursor(fuente_cfg, cod)
                continue

            # ── Control de velocidad: ≤ M14_ACTAS_MIN / min ────
            ahora = time.time()
            elapsed = ahora - ultimo_tiempo
            if elapsed < M14_INTERVALO:
                espera = M14_INTERVALO - elapsed
                # Esperar en trozos de 1s para poder reaccionar al stop_event
                for _ in range(int(espera)):
                    if stop_event.is_set(): break
                    time.sleep(1)
                resto = espera - int(espera)
                if not stop_event.is_set() and resto > 0:
                    time.sleep(resto)
            if stop_event.is_set():
                break

            # ── Reiniciar Chrome cada REINICIAR_CADA actas ─────
            if ok_sesion > 0 and ok_sesion % REINICIAR_CADA == 0:
                print(f"{tag} [~] Reiniciando Chrome (cada {REINICIAR_CADA})...")
                cerrar(driver); ua_idx += 1
                time.sleep(random.uniform(3, 6))
                driver = crear_nav(ua_idx)
                calentar(driver, fuente_cfg)
                ok_sesion = 0

            # ── Descarga ────────────────────────────────────────
            ultimo_tiempo = time.time()
            ruta, estado = descargar(driver, cod, cod, M14_MAX_ID, fuente_cfg)

            if estado == "ok":
                ok += 1; ok_sesion += 1
                # Parsear inmediatamente
                try:
                    aid = re.search(r"Acta_(.+)\.txt", os.path.basename(ruta)).group(1)
                    jp  = os.path.join(json_dir, f"{aid}.json")
                    if not os.path.exists(jp):
                        Parser(ruta, json_dir=json_dir, fuente=fuente_key).process()
                except Exception as _pe:
                    pass
                # Regenerar HTML compartido cada M14_REGEN_CADA actas OK
                with _m14_lock_html:
                    _m14_ok_total[0] += 1
                    if _m14_ok_total[0] % M14_REGEN_CADA == 0:
                        print(f"{tag} [~] Regenerando HTML ({_m14_ok_total[0]} actas OK acumuladas)...")
                        try:
                            generar_html()
                        except Exception as _he:
                            print(f"{tag} [!] Error HTML: {_he}")

            elif estado == "vacia":
                mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                try: os.remove(ruta)
                except: pass
                vacias_n += 1

            elif estado in ("bloqueo", "error"):
                fail += 1
                # En bloqueo: pausa larga + reiniciar Chrome
                if estado == "bloqueo":
                    pausa_b = random.randint(45, 75)
                    print(f"{tag} [!] Bloqueo en ID {cod} → pausa {pausa_b}s + nueva sesión")
                    cerrar(driver); driver = None
                    for _ in range(pausa_b):
                        if stop_event.is_set(): break
                        time.sleep(1)
                    if not stop_event.is_set():
                        ua_idx += 1
                        driver = crear_nav(ua_idx)
                        calentar(driver, fuente_cfg)
                        ok_sesion = 0
                        # Reintentar este mismo ID
                        ruta2, estado2 = descargar(driver, cod, cod, M14_MAX_ID, fuente_cfg)
                        if estado2 == "ok":
                            ok += 1; ok_sesion += 1; fail -= 1
                        elif estado2 == "vacia":
                            mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                            try: os.remove(ruta2)
                            except: pass
                            vacias_n += 1

            # ── Guardar cursor cada 50 IDs procesados ──────────
            if cod % 50 == 0:
                _m14_save_cursor(fuente_cfg, cod)
                en_disco_n = sum(1 for f in os.listdir(out_dir) if pat.match(f))
                print(f"{tag} Progreso: ID {cod}/{M14_MAX_ID} | "
                      f"✓{ok} vacías:{vacias_n} ✗{fail} | disco:{en_disco_n}")

        # ── Fin del bucle ───────────────────────────────────────
        _m14_save_cursor(fuente_cfg, M14_MAX_ID)
        print(f"\n{tag} ══ Rastreo completado: {ok} OK | {vacias_n} vacías | {fail} fallidas ══")

    except Exception:
        print(f"{tag} ERROR CRITICO en hilo Modo 14:")
        traceback.print_exc()
    finally:
        if driver:
            try: cerrar(driver)
            except: pass
        print(f"{tag} Hilo finalizado.")


def modo14_rastreo_silencioso():
    """Modo 14: rastreo silencioso de IDs 1→9999, ≤6/min por fuente, paralelo."""
    print("\n" + "=" * 72)
    print("  MODO 14 — Rastreo silencioso  (1 → 9999, sin bloqueos)")
    print("=" * 72)
    print(f"  • Recorre IDs del 1 al {M14_MAX_ID} en orden ascendente")
    print(f"  • Máximo {M14_ACTAS_MIN} actas por minuto por fuente (~{M14_INTERVALO:.0f}s entre descargas)")
    print(f"  • Los IDs ya en disco o vacíos se saltan instantáneamente")
    print(f"  • Cada fuente va en su propio hilo (webs independientes)")
    print(f"  • Cursor guardado en disco: si paras, retoma donde lo dejó")
    print(f"  • HTML se regenera cada {M14_REGEN_CADA} actas OK nuevas")
    print(f"  • Pulsa Ctrl+C para parar limpiamente")
    print("=" * 72 + "\n")

    # ── Selección de fuentes ───────────────────────────────────────────────
    FUENTES_M14 = {
        "A":  [("alava",    "[ÁLAVA   ]")],
        "E":  [("euskadi",  "[EUSKADI ]")],
        "G":  [("gipuzkoa", "[GIPUZKOA]")],
        "B":  [("bizkaia",  "[BIZKAIA ]")],
        "NA": [("navarra",  "[NAVARRA ]")],
        "N":  [("rfef",     "[RFEF    ]")],
        "R":  [("rioja",    "[RIOJA   ]")],
        "CA": [("cantabria", "[CANTABRIA]")],
        "SA": [("euskadi",  "[EUSKADI ]"), ("gipuzkoa", "[GIPUZKOA]"),
               ("bizkaia",  "[BIZKAIA ]"), ("navarra",  "[NAVARRA ]"),
               ("rfef",     "[RFEF    ]"), ("rioja",    "[RIOJA   ]"),
               ("cantabria", "[CANTABRIA]")],
        "T":  [("alava",    "[ÁLAVA   ]"), ("euskadi",  "[EUSKADI ]"),
               ("gipuzkoa", "[GIPUZKOA]"), ("bizkaia",  "[BIZKAIA ]"),
               ("navarra",  "[NAVARRA ]"), ("rfef",     "[RFEF    ]"),
               ("rioja",    "[RIOJA   ]"), ("cantabria", "[CANTABRIA]")],
    }

    print("  ¿Qué fuentes quieres rastrear?")
    print("  [T]  Todas  (Álava + Euskadi + Gipuzkoa + Bizkaia + Navarra + RFEF + La Rioja + Cantabria)")
    print("  [SA] Sin Álava  (Euskadi + Gipuzkoa + Bizkaia + Navarra + RFEF + La Rioja + Cantabria)")
    print("  [A]  Solo Álava")
    print("  [E]  Solo Euskadi")
    print("  [G]  Solo Gipuzkoa")
    print("  [B]  Solo Bizkaia")
    print("  [NA] Solo Navarra")
    print("  [N]  Solo RFEF (Nacional)")
    print("  [R]  Solo La Rioja")
    print()
    while True:
        sel = input("  Elige [T/SA/A/E/G/B/NA/N/R]: ").strip().upper()
        if sel in FUENTES_M14:
            break
        print("  Opción no válida.")

    fuentes_sel = FUENTES_M14[sel]
    nombres     = ", ".join(tag.strip("[] ") for _, tag in fuentes_sel)
    print(f"\n  → Fuentes: {nombres}")

    # Mostrar estado de cursores guardados
    print()
    for fk, tag in fuentes_sel:
        cur = _m14_load_cursor(FUENTES[fk])
        if cur > 0:
            pct = cur / M14_MAX_ID * 100
            print(f"  {tag} Cursor guardado: ID {cur}/{M14_MAX_ID} ({pct:.1f}%) — reanudará desde {cur+1}")
        else:
            print(f"  {tag} Sin cursor previo — empieza desde ID 1")

    print()
    resp = input("  ¿Resetear cursores y empezar desde 1? [s/N]: ").strip().lower()
    if resp == "s":
        for fk, tag in fuentes_sel:
            fp = _m14_cursor_file(FUENTES[fk])
            try: os.remove(fp)
            except: pass
        print("  [+] Cursores reseteados. Empezará desde ID 1.\n")
    else:
        print("  [~] Reanudando desde cursores guardados.\n")

    # Reset contador HTML compartido
    _m14_ok_total[0] = 0

    stop_event = threading.Event()
    fuentes_stop_events = {fk: stop_event for fk, _ in fuentes_sel}

    hilos = [
        threading.Thread(
            target=_modo14_fuente,
            args=(fk, stop_event, tag, fuentes_stop_events),
            daemon=True
        )
        for fk, tag in fuentes_sel
    ]

    for i, hilo in enumerate(hilos):
        hilo.start()
        if i < len(hilos) - 1:
            # Desfase entre arranques para no saturar Chrome al inicio
            time.sleep(random.uniform(6, 12))

    print(f"[*] {len(hilos)} hilo(s) arrancados. Pulsa Ctrl+C para parar limpiamente.\n")

    try:
        while any(h.is_alive() for h in hilos):
            time.sleep(5)
    except KeyboardInterrupt:
        print("\n[!] Interrupción — deteniendo hilos (puede tardar hasta 30s)...")
        stop_event.set()
        for h in hilos:
            h.join(timeout=60)

    print("\n[*] Generando HTML final...")
    try:
        generar_html()
        print(f"[+] HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
    except Exception as e:
        print(f"[!] Error generando HTML: {e}")
    print("[+] Modo 14 finalizado.\n")


# ═══════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════
def main():
    driver = None
    try:
        t0 = time.time()

        # ── Selección de modo ──────────────────────────────────────────
        print("=" * 72)
        print("  FAF Stats — Modo de ejecucion")
        print("=" * 72)
        print("  [1] Normal     (automatico: 50 nuevas arriba + 50 abajo)")
        print("  [2] Manual     (introduces un ID -> ese + 50 previos, re-descarga aunque esten)")
        print("  [3] Actualizar (reparsea TODOS los TXT -> corrige resultados y datos)")
        print("  [3.1] Actualizar + Discrepancias (igual que 3, y ademas re-analiza tablas cruzadas ya conocidas)")
        print("  [4] Revisar    (corrige rojas directas en actas ya descargadas, 20/pasada)")
        print("  [5] Limpiar    (detecta actas vacias en disco y las elimina del TXT)")
        print("  [6] Huecos     (gaps 1-5 entre IDs consecutivos, O rastreo de grandes zonas inexploradas)")
        print("  [7] Retrogrado (jornadas antiguas: 30/tanda, 20min pausa — elige fuentes: Todas / Sin Álava / una sola)")
        print("  [8] Reparsear Nacional (re-parsea solo los TXT de RFEF y regenera sus JSON)")
        print("  [9] Jornada siguiente (descarga los partidos de la proxima jornada en TODAS las ligas/categorias)")
        print("  [10] Duplicados (detecta y corrige actas duplicadas: re-descarga, re-parsea, regen. HTML)")
        print("  [11] Exportar datos (extrae todos los datos del HTML a JSON local)")
        print("  [12] Tablas cruzadas (descarga tabla cruzada de un CodGrupo + 50 anteriores,")
        print("       detecta discrepancias con actas descargadas y las muestra en Config)")
        print("  [13] Cambiar ruta   (actualiza la ruta de la carpeta F en este script)")
        print("  [14] Rastreo silencioso (barre IDs 1→9999, ≤6/min, paralelo, anti-bloqueo)")
        print()
        while True:
            modo = input("  Elige opcion [1/2/3/3.1/4/5/6/7/8/9/10/11/12/13/14]: ").strip()
            if modo in ("1", "2", "3", "3.1", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"):
                break
            print("  Introduce 1, 2, 3, 3.1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 o 14.")

        # ── Selección de fuente (modo 3, 6, 7, 8, 9, 10, 11 y 12 no la piden al usuario) ──
        if modo in ("3", "3.1", "6", "7", "9", "10", "11", "12"):
            fuente_key = "alava"   # valor por defecto, no se usa en estos modos
            fuente_cfg = FUENTES[fuente_key]
        elif modo == "8":
            fuente_key = "rfef"
            fuente_cfg = FUENTES[fuente_key]
        else:
            print()
            print("  ¿De qué federación quieres descargar/procesar actas?")
            print("  [A] Álava       (FAF — faf-aff.eus)")
            print("  [E] Euskadi     (EuskadiFutbol — euskadifutbol.eus)")
            print("  [G] Gipuzkoa    (RFGF — gipuzkoafutbola.eus)")
            print("  [B] Bizkaia     (FVF — fvf-bff.eus)")
            print("  [NA] Navarra    (FutNavarra — futnavarra.es)")
            print("  [N] Nacional    (RFEF — marcadores.rfef.es)")
            print("  [R] La Rioja    (FRFutbol — frfutbol.com)")
            print()
            while True:
                sel = input("  Elige fuente [A/E/G/B/NA/N/R/CA]: ").strip().upper()
                if sel in ("A", "E", "G", "B", "NA", "N", "R", "CA"):
                    break
                print("  Introduce A, E, G, B, NA, N, R o CA.")
            fuente_key = {"A": "alava", "E": "euskadi", "G": "gipuzkoa", "B": "bizkaia", "NA": "navarra", "N": "rfef", "R": "rioja", "CA": "cantabria"}[sel]
            fuente_cfg = FUENTES[fuente_key]
            print(f"\n  → Fuente seleccionada: {fuente_cfg['label']}\n")

        empty_ids = load_empty_ids(fuente_cfg["empty_file"])
        out_dir   = fuente_cfg["output_dir"]
        json_dir  = fuente_cfg["json_dir"]
        prefix    = fuente_cfg["prefix"]

        acta_manual = None
        if modo == "4":
            revisar_tarjetas_html(fuente_cfg)
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "5":
            limpiar_vacias(fuente_cfg)
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "6":
            analizar_huecos()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "7":
            modo7_retrograde()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "10":
            # Ejecutar en TODAS las fuentes
            for fkey, fcfg in FUENTES.items():
                corregir_duplicados(fkey, fcfg)
            t = time.time() - t0
            print("=" * 72)
            print(f"  MODO 10 COMPLETADO PARA TODAS LAS FUENTES en {t:.1f}s ({t/60:.1f} min)")
            print(f"  HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
            print("=" * 72)
            return

        if modo == "8":
            fcfg = FUENTES["rfef"]
            odir = fcfg["output_dir"]
            jdir = fcfg["json_dir"]
            pfx  = fcfg["prefix"]
            pat8 = re.compile(rf"Acta_{re.escape(pfx)}\d+\.txt")
            txts = sorted(f for f in os.listdir(odir) if pat8.match(f))
            print("=" * 72)
            print(f"  Modo 8 — Reparsear Nacional (RFEF)")
            print(f"  TXT en disco : {len(txts)}")
            print(f"  Directorio   : {odir}")
            print("=" * 72 + "\n")
            if not txts:
                print("[!] No hay TXTs de Nacional en disco. Ejecuta primero el Modo 1 con fuente N.\n")
            else:
                parseadas = errores = 0
                for fn in txts:
                    try:
                        Parser(os.path.join(odir, fn), json_dir=jdir, fuente="rfef").process()
                        parseadas += 1
                    except Exception as e:
                        print(f"  [!] Error {fn}: {e}"); errores += 1
                nj = len([f for f in os.listdir(jdir) if f.endswith(".json")])
                print(f"[+] Reparsadas: {parseadas} | Errores: {errores} | JSONs totales: {nj}\n")
                print("[*] Generando HTML...")
                generar_html()
                print(f"[+] HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "9":
            modo9_jornada_siguiente()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "11":
            print()
            print("=" * 72)
            print("  Modo 11 — Exportar datos del HTML a JSON")
            print("=" * 72)
            modo11_exportar_datos()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print("=" * 72)
            return

        if modo == "12":
            print()
            print("=" * 72)
            print("  Modo 12 — Tablas cruzadas (comparar con actas)")
            print("=" * 72)
            modo12_tablas_cruzadas()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print(f"  HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
            print("=" * 72)
            return

        if modo == "13":
            modo13_cambiar_ruta()
            return

        if modo == "14":
            modo14_rastreo_silencioso()
            return

        if modo == "2":
            print()
            while True:
                val = input("  ID del acta de inicio (incluido): ").strip()
                if val.isdigit() and int(val) > 0:
                    acta_manual = int(val)
                    break
                print("  ID invalido, debe ser un entero positivo.")
        print()

        # ── Inventario actual ──────────────────────────────────────────
        pat = re.compile(rf"Acta_{re.escape(prefix)}(\d+)\.txt")
        en_disco = {
            int(pat.search(f).group(1))
            for f in os.listdir(out_dir)
            if pat.match(f)
        }
        # Excluir vacíos conocidos (a no ser que haya pasado tiempo)
        vacios_actuales = {int(k) for k, v in empty_ids.items()
                           if not should_retry_empty(int(k), empty_ids)}

        excluir = en_disco | vacios_actuales

        # ── Modo 3: reparseo total de TODAS las fuentes, sin descarga ─────
        if modo in ("3", "3.1"):
            total_parseadas = total_errores = total_jsons = 0
            for fkey, fcfg in FUENTES.items():
                odir = fcfg["output_dir"]
                jdir = fcfg["json_dir"]
                pfx  = fcfg["prefix"]
                if not os.path.isdir(odir):
                    continue
                pat3 = re.compile(rf"Acta_{re.escape(pfx)}\d+\.txt")
                txts = sorted(f for f in os.listdir(odir) if pat3.match(f))
                if not txts:
                    print(f"[~] {fcfg['label']}: sin TXTs, saltando.")
                    continue
                print(f"[*] Reparsando {len(txts)} TXTs de {fcfg['label']}...")
                parseadas = errores = 0
                # ── Reparseo en paralelo ────────────────────────────────
                # Cada TXT se procesa de forma totalmente independiente
                # (propio archivo de entrada, propio JSON de salida), así
                # que repartir el trabajo entre varios procesos no cambia
                # ni un solo resultado, solo lo acelera. Con miles de actas
                # esto es lo que más tiempo consumía del Modo 3.
                tareas = [(os.path.join(odir, fn), jdir, fkey) for fn in txts]
                max_workers = min(32, os.cpu_count() or 4, len(tareas)) or 1
                with ProcessPoolExecutor(max_workers=max_workers) as pool:
                    # chunksize>1 reduce la sobrecarga de IPC cuando hay
                    # miles de tareas pequeñas, sin cambiar el resultado.
                    chunksize = max(1, len(tareas) // (max_workers * 4) or 1)
                    for fn, ok, err in pool.map(_reparsear_una_acta, tareas, chunksize=chunksize):
                        if ok:
                            parseadas += 1
                        else:
                            print(f"  [!] Error {fn}: {err}"); errores += 1
                nj = len([f for f in os.listdir(jdir) if f.endswith(".json")])
                print(f"[+] {fcfg['label']}: {parseadas} OK | {errores} errores | {nj} JSONs")
                total_parseadas += parseadas; total_errores += errores; total_jsons += nj
            print(f"\n[+] TOTAL: {total_parseadas} reparsadas | {total_errores} errores | {total_jsons} JSONs\n")
            # ── Eliminar actas femeninas (y sala) generadas durante el reparseo ──
            print("[*] Marcando actas de sala/femeninas (no se re-descargarán)...")
            _m7_borrar_actas_excluidas()
            print("[*] Auto-resolviendo discrepancias por goles en propia puerta...")
            # Modo 3: solo pasada TXT (sin Chrome). Modo 3.1 hace la pasada HTML completa.
            resolver_discrepancias_pp(solo_txt=(modo == "3"))

            # ── Modo 3.1: re-analizar tablas cruzadas ya conocidas ────────────
            # (misma lógica que usa el Modo 6 sub-modo 2 al terminar su rastreo,
            # extraída a _reanalizar_tablas_cruzadas_conocidas; no hace red.)
            if modo == "3.1":
                _reanalizar_tablas_cruzadas_conocidas(usar_log6=False)
                print()

            print("[*] Generando HTML...")
            generar_html()
            t = time.time() - t0
            print("=" * 72)
            print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
            print(f"  HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
            print("=" * 72)
            return

        acta_tope = fuente_cfg["acta_tope"]
        # Nacional usa 150 actas por run en Modo 2 (IDs más dispersos)
        actas_por_run = 150 if fuente_key == "rfef" else ACTAS_POR_RUN
        if modo == "2" and acta_manual is not None:
            # ── Modo manual: acta_manual incluida + hasta actas_por_run hacia abajo ──
            # Excluir: los que ya están en disco y NO están vacíos (actas completas).
            # Incluir: los que nunca se han descargado + los marcados como vacíos (reintento).
            en_disco_completos = en_disco - vacios_actuales
            candidatas = [acta_manual - i for i in range(actas_por_run + 1)
                          if (acta_manual - i) > 0]
            pendientes = [c for c in candidatas if c not in en_disco_completos][:actas_por_run]
            if not pendientes:
                print(f"  [!] Todos los IDs desde {acta_manual} hacia abajo ya están descargados")
                print(f"      y completos. No hay nada nuevo que descargar en ese rango.")
                print(f"      (Para forzar re-descarga de vacíos: Modo 5 para limpiarlos primero)")
                print()
        else:
            # ── Modo normal: actas_por_run hacia ABAJO + actas_por_run hacia ARRIBA ──
            max_disco = max(en_disco) if en_disco else acta_tope
            min_disco = min(en_disco) if en_disco else acta_tope

            candidatas_abajo = [min_disco - i for i in range(1, actas_por_run + 1) if (min_disco - i) > 0]
            candidatas_arriba= [max_disco + i for i in range(1, actas_por_run + 1)]

            pend_abajo  = [c for c in candidatas_abajo  if c not in excluir]
            pend_arriba = [c for c in candidatas_arriba if c not in excluir]

            pendientes = pend_arriba[:actas_por_run//2] + pend_abajo[:actas_por_run]
            pendientes = pendientes[:actas_por_run]
            max_disco = max(en_disco) if en_disco else acta_tope
            min_disco = min(en_disco) if en_disco else acta_tope

        print("=" * 72)
        print(f"  FAF Stats — {fuente_cfg['label']}")
        print(f"  TXT  -> {out_dir}")
        print(f"  HTML -> {HTML_DIR}")
        print(f"  En disco: {len(en_disco)} | Vacias conocidas: {len(vacios_actuales)}")
        print(f"  Pendientes: {len(pendientes)}")
        if pendientes: print(f"  Estimado: ~{max(1, int(len(pendientes)*1.2/60))} min")
        print("=" * 72 + "\n")

        # ── Descarga ──────────────────────────────────────────────────
        ok = fail = vacias = 0
        if pendientes:
            print("[*] Iniciando Chrome...")
            ua_idx = ses = 0
            driver = crear_nav(ua_idx)
            calentar(driver, fuente_cfg)
            actas_ses = fallos_consec = racha_bloqueo = 0
            ses = 1
            abortado_bloqueo = False

            def reiniciar(motivo):
                nonlocal driver, actas_ses, ua_idx, ses
                print(f"\n  [~] Reiniciando Chrome ({motivo})...")
                cerrar(driver); ua_idx += 1; ses += 1
                time.sleep(random.uniform(3, 6))
                driver = crear_nav(ua_idx); calentar(driver, fuente_cfg); actas_ses = 0

            for idx, cod in enumerate(pendientes, 1):
                if actas_ses > 0 and actas_ses % REINICIAR_CADA_SUAVE == 0:
                    reiniciar(f"cada {REINICIAR_CADA_SUAVE}")

                _delay_humano()
                ruta, estado = descargar(driver, cod, idx, len(pendientes), fuente_cfg)

                if estado == "vacia":
                    mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                    try: os.remove(ruta)
                    except: pass
                    vacias += 1
                    fallos_consec = 0
                elif estado == "ok":
                    ok += 1
                    fallos_consec = 0
                    racha_bloqueo = 0
                    # ── Parsear y guardar cada 5 actas OK ──────────────
                    if ok % 5 == 0:
                        try:
                            aid = re.search(r"Acta_(.+)\.txt", os.path.basename(ruta)).group(1)
                            jp  = os.path.join(json_dir, f"{aid}.json")
                            if not os.path.exists(jp):
                                Parser(ruta, json_dir=json_dir, fuente=fuente_key).process()
                            print(f"  [~] Guardado intermedio ({ok} actas OK)...")
                            generar_html()
                        except Exception as _pe:
                            pass  # guardado intermedio no es crítico
                else:
                    vivo = True
                    try: _ = driver.current_url
                    except: vivo = False
                    if not vivo:
                        reiniciar("Chrome caido"); fallos_consec = 0
                        _delay_humano()
                        ruta, estado = descargar(driver, cod, idx, len(pendientes), fuente_cfg)
                        if estado == "ok": ok += 1
                        elif estado == "vacia":
                            mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                            try: os.remove(ruta)
                            except: pass
                            vacias += 1
                        else: fail += 1; fallos_consec += 1
                    else:
                        fallos_consec += 1
                        fail += 1

                    if fallos_consec >= FALLOS_PAUSA:
                        racha_bloqueo += 1
                        p = _pausa_escalada(racha_bloqueo)
                        print(f"\n  [!] {fallos_consec} fallos — racha de bloqueo nº{racha_bloqueo} "
                              f"— pausa {p}s + nueva sesion")
                        if racha_bloqueo > RACHAS_MAX_BLOQUEO:
                            print(f"\n  [X] {racha_bloqueo} rachas de bloqueo seguidas: la IP parece "
                                  f"marcada por el servidor. Se detiene la descarga para no agravarlo.")
                            print(f"      Prueba de nuevo más tarde (30-60 min) o, si persiste, "
                                  f"cambia de red (otro WiFi/4G/VPN).\n")
                            abortado_bloqueo = True
                            break
                        reiniciar("anti-bloqueo"); time.sleep(p); fallos_consec = 0
                        _delay_humano()
                        ruta, estado = descargar(driver, cod, idx, len(pendientes), fuente_cfg)
                        if estado == "ok": ok += 1; fail -= 1
                        elif estado == "vacia":
                            mark_empty(cod, empty_ids, fuente_cfg["empty_file"])
                            try: os.remove(ruta)
                            except: pass
                            vacias += 1

                actas_ses += 1

            cerrar(driver); driver = None
            etiqueta = "interrumpida por bloqueo" if abortado_bloqueo else "Descarga"
            print(f"\n[+] {etiqueta}: {ok} OK | {vacias} vacías | {fail} fallidas | {ses} sesiones | {time.time()-t0:.0f}s\n")
        else:
            print("[*] No hay nuevas actas que descargar.\n")



        # ── Parseo: todos los TXT sin JSON válido ─────────────────────
        print("[*] Parseando actas...")
        parseadas = 0
        pat_parse = re.compile(rf"Acta_{re.escape(prefix)}\d+\.txt")
        for fn in sorted(f for f in os.listdir(out_dir) if pat_parse.match(f)):
            aid = re.search(r"Acta_(.+)\.txt", fn).group(1)
            jp  = os.path.join(json_dir, f"{aid}.json")
            reparsear = True
            if os.path.exists(jp):
                try:
                    with open(jp, encoding="utf-8") as jf: j = json.load(jf)
                    if all(k in j for k in ("jornada","titulares_local","sustituciones_local")):
                        reparsear = False
                except: pass
            if reparsear:
                try:
                    Parser(os.path.join(out_dir, fn), json_dir=json_dir, fuente=fuente_key).process()
                    parseadas += 1
                except Exception as e:
                    print(f"  [!] Error {fn}: {e}")

        total_j = len([f for f in os.listdir(json_dir) if f.endswith(".json")])
        print(f"[+] Parseadas: {parseadas} | Total JSONs: {total_j}\n")

        # ── HTML ──────────────────────────────────────────────────────
        print("[*] Generando HTML...")
        generar_html()

        t = time.time() - t0
        print("=" * 72)
        print(f"  COMPLETADO en {t:.1f}s ({t/60:.1f} min)")
        print(f"  HTML: {os.path.join(HTML_DIR, 'FAF_Stats.html')}")
        print("=" * 72)

    except Exception:
        print("\n" + "!" * 72 + "\nERROR CRITICO:")
        traceback.print_exc(); print("!" * 72)
    finally:
        if driver: cerrar(driver)
        print("\nFin."); os.system("pause")

if __name__ == "__main__":
    main()