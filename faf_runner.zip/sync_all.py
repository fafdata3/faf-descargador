# -*- coding: utf-8 -*-
"""Entry point del runner cloud de FAF Stats.

Uso:
  python sync_all.py --once                       # una pasada de sync
  python sync_all.py --daemon                     # bucle infinito (systemd/docker)
  python sync_all.py --once --no-deploy           # synca sin tocar Pages
  python sync_all.py --rebuild-only               # regen+build+deploy sin descarga
  python sync_all.py --once --sources bizkaia     # solo una fuente
  python sync_all.py --bootstrap                  # trae el corpus de la nube (S3) a /data

El estado y las actas viven en FAF_DATA_DIR (por defecto /data) y en la nube
(S3/Oracle/R2). Con FAF_REBUILD_AFTER_N=1 (por defecto) cada acta nueva
descargada regenera el HTML y despliega Pages automáticamente (con un piso
de FAF_REBUILD_MIN minutos para no saturar).
"""
import argparse
import json
import os
import random
import re
import sys
import time

import config
import engine
import rebuild_deploy
import storage

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def sembrar_desde_web():
    """Reconstruye corpus + state.json desde la web pública (SIN B2).

    Fallback para cuando B2 no deja leer (¿tope de lecturas Class B
    agotado?): en vez del bundle S3 por fuente se bajan los chunks públicos
    del sitio (manifest + actas.NNN.json + sync_status.json) y se escriben
    las actas JSON en FUENTES_DIR como haría el Parser. Si el corpus ya está
    en disco solo refresca el estado. Devuelve nº de actas disponibles."""
    dl = engine.load_monolito()
    web = config.WEB_BASE.rstrip("/") + "/data"
    import urllib.request

    def _get(url):
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=180) as r:
            return json.loads(r.read())

    # Estado: highs/cursors publicados por el cron -> state.json
    state = {}
    try:
        st = _get(f"{web}/sync_status.json") or {}
        for fk, fcfg in dl.FUENTES.items():
            s = (st.get("sources", {}) or {}).get(fk) or {}
            if s.get("high") is not None:
                state[fk] = {"high": s["high"], "cursor": s.get("cursor")}
    except Exception as e:
        print(f"[web-bootstrap] aviso: no se pudo leer el estado de la web ({e})")

    corpus = sum(1 for fcfg in dl.FUENTES.values()
                 for _ in os.listdir(fcfg["json_dir"]))
    if corpus:
        storage.save_json(config.STATE_FILE, state)
        print(f"[web-bootstrap] corpus ya en disco ({corpus} actas); "
              f"estado refrescado (sin B2)")
        return corpus
    if not state:
        print("[web-bootstrap] sin estado público ni corpus local: no se puede sembrar.")
        return 0

    try:
        m = _get(f"{web}/manifest.json")
    except Exception as e:
        print(f"[web-bootstrap] no se pudo leer manifest.json: {e}")
        return 0
    chunks = m.get("chunks") or []
    total = 0
    for i, ch in enumerate(chunks, 1):
        try:
            recs = _get(f"{web}/{ch}")
        except Exception as e:
            print(f"[web-bootstrap] fallo en {ch}: {e}")
            break
        for r in recs or []:
            fk = r.get("fuente")
            if fk not in dl.FUENTES:
                continue
            aid = r.get("acta_id")
            if not aid:
                continue
            # acta_id ya lleva el prefijo (E_10043037, ...): fichero <aid>.json
            with open(os.path.join(dl.FUENTES[fk]["json_dir"], f"{aid}.json"),
                      "w", encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False)
            total += 1
        if i % 5 == 0 or i == len(chunks):
            print(f"[web-bootstrap] {i}/{len(chunks)} chunks ({total} actas)")
    storage.save_json(config.STATE_FILE, state)
    print(f"[web-bootstrap] corpus listo desde la web: {total} actas (sin B2)")
    return total


def bootstrap(store):
    """Trae el corpus a FAF_DATA_DIR. Primero intenta B2 (bundles por fuente,
    rápido); si no deja leer (¿tope Class B agotado?) cae a sembrar_desde_web()
    para no bloquear el runner ni el deploy del cron."""
    n = _bootstrap_s3(store)
    if n > 0 or not store.cloud_enabled:
        return n
    print("[bootstrap] B2 sin datos (¿tope de lecturas Class B?). "
          "Sembrando corpus desde la web pública...")
    return sembrar_desde_web()


def _bootstrap_s3(store):
    """Trae el corpus desde la nube a FAF_DATA_DIR (bundles tar.gz por fuente).

    Solo ~9 objetos: 7 bundles (JSON comprimido por fuente) + state.json y
    sync_status.json, más los empty_ids/revisadas de cada fuente. Sin listados
    masivos: una ejecución fresca de GitHub Actions baja el corpus en segundos.
    """
    if not store.cloud_enabled:
        print("[bootstrap] nube no configurada; no hay nada que traer.")
        return 0
    # Sonda rápida: si B2 rechaza LECTURAS (tope Class B agotado -> Forbidden),
    # no merece la pena intentar los ~40 objetos: se salta a web-seed ya.
    sonda = store.readable("state.json")
    if sonda is False:
        print("[bootstrap] B2 rechaza lecturas (Forbidden/Class B): "
              "se salta S3 y se sembrará desde la web.")
        return 0
    total = 0
    for k in config.ALL_SOURCES:
        bkey = store.bundle_key(k)
        dtmp = os.path.join(config.DATA_DIR, "bundle_tmp")
        os.makedirs(dtmp, exist_ok=True)
        dest = os.path.join(dtmp, f"{k}.tar.gz")
        if store.download(bkey, dest):
            if store.extract_bundle(k, dest):
                total += 1
        for small in ("empty_ids.json", "revisadas.json",
                      "duplicados_descartadas.json"):
            sfile = os.path.join(config.FUENTES_DIR, k, small)
            if store.download(f"fuentes/{k}/{small}", sfile,
                              quiet=(small != "empty_ids.json")):
                total += 1
    for small in ("state.json", "sync_status.json"):
        if store.download(small, os.path.join(config.DATA_DIR, small),
                          quiet=(small != "state.json")):
            total += 1
    import shutil
    shutil.rmtree(os.path.join(config.DATA_DIR, "bundle_tmp"), ignore_errors=True)
    print(f"[bootstrap] OK: {total} ficheros traídos de la nube a {config.DATA_DIR}")
    return total


def ids_rescate(json_dir, prefix):
    """IDs de una fuente cuyas actas YA en el corpus son de temporadas 2025+.

    El rescue re-descarga y repasa estas actas con el Parser corregido (no
    toca las 2026-27 todavía no descargadas: el sync normal las baja ya con
    el parser nuevo y sin errores de marcador)."""
    pat = re.compile(rf"^{re.escape(prefix)}(\d+)\.json$")
    ids = []
    for fn in os.listdir(json_dir):
        m = pat.match(fn)
        if not m:
            continue
        try:
            with open(os.path.join(json_dir, fn), encoding="utf-8") as f:
                a = json.load(f)
        except Exception:
            continue
        temp = (a or {}).get("temporada", "") or ""
        if temp.startswith(tuple(config.RESCUE_TEMPS)):
            ids.append(int(m.group(1)))
    return sorted(set(ids), reverse=True)


def rescue_source(fkey, status, store, pool, ok_acumulado):
    """Repasa 2025+ de una fuente: descarga fresca + Parser corregido.

    Reutiliza engine.bajar_acta (mismo ritmo anti-bloqueo; si hay Chrome
    disponible usa la sesión Selenium Modo 7). Firma un marcador .rescued por
    acta para poder reanudar la pasada siguiente sin re-hacer las ya
    corregidas. Actualiza el bundle de la fuente si hubo cambios."""
    dl = engine.load_monolito()
    cfg = dl.FUENTES[fkey]
    st = status.sources[fkey]
    prefix = cfg["prefix"]
    out_dir = cfg["output_dir"]
    json_dir = cfg["json_dir"]

    ses = engine.SesionChrome(dl)
    if not ses.iniciar(fkey, cfg):
        ses = None  # sin Chrome → fallback a requests

    ids = ids_rescate(json_dir, prefix)
    print(f"[{fkey}] rescue: {len(ids)} actas 2025+ en el corpus")

    ok = 0
    vacias = 0
    consec = 0
    for cod in ids:
        if config.RESCUE_MAX_PER_SOURCE and ok >= config.RESCUE_MAX_PER_SOURCE:
            print(f"[{fkey}] tope de rescue alcanzado ({ok}); quedan sin repasar")
            break
        msr = os.path.join(out_dir, f"Acta_{prefix}{cod}.rescued")
        if os.path.exists(msr):
            continue
        if ses is None:
            time.sleep(random.uniform(config.PACING_SEC * 0.6,
                                      config.PACING_SEC * 1.5))
        ruta, estado = engine.bajar_acta(fkey, cfg, cod, dl, sesion=ses)

        if estado == "ok":
            try:
                dl.Parser(ruta, json_dir=json_dir, fuente=fkey).process()
            except Exception as exc:
                est = f"parse-{exc}"
                print(f"[{fkey}] error de parse en {prefix}{cod}: {exc}")
                st["last_error"] = f"{prefix}{cod}: {exc}"
                consec += 1
                if consec >= config.MAX_CONSEC_ERRORS:
                    break
                continue  # no firmar el marcador; lo reintenta otra pasada

        if estado == "ok":
            try:
                with open(msr, "w", encoding="utf-8") as f:
                    f.write("ok")
            except Exception:
                pass
            ok += 1
            consec = 0
            ok_acumulado[0] += 1
            st["ok"] += 1
            st["last_ok_ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
            print(f"[{fkey}] +{ok} {prefix}{cod}")
        elif estado == "vacia":
            vacias += 1
            st["vacias"] += 1
            print(f"[{fkey}] {prefix}{cod} vacia (se re-intentara otra pasada)")
            if vacias % config.CONSEC_EMPTY_PAUSE == 0:
                engine._pausa_larga(st)
        else:  # bloqueo / error
            st["fails"] += 1
            if estado == "bloqueo":
                st["blocks"] += 1
                st["last_block_ts"] = time.strftime("%Y-%m-%d %H:%M:%S")
                if pool.on_block(fkey, status):
                    st["ip"] = pool.current_proxy(fkey)
                # Con sesión Selenium el bloqueo ya fue gestionado por
                # SesionChrome (reinicio leve o pausa M7 larga).
                if ses is None:
                    engine._pausa_larga(st)
            else:
                st["last_error"] = estado or ""
                time.sleep(random.uniform(6, 12))
            consec += 1
            if consec >= config.MAX_CONSEC_ERRORS:
                print(f"[{fkey}] rescue: {consec} fallos seguidos, se salta la fuente")
                break
    if ses is not None:
        ses.cerrar()

    # Subir el bundle actualizado (el runner es efímero) y el estado.
    if getattr(store, "cloud", None) and store.cloud.cloud_enabled and ok > 0:
        try:
            os.makedirs(config.BUILD_DIR, exist_ok=True)
            bundle = os.path.join(config.BUILD_DIR, f"bundle_{fkey}.tar.gz")
            if store.tar_bundle(fkey, bundle):
                if store.upload(bundle, store.bundle_key(fkey)):
                    print(f"[{fkey}] bundle actualizado en la nube")
            try:
                os.remove(bundle)
            except Exception:
                pass
        except Exception:
            import traceback
            traceback.print_exc()
    return ok


def pedir_fuentes():
    """Pregunta qué fuentes descargar (solo en el PC, terminal interactiva).
    'todas' o Enter = todas; si no, csv: 'bizkaia' o 'alava,bizkaia'.
    Devuelve la lista de fuentes válidas o None para no cambiar nada."""
    if not sys.stdin.isatty() or os.environ.get("CI"):
        return None
    print("\n== Fuentes a descargar ==")
    print("    'todas' (o Enter) = todas; o elige una o varias separadas por "
          "comas.")
    print(f"    disponibles: {', '.join(config.ALL_SOURCES)}")
    try:
        linea = input(f"fuentes [{','.join(config.SOURCES)}]: ").strip()
    except EOFError:
        return None
    if not linea or linea.lower() in ("todas", "all", "*"):
        return list(config.ALL_SOURCES)
    pedidas = [s.strip().lower() for s in linea.split(",") if s.strip()]
    validas = [s for s in pedidas if s in config.ALL_SOURCES]
    malas = [s for s in pedidas if s not in config.ALL_SOURCES]
    if malas:
        print(f"[fuentes] se ignoran desconocidas: {', '.join(malas)}")
    if not validas:
        print("[fuentes] ninguna válida; se usan todas.")
        return list(config.ALL_SOURCES)
    print(f"[fuentes] {', '.join(validas)}")
    return validas


def pedir_anclas(state, arg_actas=None):
    """Actas de arranque elegidas por el usuario, formato 'fuente=acta,...'
    (p.ej. 'alava=9990228,euskadi=9990000'). En el PC se preguntan ANTES de
    empezar (el loop las usa como ancla: se rastrea desde cada una hacia
    arriba). Enter = auto (heurística). En modo no interactivo (cron de
    GitHub) devuelve lo que venga por --actas o {} (nunca pregunta)."""
    if arg_actas:
        return _parse_anclas(arg_actas)
    if not sys.stdin.isatty() or os.environ.get("CI"):
        return {}
    dl = engine.load_monolito()
    ejemplo = []
    for fkey in config.SOURCES:
        if fkey not in dl.FUENTES:
            continue
        high = state.data.get(fkey, {}).get("high")
        cfg = dl.FUENTES[fkey]
        seed = int(cfg["seed_high"]) if cfg.get("seed_high") else None
        v = high or seed or 0
        if v:
            ejemplo.append(f"{fkey}={v}")
    print("\n== Actas de arranque / desde qué acta empezar (opcional) ==")
    if not ejemplo:
        print("(sin state todavía: se usará la heurística automática)")
    else:
        print("    Formato fuente=acta, separadas por comas. Cada valor es el")
        print("    ÚLTIMO acta ya publicada de esa fuente; se rastrea hacia")
        print("    arriba desde ahí. Editables, o Enter = auto (los de abajo):")
        print(f"    {','.join(ejemplo)}")
    try:
        linea = input("fuente=acta,fuente=acta,... [Enter=auto]: ").strip()
    except EOFError:
        return {}
    if not linea:
        print("[anclas] auto (heurística)")
        return {}
    return _parse_anclas(linea)


def _parse_anclas(raw):
    anclas = {}
    for par in (raw or "").split(","):
        par = par.strip()
        if not par:
            continue
        if "=" not in par:
            print(f"[anclas] se ignora '{par}' (formato fuente=acta)")
            continue
        fk, _, val = par.partition("=")
        fk = fk.strip()
        try:
            anclas[fk] = int(val.strip())
        except ValueError:
            print(f"[anclas] se ignora '{fk}={val}' (acta no numérica)")
    if anclas:
        print("[anclas] " + ", ".join(f"{k}={v}" for k, v in anclas.items()))
    return anclas


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(line_buffering=True)
        sys.stderr.reconfigure(line_buffering=True)
    ap = argparse.ArgumentParser(description="Runner cloud FAF Stats")
    ap.add_argument("--once", action="store_true",
                    help="una pasada y salir")
    ap.add_argument("--portable", action="store_true",
                    help="modo descargador de PC: no despliega, marca actas "
                         "externas (pc_uploads) para que el cron despliegue, "
                         "y sube el bundle sin regenerar HTML")
    ap.add_argument("--daemon", action="store_true",
                    help="bucle infinito (modo servidor)")
    ap.add_argument("--rebuild-only", action="store_true",
                    help="solo regenerar/build/deploy")
    ap.add_argument("--rescue", action="store_true",
                    help="reprocesar temporadas 2025+ en el corpus (parser corregido)")
    ap.add_argument("--no-deploy", action="store_true",
                    help="no desplegar en Pages (solo build local)")
    ap.add_argument("--bootstrap", action="store_true",
                    help="traer el corpus completo desde la nube")
    ap.add_argument("--sources", default=None,
                    help="fuentes (csv), p.ej. alava,bizkaia")
    ap.add_argument("--interval", type=int, default=None,
                    help="segundos entre pasadas en modo daemon (default: FAF_INTERVAL)")
    ap.add_argument("--dry", action="store_true",
                    help="no descargar; solo imprimir candidatos")
    ap.add_argument("--actas", default=None,
                    help="actas de arranque, formato 'fuente=id,fuente=id' "
                         "(p.ej. 'alava=9990228,euskadi=9990000'); en el PC se "
                         "preguntan antes de empezar si no se pasa este flag")
    args = ap.parse_args()

    if args.sources:
        config.SOURCES = [s.strip() for s in args.sources.split(",") if s.strip()]
    if args.no_deploy:
        config.DEPLOY_ENABLED = False
    if args.dry:
        config.DRY = True

    store = storage.ObjectStore()
    engine.load_monolito()

    if args.portable:
        # Modo descargador de PC: nunca despliega Pages ni AWS/CF; solo
        # descarga, sube el bundle/estado a la nube y marca pc_uploads para
        # que el cron de GitHub detecte las actas externas y despliegue.
        config.DEPLOY_ENABLED = False
        config.RUN_BUDGET_SEC = max(config.RUN_BUDGET_SEC, 5400)
        # En el PC: fuentes en hilos paralelos reales (cada una con su Chrome
        # e IP residencial); un atasco en una federación no bloquea a las demás.
        config.PARALLEL_SOURCES = True

    if args.bootstrap:
        n = bootstrap(store)
        # Si B2 no deja leer hoy (cap Class B) el corpus no llega y ejecutar
        # sería 30+ min de sondear IDs vacíos sin avanzar. Fallar rápido para
        # que el cron de mañana (cap reiniciado) haga el trabajo de verdad.
        if config.REQUIRE_BOOTSTRAP and n == 0:
            print("[bootstrap] ERROR: 0 ficheros traídos de la nube. "
                  "¿Límite B2 (Class B) o credenciales? Abortando.")
            sys.exit(1)
        # sin --once/--daemon explícitos, el bootstrap hace una pasada y sale
        if not (args.once or args.daemon):
            args.once = True

    if args.portable and not args.sources:
        sel = pedir_fuentes()
        if sel:
            config.SOURCES = sel

    status = engine.Status()
    state = engine.StateStore()
    pool = engine.ProxyPool()
    # Actas de arranque (solo se preguntan una vez, al inicio):
    # 'fuente=acta,...' en el PC (o --actas). Enter = auto (heurística).
    anclas = {} if (args.rebuild_only or args.rescue) \
        else pedir_anclas(state, args.actas) or {}
    if args.portable:
        # Lector de terminal: escribir 'fin' corta el rastreo y cierra con lo
        # ya descargado (que se sube al instante). En el cron no es tty.
        engine.iniciar_monitor_parada()

    version = ""
    last_deploy = 0.0
    ok_acumulado = [0]

    def pasada(running=True):
        nonlocal version, last_deploy
        engine.batch(status, state, pool, ok_acumulado, anclas=anclas)
        engine.publish_status(status, state, version=version, running=running)
        if args.portable:
            # Marcar en el estado cuántas actas se subieron desde un PC
            # externo. El cron de GH lee este contador en su propio state.json
            # (traído con --bootstrap) y despliega cuando detecte nuevas.
            state.data["pc_uploads"] = (state.data.get("pc_uploads", 0)
                                        + ok_acumulado[0])
            store.save()
            store.upload(config.STATE_FILE, "state.json")
            print(f"[portable] pc_uploads={state.data['pc_uploads']} "
                  f"(nuevas en esta pasada={ok_acumulado[0]})")
            return
        # Actas subidas desde PCs externos (descargador portátil) que aún no
        # se han desplegado en la web: el cron las detecta aquí y regenera.
        externas = (state.data.get("pc_uploads", 0)
                    - state.data.get("pc_desplegadas", 0))
        if externas > 0:
            print(f"[pasada] {externas} actas externas (PC) sin desplegar")
        due = last_deploy > 0 and (time.time() - last_deploy) >= config.REBUILD_MIN * 60
        nuevas = ok_acumulado[0] + max(0, externas) >= config.REBUILD_AFTER_N
        if config.DRY:
            print(f"[pasada] dry-mode: {ok_acumulado[0]} actas pendientes, sin regen/deploy.")
            return
        if nuevas or due:
            print(f"[pasada] nuevas={ok_acumulado[0]} ({max(0,externas)} externas) "
                  f"due={due} -> regenerar y desplegar")
            version, url = rebuild_deploy.regenerar_y_desplegar(
                status, state, version=version)
            if ok_acumulado[0] >= config.REBUILD_AFTER_N:
                ok_acumulado[0] = 0
            if url:
                last_deploy = time.time()
            # Tras desplegar, registrar qué pc_uploads ya están en la web
            state.data["pc_desplegadas"] = state.data.get("pc_uploads", 0)
            store.save()
            store.upload(config.STATE_FILE, "state.json")

    if args.rebuild_only:
        print("== REBUILD ONLY ==")
        # Regenerar SIEMPRE con el corpus traído de la nube: sin bootstrap el
        # monolito carga 0 actas y el deploy publica una web vacía (0 equipos,
        # 0 partidos) encima de la que tenía datos.
        if not args.bootstrap:
            n = bootstrap(store)
            if config.REQUIRE_BOOTSTRAP and n == 0:
                print("[bootstrap] ERROR: 0 ficheros traídos de la nube. "
                      "Abortando rebuild.")
                sys.exit(1)
        ver, url = rebuild_deploy.regenerar_y_desplegar(status, state,
                                                        version=version, force=True)
        print(f"REBUILD OK ver={ver} url={url}")
        return

    if args.rescue:
        print("== RESCUE 2025+ ==")
        dl = engine.load_monolito()
        total = 0
        for fkey in config.SOURCES:
            if fkey in config.RESCUE_SKIP:
                print(f"[{fkey}] excluida del rescue ({config.RESCUE_SKIP})")
                continue
            if fkey not in dl.FUENTES:
                print(f"[{fkey}] no existe en FUENTES, se salta")
                continue
            try:
                n = rescue_source(fkey, status, store, pool, ok_acumulado)
                total += n
            except Exception:
                print(f"[{fkey}] fallo inesperado del rescue.")
                import traceback
                traceback.print_exc()
            store.save()
        engine.publish_status(status, store, version="", running=False)
        print(f"\n== RESCUE TERMINADO: {total} actas repasadas ==")
        return

    if args.once:
        pasada(running=False)
        print("\n== PASADA TERMINADA ==")
        print(f"actas OK nuevas esta pasada: {ok_acumulado[0]}")
        print(f"estado: {config.STATUS_FILE}")
        return

    print(f"[daemon] start | interval={args.interval or config._env_int('FAF_INTERVAL', 900)}s"
          f" | sources={config.SOURCES}")
    try:
        while True:
            pasada(running=True)
            seg = args.interval or config._env_int("FAF_INTERVAL", 900)
            print(f"[daemon] durmiendo {seg}s...")
            time.sleep(seg)
    except KeyboardInterrupt:
        print("\n[daemon] detenido por el usuario.")


if __name__ == "__main__":
    main()