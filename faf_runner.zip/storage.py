# -*- coding: utf-8 -*-
"""Almacenamiento en la nube de las actas crudas y del estado.

Implementación mínima compatible con R2 / S3 (boto3). Si la nube no está
configurada, el runner funciona igual en modo local (solo disco) y avisa.
El almacén guarda:
  fuentes/<key>/txt/Acta_<prefijo><id>.txt
  fuentes/<key>/json/<id>.json
  state.json
  sync_status.json
"""
import os

import config


class ObjectStore:
    """Cache local + nube opcional. Lecturas: local primero (rápido).
    Escrituras: local + upload asíncrono best-effort a la nube."""

    def __init__(self):
        self._s3 = None
        self._bucket = None
        if config.S3_ACCESS_KEY and config.S3_SECRET_KEY:
            try:
                import boto3
                from botocore.config import Config as _BotoConfig
                self._s3 = boto3.client(
                    "s3",
                    endpoint_url=config.S3_ENDPOINT or None,
                    aws_access_key_id=config.S3_ACCESS_KEY,
                    aws_secret_access_key=config.S3_SECRET_KEY,
                    region_name=config.S3_REGION,
                    config=_BotoConfig(retries={"max_attempts": 2}, connect_timeout=15,
                                       read_timeout=60),
                )
                self._bucket = config.S3_BUCKET
            except Exception as e:
                print(f"[storage] No se pudo inicializar la nube (modo local): {e}")
                self._s3 = None

    @property
    def cloud_enabled(self):
        return self._s3 is not None

    # ── ficheros locales de estado (el runner SIEMPRE usa disco local) ─────
    def state_dir(self, fuente_key):
        d = os.path.join(config.FUENTES_DIR, fuente_key)
        os.makedirs(os.path.join(d, "txt"), exist_ok=True)
        os.makedirs(os.path.join(d, "json"), exist_ok=True)
        return d

    def txt_local(self, fuente_key):
        return os.path.join(self.state_dir(fuente_key), "txt")

    def json_local(self, fuente_key):
        return os.path.join(self.state_dir(fuente_key), "json")

    # ── API de nube (best-effort) ──────────────────────────────────────────
    def readable(self, key="state.json"):
        """Comprueba si la nube permite LECTURAS. True si se puede leer el
        objeto, False si B2 responde Forbidden (tope Class B agotado),
        None en caso de error sin relación con permisos."""
        if not self._s3:
            return None
        try:
            self._s3.head_object(Bucket=self._bucket, Key=key)
            return True
        except Exception as e:
            msg = str(e)
            if "Forbidden" in msg or "403" in msg or "AccessDenied" in msg:
                return False
            return None

    def upload(self, local_path, key, verify=None):
        """Sube un objeto; si verify (default FAF_S3_VERIFY) confirma
        persistencia con head_object (B2 tuvo caídas transitorias con uploads
        'exitosos' que no quedaban)."""
        if verify is None:
            verify = config.S3_VERIFY
        if not self._s3 or not os.path.exists(local_path):
            return False
        tam = os.path.getsize(local_path)
        try:
            self._s3.upload_file(local_path, self._bucket, key)
            if verify:
                h = self._s3.head_object(Bucket=self._bucket, Key=key)
                if h.get("ContentLength") != tam:
                    print(f"[storage] upload {key} sin persistir (size {h.get('ContentLength')} != {tam})")
                    return False
            return True
        except Exception as e:
            print(f"[storage] upload {key} falló: {e}")
            return False

    def download(self, key, local_path, quiet=False):
        if not self._s3:
            return False
        try:
            os.makedirs(os.path.dirname(local_path), exist_ok=True)
            self._s3.download_file(self._bucket, key, local_path)
            return True
        except Exception as e:
            if quiet and ("404" in str(e) or "Not Found" in str(e)):
                return False
            print(f"[storage] download {key} falló: {e}")
            return False

    def list(self, prefix):
        if not self._s3:
            return []
        out = []
        try:
            paginator = self._s3.get_paginator("list_objects_v2")
            for page in paginator.paginate(Bucket=self._bucket, Prefix=prefix):
                for o in page.get("Contents", []):
                    out.append(o["Key"])
        except Exception as e:
            print(f"[storage] list {prefix} falló: {e}")
        return out

    # ── Corpus en B2 como tar.gz por fuente (no 130k objetos sueltos) ──────
    # El build y los scan del runner leen el JSON local; en la nube guardamos
    # un único bundle comprimido por fuente para que una ejecución fresca de
    # GitHub Actions baje ~7 ficheros en segundos y no el corpus completo.
    def bundle_key(self, fuente_key):
        return f"fuentes/{fuente_key}/bundle.tar.gz"

    def tar_bundle(self, fuente_key, dest):
        """Crea fuentes/<key>/bundle.tar.gz con el json_dir actual."""
        import tarfile
        d = os.path.join(config.FUENTES_DIR, fuente_key, "json")
        if not os.path.isdir(d):
            return False
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with tarfile.open(dest, "w:gz") as t:
            for fn in sorted(os.listdir(d)):
                t.add(os.path.join(d, fn), arcname=fn)
        return True

    def extract_bundle(self, fuente_key, src):
        """Extrae bundle.tar.gz dentro del json_dir de la fuente."""
        import tarfile
        d = os.path.join(config.FUENTES_DIR, fuente_key, "json")
        os.makedirs(d, exist_ok=True)
        with tarfile.open(src, "r:gz") as t:
            for m in t.getmembers():
                if not m.isfile():
                    continue
                f = t.extractfile(m)
                if f is None:
                    continue
                name = os.path.basename(m.name)
                with open(os.path.join(d, name), "wb") as out:
                    out.write(f.read())
        return True

    def backup_acta(self, fuente_key, aid, txt_path, json_path):
        """Guarda una acta en la nube (TXT + JSON) si la nube está activa."""
        pre = f"fuentes/{fuente_key}/txt/Acta_{aid}.txt"
        pjs = f"fuentes/{fuente_key}/json/{aid}.json"
        self.upload(txt_path, pre)
        if json_path and os.path.exists(json_path):
            self.upload(json_path, pjs)


def load_json(fp, default=None):
    import json
    try:
        with open(fp, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def save_json(fp, data):
    import json, tempfile
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    # tmp ÚNICO por llamada: con hilos paralelos (varias fuentes a la vez,
    # un solo state.json) dos escrituras no deben pisarse el mismo fichero.
    fd, tmp = tempfile.mkstemp(suffix=".json.tmp", dir=os.path.dirname(fp) or ".")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
        os.replace(tmp, fp)
    except Exception:
        try:
            os.remove(tmp)
        except Exception:
            pass
        raise